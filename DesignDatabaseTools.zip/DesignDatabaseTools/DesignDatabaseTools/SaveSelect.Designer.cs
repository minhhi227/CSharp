﻿namespace DesignDatabaseTools
{
    partial class SaveSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ribbonClientPanel1 = new DevComponents.DotNetBar.Ribbon.RibbonClientPanel();
            this.Pdf = new DevComponents.DotNetBar.ButtonX();
            this.Word1 = new DevComponents.DotNetBar.ButtonX();
            this.ribbonClientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonClientPanel1
            // 
            this.ribbonClientPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.ribbonClientPanel1.Controls.Add(this.Pdf);
            this.ribbonClientPanel1.Controls.Add(this.Word1);
            this.ribbonClientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonClientPanel1.Location = new System.Drawing.Point(0, 0);
            this.ribbonClientPanel1.Name = "ribbonClientPanel1";
            this.ribbonClientPanel1.Size = new System.Drawing.Size(389, 183);
            // 
            // 
            // 
            this.ribbonClientPanel1.Style.Class = "RibbonClientPanel";
            this.ribbonClientPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonClientPanel1.StyleMouseDown.Class = "";
            this.ribbonClientPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonClientPanel1.StyleMouseOver.Class = "";
            this.ribbonClientPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonClientPanel1.TabIndex = 0;
            this.ribbonClientPanel1.Text = "ribbonClientPanel1";
            // 
            // Pdf
            // 
            this.Pdf.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Pdf.BackColor = System.Drawing.SystemColors.Window;
            this.Pdf.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Pdf.Image = global::DesignDatabaseTools.Properties.Resources.pdf2;
            this.Pdf.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Pdf.Location = new System.Drawing.Point(217, 27);
            this.Pdf.Name = "Pdf";
            this.Pdf.Size = new System.Drawing.Size(140, 138);
            this.Pdf.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Pdf.TabIndex = 1;
            this.Pdf.Click += new System.EventHandler(this.Pdf_Click);
            // 
            // Word1
            // 
            this.Word1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Word1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Word1.Image = global::DesignDatabaseTools.Properties.Resources.microsoft_office_word;
            this.Word1.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Word1.Location = new System.Drawing.Point(34, 27);
            this.Word1.Name = "Word1";
            this.Word1.Size = new System.Drawing.Size(140, 138);
            this.Word1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Word1.TabIndex = 0;
            this.Word1.Click += new System.EventHandler(this.Word_Click);
            // 
            // SaveSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 183);
            this.Controls.Add(this.ribbonClientPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SaveSelect";
            this.Text = "SaveSelect";
            this.ribbonClientPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Ribbon.RibbonClientPanel ribbonClientPanel1;
        private DevComponents.DotNetBar.ButtonX Pdf;
        private DevComponents.DotNetBar.ButtonX Word1;
    }
}