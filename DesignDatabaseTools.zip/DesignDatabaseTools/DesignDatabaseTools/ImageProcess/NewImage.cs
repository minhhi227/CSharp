﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace DesignDatabaseTools.ImageProcess
{
    class NewImage
    {
        private static int i = 0;  //dem so hinh duoc tao ra
        Bitmap image;
        int width = 504;
        string widthType = "pixels";
        int height = 360;
        string heightType = "pixels";
        int resolution = 72;
        string resolutionType = "pixels/inch";
        Color background = Color.White;

        public Bitmap Image
        {
            get { return image; }
        }

        private void SetBackground()
        {
            BitmapData bmpData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height),
                 ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);

            IntPtr ptr = bmpData.Scan0;
            int bytes = image.Width * image.Height * 3;
            byte[] rgbBytes = new byte[bytes];

            Marshal.Copy(ptr, rgbBytes, 0, bytes);

            for (int i = 0; i < bytes; i += 3)
            {
                rgbBytes[i] = (byte)background.B;
                rgbBytes[i + 1] = (byte)background.G;
                rgbBytes[i + 2] = (byte)background.R;
            }

            Marshal.Copy(rgbBytes, 0, ptr, bytes);

            image.UnlockBits(bmpData);
        }

        private void ConvertHeightWith()
        {
            switch (widthType)
            {
                case "inches":
                    if (resolutionType == "pixels/inch")
                        width = width * resolution;
                    else
                        width = (int)(width * resolution * 2.54);
                    break;

                case "cm":
                    if (resolutionType == "pixles/inch")
                        width = (int)(width * resolution / 2.54);
                    else
                        width = width * resolution;
                    break;
            }

            switch (heightType)
            {
                case "inches":
                    if (resolutionType == "pixels/inch")
                        height = height * resolution;
                    else
                        height = (int)(height * resolution * 2.54);
                    break;

                case "cm":
                    if (resolutionType == "pixles/inch")
                        height = (int)(height * resolution / 2.54);
                    else
                        height = height * resolution;
                    break;
            }

            if (resolutionType == "pixels/cm")
                resolution = (int)(resolution * 2.54);

        }

        public void CreateImage()
        {
            image = new Bitmap(width, height);
            image.SetResolution(resolution, resolution);
            SetBackground();
        }

    }
}
