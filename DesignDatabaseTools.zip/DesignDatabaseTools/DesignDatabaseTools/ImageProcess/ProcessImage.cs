﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using DevComponents.WinForms;
using DevComponents.DotNetBar;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

using DockToolKit;


namespace DesignDatabaseTools.ImageProcess
{
    class ProcessImage
    {

      

        //Create Image
        public void CreateImage(MouseEventArgs e,int flag)
        {
            
        }
      
        //tao hieu ung chon
        public void CreateSelectEntry(PictureBox mainpage, PictureBox entry)
        {
           
           
           
            
        }
        //ham thay doi bieu tuong con tro chuot
        public void ChangeMouseMotion(PictureBox p, PictureBox temp, object sender, MouseEventArgs e)
        {
           
           

        }

        //ham resize 

        public void Resize(Cursor m, MouseEventArgs e, PictureBox temp)
        {

           

        }

        //--------------------------------------------------------------------------------------------------------------------
 

        

    }
}
