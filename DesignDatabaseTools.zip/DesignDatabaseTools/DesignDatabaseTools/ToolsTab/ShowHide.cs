﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using DevComponents.WinForms;
using DevComponents.DotNetBar;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace DesignDatabaseTools.ToolsTab
{
    class ShowHide
    {
        public void DrawGrid(Graphics g, DrawArea area)
        {
            //TODO: ham draw ve grid
           
            Pen p1 = new Pen(Color.Gray, 1);
            p1.DashStyle = DashStyle.DashDot;

            for (int i = 0; i < area.Height; i += 20)
            {
                g.DrawLine(p1, new Point(0, i), new Point(area.Width, i));

            }

            for (int i = 0; i < area.Width; i += 20)
            {
                g.DrawLine(p1, new Point(i, 0), new Point(i, area.Height));
            }
            
        }

    }
}
