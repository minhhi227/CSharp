﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace DesignDatabaseTools.ToolsTab
{
    class Property
    {

        public void ScreenShot(PictureBox MainPage)
        {
           MainPage.Image = this.ScreenShot();
           MainPage.SizeMode = PictureBoxSizeMode.Zoom;

            MainPage.Image.Save(
              "ScreenShotShot.jpg", ImageFormat.Jpeg);
        }

        //chup man hinh 
        public Bitmap ScreenShot()
        {
            Rectangle totalSize = Rectangle.Empty;

            foreach (Screen s in Screen.AllScreens)
                totalSize = Rectangle.Union(totalSize, s.Bounds);

            Bitmap screenShotBMP = new Bitmap(
                totalSize.Width, totalSize.Height,
                PixelFormat.Format32bppArgb);

            Graphics screenShotGraphics = Graphics.FromImage(
                screenShotBMP);

            screenShotGraphics.CopyFromScreen(
                totalSize.Location.X,
                totalSize.Location.Y,
                0, 0, totalSize.Size,
                CopyPixelOperation.SourceCopy);

            return screenShotBMP;
        }


    }
}
