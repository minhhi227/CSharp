﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.MainFuction
{
    //------------------------------------ENTRY-----------------------
    public abstract class Entry
    {
        // type
        public enum EntryType
        {
            Class,
            relationship,
            NumberOfEntry
        } ;

        private Entry.EntryType entrytype;
        public Entry.EntryType TypeEntry
        {
            get { return entrytype; }
            set { entrytype = value; }
        }

    }
    //---------------------------CLASS---------------------------------


   public class SimpleClass : Entry
    {
       //TYPE
        public enum ClassType
        {
            Class,
            AbstractClass,
            AssociationClass,
            NumberOfClass
        } ;
       //ID
        public int ID;
       //NAME
        public string Name;
       //ATTRIBUTES
        public List<Attributes> attribute = new List<Attributes>();
       //METHODS
        public List<Opers> Methods = new List<Opers>();
       //LIST RELATIONSHIP
        public List<Relationship> Relationships = new List<Relationship>();

        public ClassType Type;

        public bool final = false;
    }

   public class Attributes
    {
       //NAME
        public string Name;
        public bool PK = false;
       //TYPE
        public enum AttType
        {
            single,
            composed,
            array,
            nested,
            objecttype,
            derived,
            NumberOfAttributes
        }
       //DATATYPE
        public enum DataType
        {
            number,
            varchar,
            interger,
            date,
            datetime,
            floats,
            chars,
            decimals,
            boolean,
            doubles
            //objecttype
        }
        private Attributes.AttType _type;

        public Attributes.AttType Type
        {
            get { return _type; }
            set { _type = value; }
        }

        private Attributes.DataType _datatype;

        public Attributes.DataType Data_Type
        {
            get { return _datatype; }
            set { _datatype = value; }
        }
        public string objectname;
        public string tablename;
        public int lengtharray;
        public string strigger;
    }


  //----------------------------------RELATIONSHIP----------------------------------------
  public class Relationship : Entry
    {
        public int ID;
      //name
        public string RoleName;
      //multiplicity
        public string mul1;
        public string mul2;
        public string mul3;
        public string mul4;
      //class
        public List<string> ListClass = new List<string>();
       //TYPE
        public enum RelaType
        {
            aggregation,
            composition,
            nary,
            binary,              //simple relationship
            association_class_binary,
            generalization,
            association_class_line,
            recurcy,
            NumberOfRelationship
        }
       
        private Relationship.RelaType type;

        public Relationship.RelaType RelationType
        {
            get { return type; }
            set { type = value; }
        }

    }
  
}
