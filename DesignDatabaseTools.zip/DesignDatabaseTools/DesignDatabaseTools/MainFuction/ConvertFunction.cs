﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

using DesignDatabaseTools.DrawObject;
using DesignDatabaseTools.Methods;

namespace DesignDatabaseTools.MainFuction
{
    class ConvertFunction
    {
        #region MEMBERS
        private const string ClassToEntry = "Step 1: Transform Class Diagram into Class Entry...."+"\n";
        private const string EntryToUDT = "Step 2: Transform Class Entry into User Defined Type...." + "\n";
        private const string UDTToOracle = "Step 3: Transform User Defined Type into Relation Object Text Oracle...." + "\n";

        private DrawArea _area;


        public DrawArea Area
        {
            get { return _area; }
            set { _area = value; }
        }

        List<UDTDefinition> ListUDT=new List<UDTDefinition>();      //list ket qua luu UDT tu class diagram
        SubFunction subfunction = new SubFunction();

        List<DrawObject.DrawObject> tempobj = new List<DrawObject.DrawObject>();

        public const string Mot = "1";
        public const string Sao = "*";
        //public const string Unknown = "1..n";

        private ConvertForm _Owner;

        public ConvertForm Owner
        {
            get { return _Owner; }
            set { _Owner = value; }
        }
        public void Init()
        {
            
        }

        #endregion

        #region CONVERT CLASS DIAGRAM TO ENTRY
        //--------------------------------------------Transform Graphic -> ENTRY---------------------------------

        //------------------------------------Class
        public DrawObject.DrawObject get_ass(DrawAssociationClass obj, GraphicsList Graphics)
        {
            
            for (int i = 0; i < Graphics.Count; i++)
            {
                DrawObject.DrawObject o = (DrawObject.DrawObject) Graphics[i];
                if (o.ObjType == DrawObject.DrawObject.ObjectType.AssociationLine)
                {
                    DrawAssociation ass = (DrawAssociation)o;
                    if (ass.AssClass == obj) return ass;
                }
                else if (o.ObjType == DrawObject.DrawObject.ObjectType.Binary)
                {
                    DrawBinary b = (DrawBinary)o;
                    if (b.AssClass == obj) return b;
                }
            }

            return null;
        }
        public SimpleClass ClassEntry(DrawClass obj, GraphicsList Graphics)
        {
            
            SimpleClass Newclass = new SimpleClass();
            //apply ten va kieu
            Newclass.TypeEntry= Entry.EntryType.Class;
            //DrawClass o1 = (DrawClass)obj;
            //if (obj.final) MessageBox.Show("hieu");
            Newclass.final = obj.final;   //final
            //type class
            switch (obj.ObjType)
            {
                case DrawObject.DrawObject.ObjectType.Class:
                    Newclass.Type = SimpleClass.ClassType.Class;
                    break;
                case DrawObject.DrawObject.ObjectType.AbstractClass:
                    Newclass.Type = SimpleClass.ClassType.AbstractClass;
                    break;
            }
            //name
            Newclass.Name = obj.ClassName;
            //apply thuoc tinh 
            Newclass.attribute = TransformAttributes(obj.ListAttribute,obj.ClassName);
            //apply phuong thuc
            Newclass.Methods = obj.ListOperation;
            
            //apply relationships here
            foreach (ConnectPoint p in obj.ListConnectPoint)
            {
                if (p.association.Count > 0)
                {
                    List<Relationship> tmp = TransformRelationship(p.association, obj, Graphics);
                    foreach(Relationship r in tmp )
                    {
                        Newclass.Relationships.Add(r);
                    }

                }
            }

            if (obj.Recurcys != null)
            {
               
                Relationship re = new Relationship();

                re.ID = obj.Recurcys.ID;
                re.RoleName = obj.Recurcys.RoleName.TheText;
                re.RelationType = Relationship.RelaType.recurcy;
                re.ListClass.Add(obj.ClassName);
                re.ListClass.Add(obj.ClassName);
                re.mul1 = obj.Recurcys.mul1.TheText;
                re.mul2 = obj.Recurcys.mul2.TheText;
                Newclass.Relationships.Add(re);
            }
           
            return Newclass;
        }


        public List<Attributes> TransformAttributes(List<Attri> ListAtt,string classname)
        {
            List<Attributes> result = new List<Attributes>();
            int y = 0;
            foreach (Attri a in ListAtt)
            {
                Attributes thuoctinh = new Attributes();
                thuoctinh.Name = a.Name;
                thuoctinh.PK = a.pk;
                //kind
                switch (a.AttriKind)
                {
                    case Attri.Kind.composite:
                        thuoctinh.Type = Attributes.AttType.objecttype;
                        thuoctinh.objectname = a.composited;
                        break;
                    case Attri.Kind.derived:
                        thuoctinh.strigger = a.striggername;
                        thuoctinh.tablename = classname;
                        thuoctinh.Type = Attributes.AttType.derived;
                        break;
                    case Attri.Kind.multivalued:

                        if (a.multivaluename == "")
                        {
                            thuoctinh.Type = Attributes.AttType.nested;
                        }
                        else
                        {
                            thuoctinh.Type = Attributes.AttType.array;
                            int checknum;
                            if(int.TryParse(a.multivaluename,out checknum))
                            {
                            thuoctinh.lengtharray = Convert.ToInt32(a.multivaluename);
                            }
                        }
                    
                        break;
                    case Attri.Kind.normal:
                        thuoctinh.Type = Attributes.AttType.single;
                        break;
                }

                    switch (a.DataType)
                    {
                        case Attri.Type.interger:
                            thuoctinh.Data_Type = Attributes.DataType.interger;
                            break;
                        case Attri.Type.number:
                            thuoctinh.Data_Type = Attributes.DataType.number;
                            break;
                        case Attri.Type.varchar:
                            thuoctinh.Data_Type = Attributes.DataType.varchar;
                            break;
                        case Attri.Type.boolean:
                            thuoctinh.Data_Type = Attributes.DataType.boolean;
                            break;
                        case Attri.Type.chars:
                            thuoctinh.Data_Type = Attributes.DataType.chars;
                            break;
                        case Attri.Type.datetime:
                            thuoctinh.Data_Type = Attributes.DataType.datetime;
                            break;
                        case Attri.Type.decimals:
                            thuoctinh.Data_Type = Attributes.DataType.decimals;
                            break;
                        case Attri.Type.doubles:
                            thuoctinh.Data_Type = Attributes.DataType.doubles;
                            break;
                        case Attri.Type.floats:
                            thuoctinh.Data_Type = Attributes.DataType.floats;
                            break;
                    
                    }
                

                result.Add(thuoctinh);
                y++;
            }

            return result;
        }

        public Relationship Relationship_Association(DrawAssociation ass)
        {
            Relationship result = new Relationship();
            //ID
            result.ID = ass.ID;
            //rolename
            if (ass.ObjType != DrawObject.DrawObject.ObjectType.AssociationClassLine)
            {
                if (ass.RoleName != null)
                {
                    result.RoleName = ass.RoleName.TheText;
                }
            }
            //type
            switch (ass.ObjType)
            {
                case DrawObject.DrawObject.ObjectType.AssociationLine:
                    result.RelationType = Relationship.RelaType.binary;
                    break;
                case DrawObject.DrawObject.ObjectType.Aggernation:
                    result.RelationType = Relationship.RelaType.aggregation;
                    break;
                case DrawObject.DrawObject.ObjectType.Composition:
                    result.RelationType = Relationship.RelaType.composition;
                    break;
                case DrawObject.DrawObject.ObjectType.Generalization:
                    result.RelationType = Relationship.RelaType.generalization;
                    break;
            }

            //list class, multiplicity

           switch(ass.ObjType)
           {
               case DrawObject.DrawObject.ObjectType.AssociationLine:

            
                    result.mul1 = ass.mul_left.TheText;
                    result.mul2 = ass.mul_right.TheText;

                    result.ListClass.Add(ass.start_class.ClassName);
                    result.ListClass.Add(ass.end_class.ClassName);
             
              
                    break;
               case DrawObject.DrawObject.ObjectType.Aggernation:
               case DrawObject.DrawObject.ObjectType.Composition:

                    result.mul1 = ass.mul_left.TheText;
                    result.mul2 = ass.mul_right.TheText;

                    result.ListClass.Add(ass.start_class.ClassName);
                    result.ListClass.Add(ass.end_class.ClassName);
                    break;
               case DrawObject.DrawObject.ObjectType.Generalization:
                    result.ListClass.Add(ass.start_class.ClassName);
                    result.ListClass.Add(ass.end_class.ClassName);
                    break;
            
           }

            return result;
        }

        public Relationship Relationship_Associationclass(DrawAssociation aa,DrawClass classgoc,GraphicsList Graphics)
        {

            Relationship result = new Relationship();
            result.RelationType = Relationship.RelaType.binary;

            //get right  
       
            DrawClass tempc = new DrawClass();
            tempc.ClassName = classgoc.ClassName + "_temp";
            tempc.ObjType = DrawObject.DrawObject.ObjectType.Class;

            DrawAssociation tempa1 = new DrawAssociation();
            tempa1.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempa1.RoleName = new DrawText();
            if (aa.AssClass.start_class != null)
            {
                tempa1.RoleName.TheText = aa.AssClass.start_class.ClassName;
            }
            else
            {
                tempa1.RoleName.TheText = aa.AssClass.end_class.ClassName;
            }

            tempa1.mul_left = new DrawText();
            tempa1.mul_right = new DrawText();

            tempa1.mul_left.TheText = "1";
            tempa1.start_class = tempc;
            tempa1.mul_right.TheText = "1";

            if (aa.AssClass.start_class != null)
            {
                tempa1.end_class = aa.AssClass.start_class;
            }
            else
            {
                tempa1.end_class = aa.AssClass.end_class;
            }

            DrawAssociation tempa2 = new DrawAssociation();
            tempa2.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempa2.RoleName = new DrawText();
            if (aa.AssClass.start_class != null)
            {
                tempa2.RoleName.TheText = aa.AssClass.start_class.ClassName;
            }
            else
            {
                tempa2.RoleName.TheText = aa.AssClass.end_class.ClassName;
            }

            tempa2.mul_left = new DrawText();
            tempa2.mul_right = new DrawText();

            tempa2.mul_left.TheText = "1";
            tempa2.start_class = tempc;
            tempa2.mul_right.TheText = "1";


            if (aa.start_class.ClassName == classgoc.ClassName)
            {
                result.mul2 = aa.mul_right.TheText;
                tempa2.end_class = aa.end_class;
            }
            else
            {
                result.mul2 = aa.mul_left.TheText;
                tempa2.end_class = aa.start_class;
            }
            
            
           
            ConnectPoint p = new ConnectPoint();
            p.association.Add(tempa1);
            p.association.Add(tempa2);
            tempc.ListConnectPoint.Add(p);

            //multiplicity
            result.mul1 = "1";
       
            //list class
            result.ListClass.Add(classgoc.ClassName);
            result.ListClass.Add(tempc.ClassName);
         
            tempobj.Add(tempc);
            tempobj.Add(tempa1);
            tempobj.Add(tempa2);
          

            return result;
        
        }

        public Relationship Relationship_associationclass_binary(DrawBinary bb, DrawClass classgoc, GraphicsList Graphics)
        {
            Relationship result = new Relationship();

            //get ass 1         
            DrawClass bitemp1 = new DrawClass();
            bitemp1.ClassName = classgoc.ClassName + bb.p3_class.ClassName;
            bitemp1.ObjType = DrawObject.DrawObject.ObjectType.Class;

            DrawAssociation tempas1 = new DrawAssociation();
            tempas1.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempas1.RoleName = new DrawText();
            tempas1.RoleName.TheText = classgoc.ClassName;

            tempas1.mul_left = new DrawText();
            tempas1.mul_right = new DrawText();

            tempas1.mul_left.TheText = "1";
            tempas1.start_class = bitemp1;
            tempas1.mul_right.TheText = "1";
            if (bb.AssClass.start_class != null)
            {
                tempas1.end_class = bb.AssClass.start_class;
            }
            else
            {
                tempas1.end_class = bb.AssClass.end_class;
            }

            DrawAssociation tempas2 = new DrawAssociation();
            tempas2.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempas2.RoleName = new DrawText();
            tempas2.RoleName.TheText = bb.RoleName;

            tempas2.mul_left = new DrawText();
            tempas2.mul_right = new DrawText();
            tempas2.mul_left.TheText = "1";
            tempas2.start_class = bitemp1;
            tempas2.mul_right.TheText = bb.list_mul[0].TheText;
          

            DrawAssociation tempas3 = new DrawAssociation();
            tempas3.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempas3.RoleName = new DrawText();
            tempas3.RoleName.TheText = bb.RoleName;

            tempas3.mul_left = new DrawText();
            tempas3.mul_right = new DrawText();
            tempas3.mul_left.TheText = "1";
            tempas3.start_class = bitemp1;
            tempas3.mul_right.TheText = bb.list_mul[0].TheText;

            if (bb.p1_class.ClassName == classgoc.ClassName)
            {
                tempas2.end_class = bb.p2_class;
                tempas3.end_class = bb.p3_class;
            }
            else if (bb.p2_class.ClassName == classgoc.ClassName)
            {
                tempas2.end_class = bb.p1_class;
                tempas3.end_class = bb.p3_class;
            }
            else
            {
                tempas2.end_class = bb.p1_class;
                tempas3.end_class = bb.p2_class;
            }

            ConnectPoint pp1 = new ConnectPoint();
            pp1.association.Add(tempas1);
            pp1.association.Add(tempas2);
            pp1.association.Add(tempas3);
            bitemp1.ListConnectPoint.Add(pp1);

            tempobj.Add(bitemp1);
            tempobj.Add(tempas1);
            tempobj.Add(tempas2);
            tempobj.Add(tempas3);

            //multiplicity
            result.mul1 = "1";
            result.mul2 = "1";
            //list class
            result.ListClass.Add(classgoc.ClassName);
            result.ListClass.Add(bitemp1.ClassName);

            return result;
        }
        public Relationship Relationship_exAssociation(DrawExtraAssociation ex)
        {
            Relationship result = new Relationship();
            result.ID = ex.ID;
            //rolename
            if (ex.ObjType != DrawObject.DrawObject.ObjectType.AssociationClassLine)
            {
                result.RoleName = ex.RoleName.TheText;
            }
            //type
            result.RelationType = Relationship.RelaType.binary;
           
                result.mul1 = ex.mul_left.TheText;
                result.mul2 = ex.mul_right.TheText;

                result.ListClass.Add(ex.start_class.ClassName);
                result.ListClass.Add(ex.end_class.ClassName);
        
            return result;

        }
        public Relationship Relationship_binary(DrawBinary binary, DrawClass classgoc, GraphicsList Graphics)
        {
            Relationship result = new Relationship();
            result.ID = binary.ID;
            result.RoleName = binary.RoleName;
            result.RelationType = Relationship.RelaType.binary;

            DrawClass tempc = new DrawClass();
            tempc.ClassName = binary.RoleName + classgoc.ClassName;
            tempc.ObjType = DrawObject.DrawObject.ObjectType.Class;

            DrawAssociation tempa1 = new DrawAssociation();
            tempa1.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempa1.RoleName = new DrawText();
            tempa1.RoleName.TheText = binary.RoleName;

            tempa1.mul_left = new DrawText();
            tempa1.mul_right = new DrawText();

            tempa1.mul_left.TheText = "1";
            tempa1.start_class = tempc;

            DrawAssociation tempa2 = new DrawAssociation();
            tempa2.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempa2.RoleName = new DrawText();
            tempa2.RoleName.TheText = binary.RoleName;

            tempa2.mul_left = new DrawText();
            tempa2.mul_right = new DrawText();
            tempa2.mul_left.TheText = "1";
            tempa2.start_class = tempc;

            if(binary.p1_class.ClassName == classgoc.ClassName)
            {
                tempa1.mul_right.TheText = binary.list_mul[1].TheText;
                tempa1.end_class = binary.p2_class;

                tempa2.mul_right.TheText  = binary.list_mul[2].TheText;
                tempa2.end_class = binary.p3_class;
            }
            else if (binary.p2_class.ClassName == classgoc.ClassName)
            {
                tempa1.mul_right.TheText  = binary.list_mul[0].TheText;
                tempa1.end_class = binary.p1_class;
                tempa2.mul_right.TheText  = binary.list_mul[2].TheText;
                tempa2.end_class = binary.p3_class;
            }
            else if (binary.p3_class.ClassName == classgoc.ClassName)
            {
                tempa1.mul_right.TheText  = binary.list_mul[0].TheText;
                tempa1.end_class = binary.p1_class;
                tempa2.mul_right.TheText  = binary.list_mul[1].TheText;
                tempa2.end_class = binary.p2_class;
            }

            ConnectPoint p = new ConnectPoint();
            p.association.Add(tempa1);
            p.association.Add(tempa2);
            tempc.ListConnectPoint.Add(p);

            tempobj.Add(tempc);
            tempobj.Add(tempa1);
            tempobj.Add(tempa2);

                //multiplicity
                result.mul1 = "1";
                result.mul2 = "1";
                //list class
                result.ListClass.Add(classgoc.ClassName);
                result.ListClass.Add(tempc.ClassName);
                

            return result;
        }

        public Relationship Relationship_nary(DrawNary nary, DrawClass classgoc, GraphicsList Graphics)
        {
            Relationship result = new Relationship();
            result.ID = nary.ID;
            result.RoleName = nary.RoleName;
            result.RelationType = Relationship.RelaType.binary;

            DrawClass tempc = new DrawClass();
            tempc.ClassName = nary.RoleName + classgoc.ClassName;
            tempc.ObjType = DrawObject.DrawObject.ObjectType.Class;

            DrawAssociation tempa1 = new DrawAssociation();
            tempa1.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempa1.RoleName = new DrawText();
            tempa1.RoleName.TheText = nary.RoleName;

            tempa1.mul_left = new DrawText();
            tempa1.mul_right = new DrawText();

            tempa1.mul_left.TheText = "1";
            tempa1.start_class = tempc;

            DrawAssociation tempa2 = new DrawAssociation();
            tempa2.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempa2.RoleName = new DrawText();
            tempa2.RoleName.TheText = nary.RoleName;

            tempa2.mul_left = new DrawText();
            tempa2.mul_right = new DrawText();
            tempa2.mul_left.TheText = "1";
            tempa2.start_class = tempc;

            DrawAssociation tempa3 = new DrawAssociation();
            tempa3.ObjType = DrawObject.DrawObject.ObjectType.AssociationLine;
            tempa3.RoleName = new DrawText();
            tempa3.RoleName.TheText = nary.RoleName;

            tempa3.mul_left = new DrawText();
            tempa3.mul_right = new DrawText();
            tempa3.mul_left.TheText = "1";
            tempa3.start_class = tempc;

            if (nary.p1_class.ClassName == classgoc.ClassName)
            {
                tempa1.mul_right.TheText = nary.list_mul[1].TheText;
                tempa1.end_class = nary.p2_class;

                tempa2.mul_right.TheText = nary.list_mul[2].TheText;
                tempa2.end_class = nary.p3_class;

                tempa3.mul_right.TheText = nary.list_mul[3].TheText;
                tempa3.end_class = nary.p4_class;
            }
            else if (nary.p2_class.ClassName == classgoc.ClassName)
            {
                tempa1.mul_right.TheText = nary.list_mul[0].TheText;
                tempa1.end_class = nary.p1_class;
                tempa2.mul_right.TheText = nary.list_mul[2].TheText;
                tempa2.end_class = nary.p3_class;
                tempa3.mul_right.TheText = nary.list_mul[3].TheText;
                tempa3.end_class = nary.p4_class;
            }
            else if (nary.p3_class.ClassName == classgoc.ClassName)
            {
                tempa1.mul_right.TheText = nary.list_mul[0].TheText;
                tempa1.end_class = nary.p1_class;
                tempa2.mul_right.TheText = nary.list_mul[1].TheText;
                tempa2.end_class = nary.p2_class;

                tempa3.mul_right.TheText = nary.list_mul[3].TheText;
                tempa3.end_class = nary.p4_class;
            }

            else if (nary.p4_class.ClassName == classgoc.ClassName)
            {
                tempa1.mul_right.TheText = nary.list_mul[1].TheText;
                tempa1.end_class = nary.p2_class;
                tempa2.mul_right.TheText = nary.list_mul[2].TheText;
                tempa2.end_class = nary.p3_class;

                tempa3.mul_right.TheText = nary.list_mul[0].TheText;
                tempa3.end_class = nary.p1_class;
            }


            ConnectPoint p = new ConnectPoint();
            p.association.Add(tempa1);
            p.association.Add(tempa2);
            tempc.ListConnectPoint.Add(p);

            tempobj.Add(tempc);
            tempobj.Add(tempa1);
            tempobj.Add(tempa2);
            tempobj.Add(tempa3);

            //multiplicity
            result.mul1 = "1";
            result.mul2 = "1";
            //list class
            result.ListClass.Add(classgoc.ClassName);
            result.ListClass.Add(tempc.ClassName);



            return result;
        }


        public List<Relationship> TransformRelationship(List<DrawObject.DrawObject> ListRelationship, DrawClass cla, GraphicsList Graphics)
        {
           List<Relationship> result = new List<Relationship>();

           foreach(DrawObject.DrawObject obj in ListRelationship)
            {
                if (!obj.Hide)
                {
                    switch (obj.ObjType)
                    {
                        case DrawObject.DrawObject.ObjectType.AssociationLine:
                        case DrawObject.DrawObject.ObjectType.Aggernation:
                        case DrawObject.DrawObject.ObjectType.Composition:
                        case DrawObject.DrawObject.ObjectType.Generalization:
                            DrawAssociation o3 = (DrawAssociation)obj;
                            if (o3.AssClass == null)
                            {
                                Relationship new_relationship = Relationship_Association(o3);
                                new_relationship.TypeEntry = Entry.EntryType.relationship;
                                result.Add(new_relationship);
                            }
                            else
                            {
                              Relationship new_relationship1 =   Relationship_Associationclass(o3, cla, Graphics);
                              new_relationship1.TypeEntry = Entry.EntryType.relationship;
                              result.Add(new_relationship1);
                            }
                            break;
                        case DrawObject.DrawObject.ObjectType.Binary:
                            DrawBinary o4 = (DrawBinary)obj;
                            if (o4.AssClass == null)
                            {
                                Relationship new_binary = Relationship_binary(o4, cla, Graphics);
                                new_binary.TypeEntry = Entry.EntryType.relationship;
                                result.Add(new_binary);
                            }
                            else
                            {
                                Relationship new_binaryass = Relationship_associationclass_binary(o4, cla, Graphics);
                                new_binaryass.TypeEntry = Entry.EntryType.relationship;
                                result.Add(new_binaryass);
                            }
                            break;
                        case DrawObject.DrawObject.ObjectType.Nary:
                            DrawNary o5 = (DrawNary)obj;
                            Relationship new_nary = Relationship_nary(o5, cla, Graphics);
                            new_nary.TypeEntry = Entry.EntryType.relationship;
                            result.Add(new_nary);
                            break;
                        case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                            DrawExtraAssociation o6 = (DrawExtraAssociation)obj;
                            Relationship new_ex = Relationship_exAssociation(o6);
                            new_ex.TypeEntry = Entry.EntryType.relationship;
                            result.Add(new_ex);
                            break;
                        case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                            //DrawAssociationClass assc = (DrawAssociationClass)obj;
                            
                            
                            break;
                        
                    }
                }
            }
           
            return result;
        }

        public List<Entry> TransformClassDiagram(GraphicsList Graphics)
        {
            //TODO: Transform GraphicDiagram -> EtryList
            List<Entry> result = new List<Entry>();
            bool flag = false;

 Owner.BeginInvoke((ThreadStart)delegate()
    {
            for (int i = 0; i < Graphics.Count; i++)
            {
               
                    DrawObject.DrawObject obj = (DrawObject.DrawObject)Graphics[i];
                    switch (obj.ObjType)
                    {
                        case DrawObject.DrawObject.ObjectType.Class:
                        case DrawObject.DrawObject.ObjectType.AbstractClass:
                            DrawClass o1 = (DrawClass)obj;
                            
                            SimpleClass c = ClassEntry(o1, Graphics);
                                result.Add(c);
                            
                            break;
                    
             
                    }

                   

                
            }


            foreach( DrawObject.DrawObject obj in tempobj)
            {
               
                    switch (obj.ObjType)
                    {
                        case DrawObject.DrawObject.ObjectType.Class:
                        case DrawObject.DrawObject.ObjectType.AbstractClass:
                            DrawClass o1 = (DrawClass)obj;

                            SimpleClass c = ClassEntry(o1, Graphics);
                            result.Add(c);

                            break;

                    }

            }

           
            Owner.Text = "Proccessing...";
            Owner.Processing.Text = "";
            Owner.progressBar1.PerformStep();
            if (!flag) { Owner.ProgressRichBox.Text = ClassToEntry; flag = true; }
          });

          Thread.Sleep(100);

            return result;
        }


        #endregion

       
        #region CONVERT ENTRY TO UDT

        //-----------------------------------------TransformFunction Entry->UDT---------------------------------------

        public UDTDefinition TransformClass(SimpleClass Class,List<Entry> ListEntry)
        {
            //TODO: transform Class -> UDT
            UDTDefinition result=new UDTDefinition();
            //ID
            result.ID = Class.ID;
            // NAME
            result.Identity = Class.Name;
            //TYPE
            result.Type = UDTType._UDTType.UDT;
            if (Class.Type == SimpleClass.ClassType.AbstractClass) result.instant = false;
            else result.instant = true;

            result.final = Class.final;   //final

            //ATTRIBUTES
            result.ListBIT = AttributesUDT(Class.attribute);
            //RELATIONSHIP
            result.ListAssType = RelationshipUDT(Class,ListEntry);

            foreach (Relationship r in Class.Relationships)
            {
                if (r.RelationType == Relationship.RelaType.generalization)
                {
                    if (r.ListClass[0] == Class.Name)
                    {
                        result.under = true;
                        result.UnderClass = r.ListClass[1];
                    }
                }
            }
            //METHODS
            result.methods = Class.Methods;
            //QUILIFIERS
           
            return result;
            
        }

        public UDTType TransformAggregation(SimpleClass ClassGoc,Relationship Agg)
        {
            
            if (Agg.ListClass[0] == ClassGoc.Name)
            {
                if (Agg.mul2 == Mot || Agg.mul2=="0..1")
                {
                    objecttype newf = new objecttype(); //new ReferenceType(Agg.ListClass[1]);
                    newf.alter = true;
                    newf.altername = Agg.ListClass[0];
                    newf.Type = UDTType._UDTType.objtype;
                    newf.objname = Agg.ListClass[1];
                    return newf;
                }
                else if (Agg.mul2 == Sao || Agg.mul2.Substring(Agg.mul2.Length - 1, 1).Equals("n") || subfunction.check_sao(Agg.mul2))
                {
                    MultiSetType newm = new MultiSetType();
                    newm.Type = UDTType._UDTType.multiset;
                    newm.alter = true;
                    newm.REFtype.Add(new ReferenceType(Agg.ListClass[1], Agg.ListClass[0], Agg.ListClass[0]));
                    return newm;
                }
                else
                {
                    ArrayType newa = new ArrayType();
                    newa.Type = UDTType._UDTType.array;
                    newa.alter = true;
                    newa.REFtype.Add(new ReferenceType(Agg.ListClass[1], Agg.ListClass[0], Agg.ListClass[0]));
                    newa.MaxLength = Agg.mul2;
                    return newa;
                }
            }
            else if (Agg.ListClass[1] == ClassGoc.Name)
            {
                if (Agg.mul1 == Mot || Agg.mul1 == "0..1")
                {
                    ReferenceType newf = new ReferenceType(Agg.ListClass[0]);
                   
                    newf.RefName = Agg.RoleName;
                    newf.Type = UDTType._UDTType._ref;
                    return newf;
                }
                else if (Agg.mul1 == Sao || Agg.mul1.Substring(Agg.mul1.Length - 1, 1).Equals("n") || subfunction.check_sao(Agg.mul1))
                {
                    MultiSetType newm = new MultiSetType();
                    newm.Type = UDTType._UDTType.multiset;
                    newm.REFtype.Add(new ReferenceType(Agg.ListClass[0], Agg.ListClass[1]));
                    return newm;
                }
                else
                {
                    ArrayType newa = new ArrayType();
                    newa.Type = UDTType._UDTType.array;
                    newa.REFtype.Add(new ReferenceType(Agg.ListClass[0], Agg.ListClass[1]));
                    newa.MaxLength = Agg.mul1;
                    return newa;
                }
            }

            return null;
        }

        public SimpleClass FindEntry(string name, List<Entry> Entries)
        {
            foreach (Entry en in Entries)
            {
                switch(en.TypeEntry)
                {
                    case Entry.EntryType.Class:
                        SimpleClass s = (SimpleClass)en;
                        if (s.Name == name) return s;
                        break;
                }
                
            }
            return null;
        }

        public UDTType TransformComposition(SimpleClass ClassGoc, Relationship Comp,List<Entry> ListEntry)
        {
            //TODO: Transform Composition -> UDT

            if (Comp.ListClass[0] == ClassGoc.Name)
            {
                if (Comp.mul2 == Mot || Comp.mul2 == "0..1")
                {
                    objecttype newf = new objecttype(); //new ReferenceType(Agg.ListClass[1]);
                    newf.Type = UDTType._UDTType.objtype;
                    newf.alter = true;
                    newf.altername = Comp.ListClass[0];
                    newf.objname = Comp.ListClass[1];
                    return newf;
                }
                else if (Comp.mul2 == Sao || Comp.mul2.Substring(Comp.mul2.Length - 1, 1).Equals("n") || subfunction.check_sao(Comp.mul2))
                {
                    MultiSetType newm = new MultiSetType();
                    newm.Type = UDTType._UDTType.multiset;
                    newm.alter = true;
                    newm.ListData.Add(new ReferenceType(Comp.ListClass[1], Comp.ListClass[0], Comp.ListClass[0]));
                    return newm;
                }
                else
                {
                    ArrayType newa = new ArrayType();
                    newa.Type = UDTType._UDTType.array;
                    newa.alter = true;
                    newa.ListData.Add(new ReferenceType(Comp.ListClass[1], Comp.ListClass[0], Comp.ListClass[0]));
                    newa.MaxLength = Comp.mul2;
                    return newa;
                }
            }
            else if (Comp.ListClass[1] == ClassGoc.Name)
            {
                ReferenceType newf = new ReferenceType(Comp.ListClass[0]);
                newf.RefName = Comp.RoleName;
                newf.Type = UDTType._UDTType._ref;
                return newf;
            }

            return null;
        }

        public UDTType TransformBinary(SimpleClass ClassGoc, Relationship binary)
        {
            
            if (binary.ListClass[1] == ClassGoc.Name)
            {
                if (binary.mul1 == Mot || binary.mul1 == "0..1")
                {
                    
                    ReferenceType newf = new ReferenceType(binary.ListClass[0]);
                    newf.RefName = binary.RoleName;
                    newf.Type = UDTType._UDTType._ref;
                    return newf;
                }
                else if (binary.mul1 == Sao 
                          || binary.mul1.Substring(binary.mul1.Length-1,1).Equals("n") 
                          || subfunction.check_sao(binary.mul1)
                        )
                {
                 
                    MultiSetType newm = new MultiSetType();
                    newm.Type = UDTType._UDTType.multiset;
                    newm.REFtype.Add(new ReferenceType(binary.ListClass[0], binary.RoleName));
                    return newm;

                }
                else 
                {
                    //kieu array
                    ArrayType newa = new ArrayType();
                    newa.Type = UDTType._UDTType.array;
                    newa.REFtype.Add(new ReferenceType(binary.ListClass[0], binary.RoleName));
                    newa.MaxLength = binary.mul1;
                    return newa;
                }
            }
            else if (binary.ListClass[0] == ClassGoc.Name)
            {
                if (binary.mul2 == Mot || binary.mul2 == "0..1")
                {
                    //kieu references
                    ReferenceType newf = new ReferenceType(binary.ListClass[1]);
                    newf.alter = true;
                    newf.altername = binary.ListClass[0];
                    newf.Type = UDTType._UDTType._ref;
                    newf.RefName = binary.RoleName;
                    return newf;
                }
                else if (binary.mul2 == Sao || binary.mul2.Substring(binary.mul2.Length - 1, 1).Equals("n")
                             || subfunction.check_sao(binary.mul2)
                         )
                {
                    //kieu multiset
                    MultiSetType newm = new MultiSetType();
                    newm.alter = true;
                    newm.Type = UDTType._UDTType.multiset;
                    newm.REFtype.Add(new ReferenceType(binary.ListClass[1], binary.RoleName, binary.ListClass[0]));
                    return newm;

                }
                else
                {
                    //kieu array
                    ArrayType newa = new ArrayType();
                    newa.Type = UDTType._UDTType.array;
                    newa.alter = true;
                    newa.REFtype.Add(new ReferenceType(binary.ListClass[1], binary.RoleName, binary.ListClass[0]));
                    newa.MaxLength = binary.mul2;
                    return newa;
                }
            }

            return null;
          
        }


        public UDTType TransformGeneralization(SimpleClass ClassGoc, Relationship g, List<Entry> ListEntry)
        {
            //TODO: Transform Generalization -> UDT
          
            if (g.ListClass[1] == ClassGoc.Name)
            {
            }
            else if (g.ListClass[0] == ClassGoc.Name)
            {
            }

            return null;

        }

        public UDTType TransformRecurcy(SimpleClass ClassGoc, Relationship recurcy)
        {

            if (recurcy.mul1 == Mot && recurcy.mul2 == Mot || recurcy.mul1 == "0..1" && recurcy.mul2 == "0..1")
                {
                   //kieu references
                    ReferenceType newf = new ReferenceType(recurcy.ListClass[0]);
                    newf.alter = true;
                    newf.altername = recurcy.ListClass[0];
                    newf.RefName = recurcy.RoleName;
                    newf.Type = UDTType._UDTType._ref;
                    return newf;
                }
                else if (recurcy.mul1 == Sao
                          || recurcy.mul1.Substring(recurcy.mul1.Length - 1, 1).Equals("n")
                          || subfunction.check_sao(recurcy.mul1)
                          || recurcy.mul2 == Sao
                          || recurcy.mul2.Substring(recurcy.mul2.Length - 1, 1).Equals("n")
                          || subfunction.check_sao(recurcy.mul2)
                        )
                {
                 
                    MultiSetType newm = new MultiSetType();
                    newm.alter = true;
                    //newm.altername = recurcy.ListClass[0];
                    newm.Type = UDTType._UDTType.multiset;
                    newm.REFtype.Add(new ReferenceType(recurcy.ListClass[0], recurcy.RoleName, recurcy.ListClass[0]));
                   // newm.altername = newm.ClassName;
                    return newm;

                }
                else 
                {
                    //kieu array
                    ArrayType newa = new ArrayType();
                    newa.Type = UDTType._UDTType.array;
                    newa.alter = true;
                    newa.REFtype.Add(new ReferenceType(recurcy.ListClass[0], recurcy.RoleName, recurcy.ListClass[0]));
                    newa.MaxLength = recurcy.mul1;
                    return newa;
                }
                    
               
        }

        public List<UDTType> AttributesUDT(List<Attributes> ListAtt)
        {
            List<UDTType> BIT = new List<UDTType>();

            foreach (Attributes att in ListAtt)
            {
                builtInDataType temp = new builtInDataType();
                temp.TypeName = att.Name;

                if (att.PK) temp.pk = true;   // set primary key

                temp.Type = UDTType._UDTType.BIT;
                //apply kieu
                switch (att.Data_Type)
                {
                    case Attributes.DataType.interger:
                        temp.BuiltInType = builtInDataType.BuiltType.INTEGER;
                        break;
                    case Attributes.DataType.number:
                        temp.BuiltInType = builtInDataType.BuiltType.NUMBER;
                        break;
                    case Attributes.DataType.varchar:
                        temp.BuiltInType = builtInDataType.BuiltType.VARCHAR2;
                        break;
                    case Attributes.DataType.chars:
                        temp.BuiltInType = builtInDataType.BuiltType.CHAR;
                        break;
                    case Attributes.DataType.date:
                        temp.BuiltInType = builtInDataType.BuiltType.DATE;
                        break;
                    case Attributes.DataType.datetime:
                        temp.BuiltInType = builtInDataType.BuiltType.TIMESTAMP;
                        break;
                    case Attributes.DataType.decimals:
                        temp.BuiltInType = builtInDataType.BuiltType.DECIMAL;
                        break;
                    case Attributes.DataType.doubles:
                        temp.BuiltInType = builtInDataType.BuiltType.DOUBLE;
                        break;
                    case Attributes.DataType.floats:
                        temp.BuiltInType = builtInDataType.BuiltType.FLOAT;
                        break;
                }

                switch (att.Type)
                {
                  
                    case Attributes.AttType.array:
                        temp.arr = true;
                        temp.lengtharray = att.lengtharray;
                        break;
                    case Attributes.AttType.nested:
                        temp.nes = true;
                        break;
                    case Attributes.AttType.objecttype:
                        temp.obj = true;
                        temp.objectname = att.objectname;
                        break;
                    case Attributes.AttType.derived:
                        temp.strigger = att.strigger;
                        temp.tablename = att.tablename;
                        temp.trig = true;
                        break;
           
                }

                BIT.Add(temp);
            }

            return BIT;
        }

        public List<UDTType> RelationshipUDT(SimpleClass Class,List<Entry> ListEntry)
        {
            List<UDTType> UDTTYPE = new List<UDTType>();

            foreach (Relationship rela in Class.Relationships)
            {
                switch (rela.RelationType)
                {
                    case Relationship.RelaType.binary:
                        UDTType newb = TransformBinary(Class, rela);
                        if(newb!=null) UDTTYPE.Add(newb);
                        break;
                    case Relationship.RelaType.aggregation:
                        UDTType newa = TransformAggregation(Class, rela);
                        if(newa!=null) UDTTYPE.Add(newa);
                        break;
                    case Relationship.RelaType.composition:
                        UDTType newc = TransformComposition(Class, rela,ListEntry);
                        if(newc!=null) UDTTYPE.Add(newc);
                        break;
                    case Relationship.RelaType.generalization:
                        UDTType newg = TransformGeneralization(Class, rela,ListEntry);
                        if(newg!=null) UDTTYPE.Add(newg);
                        break;
                    case Relationship.RelaType.recurcy:
                        UDTType newre = TransformRecurcy(Class, rela);
                        if (newre != null) { UDTTYPE.Add(newre); }
                        break;
                    case Relationship.RelaType.nary:
                        break;
                }
            }
            return UDTTYPE;
        }

        public List<UDTDefinition> TransformClassToUDT(List<Entry> DiagramEntry)
        {
            //TODO: Transform EntryList -> UDT
            List<UDTDefinition> result = new List<UDTDefinition>();
            bool flag = false;
                for (int i = 0; i < DiagramEntry.Count; i++)
                {

                  Owner.BeginInvoke((ThreadStart)delegate()
                  {
                    Entry entry = (Entry)DiagramEntry[i];
                    switch (entry.TypeEntry)
                    {
                        case Entry.EntryType.Class:
                            SimpleClass NewClass = (SimpleClass)entry;
                           
                            switch (NewClass.Type)
                            {
                                case SimpleClass.ClassType.Class:
                                case SimpleClass.ClassType.AbstractClass:
                                    UDTDefinition temp = TransformClass(NewClass,DiagramEntry);
                                    result.Add(temp);
                                    break;
                            }
                        
                            break;
                       
                    }

                    Owner.Text = /*Owner.progressBar1.Value * (100 / (Owner.Area.Graphics.Count * 3)) + " % " +*/ "Proccessing...";
                    Owner.Processing.Text = /*Owner.progressBar1.Value * (100 / (Owner.Area.Graphics.Count * 3)) + " % " +*/ "";
                    Owner.progressBar1.PerformStep();
                    if (!flag) { Owner.ProgressRichBox.Text += EntryToUDT; flag = true; }
                   });

                    Thread.Sleep(100);

                }
                
             
            return result;
        }

        #endregion
      
        #region CONVERT UDT TO TABLES
        //-----------------------------------------Transform UDT-> TABLE------------------------------------------

        public List<TableType> MappingToOracleLayer(List<UDTDefinition> Udts)
        {
            //TODO: Transform UDT-> OracleLayer

           List<TableType> result = new List<TableType>();
           bool flag = false;
           foreach (UDTDefinition udt in Udts)
           {
               Owner.BeginInvoke((ThreadStart)delegate()
                {
                     TableType temp_table = new TableType();
                     temp_table.Identity = udt.Identity ;
                     temp_table.UDT = udt;
                     //apply constants
                     result.Add(temp_table);

                    Owner.Text = /*Owner.progressBar1.Value * (100 / (Owner.Area.Graphics.Count * 3)) + " % " +*/ "Proccessing...";
                    Owner.Processing.Text = /*Owner.progressBar1.Value * (100 / (Owner.Area.Graphics.Count * 3)) + " % " +*/ "";
                    Owner.progressBar1.PerformStep();
                    if (!flag) { Owner.ProgressRichBox.Text += UDTToOracle; flag = true; }
                 });

                Thread.Sleep(100);
                
           }
            return result;
        }

        #endregion
     

    }


}
