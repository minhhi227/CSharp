﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.MainFuction
{
    //--------------TYPE------------
  public class UDTType
    {
        public bool alter = false;
        public string altername;
        private string _Typename;
        private UDTType._UDTType type;
        
        public enum _UDTType
        {
            BIT,    
            UDT,
            rowtype,
            array,
            multiset,
            _ref,
            objtype

        }
       
        public string TypeName             //NAME
        {
            get { return _Typename; }
            set { _Typename = value; }
        }

        public UDTType._UDTType Type       //TYPE
        {
            get { return type; }
            set { type = value; }
        }

    
        
    }

  public class builtInDataType : UDTType
  {
      public enum BuiltType
      {
          NUMBER,
          VARCHAR2,
          INTEGER,
          DATE,
          TIMESTAMP,
          FLOAT,
          CHAR,
          DECIMAL,
         // BOOLEAN,
          DOUBLE
      }

      private builtInDataType.BuiltType builtintype;
      public builtInDataType.BuiltType BuiltInType
      {
          get { return builtintype; }
          set { builtintype = value; }
      }

      public string objectname;

      public string strigger;
      public string tablename;

      public int lengtharray;
      public bool arr = false;
      public bool nes = false;
      public bool obj = false;
      public bool trig = false;

      public bool pk = false;

      public string get_type ()
      {
          return BuiltInType.ToString();
      }
  }
   

   public class UDTDefinition : UDTType
    {
        //enum type
           

        public int ID;
        public string Identity;       // ten cua UDT identity
        public List<UDTType> ListBIT=new List<UDTType>();        // list cac kieu BIT thuoc tinh
        public List<UDTType> ListAssType = new List<UDTType>();   //list cac kieu lien ket UDT,RT,AT,MT,REF
        public List<Opers> methods=new List<Opers>();           // phuong thuc MM

        public bool final=false;
        public bool instant=true;
        public bool under=false;
       
        public string UnderClass;
    }

    //rowtype

  public class RowType : UDTType
    {
        List<fieldType> rowtype=new List<fieldType>();
    }

  public class fieldType
    {
        private string Filed;
        private UDTType DataTypes;
    }

    //array type

  public class ReferenceType : UDTType
    {
      public bool direct = false;
      public string ClassName;
      public string RefName;
      public ReferenceType(string name)
      {
          ClassName = name;
      }
      public ReferenceType(string name,string name2)
      {
          ClassName = name;
          RefName = name2;
      }

      public ReferenceType(string name, string name2,string name3)
      {
          ClassName = name;
          RefName = name2;
          altername = name3;
      }

      public ReferenceType()
      {
      }
    }

   public class ArrayType : UDTType
    {
        public List<UDTType> ListData=new List<UDTType>();
        public List<ReferenceType> REFtype=new List<ReferenceType>();
        //public List<UDTType> StructuredType = new List<UDTType>();
        public string MaxLength;

    }

  public class MultiSetType : UDTType
    {
        public List<UDTType> ListData=new List<UDTType>();
        public List<ReferenceType> REFtype=new List<ReferenceType>();
        //public List<UDTType> StructuredType=new List<UDTType>();
    }

  public class objecttype : UDTType
  {
      public string objname;
      //public List<UDTType> ListData = new List<UDTType>();
      //public List<ReferenceType> REFtype = new List<ReferenceType>();
      //public List<UDTType> StructuredType=new List<UDTType>();
  }

}
