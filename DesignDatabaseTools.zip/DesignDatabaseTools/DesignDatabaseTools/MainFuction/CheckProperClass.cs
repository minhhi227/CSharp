﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using DesignDatabaseTools.DrawObject;
using DesignDatabaseTools.Methods;

namespace DesignDatabaseTools.MainFuction
{
    class CheckProperClass
    {
        private DrawArea _area;
        SubFunction sub = new SubFunction();
        public DrawArea Area
        {
            get { return _area; }
            set { _area = value; }
        }

        #region CONST STRING

        public const string MissingClassName = " {M01} -> Class is missing class name or abstract class name  ";
        public const string MissingAttributes = " doesn't have any attributes ";
        public const string MissingOperations = " doesn't have any operations ";
        public const string MissingAssociation = " doesn't have any associations  ";
        public const string MissingClass = " doesn't have any class that link to it";
        public const string MissingMultiplicity = " is missing Multiplicity";
        public const string MissingRole = " {M05} -> Association is missing role name association";
        public const string MissingRoleBinary = " {M05} -> Binary is missing role name association";
        public const string MissingRoleNary = " {M05} -> N-ary is missing role name association";
        public const string StrangeLetter = " {S01} -> strange letter";
        public const string InvalidMultiplicity = " has invalid multiplicity";
        public const string AssclassMissingAss = " {M02} -> Association Line is missing Association";
        public const string AssclassMissingClass = " {M03} -> Association Line is missing class";
        public const string LinkTo2class = " {L01} -> Association Line is linking to 2 class";
        public const string LinkTo2Ass = " {L02} -> Association Line is linking to 2 association";
        public const string InvalidAsso = " {I02} -> Association Line is invalid";
        public const string DuplicatedAtt = " has duplicated attributes at ";
        public const string DuplicatedOp = " has duplicated operations at ";
        public const string DuplicatedClass = " is ambiguous ";
        public const string WrongObjectType = " has invalid object type";
        #endregion

        #region attributes

        Regex MultiplicityPattern1 = new Regex("[a-zA-Z]");
        Regex Blank = new Regex("[ \f\n\r\t\v]");
        Regex objAlphaNumericPattern = new Regex("[^a-zA-Z0-9]");

        public List<ErrorWarning> list_error = new List<ErrorWarning>();

        #endregion
        
        public void CheckClass(DrawClass Class, GraphicsList Graphics)
        {
            List<string> Error = new List<string>();
            bool name = false;
            if (Class.ClassName == "" && !sub.CheckAssociationClass(Class) )
            {
                list_error.Add(new ErrorWarning(MissingClassName, ErrorWarning.type.error));
                name = true;
            }
            if (Class.ListAttribute.Count == 0)
            {
                if (!name)
                {
                    list_error.Add(new ErrorWarning(Class.ClassName + MissingAttributes, ErrorWarning.type.warning));
                }
                else
                {
                    list_error.Add(new ErrorWarning(" Class " + MissingAttributes, ErrorWarning.type.warning));
                }
            }
            else
            {
                for (int i = 0; i < Class.ListAttribute.Count;i++ )
                {
                    Attri at = Class.ListAttribute[i];
                    
                    for (int y = i + 1; y < Class.ListAttribute.Count; y++) 
                    {
                        Attri at2 = Class.ListAttribute[y];
                        if (at.Name == at2.Name && at.DataType == at2.DataType)
                        {
                            
                            list_error.Add(new ErrorWarning(" {D01} -> " +Class.ClassName + DuplicatedAtt + at.Name, ErrorWarning.type.error));
                            break;
                        }
                    }
                }
            }
            if (Class.ListOperation.Count==0)
            {
                if (!name)
                {
                    list_error.Add(new ErrorWarning(Class.ClassName + MissingOperations, ErrorWarning.type.warning));
                }
                else
                {
                    list_error.Add(new ErrorWarning(" Class " + MissingOperations, ErrorWarning.type.warning));
                }
            }
            else
            {
                for (int i = 0; i < Class.ListOperation.Count; i++)
                {
                    Opers at = Class.ListOperation[i];
                    for (int y = i + 1; y < Class.ListOperation.Count; y++)
                    {
                        Opers at2 = Class.ListOperation[y];
                        if (at.Name == at2.Name && at.OpTypes == at2.OpTypes)
                        {
                            list_error.Add(new ErrorWarning(Class.ClassName + DuplicatedOp + at.Name, ErrorWarning.type.warning));
                        }
                    }
                }
            }
            /*
            bool flag = false;
            foreach (ConnectPoint p in Class.ListConnectPoint)
            {
                if (p.association.Count > 0) {flag = true; break;}
            }
            if (flag == false)
            {
                if (!name)
                {
                    list_error.Add(new ErrorWarning(Class.ClassName + MissingAssociation, ErrorWarning.type.error));
                }
                else
                {
                    list_error.Add(new ErrorWarning(" Class " + MissingAssociation, ErrorWarning.type.error));
                }
            }
            */
            //check object type

            foreach (Attri a in Class.ListAttribute)
            {
                if (a.Name.ToList().IndexOf(':') != -1)
                {
                    string temp = a.Name.Substring(sub.get_index_str(a.Name) + 1, a.Name.Length - sub.get_index_str(a.Name) - 1);
                    bool flag2 = false;
                    //check object type

                    for (int i = 0; i < Graphics.Count; i++)
                    {
                        DrawObject.DrawObject obj = (DrawObject.DrawObject)Graphics[i];
                        if (obj.ObjType == DrawObject.DrawObject.ObjectType.AbstractClass || obj.ObjType == DrawObject.DrawObject.ObjectType.Class)
                        {
                            DrawClass c = (DrawClass) obj;
                            if (temp.TrimStart().TrimEnd() == c.ClassName.TrimStart().TrimEnd()) {flag2 = true; break;}
                        }
                    }

                    if (!flag2) list_error.Add(new ErrorWarning(Class.ClassName + WrongObjectType, ErrorWarning.type.error));
                   
                
                }

                if (a.Name.ToList().IndexOf('[') != -1 || a.Name.ToList().IndexOf(']') != -1)
                {
                    if ((a.Name.ToList().IndexOf('[') != -1 && a.Name.ToList().IndexOf(']') == -1)
                        || (a.Name.ToList().IndexOf('[') == -1 && a.Name.ToList().IndexOf(']') != -1)
                        )
                    {
                        list_error.Add(new ErrorWarning(Class.ClassName + WrongObjectType, ErrorWarning.type.error));
                    }
                    else
                    {
                        //check multivalued
                        int n;
                        if ((a.Name.ToList().IndexOf(']') != -1 && a.Name.ToList().IndexOf(']') != a.Name.Length - 1)
                            || (!int.TryParse(a.Name.Substring(a.Name.ToList().IndexOf('[') + 1, a.Name.ToList().IndexOf(']') - a.Name.ToList().IndexOf('[') - 1), out n)
                                && a.Name.Substring(a.Name.ToList().IndexOf('[') + 1, a.Name.ToList().IndexOf(']') - a.Name.ToList().IndexOf('[') - 1) != "*"
                                && a.Name.Substring(a.Name.ToList().IndexOf('[') + 1, a.Name.ToList().IndexOf(']') - a.Name.ToList().IndexOf('[') - 1) != ""
                                )
                           )
                        {
                            list_error.Add(new ErrorWarning(Class.ClassName + WrongObjectType, ErrorWarning.type.error));
                        }
                    }
                }

            }
           
        }

        public bool check_multiplicity(string str)
        {
            int n;
            if (str.ToList().IndexOf('*') != -1)
            {
                if (str.ToList().IndexOf('.') != -1)
                {
                    if (str.ToList()[str.Length - 1] != '*' || !int.TryParse(str.Substring(0, str.ToList().IndexOf('.')), out n))
                    {
                        return true;
                    }
                }
                else
                {
                    if (str.TrimEnd().TrimStart().Length > 1) return true;
                }
                
            }
            else 
            {
                if (str.ToList().IndexOf('.') != -1)
                {
                    if (!int.TryParse(str.Substring(0, str.ToList().IndexOf('.')), out n) /*|| !int.TryParse(str.Substring(str.ToList().IndexOf('.') + 1, str.Length - str.ToList().IndexOf('.')), out n)*/)
                    {
                        return true;
                    }
                }
                else
                {
                    //if (!int.TryParse(str.TrimEnd().TrimStart().Substring(0, str.TrimEnd().TrimStart().ToList().IndexOf('.')), out n)) return true;
                }
            }

            return false;
        }

        public void CheckAssociation(DrawAssociation Association)
        {
           
            //check name
           /*
            if (Association.RoleName == null || Association.RoleName.TheText==" ")
            {
                if (Association.AssClass == null)
                {
                    list_error.Add(new ErrorWarning(MissingRole, ErrorWarning.type.error));
                }
               
            }
         */
            //check multiplicity
            if (Association.ObjType != DrawObject.DrawObject.ObjectType.Generalization
                && Association.ObjType != DrawObject.DrawObject.ObjectType.Aggernation
                && Association.ObjType != DrawObject.DrawObject.ObjectType.Composition
                && Association.ObjType != DrawObject.DrawObject.ObjectType.AssociationClassLine)
            {
                if (Association.mul_left == null //|| Association.mul_left.TheText == " "
                    || Association.mul_right == null /*|| Association.mul_right.TheText == " "*/)
                {

                    if (Association.RoleName!=null)
                    {
                       
                        list_error.Add(new ErrorWarning(Association.RoleName.TheText + MissingMultiplicity, ErrorWarning.type.error));
                    }
                    else
                    {
                        //MessageBox.Show("hieu1");
                        list_error.Add(new ErrorWarning(" Association " + MissingMultiplicity, ErrorWarning.type.error));
                    }
                }
                else
                {
                    if (MultiplicityPattern1.IsMatch(Association.mul_left.TheText)
                        || MultiplicityPattern1.IsMatch(Association.mul_right.TheText))
                    {
                        if (Association.RoleName != null)
                        {
                            list_error.Add(new ErrorWarning(" {I01} -> "+Association.RoleName.TheText + InvalidMultiplicity, ErrorWarning.type.error));
                        }
                        else
                        {
                            list_error.Add(new ErrorWarning(" {I01} -> Association " + InvalidMultiplicity, ErrorWarning.type.error));
                        }
                    }
                }

            }
            //check linked class
            if (Association.start_class == null || Association.end_class == null)
            {
                if (Association.RoleName != null)
                {
                    list_error.Add(new ErrorWarning(" {M02} -> "+Association.RoleName.TheText + MissingClass, ErrorWarning.type.error));
                }
                else
                {
                    list_error.Add(new ErrorWarning(" {M02} -> Association " + MissingClass, ErrorWarning.type.error));
                }
            }
            
            //check multiplicity

            if (Association.mul_left != null && Association.mul_right != null)
            {
                if (check_multiplicity(Association.mul_left.TheText) || check_multiplicity(Association.mul_right.TheText))
                {
                    list_error.Add(new ErrorWarning(" {I01} -> Association " + InvalidMultiplicity, ErrorWarning.type.error));
                }
            }
            
        }

        public void CheckExAssociation(DrawExtraAssociation Association)
        {
            bool name = false;
            //check name
            if (Association.RoleName == null || Blank.IsMatch(Association.RoleName.TheText))
            {
                list_error.Add(new ErrorWarning(MissingRole, ErrorWarning.type.error));
                name = true;
            }
            //check multiplicity
            if (Association.ObjType != DrawObject.DrawObject.ObjectType.Generalization
                && Association.ObjType != DrawObject.DrawObject.ObjectType.Aggernation
                && Association.ObjType != DrawObject.DrawObject.ObjectType.Composition
                && Association.ObjType != DrawObject.DrawObject.ObjectType.AssociationClassLine)
            {
                if (Association.mul_left == null || Association.mul_left.TheText == " "
                    || Association.mul_right == null || Association.mul_right.TheText == " ")
                {
                    if (!name)
                    {
                        list_error.Add(new ErrorWarning(" {M04} -> "+Association.RoleName.TheText + MissingMultiplicity, ErrorWarning.type.error));
                    }
                    else
                    {
                        list_error.Add(new ErrorWarning(" {M04} -> Association " + MissingMultiplicity, ErrorWarning.type.error));
                    }
                }
                else
                {
                    if (MultiplicityPattern1.IsMatch(Association.mul_left.TheText)
                        || MultiplicityPattern1.IsMatch(Association.mul_right.TheText))
                    {
                        if (!name)
                        {
                            list_error.Add(new ErrorWarning(" {M04} -> " + Association.RoleName.TheText + InvalidMultiplicity, ErrorWarning.type.error));
                        }
                        else
                        {
                            list_error.Add(new ErrorWarning(" {M04} ->Association " + InvalidMultiplicity, ErrorWarning.type.error));
                        }
                    }
                }

            }
            //check linked class
            if (Association.start_class == null || Association.end_class == null)
            {
                if (!name)
                {
                    list_error.Add(new ErrorWarning(" {M02} -> "+Association.RoleName.TheText + MissingClass, ErrorWarning.type.error));
                }
                else
                {
                    list_error.Add(new ErrorWarning(" {M02} -> Association " + MissingClass, ErrorWarning.type.error));
                }
            }

        }
       
        public void CheckBinary(DrawBinary binary)
        {

            bool name = false;
            /*
            if (binary.RoleName == "" || Blank.IsMatch(binary.RoleName))
            {
                list_error.Add(new ErrorWarning(MissingRoleBinary, ErrorWarning.type.error));
                name = true;
            }
           */
            for (int i = 0; i < binary.list_mul.Length; i++)
            {
                if (binary.list_mul[i] == null || binary.list_mul[i].TheText == " ") 
                {
                    if (!name)
                    {
                        list_error.Add(new ErrorWarning(binary.RoleName + MissingMultiplicity, ErrorWarning.type.error));
                    }
                    else
                    {
                        list_error.Add(new ErrorWarning(" Binary " + MissingMultiplicity, ErrorWarning.type.error));
                    }
                    break;
                }
                else
                {
                    if (MultiplicityPattern1.IsMatch(binary.list_mul[i].TheText))
                    {
                        if (!name)
                        {
                            list_error.Add(new ErrorWarning(binary.RoleName + InvalidMultiplicity, ErrorWarning.type.error));
                        }
                        else
                        {
                            list_error.Add(new ErrorWarning(" 3 N-ary " + InvalidMultiplicity, ErrorWarning.type.error));
                        }
                        break;
                    }
                }
            }

            if (binary.p1_class == null || binary.p2_class == null || binary.p3_class == null)
            {
                if (!name)
                {
                    list_error.Add(new ErrorWarning(binary.RoleName + MissingClass, ErrorWarning.type.error));
                }
                else
                {
                    list_error.Add(new ErrorWarning(" 3 N-ary " + MissingClass, ErrorWarning.type.error));
                }
            }
           
        }


        public void CheckNary(DrawNary Nary)
        {
            bool name = false;
            if (Nary.RoleName == "" || Blank.IsMatch(Nary.RoleName))
            {
                list_error.Add(new ErrorWarning(MissingRoleNary, ErrorWarning.type.error));
                name = true;
            }
            
            for (int i = 0; i < Nary.list_mul.Length; i++)
            {
                if (Nary.list_mul[i] == null || Nary.list_mul[i].TheText == " ") 
                {
                    if (!name)
                    {
                        list_error.Add(new ErrorWarning(Nary.RoleName + MissingMultiplicity, ErrorWarning.type.error));
                    }
                    else
                    {
                        list_error.Add(new ErrorWarning(" 4 N-ary " + MissingMultiplicity, ErrorWarning.type.error));
                    }
                    break;
                }
                else
                {
                    if (MultiplicityPattern1.IsMatch(Nary.list_mul[i].TheText))
                    {
                        if (!name)
                        {
                            list_error.Add(new ErrorWarning(Nary.RoleName + InvalidMultiplicity, ErrorWarning.type.error));
                        }
                        else
                        {
                            list_error.Add(new ErrorWarning(" 4 N-ary " + InvalidMultiplicity, ErrorWarning.type.error));
                        }
                        break;
                    }
                }
            }

            if (Nary.p1_class == null || Nary.p2_class == null || Nary.p3_class == null || Nary.p4_class == null)
            {
                if (!name)
                {
                    list_error.Add(new ErrorWarning(Nary.RoleName + MissingClass, ErrorWarning.type.error));
                }
                else
                {
                    list_error.Add(new ErrorWarning(" N-ary " + MissingClass, ErrorWarning.type.error));
                }
            }
        
        }

        public void CheckStrangeSymbol(DrawText t)
        {
            
             if (t.TheText != "<<PK>>" && t.TheText != "<<Dynamic>>" && !objAlphaNumericPattern.IsMatch(t.TheText))
             {
                 list_error.Add(new ErrorWarning(StrangeLetter, ErrorWarning.type.error));
            }
           
        }

        public void CheckAssociationClassLine(DrawAssociationClass ass,GraphicsList graphics)
        {
            if (ass.start_class != null)
            {
                if (ass.end_class != null)
                {
                    list_error.Add(new ErrorWarning(LinkTo2class, ErrorWarning.type.error));
                }
                else
                {
                    DrawObject.DrawObject temp = graphics.GetObjectWithID(ass.end_flag);
                    if (temp == null)
                    {
                        list_error.Add(new ErrorWarning(AssclassMissingAss, ErrorWarning.type.error));
                    }
                    else if (temp.ObjType != DrawObject.DrawObject.ObjectType.AssociationLine
                            && temp.ObjType != DrawObject.DrawObject.ObjectType.Binary
                            && temp.ObjType != DrawObject.DrawObject.ObjectType.Nary)
                            
                        {
                            list_error.Add(new ErrorWarning(AssclassMissingAss, ErrorWarning.type.error));
                        }
                    

                }
            }
            else if (ass.end_class != null)
            {
                if (ass.start_class != null)
                {
                    list_error.Add(new ErrorWarning(LinkTo2class, ErrorWarning.type.error));
                }
                else
                {
                    DrawObject.DrawObject temp = graphics.GetObjectWithID(ass.start_flag);
                    if (temp == null)
                    {
                        list_error.Add(new ErrorWarning(AssclassMissingAss, ErrorWarning.type.error));
                    }
                    else
                    {
                      
                        if (temp.ObjType != DrawObject.DrawObject.ObjectType.AssociationLine
                            && temp.ObjType!= DrawObject.DrawObject.ObjectType.Binary
                            && temp.ObjType!= DrawObject.DrawObject.ObjectType.Nary )
                        {
                            list_error.Add(new ErrorWarning(AssclassMissingAss, ErrorWarning.type.error));
                        }
                    }

                }
            }
            else
            {
                list_error.Add(new ErrorWarning(InvalidAsso, ErrorWarning.type.error));
            }
        }

        

        //--------------------------------------CheckFunction------------------------------------
        public void CheckClassDiagram(GraphicsList Graphics)
        {
           
            if (Graphics != null)
            {
                for (int i = 0; i < Graphics.Count; i++)
                {
                    DrawObject.DrawObject obj = (DrawObject.DrawObject)Graphics[i];
                    switch (obj.ObjType)
                    {
                        case DrawObject.DrawObject.ObjectType.Class:
                        case DrawObject.DrawObject.ObjectType.AbstractClass:
                            DrawClass c = (DrawClass)obj;
                            CheckClass(c, Graphics);
                            //check duplicated class name
                            for (int y = i + 1; y < Graphics.Count; y++)
                            {
                                DrawObject.DrawObject obj2 = (DrawObject.DrawObject)Graphics[y];
                                switch (obj2.ObjType)
                                {
                                    case DrawObject.DrawObject.ObjectType.Class:
                                    case DrawObject.DrawObject.ObjectType.AbstractClass :
                                        DrawClass c2 = (DrawClass)obj2;
                                        if (c.ClassName == c2.ClassName)
                                        {
                                            list_error.Add(new ErrorWarning(c.ClassName + DuplicatedClass, ErrorWarning.type.error));
                                            break;
                                        }
                                        break;
                                }
                            }
                            break;
                        case DrawObject.DrawObject.ObjectType.AssociationLine:
                        case DrawObject.DrawObject.ObjectType.Composition:
                        case DrawObject.DrawObject.ObjectType.Aggernation:
                        case DrawObject.DrawObject.ObjectType.Generalization:
                     
                            DrawAssociation a = (DrawAssociation)obj;
                            CheckAssociation(a);
                            break;
                        case DrawObject.DrawObject.ObjectType.Binary:
                            DrawBinary b = (DrawBinary)obj;
                            CheckBinary(b);
                            break;
                        case DrawObject.DrawObject.ObjectType.Nary:
                            DrawNary n = (DrawNary)obj;
                            CheckNary(n);
                            break;
                        case DrawObject.DrawObject.ObjectType.text:
                            DrawText t = (DrawText)obj;
                           // CheckStrangeSymbol(t);
                            break;
                        case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                            DrawAssociationClass asso = (DrawAssociationClass)obj;
                            CheckAssociationClassLine(asso, Graphics);
                            break;
                        case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                            DrawExtraAssociation ex = (DrawExtraAssociation)obj;
                            CheckExAssociation(ex);
                            break;
                    }
                }
            }
        
        }
    }

    public class ErrorWarning
    {
        public string name;
        public enum type
        {
            error,
            warning
        }
        public type Type;
        public ErrorWarning(string str, type ty)
        {
            this.name = str;
            this.Type = ty;
        }
        public ErrorWarning()
        {
        }
    }
    


}
