﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignDatabaseTools.MainFuction
{
    public enum SC
    {
        Primary,
        unique,
        foreinkey,
        not_null

    }

    class OraclePlayerDefinition
    {
    }

   public class TableType
    {
        public string Identity;
        public UDTDefinition UDT;
        public SC Constraint;
    }
}
