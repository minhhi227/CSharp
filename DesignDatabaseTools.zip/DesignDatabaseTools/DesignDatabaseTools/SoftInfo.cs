﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DesignDatabaseTools
{
    public partial class SoftInfo : Form
    {
        public SoftInfo()
        {
            InitializeComponent();
        }

        private void SoftInfoLoad(object sender, EventArgs e)
        {
           this.Information.Text = "  Design Database Tools enables developers, DBAs, \n " +
                                   " and designers to create, maintain and document quality \n "+
                                   " database designs and structures across various database\n " +
                                   " platforms.Using the tool, you can make your database \n " +
                                   " development process much easier. ";
        }

        private void Information_Click(object sender, EventArgs e)
        {

        }
    }
}
