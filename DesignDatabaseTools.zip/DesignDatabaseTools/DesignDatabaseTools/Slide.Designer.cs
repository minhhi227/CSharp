﻿namespace DesignDatabaseTools
{
    partial class Slide
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.panelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.Next = new DevComponents.DotNetBar.ButtonX();
            this.Slides = new DevComponents.DotNetBar.ButtonX();
            this.Pre = new DevComponents.DotNetBar.ButtonX();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.panelEx1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox
            // 
            this.pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox.Location = new System.Drawing.Point(0, 0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(882, 335);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox.TabIndex = 3;
            this.pictureBox.TabStop = false;
            // 
            // timer
            // 
            this.timer.Interval = 1500;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // panelEx1
            // 
            this.panelEx1.AutoScroll = true;
            this.panelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelEx1.Controls.Add(this.Next);
            this.panelEx1.Controls.Add(this.Slides);
            this.panelEx1.Controls.Add(this.Pre);
            this.panelEx1.Controls.Add(this.pictureBox);
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEx1.Location = new System.Drawing.Point(0, 0);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(882, 335);
            this.panelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelEx1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx1.Style.GradientAngle = 90;
            this.panelEx1.TabIndex = 1;
            this.panelEx1.Text = "panelEx1";
            // 
            // Next
            // 
            this.Next.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Next.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Next.Location = new System.Drawing.Point(224, 12);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(97, 23);
            this.Next.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Next.TabIndex = 5;
            this.Next.Text = "Next";
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // Slides
            // 
            this.Slides.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Slides.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Slides.Location = new System.Drawing.Point(104, 12);
            this.Slides.Name = "Slides";
            this.Slides.Size = new System.Drawing.Size(98, 23);
            this.Slides.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Slides.TabIndex = 4;
            this.Slides.Text = "START";
            this.Slides.Click += new System.EventHandler(this.Slides_Click);
            // 
            // Pre
            // 
            this.Pre.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Pre.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Pre.Location = new System.Drawing.Point(12, 12);
            this.Pre.Name = "Pre";
            this.Pre.Size = new System.Drawing.Size(75, 23);
            this.Pre.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Pre.TabIndex = 3;
            this.Pre.Text = "Previous";
            this.Pre.Click += new System.EventHandler(this.Pre_Click);
            // 
            // Slide
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(882, 335);
            this.Controls.Add(this.panelEx1);
            this.Name = "Slide";
            this.Text = "Slide";
            this.Load += new System.EventHandler(this.Slide_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.panelEx1.ResumeLayout(false);
            this.panelEx1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.PictureBox pictureBox;
        private DevComponents.DotNetBar.PanelEx panelEx1;
        private DevComponents.DotNetBar.ButtonX Next;
        private DevComponents.DotNetBar.ButtonX Slides;
        private DevComponents.DotNetBar.ButtonX Pre;
    }
}