﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;

namespace DesignDatabaseTools.DrawObject
{
    class DrawAgg : DrawAssociation
    {
        

        #region Constructor

        public override DrawObject Clone() 
        {
            DrawAgg drawLine = new DrawAgg();
            drawLine.startPoint = startPoint;
            drawLine.endPoint = endPoint;

            FillDrawObjectFields(drawLine);
            return drawLine;
        }


        public DrawAgg() : base()
		{
            
		}

		

        public DrawAgg(int x1, int y1, int x2, int y2, Color lineColor, int lineWidth,DrawArea a)
         
		{
            base.DrawOthersAssociation(x1, y1, x2, y2, lineColor, lineWidth, a, 1);
		}

        #endregion

        public override void Draw(Graphics g)
        {
            base.Draw(g, 2);
        }
    }
}
