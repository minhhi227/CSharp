﻿
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Diagnostics;

namespace DesignDatabaseTools.DrawObject
{
	
	public class DrawTriangle : DrawObject
    {
        #region Attributes

        public Rectangle rectangle;
		
        private const string entryRectangle = "Rect";
        private const string entryLeft = "left";
        private const string entryRight = "right";
        private const string entryTop = "top";
        private const string entryBottom = "bottom";

        private DrawArea area;
        
        #endregion

        #region Get/Set Function

        public bool left = false;
        public bool right = false;
        public bool top = false;
        public bool bottom = false;

		public Rectangle Rectangle
		{
			get { return rectangle; }
			set { rectangle = value; }
		}

        public DrawArea Area
        {
            get { return area; }
            set { area = value; }
        }
        #endregion

        #region Constructor

        public DrawTriangle()
		{
			SetRectangle(0, 0, 1,1);
			Initialize();
		}


		
		public override DrawObject Clone()
		{
			DrawTriangle drawText = new DrawTriangle();

			drawText.rectangle = rectangle;

			FillDrawObjectFields(drawText);
			return drawText;
		}


		public DrawTriangle(int x, int y,Color filledColor,DrawArea _area)
		{
            SetRectangle(0, 0, 20, 20);
            Color = filledColor;
            rectangle.Location = new Point(x, y);
            this.FillColor = Color.Black;
            area = _area;

			Initialize();
		}

        #endregion


        public override void Draw(Graphics g)
		{
           
			Pen pen = new Pen(Color);
            Brush b = new SolidBrush(FillColor);
			GraphicsPath gp = new GraphicsPath();
            Point p1 = new Point(0, 0);
            Point p2=new Point(0,0);
            Point p3 =new Point(0,0);

            if (left)
            {
                p1 = Rectangle.Location;
                p2 = new Point(Rectangle.X, Rectangle.Y + Rectangle.Height);
                p3 = new Point(Rectangle.X + Rectangle.Width / 2, Rectangle.Y + Rectangle.Height / 2);
            }
            else if(right)
            {
                p1 = new Point(Rectangle.X + Rectangle.Width, Rectangle.Y);
                p2 = new Point(Rectangle.X + Rectangle.Width, Rectangle.Y + Rectangle.Height);
                p3 = new Point(Rectangle.X + Rectangle.Width / 2, Rectangle.Y + Rectangle.Height / 2);
            }
            else if (top)
            {
                p1 = Rectangle.Location;
                p2 = new Point(Rectangle.X + Rectangle.Width, Rectangle.Y);
                p3 = new Point(Rectangle.X + Rectangle.Width / 2, Rectangle.Y + Rectangle.Height / 2);
            }
            else if (bottom)
            {
                p1 = new Point(Rectangle.X + Rectangle.Width, Rectangle.Y + Rectangle.Height);
                p2 = new Point(Rectangle.X, Rectangle.Y + Rectangle.Height);
                p3 = new Point(Rectangle.X + Rectangle.Width / 2, Rectangle.Y + Rectangle.Height / 2);
            }

            Point[] list_point = { p1, p2, p3 };
            gp.AddPolygon(list_point);

            //MessageBox.Show(FillColor.ToString());
			g.DrawPath(pen, gp);         //add vao graphic
            g.FillPath(b, gp);

            gp.Dispose();
			
			pen.Dispose();
            b.Dispose();
		}

        #region Select effect

        public override int HandleCount
        {
            get { return 8; }
        }


        public override Point GetHandle(int handleNumber)
        {

            int x, y, xCenter, yCenter;

            xCenter = rectangle.X + rectangle.Width / 2;
            yCenter = rectangle.Y + rectangle.Height / 2;
            x = rectangle.X;
            y = rectangle.Y;

            switch (handleNumber)
            {
                case 1:
                    x = rectangle.X;
                    y = rectangle.Y;
                    break;
                case 2:
                    x = xCenter;
                    y = rectangle.Y;
                    break;
                case 3:
                    x = rectangle.Right;
                    y = rectangle.Y;
                    break;
                case 4:
                    x = rectangle.Right;
                    y = yCenter;
                    break;
                case 5:
                    x = rectangle.Right;
                    y = rectangle.Bottom;
                    break;
                case 6:
                    x = xCenter;
                    y = rectangle.Bottom;
                    break;
                case 7:
                    x = rectangle.X;
                    y = rectangle.Bottom;
                    break;
                case 8:
                    x = rectangle.X;
                    y = yCenter;
                    break;
            }

            return new Point(x, y);
        }


        public override int HitTest(Point point)
        {
            if (Selected)
            {
                for (int i = 1; i <= HandleCount; i++)
                {
                    if (GetHandleRectangle(i).Contains(point))
                        return i;
                }
            }

            if (PointInObject(point))
                return 0;

            return -1;
        }


        protected override bool PointInObject(Point point)
        {
            return rectangle.Contains(point);
        }


        public override Cursor GetHandleCursor(int handleNumber)
        {
            switch (handleNumber)
            {
                case 1:
                    return Cursors.SizeNWSE;
                case 2:
                    return Cursors.SizeNS;
                case 3:
                    return Cursors.SizeNESW;
                case 4:
                    return Cursors.SizeWE;
                case 5:
                    return Cursors.SizeNWSE;
                case 6:
                    return Cursors.SizeNS;
                case 7:
                    return Cursors.SizeNESW;
                case 8:
                    return Cursors.SizeWE;
                default:
                    return Cursors.Default;
            }
        }

        public override void MoveHandleTo(Point point, int handleNumber)
        {
            int left = Rectangle.Left;
            int top = Rectangle.Top;
            int right = Rectangle.Right;
            int bottom = Rectangle.Bottom;

            switch (handleNumber)
            {
                case 1:
                    left = point.X;
                    top = point.Y;
                    break;
                case 2:
                    top = point.Y;
                    break;
                case 3:
                    right = point.X;
                    top = point.Y;
                    break;
                case 4:
                    right = point.X;
                    break;
                case 5:
                    right = point.X;
                    bottom = point.Y;
                    break;
                case 6:
                    bottom = point.Y;
                    break;
                case 7:
                    left = point.X;
                    bottom = point.Y;
                    break;
                case 8:
                    left = point.X;
                    break;
            }
            Dirty = true;

                SetRectangle(left, top, right - left, bottom - top);
            

        }


        public override bool IntersectsWith(Rectangle rectangle)
        {
            return Rectangle.IntersectsWith(rectangle);
        }


        public override void Move(int deltaX, int deltaY)
        {
            rectangle.X += deltaX;
            rectangle.Y += deltaY;
            Dirty = true;

        }

        public override void Dump()
        {
            base.Dump();

            Trace.WriteLine("rectangle.X = " + rectangle.X.ToString(CultureInfo.InvariantCulture));
            Trace.WriteLine("rectangle.Y = " + rectangle.Y.ToString(CultureInfo.InvariantCulture));
            Trace.WriteLine("rectangle.Width = " + rectangle.Width.ToString(CultureInfo.InvariantCulture));
            Trace.WriteLine("rectangle.Height = " + rectangle.Height.ToString(CultureInfo.InvariantCulture));
        }

        public override void Normalize()
        {
            rectangle = DrawRectangle.GetNormalizedRectangle(rectangle);
        }

        #endregion

        #region Stream
        public override void SaveToStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryRectangle, orderNumber, objectIndex),
				rectangle);
            info.AddValue(
                  String.Format(CultureInfo.InvariantCulture,
                                "{0}{1}-{2}",
                                entryLeft, orderNumber, objectIndex),
                  left);
            info.AddValue(
                  String.Format(CultureInfo.InvariantCulture,
                                "{0}{1}-{2}",
                                entryRight, orderNumber, objectIndex),
                  right);
            info.AddValue(
                  String.Format(CultureInfo.InvariantCulture,
                                "{0}{1}-{2}",
                                entryTop, orderNumber, objectIndex),
                  top);
            info.AddValue(
                  String.Format(CultureInfo.InvariantCulture,
                                "{0}{1}-{2}",
                                entryBottom, orderNumber, objectIndex),
                  bottom);
           
			base.SaveToStream(info, orderNumber, objectIndex);
		}

		
		public override void LoadFromStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			rectangle = (Rectangle)info.GetValue(
									String.Format(CultureInfo.InvariantCulture,
												  "{0}{1}-{2}",
												  entryRectangle, orderNumber, objectIndex),typeof(Rectangle));
            left = info.GetBoolean(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryLeft, orderNumber, objectIndex));
            right = info.GetBoolean(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryRight, orderNumber, objectIndex));
            top = info.GetBoolean(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryTop, orderNumber, objectIndex));
            bottom = info.GetBoolean(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryBottom, orderNumber, objectIndex));
			
			base.LoadFromStream(info, orderNumber, objectIndex);
        }

        #endregion

        #region Helper Functions
        protected void SetRectangle(int x, int y, int width, int height)
        {
            rectangle.X = x;
            rectangle.Y = y;
            rectangle.Width = width;
            rectangle.Height = height;
        }

        public static Rectangle GetNormalizedRectangle(int x1, int y1, int x2, int y2)
		{
		if ( x2 < x1 )
		{
		    int tmp = x2;
		    x2 = x1;
		    x1 = tmp;
		}

		if ( y2 < y1 )
		{
		    int tmp = y2;
		    y2 = y1;
		    y1 = tmp;
		}

		return new Rectangle(x1, y1, x2 - x1, y2 - y1);
		}

		public static Rectangle GetNormalizedRectangle(Point p1, Point p2)
		{
		return GetNormalizedRectangle(p1.X, p1.Y, p2.X, p2.Y);
		}

		public static Rectangle GetNormalizedRectangle(Rectangle r)
		{
		return GetNormalizedRectangle(r.X, r.Y, r.X + r.Width, r.Y + r.Height);
		}

		#endregion
	}
}
