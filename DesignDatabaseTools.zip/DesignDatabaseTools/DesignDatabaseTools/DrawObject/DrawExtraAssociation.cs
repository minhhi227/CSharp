﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Reflection;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;

using DesignDatabaseTools.Methods;
using DesignDatabaseTools.Tools;


namespace DesignDatabaseTools.DrawObject
{
    class DrawExtraAssociation : DrawObject
    {
        #region Attributes

        public Point startPoint;
        public Point center1;
        public Point center2;
		public Point endPoint;

        public bool ConnectBool = false;

		private const string entryStart = "Start";
		private const string entryEnd = "End";
        private const string entryCenter1= "center1";
        private const string entryCenter2 = "center2";
        private const string entryMulLeft = "MulLeft";
        private const string entryMulRight = "MulRight";
        private const string entryRole = "RoleName";
        private const string entryLeftTri = "LeftTri";
        private const string entryRightTri = "RightTri";
		
		private GraphicsPath areaPath = null;

		private Pen areaPen = null;
		private Region areaRegion = null;

        SubFunction func = new SubFunction();
        ToolObject tools = new ToolObject();

        private DrawArea _Area;

        public DrawClass start_class;
        public DrawClass end_class;

        public int start_flag = -1;      //xac dinh connect dau hay cuoi
        public int end_flag = -1;

        public DrawAssociationClass AssClass;
        public List<ConnectPoint> ListConnectPoint = new List<ConnectPoint>();   //list nhung diem connectpoint
        public bool connect = false;
        public int diemsang = -1;

        //rectangle role, multiplicity
        public DrawText RoleName = null;

        public DrawTriangle role_left_tri = null;
        public DrawTriangle role_right_tri = null;

        public DrawText mul_left = null;
        public DrawText mul_right = null;

        //load sub items
        int index_mul_left = -1;
        int index_mul_right = -1;
        int index_role = -1;
        int index_mul_left_tri = -1;
        int index_mul_right_tri = -1;

        #endregion

        #region Get/Set Function

        public DrawArea Area
        {
            get { return _Area; }
            set { _Area = value; }
        }

        protected GraphicsPath AreaPath
        {
            get { return areaPath; }
            set { areaPath = value; }
        }

        protected Pen AreaPen
        {
            get { return areaPen; }
            set { areaPen = value; }
        }

        protected Region AreaRegion
        {
            get { return areaRegion; }
            set { areaRegion = value; }
        }
        #endregion

        #region Constructor


        public override DrawObject Clone()
        {
            DrawExtraAssociation drawLine = new DrawExtraAssociation();
            drawLine.startPoint = startPoint;
            drawLine.endPoint = endPoint;
            drawLine.center1 = center1;
            drawLine.center2 = center2;

            FillDrawObjectFields(drawLine);
            return drawLine;
        }


        public DrawExtraAssociation()
		{
            startPoint = new Point(0, 0);
            endPoint = new Point(1, 1);
			ZOrder = 0;

			Initialize();
		}

		public DrawExtraAssociation(int x1, int y1, int x2, int y2)
		{
            Center = new Point((x1 + x2) / 2, (y1 + y2) / 2);
            startPoint = new Point(x1, y1);
            endPoint = new Point(x2, y2);
			ZOrder = 0;
			
			Initialize();
		}

      

        public DrawExtraAssociation(Point start,Point c1,Point c2,Point end, Color lineColor, int lineWidth,DrawArea area)
		{
            _Area = area;

            Center = new Point(center1.X, (center1.Y+center2.Y)/2);
            startPoint = start;
            center2 = c2;
            center1 = c1;
            endPoint = end;

            string t;
            Color c = Color.Black;
            Font f = new Font("Tahoma", 10, FontStyle.Regular);

            t = "0..1";
            mul_left = new DrawText(startPoint.X, startPoint.Y - 15, 40, 20, t, f, c,Area);
            mul_right = new DrawText(endPoint.X -20, endPoint.Y-15, 40, 20, t, f, c,Area);
            tools.AddNewObject(area, mul_left, DrawObject.ObjectType.text);
            tools.AddNewObject(area, mul_right, DrawObject.ObjectType.text);

            t = "role";
            RoleName = new DrawText(center1.X-30, (center1.Y+center2.Y)/2, 40, 20, t, f, c,Area);
            tools.AddNewObject(area, RoleName, DrawObject.ObjectType.text);

            role_left_tri = new DrawTriangle(center2.X-20, center2.Y - 20, c,area);
            role_left_tri.top = true;
            role_right_tri = new DrawTriangle(center1.X-20, center1.Y+20, c,area);
            role_right_tri.bottom = true;
            tools.AddNewObject(area, role_left_tri, DrawObject.ObjectType.others);
            tools.AddNewObject(area, role_right_tri, DrawObject.ObjectType.others);

            ListConnectPoint = func.SetConnectPointExtra(this);
            
			Color = lineColor;
			PenWidth = lineWidth;
			ZOrder = 0;

			Initialize();
		}

        

        #endregion
        
        //ham ve association

        public void turn_on_connect_point(Graphics g)
        {
            if (connect == true)
            {
                SolidBrush brush = new SolidBrush(Color.Black);
                foreach (ConnectPoint p in ListConnectPoint)
                {
                    Rectangle temp = p.connect_area;
                    g.DrawLine(new Pen(Color.Green), temp.Location, new Point(temp.X + temp.Width, temp.Y + temp.Height));
                    g.DrawLine(new Pen(Color.Green), new Point(temp.X, temp.Y + temp.Height), new Point(temp.X + temp.Width, temp.Y));
                }
                if (diemsang >= 0)
                {
                    Rectangle temp1 = ListConnectPoint[diemsang].connect_area;
                    g.DrawRectangle(new Pen(Color.Red, 3), temp1);
                }
            }
        }

        public override void Draw(Graphics g)
		{
            //TODO: ham draw ve association
			g.SmoothingMode = SmoothingMode.AntiAlias;

			Pen pen;
			pen = new Pen(Color, PenWidth);
			
			
			GraphicsPath gp = new GraphicsPath();
			gp.AddLine(center1, endPoint);
            gp.AddLine(center1, center2);
            gp.AddLine(startPoint, center2);

            if (Area != null) Set_subitems();
            turn_on_connect_point(g);
		
			g.DrawPath(pen, gp);
			gp.Dispose();
			pen.Dispose();
		}

        
        #region Select effect

        public override int HandleCount
		{
			get { return 7; }
		}

		
		public override Point GetHandle(int handleNumber)
		{
            
			GraphicsPath gp = new GraphicsPath();
			Matrix m = new Matrix();
			gp.AddLine(center1, center2);
			RectangleF pathBounds = gp.GetBounds();
			m.RotateAt(Rotation, new PointF(pathBounds.Left + (pathBounds.Width / 2), pathBounds.Top + (pathBounds.Height / 2)), MatrixOrder.Append);
			gp.Transform(m);
			Point start, end;
			start = Point.Truncate(gp.PathPoints[0]);
			end = Point.Truncate(gp.PathPoints[1]);
			gp.Dispose();
			m.Dispose();
		
            int x = startPoint.X;
            int y = startPoint.Y;

            switch (handleNumber)
            {
                case 1:
                    x = startPoint.X;
                    y = startPoint.Y;
                    break;
                case 2:
                    x = (startPoint.X+center2.X)/2;
                    y = startPoint.Y;
                    break;
                case 3:
                    x = center2.X;
                    y = center2.Y;
                    break;
                case 4:
                    x = center1.X;
                    y = (center1.Y+center2.Y)/2;
                    break;
                case 5:
                    x = center1.X;
                    y = center1.Y;
                    break;
                case 6:
                    x = (center1.X+endPoint.X)/2;
                    y = center1.Y;
                    break;
                case 7:
                    x = endPoint.X;
                    y = endPoint.Y;
                    break;
              
            }
            return new Point(x, y);
		}

		
		public override int HitTest(Point point)
		{
			if (Selected)
				for (int i = 1; i <= HandleCount; i++)
				{
					GraphicsPath gp = new GraphicsPath();
					gp.AddRectangle(GetHandleRectangle(i));
					bool vis = gp.IsVisible(point);
					gp.Dispose();
					if (vis)
						return i;
				}
			// OK, so the point is not on a selection handle, is it anywhere else on the line?
			if (PointInObject(point))
				return 0;
			return -1;
		}

		protected override bool PointInObject(Point point)
		{
			CreateObjects();
			return AreaRegion.IsVisible(point);
		}

		public override bool IntersectsWith(Rectangle rectangle)
		{
			CreateObjects();
			return AreaRegion.IsVisible(rectangle);
		}

		public override Cursor GetHandleCursor(int handleNumber)
		{
			switch (handleNumber)
			{
				case 1:
                    return Cursors.SizeAll;
				case 2:
					return Cursors.SizeNS;
                case 3:
                    return Cursors.SizeNWSE;
                case 4:
                    return Cursors.SizeWE;
                case 5:
                    return Cursors.SizeNWSE;
                case 6:
                    return Cursors.SizeNS;
                case 7:
                    return Cursors.SizeAll;
				default:
					return Cursors.Default;
			}
		}

		public override void MoveHandleTo(Point point, int handleNumber)
		{

            switch (handleNumber)
            {
                case 1:
                    startPoint.X = point.X;
                    this.mul_left.rectangle.X = point.X;
                    break;
                case 2:
                    startPoint.Y = point.Y;
                    center2.Y = point.Y;
                    this.mul_left.rectangle.Y= point.Y;
                    this.role_left_tri.rectangle.Y = (center1.Y + center2.Y) /2 -10;
                    this.role_right_tri.rectangle.Y = (center1.Y + center2.Y) / 2 + 10;
                    break;
                case 3:
                case 4:
                case 5:
                    center2.X = point.X;
                    center1.X = point.X;
                    this.RoleName.rectangle.X = point.X;
                    this.role_left_tri.rectangle.X = point.X;
                    this.role_right_tri.rectangle.X = point.X;
                    break;
                case 6:
                    center1.Y = point.Y;
                    endPoint.Y = point.Y;
                    this.mul_right.rectangle.Y = point.Y;
                    this.role_left_tri.rectangle.Y= (center1.Y + center2.Y) / 2 - 10;
                    this.role_right_tri.rectangle.Y = (center1.Y + center2.Y) / 2 + 10;
                    break;
                case 7:
                    endPoint.X = point.X;
                    this.mul_right.rectangle.X = point.X;
                    break;
              
            }

            ListConnectPoint = func.SetConnectPointExtra(this);
            //show connect point
            func.GetObjectConnectPoint(this, Area.Graphics.GetListObject());
            KeepAssociation();
			Dirty = true;
			Invalidate();
		}

		public override void Move(int deltaX, int deltaY)
		{
            KeepAssociation();

			startPoint.X += deltaX;
			startPoint.Y += deltaY;

			endPoint.X += deltaX;
			endPoint.Y += deltaY;

            center1.X += deltaX;
            center1.Y += deltaY;

            center2.X += deltaX;
            center2.Y += deltaY;

            //show connect point

            if (mul_left != null)
            {
                mul_left.rectangle.X += deltaX;
                mul_left.rectangle.Y += deltaY;
            }
            if (mul_right != null)
            {
                mul_right.rectangle.X += deltaX;
                mul_right.rectangle.Y += deltaY;
            }
            if (RoleName != null)
            {
                RoleName.rectangle.X += deltaX;
                RoleName.rectangle.Y += deltaY;
            }
            if (role_left_tri != null)
            {
                role_left_tri.rectangle.X += deltaX;
                role_left_tri.rectangle.Y += deltaY;
            }
            if (role_right_tri != null)
            {
                role_right_tri.rectangle.X += deltaX;
                role_right_tri.rectangle.Y += deltaY;
            }

            func.GetObjectConnectPoint(this, Area.Graphics.GetListObject());

            ListConnectPoint = func.SetConnectPointExtra(this);

			Dirty = true;
			Invalidate();
		}

        #endregion

        #region Stream

        public override void SaveToStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryStart, orderNumber, objectIndex),
				startPoint);

            

			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryEnd, orderNumber, objectIndex),
				endPoint);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryCenter1, orderNumber, objectIndex),
                center1);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryCenter2, orderNumber, objectIndex),
                center2);
            info.AddValue(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entryMulLeft, orderNumber, objectIndex),
              Area.Graphics.GetIndex(mul_left));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulRight, orderNumber, objectIndex),
               Area.Graphics.GetIndex(mul_right));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRole, orderNumber, objectIndex),
               Area.Graphics.GetIndex(RoleName));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryLeftTri, orderNumber, objectIndex),
               Area.Graphics.GetIndex(role_left_tri));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRightTri, orderNumber, objectIndex),
               Area.Graphics.GetIndex(role_right_tri));

			base.SaveToStream(info, orderNumber, objectIndex);
		}

		public override void LoadFromStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			startPoint = (Point)info.GetValue(
									String.Format(CultureInfo.InvariantCulture,
												  "{0}{1}-{2}",
												  entryStart, orderNumber, objectIndex),
									typeof(Point));

			endPoint = (Point)info.GetValue(
								String.Format(CultureInfo.InvariantCulture,
											  "{0}{1}-{2}",
											  entryEnd, orderNumber, objectIndex),
								typeof(Point));

            center1 = (Point)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entryCenter1, orderNumber, objectIndex),
                                typeof(Point));

            center2 = (Point)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entryCenter2, orderNumber, objectIndex),
                                typeof(Point));
            index_mul_left = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulLeft, orderNumber, objectIndex));
            index_mul_right = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulRight, orderNumber, objectIndex));
            index_role = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRole, orderNumber, objectIndex));
            index_mul_left_tri = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryLeftTri, orderNumber, objectIndex));
            index_mul_right_tri = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRightTri, orderNumber, objectIndex));

			base.LoadFromStream(info, orderNumber, objectIndex);
		}

        #endregion

        #region Others function
        protected void Invalidate()
		{
			if (AreaPath != null)
			{
				AreaPath.Dispose();
				AreaPath = null;
			}

			if (AreaPen != null)
			{
				AreaPen.Dispose();
				AreaPen = null;
			}

			if (AreaRegion != null)
			{
				AreaRegion.Dispose();
				AreaRegion = null;
			}
		}

		
		protected virtual void CreateObjects()
		{
			if (AreaPath != null)
				return;

			AreaPath = new GraphicsPath();
		
			AreaPen = new Pen(Color.Black, PenWidth < 7 ? 7 : PenWidth);
		
			if (center1.Equals((Point)center2))
			{
				center1.X++;
				center1.Y++;
			}
			
            AreaPath.AddLine(center1.X, center1.Y, center2.X, center2.Y);
			AreaPath.Widen(AreaPen);
	
			if (Rotation != 0)
			{
				RectangleF pathBounds = AreaPath.GetBounds();
				Matrix m = new Matrix();
				m.RotateAt(Rotation, new PointF(pathBounds.Left + (pathBounds.Width / 2), pathBounds.Top + (pathBounds.Height / 2)), MatrixOrder.Append);
				AreaPath.Transform(m);
				m.Dispose();
			}

			// Create region from the path
			AreaRegion = new Region(AreaPath);
		}

        public void KeepAssociation()
        {
            if (AssClass != null)
            {
                if (AssClass.start_flag == this.ID)
                {
                    AssClass.startPoint = ListConnectPoint[diemsang].point;
                }
                else if (AssClass.end_flag == this.ID)
                {
                    AssClass.endPoint = ListConnectPoint[diemsang].point;
                }
            }
        }

        public void Set_subitems()
        {
            if (index_mul_left != -1)
            {
                mul_left = (DrawText)Area.Graphics[index_mul_left];
                index_mul_left = -1;
            }
            if (index_mul_right != -1)
            {
                mul_right = (DrawText)Area.Graphics[index_mul_right];
                index_mul_right = -1;
            }
            if (index_role != -1)
            {
                RoleName = (DrawText)Area.Graphics[index_role];
                index_role = -1;
            }
            if (index_mul_left_tri != -1)
            {
                role_left_tri = (DrawTriangle)Area.Graphics[index_mul_left_tri];
                index_mul_left_tri = -1;
            }
            if (index_mul_right_tri != -1)
            {
                role_right_tri = (DrawTriangle)Area.Graphics[index_mul_right_tri];
                index_mul_right_tri = -1;
            }

        }
        #endregion

       

    }
}
