﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Reflection;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;

using DesignDatabaseTools.Methods;
using DesignDatabaseTools.Tools;

namespace DesignDatabaseTools.DrawObject
{
    [Serializable]
    public class DrawAssociation : DrawObject
    {
        #region Attributes

        public Point startPoint;
		public Point endPoint;

        //public bool ConnectBool = false;              //bao hieu dang dc connect hay ko

		private const string entryStart = "Start";
		private const string entryEnd = "End";
        private const string entryMulLeft = "MulLeft";
        private const string entryMulRight = "MulRight";
        private const string entryRole = "RoleName";
        private const string entryLeftTri = "LeftTri";
        private const string entryRightTri = "RightTri";

        private const string entryAssClass = "AssClass";
        
        
		private GraphicsPath areaPath = null;

		private Pen areaPen = null;
		private Region areaRegion = null;

        public List<ConnectPoint> ListConnectPoint = new List<ConnectPoint>();   //list nhung diem connectpoint
        public bool connect = false;
        public int diemsang = -1;

        SubFunction subfunction = new SubFunction();
        ToolObject tools = new ToolObject();

        private DrawArea _Area;
        //public List<DrawObject> ListClass= new List<DrawObject>();               //list class
        public DrawAssociationClass AssClass = null;
        public string ass_mul_left;
        public string ass_mul_right;
        //public DrawAssociation Ass;
        //public DrawObject association;

        public DrawClass start_class;
        public DrawClass end_class;

        //rectangle role, multiplicity
        public DrawText RoleName =null;      
       
        public DrawTriangle role_left_tri=null;
        public DrawTriangle role_right_tri=null;
      
        public DrawText mul_left=null;
        public DrawText mul_right=null;
        //load sub items
        int index_mul_left=-1;
        int index_mul_right=-1;
        int index_role =-1;
        int index_mul_left_tri =-1;
        int index_mul_right_tri = -1;
        int index_Assclass = -1;

        public int start_flag = -1;      //xac dinh connect dau hay cuoi
        public int end_flag = -1;

        //public string RoleName;

        #endregion

        #region Get/Set Function
        public DrawArea Area
        {
            get { return _Area; }
            set { _Area = value; }
        }

        protected GraphicsPath AreaPath
        {
            get { return areaPath; }
            set { areaPath = value; }
        }

        protected Pen AreaPen
        {
            get { return areaPen; }
            set { areaPen = value; }
        }

        protected Region AreaRegion
        {
            get { return areaRegion; }
            set { areaRegion = value; }
        }
        #endregion

        #region Constructor

       
        public override DrawObject Clone()
        {
            DrawAssociation drawLine = new DrawAssociation();
            drawLine.startPoint = startPoint;
            drawLine.endPoint = endPoint;

            FillDrawObjectFields(drawLine);
            return drawLine;
        }


        public DrawAssociation()
		{
            startPoint = new Point(0, 0);
            endPoint = new Point(1, 1);
			ZOrder = 0;

			Initialize();
		}

        public void DrawMulRole(DrawArea area ,int flag)
        {
            
            //add role, multiplicity
            string t;
            Color c = Color.Black;
            Font f = new Font("Tahoma", 10, FontStyle.Regular);
             //0: association  1: agg   2: comp   3: assline   4: ger   
            if (flag == 0 || flag == 1 || flag == 2)
            {
                t = "0..1";
                mul_left = new DrawText(startPoint.X, startPoint.Y - 15,40,20, t, f, c,Area);
                mul_right = new DrawText(endPoint.X - 20, endPoint.Y - 15,40,20, t, f, c,Area);
                tools.AddNewObject(area, mul_left, DrawObject.ObjectType.text);
                tools.AddNewObject(area, mul_right, DrawObject.ObjectType.text);
            }
            if (flag != 3)
            {
                t = "role";
                RoleName = new DrawText(Center.X, Center.Y - 15,40,20, t, f, c,Area);
              
                tools.AddNewObject(area, RoleName, DrawObject.ObjectType.text);
            }
            if (flag == 0)
            {
                role_left_tri = new DrawTriangle(Center.X + 40, Center.Y - 20, c,Area);
                role_left_tri.left = true;
                role_right_tri = new DrawTriangle(Center.X - 40, Center.Y - 20, c,Area);
                role_right_tri.right = true;
                tools.AddNewObject(area, role_left_tri, DrawObject.ObjectType.others);
                tools.AddNewObject(area, role_right_tri, DrawObject.ObjectType.others);
            }
        }

        public DrawAssociation(int x1, int y1, int x2, int y2, Color lineColor, int lineWidth,DrawArea area)
		{
            //diem
            Center = new Point((x1 + x2) / 2, (y1 + y2) / 2);
            startPoint = new Point(x1, y1);
            endPoint = new Point(x2, y2);
            
        
            //thuoc tinh
			Color = lineColor;
			PenWidth = lineWidth;
			ZOrder = 0;
            //chu thich
			
            //gan area
            _Area = area;

            DrawMulRole(area,0);

            ListConnectPoint = subfunction.ListConnectPointAss(startPoint, endPoint);

			Initialize();
		}

        public void DrawOthersAssociation(int x1, int y1, int x2, int y2, Color lineColor, int lineWidth, DrawArea area,int flag)
        {
            //diem
            Center = new Point((x1 + x2) / 2, (y1 + y2) / 2);
            startPoint = new Point(x1, y1);
            endPoint = new Point(x2, y2);


            //thuoc tinh
            Color = lineColor;
            PenWidth = lineWidth;
            ZOrder = 0;
            //chu thich

            //gan area
            _Area = area;

            DrawMulRole(area,flag);
            Initialize();
        }
    

        #endregion

        #region DRAW
        //ham ve association

        public void turn_on_connect_point(Graphics g)
        {
            if (connect == true && this.ObjType == ObjectType.AssociationLine)
            {
                SolidBrush brush = new SolidBrush(Color.Black);
                foreach (ConnectPoint p in ListConnectPoint)
                {
                    Rectangle temp = p.connect_area;
                    g.DrawLine(new Pen(Color.Green), temp.Location, new Point(temp.X + temp.Width, temp.Y + temp.Height));
                    g.DrawLine(new Pen(Color.Green), new Point(temp.X, temp.Y + temp.Height), new Point(temp.X + temp.Width, temp.Y));
                }
                if (diemsang >= 0)
                {
                    Rectangle temp1 = ListConnectPoint[diemsang].connect_area;
                    g.DrawRectangle(new Pen(Color.Red, 3), temp1);
                }
            }
        }

        public override void Draw(Graphics g)
		{
            //TODO: ham draw ve association
			g.SmoothingMode = SmoothingMode.AntiAlias;

			Pen pen;
			pen = new Pen(Color, PenWidth);
			
			GraphicsPath gp = new GraphicsPath();
			gp.AddLine(startPoint, endPoint);

            if (Area != null)
            {
                if (!Area.Graphics.exists(mul_left))
                {
                    mul_left = null;
                }

                if (!Area.Graphics.exists(mul_right))
                {
                    mul_right = null;
                }

                if (!Area.Graphics.exists(RoleName))
                {
                    RoleName = null;
                }

                if (!Area.Graphics.exists(role_left_tri))
                {
                    role_left_tri = null;
                }

                if (!Area.Graphics.exists(role_right_tri))
                {
                    role_right_tri = null;
                }

               Set_subitems();
            }

            turn_on_connect_point(g);
           
			g.DrawPath(pen, gp);
			gp.Dispose();
			pen.Dispose();
		}

        // ham draw ve generalization, agg, composition...
        public void Draw(Graphics g,int i)
        {
            
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Brush br = new SolidBrush(Color);
            Pen pen;
            pen = new Pen(Color, PenWidth);
           
            if (i == 4)
            {
                float[] dashValues = { 5, 2, 4, 4 };
                //pen = new Pen(Color.Black, 1);
                pen.DashPattern = dashValues;
            }
            GraphicsPath gp = new GraphicsPath();
            gp.AddLine(startPoint, endPoint);
        

            g.DrawPath(pen, gp);

            if (i == 1)
            {
                List<Point> pp =subfunction.GetPoint(startPoint,endPoint,1);
                Point[] Points = new Point[]{pp[0],pp[1],pp[2]};
                g.FillPolygon(new SolidBrush(Color.White), Points);
                g.DrawPolygon(pen, Points);
                if (Area != null)
                {
                    if (!Area.Graphics.exists(RoleName))
                    {
                        RoleName = null;
                    }
                    Set_subitems();
                }
            
            }
            else if (i == 2)
            {
                List<Point> pp =subfunction.GetPoint(startPoint, endPoint, 2);
                Point[] Points = new Point[] { pp[0], pp[2], pp[1], pp[3] };
                g.FillPolygon(new SolidBrush(Color.White), Points);
                g.DrawPolygon(pen, Points);
                if (Area != null)
                {
                    if (!Area.Graphics.exists(mul_left))
                    {
                        mul_left = null;
                    }

                    if (!Area.Graphics.exists(mul_right))
                    {
                        mul_right = null;
                    }

                    if (!Area.Graphics.exists(RoleName))
                    {
                        RoleName = null;
                    }

                    Set_subitems();
                }
            }
            else if (i == 3)
            {
                List<Point> pp =subfunction.GetPoint(startPoint, endPoint, 2);
                Point[] Points = new Point[] { pp[0], pp[2], pp[1],pp[3] };
                g.FillPolygon(br, Points);
                if (Area != null)
                {
                    if (!Area.Graphics.exists(mul_left))
                    {
                        mul_left = null;
                    }

                    if (!Area.Graphics.exists(mul_right))
                    {
                        mul_right = null;
                    }

                    if (!Area.Graphics.exists(RoleName))
                    {
                        RoleName = null;
                    }

                    Set_subitems();
                }
            }

            //turn_on_connect_point(g);

            gp.Dispose();
            pen.Dispose();
        }

        #endregion

        #region Select effect

        public override int HandleCount
		{
			get { return 2; }
		}

		
		public override Point GetHandle(int handleNumber)
		{
            
			GraphicsPath gp = new GraphicsPath();
			Matrix m = new Matrix();
			gp.AddLine(startPoint, endPoint);
			RectangleF pathBounds = gp.GetBounds();
			m.RotateAt(Rotation, new PointF(pathBounds.Left + (pathBounds.Width / 2), pathBounds.Top + (pathBounds.Height / 2)), MatrixOrder.Append);
			gp.Transform(m);
			Point start, end;
			start = Point.Truncate(gp.PathPoints[0]);
			end = Point.Truncate(gp.PathPoints[1]);
			gp.Dispose();
			m.Dispose();
			if (handleNumber == 1)
				return start;
			else
				return end;

            
		}

		
		public override int HitTest(Point point)
		{
            
			if (Selected)
				for (int i = 1; i <= HandleCount; i++)
				{
					GraphicsPath gp = new GraphicsPath();
					gp.AddRectangle(GetHandleRectangle(i));
					bool vis = gp.IsVisible(point);
					gp.Dispose();
					if (vis)
						return i;
				}
			// OK, so the point is not on a selection handle, is it anywhere else on the line?
			if (PointInObject(point))
				return 0;
			return -1;
		}

		protected override bool PointInObject(Point point)
		{
           
			CreateObjects();
			//return AreaPath.IsVisible(point);
			return AreaRegion.IsVisible(point);
		}

		public override bool IntersectsWith(Rectangle rectangle)
		{

			CreateObjects();
			return AreaRegion.IsVisible(rectangle);
		}

		public override Cursor GetHandleCursor(int handleNumber)
		{
			switch (handleNumber)
			{
				case 1:
				case 2:
					return Cursors.SizeAll;
				default:
					return Cursors.Default;
			}
		}

		public override void MoveHandleTo(Point point, int handleNumber)
		{
			
			if (handleNumber == 1)
				startPoint = point;
			else
				endPoint = point;

            SetSubItemPosition();

            //get connect point 
            ListConnectPoint = subfunction.ListConnectPointAss(this.startPoint, this.endPoint);

            //show connect point
            subfunction.GetObjectConnectPoint(this, Area.Graphics.GetListObject());

            KeepAssociation(); 
            //xac dinh class lien ket

			Dirty = true;
			Invalidate();
		}

		public override void Move(int deltaX, int deltaY)
		{
            KeepAssociation();

			startPoint.X += deltaX;
			startPoint.Y += deltaY;

			endPoint.X += deltaX;
			endPoint.Y += deltaY;

            if (mul_left != null)
            {
                mul_left.rectangle.X += deltaX;
                mul_left.rectangle.Y += deltaY;
            }
            if(mul_right!=null)
            {
                mul_right.rectangle.X += deltaX;
                mul_right.rectangle.Y += deltaY;
            }
            if (RoleName != null)
            {
                RoleName.rectangle.X += deltaX;
                RoleName.rectangle.Y += deltaY;
            }
            if (role_left_tri != null)
            {
                role_left_tri.rectangle.X += deltaX;
                role_left_tri.rectangle.Y += deltaY;
            }
            if (role_right_tri != null)
            {
                role_right_tri.rectangle.X += deltaX;
                role_right_tri.rectangle.Y += deltaY;
            }

            //get connect point 
            ListConnectPoint = subfunction.ListConnectPointAss(this.startPoint,this.endPoint);

            //show connect point
            subfunction.GetObjectConnectPoint(this, Area.Graphics.GetListObject());
            
			Dirty = true;
			Invalidate();
		}

        public void KeepAssociation()
        {
            if (AssClass != null)
            {
                if (AssClass.start_flag == this.ID)
                {
                    if (diemsang < ListConnectPoint.Count && diemsang >=0)
                    {
                        AssClass.startPoint = ListConnectPoint[diemsang].point;
                    }
                }
                else if(AssClass.end_flag == this.ID)
                {
                    if (diemsang < ListConnectPoint.Count && diemsang >= 0)
                    {
                        AssClass.endPoint = ListConnectPoint[diemsang].point;
                    }
                }
            }
        }

        #endregion

        #region Stream

        public override void SaveToStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryStart, orderNumber, objectIndex),
				startPoint);

			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryEnd, orderNumber, objectIndex),
				endPoint);

            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulLeft, orderNumber, objectIndex),
               Area.Graphics.GetIndex(mul_left));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulRight, orderNumber, objectIndex),
               Area.Graphics.GetIndex(mul_right));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRole, orderNumber, objectIndex),
               Area.Graphics.GetIndex(RoleName));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryLeftTri, orderNumber, objectIndex),
               Area.Graphics.GetIndex(role_left_tri));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRightTri, orderNumber, objectIndex),
               Area.Graphics.GetIndex(role_right_tri));

            info.AddValue(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entryAssClass, orderNumber, objectIndex),
              Area.Graphics.GetIndex(AssClass));

			base.SaveToStream(info, orderNumber, objectIndex);
		}

		public override void LoadFromStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			startPoint = (Point)info.GetValue(
									String.Format(CultureInfo.InvariantCulture,
												  "{0}{1}-{2}",
												  entryStart, orderNumber, objectIndex),
									typeof(Point));

			endPoint = (Point)info.GetValue(
								String.Format(CultureInfo.InvariantCulture,
											  "{0}{1}-{2}",
											  entryEnd, orderNumber, objectIndex),
								typeof(Point));
            index_mul_left = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulLeft, orderNumber, objectIndex));
            index_mul_right = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulRight, orderNumber, objectIndex));
            index_role= info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRole, orderNumber, objectIndex));
            index_mul_left_tri = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryLeftTri, orderNumber, objectIndex));
            index_mul_right_tri = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRightTri, orderNumber, objectIndex));

            index_Assclass = info.GetInt32(
             String.Format(CultureInfo.InvariantCulture,
                           "{0}{1}-{2}",
                           entryAssClass, orderNumber, objectIndex));

			base.LoadFromStream(info, orderNumber, objectIndex);
		}

        #endregion

        #region Others function
        protected void Invalidate()
		{
			if (AreaPath != null)
			{
				AreaPath.Dispose();
				AreaPath = null;
			}

			if (AreaPen != null)
			{
				AreaPen.Dispose();
				AreaPen = null;
			}

			if (AreaRegion != null)
			{
				AreaRegion.Dispose();
				AreaRegion = null;
			}
		}

		
		protected virtual void CreateObjects()
		{
			if (AreaPath != null)
				return;

			AreaPath = new GraphicsPath();
			// Take into account the width of the pen used to draw the actual object
			AreaPen = new Pen(Color.Black, PenWidth < 7 ? 7 : PenWidth);
			// Prevent Out of Memory crash when startPoint == endPoint
			if (startPoint.Equals((Point)endPoint))
			{
				endPoint.X++;
				endPoint.Y++;
			}
			AreaPath.AddLine(startPoint.X, startPoint.Y, endPoint.X, endPoint.Y);
			AreaPath.Widen(AreaPen);
			// Rotate the path about it's center if necessary
			if (Rotation != 0)
			{
				RectangleF pathBounds = AreaPath.GetBounds();
				Matrix m = new Matrix();
				m.RotateAt(Rotation, new PointF(pathBounds.Left + (pathBounds.Width / 2), pathBounds.Top + (pathBounds.Height / 2)), MatrixOrder.Append);
				AreaPath.Transform(m);
				m.Dispose();
			}

			// Create region from the path
			AreaRegion = new Region(AreaPath);
		}

        public void Set_subitems()
        {
            if (index_mul_left != -1)
            {
                mul_left = (DrawText)Area.Graphics[index_mul_left];
                index_mul_left = -1;
            }
            if (index_mul_right != -1)
            {
                mul_right = (DrawText)Area.Graphics[index_mul_right];
                index_mul_right = -1;
            }
            if (index_role != -1)
            {
                RoleName = (DrawText)Area.Graphics[index_role];
                index_role = -1;
            }
            if (index_mul_left_tri != -1)
            {
                role_left_tri = (DrawTriangle)Area.Graphics[index_mul_left_tri];
                index_mul_left_tri = -1;
            }
            if (index_mul_right_tri != -1)
            {
                role_right_tri = (DrawTriangle)Area.Graphics[index_mul_right_tri];
                index_mul_right_tri = -1;
            }

            if (index_Assclass != -1)
            {
                AssClass = (DrawAssociationClass)Area.Graphics[index_Assclass];
                index_Assclass = -1;
                if (AssClass.start_flag == -1) AssClass.start_flag = this.ID;
                else AssClass.end_flag = this.ID;
            }
           
        }

        public void SetSubItemPosition()
        {
            if (this.mul_left != null)
            {
                this.mul_left.rectangle.X = startPoint.X;
                this.mul_left.rectangle.Y = startPoint.Y - 20;
            }
            if (this.mul_right != null)
            {
                this.mul_right.rectangle.X = endPoint.X - 20;
                this.mul_right.rectangle.Y = endPoint.Y;
            }
            if (this.RoleName != null)
            {
                this.RoleName.rectangle.X = (startPoint.X + endPoint.X) / 2 - 20;
                this.RoleName.rectangle.Y = (startPoint.Y + endPoint.Y) / 2 - 20;
            }
            if (this.role_left_tri != null)
            {
                this.role_left_tri.rectangle.X = (startPoint.X + endPoint.X) / 2 + 20;
                this.role_left_tri.rectangle.Y = (startPoint.Y + endPoint.Y) / 2 - 20;
            }
            if (this.role_right_tri != null)
            {
                this.role_right_tri.rectangle.X = (startPoint.X + endPoint.X) / 2 - 40;
                this.role_right_tri.rectangle.Y = (startPoint.Y + endPoint.Y) / 2 - 20;
            }
        }
        #endregion

       

    }
}
