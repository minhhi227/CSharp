﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;


namespace DesignDatabaseTools.DrawObject
{
    
    [Serializable]
    public abstract class DrawObject  : IComparable
    {
        #region Members
        // Object properties
        private bool selected;
        private Color color;
        private Color fillColor;
        private Color fontColor;
        private bool filled;
        private int penWidth;
        private bool hide=false;
        private DrawObject.ObjectType _ObjType;
        private string tipText;

        // Last used property values (may be kept in the Registry)
        private static Color lastUsedColor = Color.Black;
        private static int lastUsedPenWidth = 1;

        // Entry names for serialization
        private const string entryColor = "Color";
        private const string entryPenWidth = "PenWidth";
        private const string entryPen = "DrawPen";
        private const string entryBrush = "DrawBrush";
        private const string entryFillColor = "FillColor";
        private const string entryFilled = "Filled";
        private const string entryZOrder = "ZOrder";
        private const string entryRotation = "Rotation";
        private const string entryTipText = "TipText";
        private const string entryObjectType = "TipObjectType";
        private const string entryID = "ID";
        private const string entryfontcolor= "FontColor";
        
        //Attributes Entry
        private int _id;
        private int _zOrder;
        private string name;
        private string text;
        public string comment;
        //enum type
        public enum ObjectType
        {
            Class,
            AbstractClass,
            AssociationLine,
            AssociationClassLine,
            ExtraAssociation,
            RecurcyLine,
            text,
            insert_text,
            Binary,
            Nary,
            Generalization,
            Aggernation,
            Composition,
            others,
            Image,
            NumberOfObject

        } ;

        private bool dirty;
        private int _rotation = 0;
        private Point _center;
        #endregion Members

        #region Properties
       
        public Point Center
        {
            get { return _center; }
            set { _center = value; }
        }

        public DrawObject.ObjectType ObjType
        {
            get { return _ObjType; }
            set { _ObjType = value; }
        }

        public int Rotation
        {
            get { return _rotation; }
            set
            {
                if (value > 360)
                    _rotation = value - 360;
                else if (value < -360)
                    _rotation = value + 360;
                else
                    _rotation = value;
            }
        }

        
        public int ZOrder
        {
            get { return _zOrder; }
            set { _zOrder = value; }
        }

       
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public bool Hide
        {
            get { return hide; }
            set { hide = value; }
        }
        
        public bool Dirty
        {
            get { return dirty; }
            set { dirty = value; }
        }

        
        public bool Filled
        {
            get { return filled; }
            set { filled = value; }
        }

       
        public bool Selected
        {
            get { return selected; }
            set { selected = value; }
        }

       
        public Color FillColor
        {
            get { return fillColor; }
            set { fillColor = value; }
        }

        public Color FontColor
        {
            get { return fontColor; }
            set { fontColor = value; }
        }
        public Color Color
        {
            get { return color; }
            set { color = value; }
        }

       
        public int PenWidth
        {
            get { return penWidth; }
            set { penWidth = value; }
        }

        public virtual int HandleCount
        {
            get { return 0; }
        }
      
        public virtual int ConnectionCount
        {
            get { return 0; }
        }
        
        public static Color LastUsedColor
        {
            get { return lastUsedColor; }
            set { lastUsedColor = value; }
        }

        
        public static int LastUsedPenWidth
        {
            get { return lastUsedPenWidth; }
            set { lastUsedPenWidth = value; }
        }

       
        public string TipText
        {
            get { return tipText; }
            set { tipText = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Text
        {
            get { return text; }
            set { text = value; }
        }
      

        #endregion Properties

        #region Constructor

        protected DrawObject()
        {
            // ReSharper disable DoNotCallOverridableMethodsInConstructor
            ID = GetHashCode();
            // ReSharper restore DoNotCallOverridableMethodsInConstructor
        }
        #endregion

        #region Virtual Functions
      
        public abstract DrawObject Clone();

       
        public virtual void Draw(Graphics g)
        {
        }

        #region Selection handle methods
       
        public virtual Point GetHandle(int handleNumber)
        {
            return new Point(0, 0);
        }

     
        public virtual Rectangle GetHandleRectangle(int handleNumber)
        {
            Point point = GetHandle(handleNumber);
            // ve hinh chu nhat nho o nhung diem dc chon
            return new Rectangle(point.X - (penWidth + 3), point.Y - (penWidth + 3), 7 + penWidth, 7 + penWidth);
            
        }

      
        public virtual void DrawTracker(Graphics g)
        {
            if (!Selected)
                return;
            //SolidBrush brush = new SolidBrush(Color.Green);
            SolidBrush b = new SolidBrush(Color.Black);
            Pen p = new Pen(Color.Black, -1.0f);

            for (int i = 1; i <= HandleCount; i++)
            {
                //g.FillRectangle(brush, GetHandleRectangle(i));
                g.DrawEllipse(p, GetHandleRectangle(i));
                g.FillEllipse(b, GetHandleRectangle(i));
            }
            //brush.Dispose();
            p.Dispose();
            b.Dispose();
        }
        #endregion Selection handle methods

        #region Connection Point methods
        
        public virtual Point GetConnection(int connectionNumber)
        {
            return new Point(0, 0);
        }
        
        public virtual Rectangle GetConnectionEllipse(int connectionNumber)
        {
            Point p = GetConnection(connectionNumber);
            // Take into account width of pen
            return new Rectangle(p.X - (penWidth + 3), p.Y - (penWidth + 3), 7 + penWidth, 7 + penWidth);

        }
        public virtual void DrawConnection(Graphics g, int connectionNumber)
        {
            SolidBrush b = new SolidBrush(Color.Red);
            Pen p = new Pen(Color.Red, -1.0f);
            g.DrawEllipse(p, GetConnectionEllipse(connectionNumber));
            g.FillEllipse(b, GetConnectionEllipse(connectionNumber));
            p.Dispose();
            b.Dispose();
        }
        
        public virtual void DrawConnections(Graphics g)
        {
            if (!Selected)
                return;
            SolidBrush b = new SolidBrush(Color.Green);
            Pen p = new Pen(Color.Black, -1.0f);
            for (int i = 0; i < ConnectionCount; i++)
            {
                g.DrawEllipse(p, GetConnectionEllipse(i));
                g.FillEllipse(b, GetConnectionEllipse(i));
            }
            p.Dispose();
            b.Dispose();
        }
        #endregion Connection Point methods
        
        public virtual int HitTest(Point point)
        {
            return -1;
        }


      
        protected virtual bool PointInObject(Point point)
        {
            return false;
        }


        public virtual Cursor GetHandleCursor(int handleNumber)
        {
            return Cursors.Default;
        }

        
        public virtual bool IntersectsWith(Rectangle rectangle)
        {
            return false;
        }

       
        public virtual void Move(int deltaX, int deltaY)
        {
        }

        
        public virtual void MoveHandleTo(Point point, int handleNumber)
        {
        }

        
        public virtual void Dump()
        {
            Trace.WriteLine("");
            Trace.WriteLine(GetType().Name);
            Trace.WriteLine("Selected = " + selected.ToString(CultureInfo.InvariantCulture));
        }

   
        public virtual void Normalize()
        {
        }

        #region Save / Load methods
       
        public virtual void SaveToStream(SerializationInfo info, int orderNumber, int objectIndex)
        {
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryColor, orderNumber, objectIndex),
                Color.ToArgb());

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryPenWidth, orderNumber, objectIndex),
                PenWidth);

            info.AddValue(
                string.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryObjectType, orderNumber, objectIndex),
                ObjType);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryFillColor, orderNumber, objectIndex),
                FillColor.ToArgb());

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryfontcolor, orderNumber, objectIndex),
                FontColor.ToArgb());

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryFilled, orderNumber, objectIndex),
                Filled);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryZOrder, orderNumber, objectIndex),
                ZOrder);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryRotation, orderNumber, objectIndex),
                Rotation);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryTipText, orderNumber, objectIndex),
                tipText);
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryID, orderNumber, objectIndex),
                ID);
        }

        
        public virtual void LoadFromStream(SerializationInfo info, int orderNumber, int objectData)
        {
            int n = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryColor, orderNumber, objectData));

            Color = Color.FromArgb(n);

            PenWidth = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryPenWidth, orderNumber, objectData));

            ObjType = (ObjectType)info.GetValue(
                                                string.Format(CultureInfo.InvariantCulture,
                                                              "{0}{1}-{2}",
                                                              entryObjectType, orderNumber, objectData),
                                                typeof(ObjectType));

            n = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryFillColor, orderNumber, objectData));

            FillColor = Color.FromArgb(n);

            n = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryfontcolor, orderNumber, objectData));

            FontColor = Color.FromArgb(n);

            Filled = info.GetBoolean(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryFilled, orderNumber, objectData));

            ZOrder = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryZOrder, orderNumber, objectData));

            Rotation = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryRotation, orderNumber, objectData));

            tipText = info.GetString(String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryTipText, orderNumber, objectData));

            ID = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryID, orderNumber, objectData));

            
        }
        #endregion Save/Load methods
        #endregion Virtual Functions

        #region Other functions
     
        protected void Initialize()
        {
        }

       
        protected void FillDrawObjectFields(DrawObject drawObject)
        {
            drawObject.selected = selected;
            drawObject.color = color;
            drawObject.penWidth = penWidth;
            //drawObject._brushType = _brushType;
          
           // drawObject.drawBrush = drawBrush;
            //drawObject.drawpen = drawpen;
            drawObject.fillColor = fillColor;

            drawObject.ID = ID;
            drawObject.Name = Name;
            drawObject.Text = Text;

            drawObject._rotation = _rotation;
            drawObject._center = _center;
        }
        #endregion Other functions

        #region IComparable Members
      
        public int CompareTo(object obj)
        {
            DrawObject d = obj as DrawObject;
            int x = 0;
            if (d != null)
                if (d.ZOrder == ZOrder)
                    x = 0;
                else if (d.ZOrder > ZOrder)
                    x = -1;
                else
                    x = 1;

            return x;
        }
        #endregion IComparable Members
    }
}