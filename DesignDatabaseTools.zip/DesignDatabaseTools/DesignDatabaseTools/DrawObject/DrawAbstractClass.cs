﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Collections.Generic;


namespace DesignDatabaseTools.DrawObject
{
    class DrawAbstractClass : DrawClass
    {
             
        #region constructor

        public override DrawObject Clone()
		{
			DrawAbstractClass drawRectangle = new DrawAbstractClass();
			drawRectangle.rectangle = rectangle;

			FillDrawObjectFields(drawRectangle);
			return drawRectangle;
		}

        public DrawAbstractClass() : base()
		{
		}

        public DrawAbstractClass(int x, int y, int width, int height, Color lineColor, Color fillColor, bool filled, int lineWidth,DrawArea area)
            :base(x,y,width,height,lineColor,fillColor,filled,lineWidth,area)
		{

		}

        #endregion

        public void GepText()
        {
            base.GepText();
        }
        public override void Draw(Graphics g)
        {
            base.Draw(g, 1);
        }

    }
}
