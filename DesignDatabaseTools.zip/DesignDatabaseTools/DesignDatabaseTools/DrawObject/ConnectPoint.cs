﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Collections.Generic;

namespace DesignDatabaseTools.DrawObject
{
    //[Serializable]
     public class ConnectPoint
    {
        public List<DrawObject> association; //association lien ket toi
        public Point point;
        public Rectangle connect_area;

       public ConnectPoint()
        {
            association = new List<DrawObject>();
        }
    }
}
