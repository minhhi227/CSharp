﻿
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Collections.Generic;

using DesignDatabaseTools.Methods;
using DesignDatabaseTools.Tools;

namespace DesignDatabaseTools.DrawObject
{
    [Serializable]
    class DrawNary : DrawObject
    {
        #region Attributes
        public Rectangle rectangle;

        public Point p1;
        public Point p2;
        public Point p3;
        public Point p4;

        public int p1_flag = -1;
        public int p2_flag = -1;
        public int p3_flag = -1;
        public int p4_flag = -1;

        public DrawClass p1_class;
        public DrawClass p2_class;
        public DrawClass p3_class;
        public DrawClass p4_class;

        private DrawArea _Area;
        public bool connectbool = false;

		private const string entryRectangle = "Rect";
        private const string rolename = "rolename";
        private const string entryP1 = "p11";
        private const string entryP2 = "p21";
        private const string entryP3 = "p31";
        private const string entryP4 = "p41";
        private const string entrynMulP1 = "ni_mul_p1";
        private const string entrynMulP2 = "ni_mul_p2";
        private const string entrynMulP3 = "ni_mul_p3";
        private const string entrynMulP4 = "ni_mul_p4";

        int index_mul_p1 = -1;
        int index_mul_p2 = -1;
        int index_mul_p3 = -1;
        int index_mul_p4 = -1;

        SubFunction subfunction = new SubFunction();

        //public List<DrawObject> ListClass = new List<DrawObject>();       //list class
        public DrawAssociationClass AssClass;
        public List<ConnectPoint> ListConnectPoint = new List<ConnectPoint>();   //list nhung diem connectpoint
        //public bool connect = false;
        public int diemsang = -1;

        public DrawText[] list_mul = new DrawText[4];
        ToolObject tools = new ToolObject();

        private string Rolename;

        public string RoleName
        {
            get { return Rolename; }
            set { Rolename = value; }
        }

		public Rectangle Rectangle
		{
			get { return rectangle; }
			set { rectangle = value; }
		}

        public DrawArea Area
        {
            get { return _Area; }
            set { _Area = value; }
        }


        #endregion


        #region constructor

        public override DrawObject Clone()
		{
			DrawNary drawRectangle = new DrawNary ();
			drawRectangle.rectangle = rectangle;

			FillDrawObjectFields(drawRectangle);
			return drawRectangle;
		}

        public DrawNary ()
		{
			SetRectangle(0, 0, 1, 1);
		}

		
        public void DrawMulRole(DrawArea area)
        {
            string t;
            Color c = Color.Black;
            Font f = new Font("Tahoma", 10, FontStyle.Regular);

            t = "0..1";
            list_mul[0] = new DrawText(p1.X, p1.Y, 40, 20, t, f, c,Area);
            list_mul[1] = new DrawText(p2.X, p2.Y, 40, 20, t, f, c,Area);
            list_mul[2] = new DrawText(p3.X, p3.Y, 40, 20, t, f, c,Area);
            list_mul[3] = new DrawText(p4.X, p4.Y - 10, 40, 20, t, f, c,Area);

            tools.AddNewObject(area, list_mul[0], DrawObject.ObjectType.text);
            tools.AddNewObject(area, list_mul[1], DrawObject.ObjectType.text);
            tools.AddNewObject(area, list_mul[2], DrawObject.ObjectType.text);
            tools.AddNewObject(area, list_mul[3], DrawObject.ObjectType.text);

        }

        public DrawNary(int x, int y, int width, int height, Color lineColor, Color fillColor, bool filled, int lineWidth,DrawArea area)
		{
           
			Center = new Point(x + (width / 2), y + (height / 2));
            rectangle.Location = new Point(x, y);
            rectangle.Size = new Size(width, height);
           //thiet lap point

            List<Point> pp = subfunction.GetPointFormRect(Rectangle);
            Point[] Points = new Point[] { pp[0], pp[1], pp[2], pp[3] };

            p1 = subfunction.GetPointRect(pp[2], pp[0],50);
            p2 = subfunction.GetPointRect(pp[3], pp[1],50);
            p3 = subfunction.GetPointRect(pp[1], pp[3],50);
            p4 = subfunction.GetPointRect(pp[0], pp[2],50);

			Color = lineColor;
			FillColor = fillColor;
			Filled = filled;
			PenWidth = lineWidth;

            _Area = area;

            ListConnectPoint = subfunction.SetConnectPointNary(this);

            DrawMulRole(area);
			
		}

        #endregion

        public void turn_on_connect_point(Graphics g)
        {
            if (diemsang >= 0)
            {
                Rectangle temp1 = ListConnectPoint[diemsang].connect_area;
                g.DrawRectangle(new Pen(Color.Red, 3), temp1);
            }

        }


        // draw reangle
        public override void Draw(Graphics g)
		{
			Pen pen;
			Brush b = new SolidBrush(FillColor);                  //fill color
            Brush btext = new SolidBrush(Color);

			pen = new Pen(Color, PenWidth);  //add pen
		

			GraphicsPath gp = new GraphicsPath();
		    //ve hinh thoi
            List<Point> pp = subfunction.GetPointFormRect(Rectangle);
            Point[] Points = new Point[] { pp[0], pp[1], pp[2],pp[3]};
            gp.AddPolygon(Points);

            //add text
            Font f = new Font("Arial", 10, FontStyle.Regular);
            g.DrawString(Rolename, f, btext, new PointF(Rectangle.X + Rectangle.Width / 4, Rectangle.Y + Rectangle.Height / 4));

		

			g.DrawPath(pen, gp);            //add vao graphic
			if (Filled) g.FillPath(b, gp);  //fill

            g.DrawLine(pen, pp[0], p1);
            g.DrawLine(pen, pp[1], p2);
            g.DrawLine(pen, pp[3], p3);
            g.DrawLine(pen, pp[2], p4);

            if (Area != null)
            {
                for (int i = 0; i < list_mul.Length; i++)
                {
                    if (!Area.Graphics.exists(list_mul[i])) list_mul[i] = null;
                }
                Set_subitems();
            }

            turn_on_connect_point(g);

			gp.Dispose();
			pen.Dispose();
			b.Dispose();
		}

		protected void SetRectangle(int x, int y, int width, int height)
		{
            //TODO: set value

			rectangle.X = x;
			rectangle.Y = y;
			rectangle.Width = width;
			rectangle.Height = height;
		}

        #region Select effect

        public override int HandleCount
		{
            //TODO: get so diem connect
			get { return 12; }
		}
	
		public override int ConnectionCount
		{
            
			get { return HandleCount; }
		}
		public override Point GetConnection(int connectionNumber)
		{
            //TODO: tra ve diem connect dang nam giu
			return GetHandle(connectionNumber);
		}
		

		public override Point GetHandle(int handleNumber)
		{
            //TODO: get diem connect 
			int x, y, xCenter, yCenter;

			xCenter = rectangle.X + rectangle.Width / 2;
			yCenter = rectangle.Y + rectangle.Height / 2;
			x = rectangle.X;
			y = rectangle.Y;

			switch (handleNumber)
			{
				case 1:
					x = rectangle.X;
					y = rectangle.Y;
					break;
				case 2:
					x = xCenter;
					y = rectangle.Y;
					break;
				case 3:
					x = rectangle.Right;
					y = rectangle.Y;
					break;
				case 4:
					x = rectangle.Right;
					y = yCenter;
					break;
				case 5:
					x = rectangle.Right;
					y = rectangle.Bottom;
					break;
				case 6:
					x = xCenter;
					y = rectangle.Bottom;
					break;
				case 7:
					x = rectangle.X;
					y = rectangle.Bottom;
					break;
				case 8:
					x = rectangle.X;
					y = yCenter;
					break;
                case 9:
                    x = p1.X;
                    y = p1.Y;
                    break;
                case 10:
                    x = p2.X;
                    y = p2.Y;
                    break;
                case 11:
                    x = p3.X;
                    y = p3.Y;
                    break;
                case 12:
                    x = p4.X;
                    y = p4.Y;
                    break;
			}
			return new Point(x, y);
		}

		
		public override int HitTest(Point point)
		{
            //TODO: tra ve so ung voi diem dang nam giu
			if (Selected)
			{
				for (int i = 1; i <= HandleCount; i++)
				{
					if (GetHandleRectangle(i).Contains(point))
						return i;
				}
			}

			if (PointInObject(point))
				return 0;
			return -1;
		}

		protected override bool PointInObject(Point point)
		{
			return rectangle.Contains(point);
		}

		
		public override Cursor GetHandleCursor(int handleNumber)
		{
            //TODO: get con tro
			switch (handleNumber)
			{
				case 1:
					return Cursors.SizeNWSE;
				case 2:
					return Cursors.SizeNS;
				case 3:
					return Cursors.SizeNESW;
				case 4:
					return Cursors.SizeWE;
				case 5:
					return Cursors.SizeNWSE;
				case 6:
					return Cursors.SizeNS;
				case 7:
					return Cursors.SizeNESW;
				case 8:
					return Cursors.SizeWE;
                case 9:
                case 10:
                case 11:
                case 12:
                    return Cursors.SizeAll;
				default:
					return Cursors.Default;
			}
		}

		
		public override void MoveHandleTo(Point point, int handleNumber)
		{
            //TODO: ham di chuyen nut connect
			int left = Rectangle.Left;
			int top = Rectangle.Top;
			int right = Rectangle.Right;
			int bottom = Rectangle.Bottom;

			switch (handleNumber)
			{
				case 1:
					left = point.X;
					top = point.Y;
					break;
				case 2:
					top = point.Y;
					break;
				case 3:
					right = point.X;
					top = point.Y;
					break;
				case 4:
					right = point.X;
					break;
				case 5:
					right = point.X;
					bottom = point.Y;
					break;
				case 6:
					bottom = point.Y;
					break;
				case 7:
					left = point.X;
					bottom = point.Y;
					break;
				case 8:
					left = point.X;
					break;
                case 9:
                    p1 = point;
                    this.list_mul[0].rectangle.Location = point;
                    subfunction.GetObjectConnectPoint(this, Area.Graphics.GetListObject());  
                    break;
                case 10:
                    p2 = point;
                    this.list_mul[1].rectangle.Location = point;
                    subfunction.GetObjectConnectPoint(this, Area.Graphics.GetListObject());  
                    break;
                case 11:
                    p3 = point;
                    this.list_mul[2].rectangle.Location = point;
                    subfunction.GetObjectConnectPoint(this, Area.Graphics.GetListObject()); 
                    break;
                case 12:
                    p4 = point;
                    this.list_mul[3].rectangle.Location = point;
                    subfunction.GetObjectConnectPoint(this, Area.Graphics.GetListObject()); 
                    break;
			}
			Dirty = true;
            if (right - left >= 30 && bottom - top >= 30)
            {
                SetRectangle(left, top, right - left, bottom - top);  //reset lai 
            }

            ListConnectPoint = subfunction.SetConnectPointNary(this);

            KeepAssociation();
		}


		public override bool IntersectsWith(Rectangle rectangle)
		{
			return Rectangle.IntersectsWith(rectangle);
		}

		
		public override void Move(int deltaX, int deltaY)
		{
            KeepAssociation();

			rectangle.X += deltaX;
			rectangle.Y += deltaY;

            p1.X += deltaX;
            p1.Y += deltaY;

            p2.X += deltaX;
            p2.Y += deltaY;

            p3.X += deltaX;
            p3.Y += deltaY;

            p4.X += deltaX;
            p4.Y += deltaY;

            
            for(int i=0;i<list_mul.Length;i++)
            {
                if (list_mul[i] != null)
                {
                    list_mul[i].rectangle.X += deltaX;
                    list_mul[i].rectangle.Y += deltaY;
                }
            }


            subfunction.GetObjectConnectPoint(this, Area.Graphics.GetListObject());

            ListConnectPoint = subfunction.SetConnectPointNary(this);

			Dirty = true;
		}

		public override void Dump()
		{
			base.Dump();

			Trace.WriteLine("rectangle.X = " + rectangle.X.ToString(CultureInfo.InvariantCulture));
			Trace.WriteLine("rectangle.Y = " + rectangle.Y.ToString(CultureInfo.InvariantCulture));
			Trace.WriteLine("rectangle.Width = " + rectangle.Width.ToString(CultureInfo.InvariantCulture));
			Trace.WriteLine("rectangle.Height = " + rectangle.Height.ToString(CultureInfo.InvariantCulture));
		}

		
		public override void Normalize()
		{
			rectangle = GetNormalizedRectangle(rectangle);
		}

        #endregion

        #region Stream
        public override void SaveToStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryRectangle, orderNumber, objectIndex),
				rectangle);
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryP1, orderNumber, objectIndex),
               p1);

            info.AddValue(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entryP2, orderNumber, objectIndex),
              p2);

            info.AddValue(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entryP3, orderNumber, objectIndex),
              p3);

            info.AddValue(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entryP4, orderNumber, objectIndex),
              p4);
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              rolename, orderNumber, objectIndex),
                Rolename);
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entrynMulP1, orderNumber, objectIndex),
               Area.Graphics.GetIndex(list_mul[0]));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entrynMulP2, orderNumber, objectIndex),
               Area.Graphics.GetIndex(list_mul[1]));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entrynMulP3, orderNumber, objectIndex),
               Area.Graphics.GetIndex(list_mul[2]));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entrynMulP4, orderNumber, objectIndex),
               Area.Graphics.GetIndex(list_mul[3]));


			base.SaveToStream(info, orderNumber, objectIndex);
		}

		
		public override void LoadFromStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			rectangle = (Rectangle)info.GetValue(
									String.Format(CultureInfo.InvariantCulture,
												  "{0}{1}-{2}",
												  entryRectangle, orderNumber, objectIndex),
									typeof(Rectangle));

            p1 = (Point)info.GetValue(
                                  String.Format(CultureInfo.InvariantCulture,
                                                "{0}{1}-{2}",
                                                entryP1, orderNumber, objectIndex),
                                  typeof(Point));

            p2 = (Point)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  entryP2, orderNumber, objectIndex),
                                    typeof(Point));

            p3 = (Point)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  entryP3, orderNumber, objectIndex),
                                    typeof(Point));

            p4 = (Point)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  entryP4, orderNumber, objectIndex),
                                    typeof(Point));

            RoleName = info.GetString(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            rolename, orderNumber, objectIndex));

            index_mul_p1 = info.GetInt32(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entrynMulP1, orderNumber, objectIndex));
            index_mul_p2 = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entrynMulP2, orderNumber, objectIndex));
            index_mul_p3 = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entrynMulP3, orderNumber, objectIndex));
            index_mul_p4 = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entrynMulP4, orderNumber, objectIndex));

			base.LoadFromStream(info, orderNumber, objectIndex);
		}

        #endregion

        #region Helper Functions
        public static Rectangle GetNormalizedRectangle(int x1, int y1, int x2, int y2)
		{
			if (x2 < x1)
			{
				int tmp = x2;
				x2 = x1;
				x1 = tmp;
			}

			if (y2 < y1)
			{
				int tmp = y2;
				y2 = y1;
				y1 = tmp;
			}
			return new Rectangle(x1, y1, x2 - x1, y2 - y1);
		}

		public static Rectangle GetNormalizedRectangle(Point p1, Point p2)
		{
			return GetNormalizedRectangle(p1.X, p1.Y, p2.X, p2.Y);
		}

		public static Rectangle GetNormalizedRectangle(Rectangle r)
		{
			return GetNormalizedRectangle(r.X, r.Y, r.X + r.Width, r.Y + r.Height);
		}

        public void Set_subitems()
        {
            if (index_mul_p1 != -1)
            {
                list_mul[0] = (DrawText)Area.Graphics[index_mul_p1];
                index_mul_p1 = -1;
            }
            if (index_mul_p2 != -1)
            {
                list_mul[1] = (DrawText)Area.Graphics[index_mul_p2];
                index_mul_p2 = -1;
            }
            if (index_mul_p3 != -1)
            {
                list_mul[2] = (DrawText)Area.Graphics[index_mul_p3];
                index_mul_p3 = -1;
            }
            if (index_mul_p4 != -1)
            {
                list_mul[3] = (DrawText)Area.Graphics[index_mul_p4];
                index_mul_p4 = -1;
            }
        }

        public void SetSubItemPosition()
        {
        }

        public void KeepAssociation()
        {
            if (AssClass != null)
            {
                if (AssClass.start_flag == this.ID)
                {
                    AssClass.startPoint = ListConnectPoint[diemsang].point;
                }
                else if (AssClass.end_flag == this.ID)
                {
                    AssClass.endPoint = ListConnectPoint[diemsang].point;
                }
            }
        }

		#endregion Helper Functions
    }
}
