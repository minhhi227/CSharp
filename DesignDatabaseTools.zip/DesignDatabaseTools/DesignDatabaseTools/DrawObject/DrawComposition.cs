﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;

namespace DesignDatabaseTools.DrawObject
{
    class DrawComposition : DrawAssociation
    {
        

        #region Constructor

        public override DrawObject Clone() 
        {
            DrawComposition drawLine = new DrawComposition();
            drawLine.startPoint = startPoint;
            drawLine.endPoint = endPoint;

            FillDrawObjectFields(drawLine);
            return drawLine;
        }


        public DrawComposition() : base()
		{
            
		}


        public DrawComposition(int x1, int y1, int x2, int y2, Color lineColor, int lineWidth,DrawArea a)
		{
            base.DrawOthersAssociation(x1, y1, x2, y2, lineColor, lineWidth, a, 2);
		}

        #endregion

        public override void Draw(Graphics g)
        {
            base.Draw(g, 3);
        }


    }
}
