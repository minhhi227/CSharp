﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignDatabaseTools.DrawObject
{
   public class Attri
    {
        public string Name;
        private Attri.Type _type;
        private Attri.Kind _kind;

        public bool pk = false;
        public string striggername;
        public string multivaluename;
        public string composited;

        public enum Type
        {
            interger,
            varchar,
            boolean,
            number,
            decimals,
            array,
            multiset,
            datetime,
            doubles,
            floats,
            chars,
            objecttype
        }

        public enum Kind
        {
            multivalued,
            composite,
            derived,
            normal
        }

        public Attri.Type DataType
        {
            get { return _type; }
            set { _type = value; }
        }

        public Attri.Kind AttriKind
        {
            get { return _kind; }
            set { _kind = value; }
        }


        public Attri(string text, Attri.Type type)
        {
            this.Name = text;
            this.DataType = type;
        }
        public Attri()
        {
        }
    }
}
