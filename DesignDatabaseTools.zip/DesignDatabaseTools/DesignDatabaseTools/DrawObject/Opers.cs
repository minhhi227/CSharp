﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignDatabaseTools.DrawObject
{
    public class Opers
    {
        public string Name;
        public enum OpType
        {
           // constructor,
           // member,
            //statics,
            INTEGER,
            VARCHAR2,
            boolean,
            NUMBER,
            DECIMAL,
            array,
            multiset,
            TIMESTAMP,
            DOUBLE,
            FLOAT,
            CHAR,
            objecttype,
          //  function,
            procedure,
            NumberOfOperations
        }
        private Opers.OpType _type;
        public Opers.OpType OpTypes
        {
            get { return _type; }
            set { _type = value; }
        }
        public Opers()
        {
        }

        public Opers(string text, Opers.OpType type)
        {
            this.Name = text;
            this.OpTypes = type;
        }
       

    }
}
