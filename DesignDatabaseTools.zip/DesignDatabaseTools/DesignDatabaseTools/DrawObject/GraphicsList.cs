﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Reflection;
using System.Runtime.Serialization;
using System.Windows.Forms;

namespace DesignDatabaseTools.DrawObject
{
    [Serializable]
    public class GraphicsList
    {
        private ArrayList graphicsList;

        private bool _isDirty;

        public ArrayList GraphicsLi
        {
            get
            {
                return graphicsList;
            }
            set
            {
                graphicsList = value;
            }
        }

        public bool Dirty
        {
            get
            {
                if (_isDirty == false)
                {
                    foreach (DrawObject o in graphicsList)
                    {
                        if (o.Dirty)
                        {
                            _isDirty = true;
                            break;
                        }
                    }
                }
                return _isDirty;
            }
            set
            {
                foreach (DrawObject o in graphicsList)
                    o.Dirty = false;
                _isDirty = false;
                
            }
        }

      
        public IEnumerable<DrawObject> Selection
        {
            get
            {
                foreach (DrawObject o in graphicsList)
                {
                    if (o.Selected)
                    {
                        yield return o;
                        
                    }
                }
            }
        }

        private const string entryCount = "ObjectCount";
        private const string entryType = "ObjectType";

        public GraphicsList()
        {
            graphicsList = new ArrayList();
        }
        
        public void LoadFromStream(SerializationInfo info, int orderNumber)
        {
            graphicsList = new ArrayList();

            // Get number of DrawObjects in this GraphicsList
            int numberObjects = info.GetInt32(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}",
                              entryCount, orderNumber));

            for (int i = 0; i < numberObjects; i++)
            {
                string typeName;
                typeName = info.GetString(
                    String.Format(CultureInfo.InvariantCulture,
                                  "{0}{1}",
                                  entryType, i));

                object drawObject;
                drawObject = Assembly.GetExecutingAssembly().CreateInstance(
                    typeName);

                // Let the Draw Object load itself
                ((DrawObject)drawObject).LoadFromStream(info, orderNumber, i);

                graphicsList.Add(drawObject);
            }
        }

        
        public void SaveToStream(SerializationInfo info, int orderNumber)
        {
            // First store the number of DrawObjects in the list
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}",
                              entryCount, orderNumber),
                graphicsList.Count);
            // Next save each individual object
            int i = 0;
            foreach (DrawObject o in graphicsList)
            {
                info.AddValue(
                    String.Format(CultureInfo.InvariantCulture,
                                  "{0}{1}",
                                  entryType, i),
                    o.GetType().FullName);
                // Let each object save itself
                o.SaveToStream(info, orderNumber, i);
                i++;
            }
        }
        
        public void Draw(Graphics g)
        {
            //TODO: ham ve cac graphics trong graphiclist tu cuoi len dau

            int numberObjects = graphicsList.Count;

            for (int i = numberObjects - 1; i >= 0; i--)
            {
                DrawObject o;
                o = (DrawObject)graphicsList[i];

                if (o.IntersectsWith(Rectangle.Round(g.ClipBounds)))
                {
                  if(!o.Hide) o.Draw(g);
                }

                if (o.Selected)
                {
                    o.DrawTracker(g);
                    //o.DrawConnections(g);

                    float[] dashValues = { 3, 1, 3, 3 };
                    Pen pen = new Pen(Color.Blue, 1);
                    pen.DashPattern = dashValues;
                    switch (o.ObjType)
                    {
                        case DrawObject.ObjectType.Class:
                        case DrawObject.ObjectType.AbstractClass:
                            DrawClass c = (DrawClass)o;
                            g.DrawRectangle(pen, c.Rectangle);
                            break;
                        case DrawObject.ObjectType.text:
                        case DrawObject.ObjectType.insert_text:
                            DrawText t = (DrawText)o;
                            g.DrawRectangle(pen, t.Rectangle);
                            break;
                        case DrawObject.ObjectType.Binary:
                            DrawBinary b = (DrawBinary)o;
                            g.DrawRectangle(pen, b.Rectangle);
                            break;
                        case DrawObject.ObjectType.Nary:
                            DrawNary n = (DrawNary)o;
                            g.DrawRectangle(pen, n.Rectangle);
                            break;
                        case DrawObject.ObjectType.others:
                            DrawTriangle ti = (DrawTriangle)o;
                            g.DrawRectangle(pen, ti.Rectangle);
                            break;
                    }
                }
            }
        }

        
        public bool Clear()
        {
            bool result = (graphicsList.Count > 0);
            graphicsList.Clear();
            
            if (result)
                _isDirty = false;
            return result;
        }

      
        public int Count
        {
            get { return graphicsList.Count; }
        }
        
        public DrawObject this[int index]
        {
            get
            {
                if (index < 0 ||
                    index >= graphicsList.Count)
                    return null;

                return (DrawObject)graphicsList[index];
            }
        }

       
        public int SelectionCount
        {
            get
            {
                int n = 0;

                foreach (DrawObject o in graphicsList)
                {
                    if (o.Selected)
                        n++;
                }

                return n;
            }
        }

        public DrawObject GetSelectedObject(int index)
        {
            int n = -1;

            foreach (DrawObject o in graphicsList)
            {
                if (o.Selected)
                {
                    n++;

                    if (n == index)
                        return o;
                }
            }

            return null;
        }

        public DrawObject GetObject(int index)
        {
            int n = -1;
            foreach (DrawObject o in graphicsList)
            {
                n++;
                    if (n == index)
                        return o;
                
            }

            return null;
        }

        public DrawObject SelectedObject()
        {
            foreach (DrawObject o in graphicsList)
            {
                if (o.Selected)
                {
                        return o;
                }
            }

            return null;
        }

        public List<DrawObject> GetListObject()
        {
            List<DrawObject> listobj = new List<DrawObject>();
            foreach (DrawObject o in graphicsList)
            {
                listobj.Add(o);
            }

            return listobj;
        }

        public int GetIndex(DrawObject obj)
        {
            if (obj != null)
            {
                for (int i = 0; i < graphicsList.Count; i++)
                {
                    if ((DrawObject)graphicsList[i] == obj) return i;
                }
            }
            return -1;
        }

        public DrawObject GetLastObject()
        {
            DrawObject o =(DrawObject) graphicsList[graphicsList.Count - 1];
            return o;
        }

        public DrawObject GetLastAddedObject()
        {
            DrawObject o = (DrawObject)graphicsList[0];
            return o;
        }

        public List<DrawObject> ListSelected()
        {
            List<DrawObject> list = new List<DrawObject>();

            foreach (DrawObject o in graphicsList)
            {
                if (o.Selected)
                {
                    list.Add(o);
                }
            }

            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        public List<int> ListSelectedID()
        {
            List<int> list = new List<int>();

            foreach (DrawObject o in graphicsList)
            {
                if (o.Selected)
                {
                    list.Add(o.ID);
                }
            }

            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }



        public void Add(DrawObject obj)
        {
            graphicsList.Sort();
            foreach (DrawObject o in graphicsList)
                o.ZOrder++;

            graphicsList.Insert(0, obj);
            
        }

        public bool exists(DrawObject obj)
        {
            foreach (DrawObject o in graphicsList)
            {
                if (o == obj) return true;
            }
            return false;
        }

        public DrawObject GetObjectWithID(int id)
        {
            foreach (DrawObject o in graphicsList)
            {
                if (o.ID == id) return o;
            }
            return null;
        }

        public void Append(DrawObject obj)
        {
            graphicsList.Add(obj);
        }

        public void SelectInRectangle(Rectangle rectangle)
        {
            UnselectAll();

            foreach (DrawObject o in graphicsList)
            {
                if (o.IntersectsWith(rectangle))
                    o.Selected = true;
            }
        }

        public void UnselectAll()
        {
            foreach (DrawObject o in graphicsList)
            {
                o.Selected = false;
            }
        }

        public void UnHideAll()
        {
            foreach (DrawObject o in graphicsList)
            {
                o.Hide = false;
            }
        }

        public void SelectAll()
        {
            foreach (DrawObject o in graphicsList)
            {
                o.Selected = true;
            }
        }


        public void HideSelected()
        {
            foreach (DrawObject o in graphicsList)
            {
                if (o.Selected)
                {
                    o.Hide = true;
                    o.Selected = false;
                }
            }
        }

        public void DeleteSubObject(DrawObject obj,int i)
        {
           
        }

        public bool DeleteSelection()
        {
            bool result = false;
            
            int n = graphicsList.Count;

            for (int i = n - 1; i >= 0; i--)
            {
                if (((DrawObject)graphicsList[i]).Selected)
                {
                    DrawObject obj =(DrawObject)graphicsList[i];

                    switch (obj.ObjType)
                    {
                        case DrawObject.ObjectType.AssociationLine:
                            DrawAssociation ass = (DrawAssociation)obj;
                            graphicsList.Remove(ass.mul_left);
                            graphicsList.Remove(ass.mul_right);
                            graphicsList.Remove(ass.RoleName);
                            graphicsList.Remove(ass.role_right_tri);
                            graphicsList.Remove(ass.role_left_tri);
                            break;
                        case DrawObject.ObjectType.RecurcyLine:
                            DrawRecurcyLine re = (DrawRecurcyLine)obj;
                            graphicsList.Remove(re.mul1);
                            graphicsList.Remove(re.mul2);
                            graphicsList.Remove(re.RoleName);
                            break;
                        case DrawObject.ObjectType.Class:
                            DrawClass cl = (DrawClass)obj;
                            if (cl.Recurcys != null)
                            {
                                graphicsList.Remove(cl.Recurcys.mul1);
                                graphicsList.Remove(cl.Recurcys.mul2);
                                graphicsList.Remove(cl.Recurcys.RoleName);

                                graphicsList.Remove(cl.Recurcys);
                                i = GetIndex(cl);
                            }
                            break;
                        case DrawObject.ObjectType.Aggernation:
                        case DrawObject.ObjectType.Composition:
                            DrawAssociation agg = (DrawAssociation)obj;
                            graphicsList.Remove(agg.mul_left);
                            graphicsList.Remove(agg.mul_right);
                            graphicsList.Remove(agg.RoleName);
                            break;
                        case DrawObject.ObjectType.Generalization:
                            DrawAssociation ger = (DrawAssociation)obj;
                            graphicsList.Remove(ger.RoleName);
                            break;
                        case DrawObject.ObjectType.Binary:
                            DrawBinary b = (DrawBinary)obj;
                            foreach (DrawObject o in b.list_mul)
                            {
                                graphicsList.Remove(o);
                            }
                            break;
                        case DrawObject.ObjectType.Nary:
                            DrawNary nary = (DrawNary)obj;
                            foreach (DrawObject o in nary.list_mul)
                            {
                                graphicsList.Remove(o);
                            }
                            break;
                        case DrawObject.ObjectType.ExtraAssociation:
                            DrawExtraAssociation ex = (DrawExtraAssociation)obj;
                            graphicsList.Remove(ex.mul_left);
                            graphicsList.Remove(ex.mul_right);
                            graphicsList.Remove(ex.RoleName);
                            graphicsList.Remove(ex.role_right_tri);
                            graphicsList.Remove(ex.role_left_tri);
                            break;
                    }

                    graphicsList.RemoveAt(i);

                    result = true;
                }
            }
            if (result)
                _isDirty = true;
            return result;
        }


        public void DeleteObject(DrawObject obj)
        {
            for (int i = 0; i < graphicsList.Count; i++)
            {
                if ((DrawObject)graphicsList[i] == obj)
                {
                    graphicsList.RemoveAt(i);
                }
            }
        }

        public void DeleteHidedObject()
        {
            for (int i = 0; i < graphicsList.Count; i++)
            {
                DrawObject temp =(DrawObject)graphicsList[i];
                if (temp.Hide)
                {
                    //graphicsList.RemoveAt(i);
                    this.UnselectAll();
                    temp.Selected = true;
                    this.DeleteSelection();
                }
            }
        }

        public DrawObject GetObject(DrawObject obj)
        {
            for (int i = 0; i < graphicsList.Count; i++)
            {
                if ((DrawObject)graphicsList[i] == obj)
                {
                    return (DrawObject)graphicsList[i];
                }
            }
            return null;
        }

        public void DeleteLastAddedObject()
        {
            if (graphicsList.Count > 0)
            {
                graphicsList.RemoveAt(0);
            }
        }

       
        public void Replace(DrawArea area,int index, DrawObject obj)
        {
            if (index >= 0 && index < graphicsList.Count)
            {
                graphicsList.RemoveAt(index);
                graphicsList.Insert(index, obj);
            }
        }

       
        public void RemoveAt(int index)
        {
            graphicsList.RemoveAt(index);
        }

        
       
        public bool MoveSelectionToFront()
        {
            int n;
            int i;
            ArrayList tempList;

            tempList = new ArrayList();
            n = graphicsList.Count;

            // Read source list in reverse order, add every selected item
            // to temporary list and remove it from source list
            for (i = n - 1; i >= 0; i--)
            {
                if (((DrawObject)graphicsList[i]).Selected)
                {
                    tempList.Add(graphicsList[i]);
                    graphicsList.RemoveAt(i);
                }
            }

            // Read temporary list in direct order and insert every item
            // to the beginning of the source list
            n = tempList.Count;

            for (i = 0; i < n; i++)
            {
                graphicsList.Insert(0, tempList[i]);
            }
            if (n > 0)
                _isDirty = true;
            return (n > 0);
        }

        
        public bool MoveSelectionToBack()
        {
            int n;
            int i;
            ArrayList tempList;

            tempList = new ArrayList();
            n = graphicsList.Count;

            // Read source list in reverse order, add every selected item
            // to temporary list and remove it from source list
            for (i = n - 1; i >= 0; i--)
            {
                if (((DrawObject)graphicsList[i]).Selected)
                {
                    tempList.Add(graphicsList[i]);
                    graphicsList.RemoveAt(i);
                }
            }

            // Read temporary list in reverse order and add every item
            // to the end of the source list
            n = tempList.Count;

            for (i = n - 1; i >= 0; i--)
            {
                graphicsList.Add(tempList[i]);
            }
            if (n > 0)
                _isDirty = true;
            return (n > 0);
        }

       
    }
}
