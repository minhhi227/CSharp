﻿
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;
using System.Collections.Generic;

using DesignDatabaseTools.Methods;


namespace DesignDatabaseTools.DrawObject
{
   
	[Serializable]
	public class DrawClass : DrawObject
    {
        #region Attributes
        public Rectangle rectangle;

        public Rectangle rectName;
        public Rectangle rectAttribute;
        public Rectangle rectOperation;
        //resize point
        public Point p1;
        public Point p2;

        private const string entryRectangle = "Rect";
        private const string entryRectName = "RectName";
        private const string entryRectAtt = "RectAtt";
        private const string entryRectOpe= "RectOpe";

        private const string entryClassName = "ClassName";
        private const string entryListAtt = "Attributes";
        private const string entryListOpe = "Operations";

        private const string entryFontName = "FontName";
        private const string entryFontSize = "FontSize";
        private const string entryRecurcy = "Recurcy";
        private const string entrylistconnect = "listconnect";
        private const string entrylistattributes = "listattributes";
        private const string entrylistoperations = "listoperations";
        private const string entryattributekind = "attributekind";

        private const string entrylistattributesname = "listattributesname";
        private const string entrylistatrributekindname = "entrylistatrributekindname";
        private const string entrylistoperationsname = "listoperationsname";

        private const string entrylistpk = "listpk";

        private const string po1 = "p1";
        private const string po2 = "p2";

        //private int recurcy_index = -1;
        
        public string ClassName= "ClassName";
        private List<Attri> Attributes = new List<Attri>();
        private List<Opers> Operations=new List<Opers>();

        private List<Attri.Type> list_a_type = new List<Attri.Type>();
        private List<Attri.Kind> list_a_kind = new List<Attri.Kind>();
        private List<Opers.OpType> list_o_type = new List<Opers.OpType>();
        private List<string> list_a_name = new List<string>();
        private List<string> list_o_name = new List<string>();
        private List<string> list_a_kind_name = new List<string>();
        private List<bool> list_pk = new List<bool>();

        public string Att="Attributes";
        public string Ope="Operations";

        public bool final = false;

        public DrawRecurcyLine Recurcys;
        public int ID_recurcy=-1;

        //connect point
        public List<ConnectPoint> ListConnectPoint = new List<ConnectPoint>();   //list nhung diem connectpoint
        public List<int> ListObjectConnectIndex = new List<int>();

        SubFunction function = new SubFunction();
        public bool connect = false;
        public int diemsang=-1;

       public DrawAssociationClass associ;

        private DrawArea _area;

        public DrawArea Area
        {
            get { return _area; }
            set { _area = value; }
        }

        //public List<DrawObject> ListAssociation = new List<DrawObject>();   //list association

        private Font _font;

        public Rectangle Rectangle
        {
            get { return rectangle; }
            set { rectangle = value; }
        }

        public Rectangle RectangleName
		{
            get { return rectName; }
            set { rectName = value; }
		}

        public Rectangle RectangleAttribute
        {
            get { return rectAttribute; }
            set { rectAttribute = value; }
        }

        public Rectangle RectangleOperation
        {
            get { return rectOperation; }
            set { rectOperation = value; }
        }

        public List<Attri> ListAttribute
        {
            get { return Attributes; }
            set { Attributes = value; }
        }

        public List<Opers> ListOperation
        {
            get { return Operations; }
            set { Operations = value; }
        }

        public Font TheFont
        {
            get { return _font; }
            set { _font = value; }
        }
        #endregion


        #region constructor

        public override DrawObject Clone()
		{
			DrawClass drawRectangle = new DrawClass();
			drawRectangle.rectangle = rectangle;

			FillDrawObjectFields(drawRectangle);
			return drawRectangle;
		}

        public DrawClass()
		{
			SetRectangle(0, 0, 1, 1);
           
		}

	

        public DrawClass(int x, int y, int width, int height, Color lineColor, Color fillColor, bool filled, int lineWidth,DrawArea area)
		{
            _area = area;  // assign area

            Center = new Point(x + (width / 2), y + (height / 2));

            rectangle.Location = new Point(x, y);
            rectangle.Size = new Size(width, height);
            ClassName += number_class().ToString();
            
            rectName = new Rectangle(Rectangle.Location, new Size(Rectangle.Width, Rectangle.Height / 3));
            rectAttribute = new Rectangle(new Point(Rectangle.Location.X, Rectangle.Location.Y + Rectangle.Height / 3), new Size(Rectangle.Width, Rectangle.Height / 3));
            rectOperation = new Rectangle(new Point(Rectangle.Location.X, Rectangle.Location.Y + Rectangle.Height / 3 * 2), new Size(Rectangle.Width, Rectangle.Height / 3));

            p1 = new Point(RectangleName.X + RectangleName.Width / 2, RectangleName.Y + RectangleName.Height);
            p2 = new Point(RectangleAttribute.X + RectangleAttribute.Width / 2, RectangleAttribute.Y + RectangleAttribute.Height);

			Color = lineColor;
			FillColor = fillColor;
			Filled = filled;
            FontColor = area.FontColor;

            _font = new Font("Tahoma", 10);

			PenWidth = lineWidth;

            ListConnectPoint = function.ListConnectPoint(Rectangle);
            
		}

        #endregion

        public void GepText()
        {
            Att = "";
            Ope = "";

            if (ListAttribute != null)
            {
                for (int i = 0; i < ListAttribute.Count; i++)
                {
                    Att += ListAttribute[i].Name + "\n";
                }
            }

            if (ListOperation != null)
            {
                for (int i = 0; i < ListOperation.Count; i++)
                {
                    Ope += ListOperation[i].Name + "\n";
                }
            }
           
        }

        public void turn_on_connect_point(Graphics g)
        {
            if (connect == true)
            {
                SolidBrush brush = new SolidBrush(Color.Black);
                foreach (ConnectPoint p in ListConnectPoint)
                {
                    Rectangle temp = p.connect_area;
                    g.DrawLine(new Pen(Color.Green), temp.Location, new Point(temp.X + temp.Width, temp.Y + temp.Height));
                    g.DrawLine(new Pen(Color.Green), new Point(temp.X, temp.Y + temp.Height), new Point(temp.X + temp.Width, temp.Y));
                }
                if (diemsang >= 0)
                {
                    Rectangle temp1 = ListConnectPoint[diemsang].connect_area;
                    g.DrawRectangle(new Pen(Color.Red, 3), temp1);
                }
            }
        }

        #region DRAW
        //draw class
        public override void Draw(Graphics g)
		{
            if (list_a_name.Count > 0|| list_o_name.Count > 0)
            {
                //MessageBox.Show("hieu");
                setlist_a_o();
                list_a_name.Clear();
                list_a_type.Clear();
                list_o_name.Clear();
                list_o_type.Clear();
            }
            GepText();      //noi string
            ResizeRect(Rectangle.Y,p1,p2,Rectangle.Y+Rectangle.Height);
			Pen pen;
			Brush b = new SolidBrush(FillColor);                  //fill color
         
            Brush btext = new SolidBrush(FontColor);  
			pen = new Pen(Color, PenWidth);  //add pen
			
			GraphicsPath gp = new GraphicsPath();
			gp.AddRectangle(GetNormalizedRectangle(Rectangle));   //add rectangle
            if (Filled) g.FillPath(b, gp);  

            gp.AddRectangle(rectName);
            gp.AddRectangle(rectAttribute);
            gp.AddRectangle(rectOperation);

            Font f = new Font(TheFont.Name, TheFont.Size, FontStyle.Bold);
            g.DrawString(ClassName, f, btext, rectName);
            g.DrawString(Att, _font, btext, rectAttribute);
            g.DrawString(Ope, _font, btext, rectOperation);

            //ve connect point
            turn_on_connect_point(g);
			g.DrawPath(pen, gp);            //add vao graphic

            if (Area != null)
            {
                if (!Area.Graphics.exists(Recurcys))
                {
                    Recurcys = null;
                }
             
            }
            
			gp.Dispose();
			pen.Dispose();
			b.Dispose();
         
		}
        
        // draw object , abstractclass
        public void Draw(Graphics g,int flag)
        {
            if (list_a_name.Count > 0 || list_o_name.Count > 0)
            {
                setlist_a_o();
                list_a_name.Clear();
                list_a_type.Clear();
                list_o_name.Clear();
                list_o_type.Clear();
            }

            GepText();      //noi string
            ResizeRect(Rectangle.Y, p1, p2, Rectangle.Y + Rectangle.Height);
            Pen pen;
            Brush b = new SolidBrush(FillColor);                  //fill color
            Brush btext = new SolidBrush(FontColor);

            pen = new Pen(Color, PenWidth);  //add pen
        
            GraphicsPath gp = new GraphicsPath();
            gp.AddRectangle(GetNormalizedRectangle(Rectangle));   //add rectangle
            if (Filled) g.FillPath(b, gp);  //fill


            if (flag == 1)
            {
                gp.AddRectangle(rectName);
                gp.AddRectangle(rectAttribute);
                gp.AddRectangle(rectOperation);

                Font f = new Font(TheFont.Name, TheFont.Size, FontStyle.Bold);
                //g.DrawString("{abstract}", f, btext, rectName);

                g.DrawString(ClassName + "{abs}", f, btext, rectName);
                g.DrawString(Att, _font, btext, rectAttribute);
                g.DrawString(Ope, _font, btext, rectOperation);

            }
        
            //ve connect point
            
            turn_on_connect_point(g);
            g.DrawPath(pen, gp);            //add vao graphic
            
            gp.Dispose();
            pen.Dispose();
            b.Dispose();

        }
		protected void SetRectangle(int x, int y, int width, int height)
		{
            //TODO: set value
			rectangle.X = x;
			rectangle.Y = y;
			rectangle.Width = width;
			rectangle.Height = height;
		}

        #endregion

        #region Select effect

        public override int HandleCount
		{
            //TODO: get so diem connect
			get { return 10; }
		}
	
		public override int ConnectionCount
		{
            
			get { return HandleCount; }
		}
		public override Point GetConnection(int connectionNumber)
		{
            //TODO: tra ve diem connect dang nam giu
			return GetHandle(connectionNumber);
		}
		

		public override Point GetHandle(int handleNumber)
		{
            //TODO: get diem connect 
			int x, y, xCenter, yCenter;

			xCenter = rectangle.X + rectangle.Width / 2;
			yCenter = rectangle.Y + rectangle.Height / 2;
			x = rectangle.X;
			y = rectangle.Y;

			switch (handleNumber)
			{
				case 1:
					x = rectangle.X;
					y = rectangle.Y;
					break;
				case 2:
					x = xCenter;
					y = rectangle.Y;
					break;
				case 3:
					x = rectangle.Right;
					y = rectangle.Y;
					break;
				case 4:
					x = rectangle.Right;
					y = yCenter;
					break;
				case 5:
					x = rectangle.Right;
					y = rectangle.Bottom;
					break;
				case 6:
					x = xCenter;
					y = rectangle.Bottom;
					break;
				case 7:
					x = rectangle.X;
					y = rectangle.Bottom;
					break;
				case 8:
					x = rectangle.X;
					y = yCenter;
					break;
                case 9:
                    x = p1.X;
                    y = p1.Y;
                    break;
                case 10:
                    x = p2.X;
                    y = p2.Y;
                    break;
			}
			return new Point(x, y);
		}

		
		public override int HitTest(Point point)
		{
            //TODO: tra ve so ung voi diem dang nam giu
			if (Selected)
			{
				for (int i = 1; i <= HandleCount; i++)
				{
					if (GetHandleRectangle(i).Contains(point))
						return i;
				}
			}

			if (PointInObject(point))
				return 0;
			return -1;
		}

		protected override bool PointInObject(Point point)
		{
			return rectangle.Contains(point);
		}

		
		public override Cursor GetHandleCursor(int handleNumber)
		{
            //TODO: get con tro
			switch (handleNumber)
			{
				case 1:
					return Cursors.SizeNWSE;
				case 2:
					return Cursors.SizeNS;
				case 3:
					return Cursors.SizeNESW;
				case 4:
					return Cursors.SizeWE;
				case 5:
					return Cursors.SizeNWSE;
				case 6:
					return Cursors.SizeNS;
				case 7:
					return Cursors.SizeNESW;
				case 8:
					return Cursors.SizeWE;
                case 9:
                case 10:
                    return Cursors.SizeNS;
				default:
					return Cursors.Default;
			}
		}

		
		public override void MoveHandleTo(Point point, int handleNumber)
		{
            //TODO: ham di chuyen nut connect
			int left = Rectangle.Left;
			int top = Rectangle.Top;
			int right = Rectangle.Right;
			int bottom = Rectangle.Bottom;

            Point temp_p1=p1;
            Point temp_p2=p2;

			switch (handleNumber)
			{
				case 1:
					left = point.X;
					top = point.Y;
                    temp_p1.X = left + (right - left) / 2;
                    temp_p2.X = left + (right - left) / 2;
					break;
				case 2:
                    if (point.Y < temp_p1.Y)
                    {
                        top = point.Y;
                    }
                    temp_p1.Y += (top - Rectangle.Top) / 2;
					break;
				case 3:
					right = point.X;
					top = point.Y;
                    temp_p1.X = left + (right - left) / 2;
                    temp_p2.X = left + (right - left) / 2;
					break;
				case 4:
					right = point.X;
                    temp_p1.X = left + (right - left) / 2;
                    temp_p2.X = left + (right - left) / 2;
					break;
				case 5:
					right = point.X;
					bottom = point.Y;
                    temp_p1.X = left + (right - left) / 2;
                    temp_p2.X = left + (right - left) / 2;
					break;
				case 6:
                    if (point.Y > temp_p2.Y)
                    {
                        bottom = point.Y;
                    }
                    temp_p2.Y += (bottom - Rectangle.Bottom) / 2;
					break;
				case 7:
					left = point.X;
					bottom = point.Y;
                    temp_p1.X = left + (right - left) / 2;
                    temp_p2.X = left + (right - left) / 2;
					break;
				case 8:
					left = point.X;
                    temp_p1.X = left + (right - left) / 2;
                    temp_p2.X = left + (right - left) / 2;
					break;
                case 9:
                    if (point.Y > top && point.Y < temp_p2.Y)
                    {
                        temp_p1.Y = point.Y;
                    }
                    break;
                case 10:
                    if (point.Y > temp_p1.Y && point.Y < bottom)
                    {
                        temp_p2.Y = point.Y;
                    }
                    break;
			}
			Dirty = true;

            if (right - left >= 100 && bottom - top >= 60)
            {
                p1 = temp_p1;
                p2 = temp_p2;
                SetRectangle(left, top, right - left, bottom - top);  //reset lai 
                ResizeRect(top, p1, p2, bottom);
                //connect point
                SetListConnect(this);
            }

            KeepAssociation();  
            
		}


		public override bool IntersectsWith(Rectangle rectangle)
		{
			return Rectangle.IntersectsWith(rectangle);
		}

		
		public override void Move(int deltaX, int deltaY)
		{
            this.set_connected_association();
            KeepAssociation();            //keo cac lien ket

			rectangle.X += deltaX;
			rectangle.Y += deltaY;

            p1.X += deltaX;
            p1.Y += deltaY;

            p2.X += deltaX;
            p2.Y += deltaY;
            
            //recurcy
            if (Recurcys != null)
            {
                Recurcys.startPoint.X += deltaX;
                Recurcys.startPoint.Y += deltaY;
                Recurcys.center1.X += deltaX;
                Recurcys.center1.Y += deltaY;
                Recurcys.center2.X += deltaX;
                Recurcys.center2.Y += deltaY;
                Recurcys.center3.X += deltaX;
                Recurcys.center3.Y += deltaY;
                Recurcys.center4.X += deltaX;
                Recurcys.center4.Y += deltaY;
                Recurcys.endPoint.X += deltaX;
                Recurcys.endPoint.Y += deltaY;

                Recurcys.mul1.rectangle.X += deltaX;
                Recurcys.mul1.rectangle.Y += deltaY;

                Recurcys.mul2.rectangle.X += deltaX;
                Recurcys.mul2.rectangle.Y += deltaY;

                Recurcys.RoleName.rectangle.X += deltaX;
                Recurcys.RoleName.rectangle.Y += deltaY;

                if (Recurcys.AssClass != null)
                {
                    if (Recurcys.AssClass.start_flag == Recurcys.ID)
                        {
                            Recurcys.AssClass.startPoint = Recurcys.ListConnectPoint[Recurcys.diemsang].point;
                        }
                    else if (Recurcys.AssClass.end_flag == Recurcys.ID)
                        {
                            Recurcys.AssClass.endPoint = Recurcys.ListConnectPoint[Recurcys.diemsang].point;
                        }
                    
                }
            }
            else
            {
                //MessageBox.Show(ID_recurcy.ToString());
                if (ID_recurcy != -1) Recurcys = (DrawRecurcyLine)Area.Graphics.GetObjectWithID(ID_recurcy);
            }

			Dirty = true;

            change_location();

            //connect point
            SetListConnect(this);

            if (Recurcys != null)
            {
                Recurcys.ListConnectPoint = function.SetConnectPointRec(Recurcys);
            }
		}

		public override void Dump()
		{
			base.Dump();

			Trace.WriteLine("rectangle.X = " + rectangle.X.ToString(CultureInfo.InvariantCulture));
			Trace.WriteLine("rectangle.Y = " + rectangle.Y.ToString(CultureInfo.InvariantCulture));
			Trace.WriteLine("rectangle.Width = " + rectangle.Width.ToString(CultureInfo.InvariantCulture));
			Trace.WriteLine("rectangle.Height = " + rectangle.Height.ToString(CultureInfo.InvariantCulture));
		}

		
		public override void Normalize()
		{
			rectangle = GetNormalizedRectangle(rectangle);
		}

        public int number_class()
        {
            int total=0;
                for (int i = 0; i < Area.Graphics.Count; i++)
                {
                    DrawObject obj = (DrawObject)Area.Graphics[i];
                    if (obj.ObjType == ObjectType.Class || obj.ObjType == ObjectType.AbstractClass) total++;
                }
         
            return total;
        }
        #endregion


        #region Effect Connect Point
      
        public void SetListConnect(DrawClass obj)
        {
            int i = 0;
            foreach(Point p in function.GetconnectPoint(obj.Rectangle))
            {
                if (ListConnectPoint.Count > 0)
                {
                    ListConnectPoint[i].point = p;
                    ListConnectPoint[i].connect_area = new Rectangle(p.X - 3, p.Y - 3, 7, 7);
                    i++;
                }
                else
                {
                    ListConnectPoint = function.ListConnectPoint(Rectangle);
                    break;
                }

                
            }
        }

        public void KeepAssociation()
        {
            foreach (ConnectPoint p in this.ListConnectPoint)
            {
                if (p.association.Count > 0)
                {
                    foreach (DrawObject ass in p.association)
                    {
                        switch (ass.ObjType)
                        {
                            case ObjectType.AssociationLine:
                            case ObjectType.Aggernation:
                            case ObjectType.Composition:
                            case ObjectType.AssociationClassLine:
                            case ObjectType.Generalization:
                                    DrawAssociation a = (DrawAssociation)ass;
                                    if (a.start_flag == this.ID)
                                    {
                                        a.startPoint = p.point;
                                        a.SetSubItemPosition();
                                        a.ListConnectPoint = function.ListConnectPointAss(a.startPoint, a.endPoint);
                                        a.KeepAssociation();
                                    }
                                    else if (a.end_flag==this.ID)
                                    {
                                        a.endPoint = p.point;
                                        a.SetSubItemPosition();
                                        a.ListConnectPoint = function.ListConnectPointAss(a.startPoint, a.endPoint);
                                        a.KeepAssociation();
                                    }
                                   
                                    break;
                            case ObjectType.Binary:
                                    DrawBinary b = (DrawBinary)ass;
                                    if (b.p1_flag== this.ID)
                                    {
                                        b.p1 = p.point;
                                        b.list_mul[0].rectangle.Location = p.point;
                                    }
                                    else if (b.p2_flag == this.ID)
                                    {
                                        b.p2 = p.point;
                                        b.list_mul[1].rectangle.Location = p.point;
                                    }
                                    else if (b.p3_flag == this.ID)
                                    {
                                        b.p3 = p.point;
                                        b.list_mul[2].rectangle.Location = p.point;
                                    }
                                    break;
                            case ObjectType.Nary:
                                DrawNary n = (DrawNary)ass;
                                    if (n.p1_flag== this.ID)
                                    {
                                        n.p1 = p.point;
                                        n.list_mul[0].rectangle.Location = p.point;
                                    }
                                    else if (n.p2_flag == this.ID)
                                    {
                                        n.p2 = p.point;
                                        n.list_mul[1].rectangle.Location = p.point;
                                    }
                                    else if (n.p3_flag == this.ID)
                                    {
                                        n.p3 = p.point;
                                        n.list_mul[2].rectangle.Location = p.point;
                                    }
                                    else if (n.p4_flag == this.ID)
                                    {
                                        n.p4 = p.point;
                                        n.list_mul[3].rectangle.Location = p.point;
                                    }
                                    break;
                            case ObjectType.ExtraAssociation:
                                    DrawExtraAssociation ex = (DrawExtraAssociation)ass;
                                    if (ex.start_flag == this.ID)
                                    {
                                        ex.startPoint = p.point;
                                        ex.mul_left.rectangle.Location = p.point;
                                        ex.center2.Y = ex.startPoint.Y;
                                    }
                                    else if (ex.end_flag==this.ID)
                                    {
                                        ex.endPoint = p.point;
                                        ex.mul_right.rectangle.Location = p.point;
                                        ex.center1.Y = ex.endPoint.Y;
                                    }
                                    break;

                        }
                    }
                }
            }
          
         
        }

        #endregion


        #region Stream
        public override void SaveToStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              po1, orderNumber, objectIndex),
                p1);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              po2, orderNumber, objectIndex),
                p2);

			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryRectangle, orderNumber, objectIndex),
				rectangle);
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryRectName, orderNumber, objectIndex),
                rectName);
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryRectAtt, orderNumber, objectIndex),
                rectAttribute);
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryRectOpe, orderNumber, objectIndex),
                rectOperation);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryClassName, orderNumber, objectIndex),
                ClassName);
       

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryFontName, orderNumber, objectIndex),
                _font.Name);
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryFontSize, orderNumber, objectIndex),
                _font.Size);

            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRecurcy, orderNumber, objectIndex),
               ID_recurcy);
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entrylistconnect, orderNumber, objectIndex),
               Set_list_connect_index());

            //save list attributes and operations

            info.AddValue(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entrylistattributes, orderNumber, objectIndex),
              get_a_type(ListAttribute));

            info.AddValue(
            String.Format(CultureInfo.InvariantCulture,
                          "{0}{1}-{2}",
                          entryattributekind, orderNumber, objectIndex),
            get_a_kind(ListAttribute));

            info.AddValue(
            String.Format(CultureInfo.InvariantCulture,
                          "{0}{1}-{2}",
                          entrylistpk, orderNumber, objectIndex),
            get_a_pk(ListAttribute));

            info.AddValue(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entrylistoperations, orderNumber, objectIndex),
              get_o_type(ListOperation));

            info.AddValue(
             String.Format(CultureInfo.InvariantCulture,
                           "{0}{1}-{2}",
                           entrylistattributesname, orderNumber, objectIndex),
             get_a_name(ListAttribute));

            info.AddValue(
             String.Format(CultureInfo.InvariantCulture,
                           "{0}{1}-{2}",
                           entrylistatrributekindname, orderNumber, objectIndex),
             get_a_kind_name(ListAttribute));

            info.AddValue(
              String.Format(CultureInfo.InvariantCulture,
                            "{0}{1}-{2}",
                            entrylistoperationsname, orderNumber, objectIndex),
             get_o_name(ListOperation));

			base.SaveToStream(info, orderNumber, objectIndex);
		}

		
		public override void LoadFromStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
            p1 = (Point)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  po1, orderNumber, objectIndex),
                                    typeof(Point));
            p2 = (Point)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  po2, orderNumber, objectIndex),
                                    typeof(Point));
            
			rectangle = (Rectangle)info.GetValue(
									String.Format(CultureInfo.InvariantCulture,
												  "{0}{1}-{2}",
												  entryRectangle, orderNumber, objectIndex),
									typeof(Rectangle));
           rectName = (Rectangle)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  entryRectName, orderNumber, objectIndex), typeof(Rectangle));
           rectAttribute = (Rectangle)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  entryRectAtt, orderNumber, objectIndex), typeof(Rectangle));
           rectOperation = (Rectangle)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  entryRectOpe, orderNumber, objectIndex), typeof(Rectangle));
          ListObjectConnectIndex = (List<int>)info.GetValue(
                                   String.Format(CultureInfo.InvariantCulture,
                                                 "{0}{1}-{2}",
                                                 entrylistconnect, orderNumber, objectIndex), typeof(List<int>));
          list_a_type = (List<Attri.Type>)info.GetValue(
                                  String.Format(CultureInfo.InvariantCulture,
                                                "{0}{1}-{2}",
                                                entrylistattributes, orderNumber, objectIndex), typeof(List<Attri.Type>));

          list_a_kind = (List<Attri.Kind>)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entryattributekind, orderNumber, objectIndex), typeof(List<Attri.Kind>));

          list_a_kind_name = (List<string>)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entrylistatrributekindname, orderNumber, objectIndex), typeof(List<string>));

          list_pk = (List<bool>)info.GetValue(
                                   String.Format(CultureInfo.InvariantCulture,
                                                 "{0}{1}-{2}",
                                                 entrylistpk, orderNumber, objectIndex), typeof(List<bool>));

            
          list_o_type = (List<Opers.OpType>)info.GetValue(
                                  String.Format(CultureInfo.InvariantCulture,
                                                "{0}{1}-{2}",
                                                entrylistoperations, orderNumber, objectIndex), typeof(List<Opers.OpType>));
          

          list_a_name = (List<string>)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entrylistattributesname, orderNumber, objectIndex), typeof(List<string>));
          list_o_name = (List<string>)info.GetValue(
                                  String.Format(CultureInfo.InvariantCulture,
                                                "{0}{1}-{2}",
                                              entrylistoperationsname, orderNumber, objectIndex), typeof(List<string>));

            ClassName = info.GetString(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryClassName, orderNumber, objectIndex));


            string name = info.GetString(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryFontName, orderNumber, objectIndex));
            float size = (float)info.GetValue(
                                    String.Format(CultureInfo.InvariantCulture,
                                                  "{0}{1}-{2}",
                                                  entryFontSize, orderNumber, objectIndex),
                                    typeof(float));

            _font = new Font(name, size);

            ID_recurcy = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRecurcy, orderNumber, objectIndex));
         
			base.LoadFromStream(info, orderNumber, objectIndex);
		}

        #endregion

        #region Helper Functions
        public static Rectangle GetNormalizedRectangle(int x1, int y1, int x2, int y2)
		{
			if (x2 < x1)
			{
				int tmp = x2;
				x2 = x1;
				x1 = tmp;
			}

			if (y2 < y1)
			{
				int tmp = y2;
				y2 = y1;
				y1 = tmp;
			}
			return new Rectangle(x1, y1, x2 - x1, y2 - y1);
		}

		public static Rectangle GetNormalizedRectangle(Point p1, Point p2)
		{
			return GetNormalizedRectangle(p1.X, p1.Y, p2.X, p2.Y);
		}

		public static Rectangle GetNormalizedRectangle(Rectangle r)
		{
			return GetNormalizedRectangle(r.X, r.Y, r.X + r.Width, r.Y + r.Height);
		}

        public void AddAttributes(string t,Attri.Type type,Attri.Kind kind,string str,bool pk)
        {
            Attri a = new Attri();
            a.Name = t;
            a.DataType = type;
            a.AttriKind = kind;
            a.pk = pk;
            switch (kind)
            {
                case Attri.Kind.composite:
                    a.composited = str;
                    break;
                case Attri.Kind.derived:
                    a.striggername = str;
                    break;
                case Attri.Kind.multivalued:
                    a.multivaluename = str;
                    break;
                case Attri.Kind.normal:
                    break;
            }
            Attributes.Add(a);
        }

        public void AddOperation(string t, Opers.OpType type)
        {
            Opers a = new Opers();
            a.Name = t;
            a.OpTypes = type;
            Operations.Add(a);
        }

        public void setlist_a_o()
        {
           
            if (list_a_name.Count>0)
            {
                for (int i = 0; i < list_a_name.Count; i++)
                {
                   
                   AddAttributes(list_a_name[i], list_a_type[i], list_a_kind[i], list_a_kind_name[i], list_pk[i]);
                   
                }
            }
            if(list_o_name.Count>0)
            {
                for (int i = 0; i < list_o_name.Count; i++)
                {
                    AddOperation(list_o_name[i], list_o_type[i]);
                }
            }
        }

        public void ResizeRect(int top, Point p1, Point p2, int bottom)
        {
            rectName.Width = Rectangle.Width;
            rectName.Height = p1.Y - top;

            rectAttribute.Width = Rectangle.Width;
            rectAttribute.Height = p2.Y - p1.Y;

            rectOperation.Width = Rectangle.Width;
            rectOperation.Height = bottom - p2.Y;

            change_location();
        }

        public void change_location()
        {
            rectName.Location = Rectangle.Location;
            rectAttribute.Location = new Point(Rectangle.Location.X, p1.Y);
            rectOperation.Location = new Point(Rectangle.Location.X, p2.Y);
        }

        //get all connected object index
        public List<int> Set_list_connect_index()
        {
            List<int> list_index = new List<int>();
            foreach (ConnectPoint p in ListConnectPoint)
            {
                if (p.association.Count > 0)
                {
                    foreach (DrawObject ass in p.association)
                    {
                        list_index.Add(ass.ID);
                    }
                }

            }
            return list_index;
        }
        //set all connected object 


        public void set_connected_association()
        {
            SetListConnect(this);

            if (ListObjectConnectIndex != null)
            {
                foreach (int i in ListObjectConnectIndex)
                {
                    DrawObject ass = Area.Graphics.GetObjectWithID(i);
                    if (ass != null)
                    {
                        switch (ass.ObjType)
                        {
                            case ObjectType.AssociationLine:
                            case ObjectType.Aggernation:
                            case ObjectType.Composition:
                            case ObjectType.AssociationClassLine:
                            case ObjectType.Generalization:
                                DrawAssociation a = (DrawAssociation)ass;
                                foreach (ConnectPoint p in ListConnectPoint)
                                {
                                    if (function.CheckPointInRect(a.startPoint, p.connect_area))
                                    {
                                        a.start_flag = this.ID;
                                        a.start_class = this;
                                        p.association.Add(ass);
                                    }
                                    else if (function.CheckPointInRect(a.endPoint, p.connect_area))
                                    {
                                        a.end_flag = this.ID;
                                        a.end_class = this;
                                        p.association.Add(ass);
                                    }
                                }

                                break;
                            case ObjectType.Binary:
                                DrawBinary b = (DrawBinary)ass;
                                foreach (ConnectPoint p in ListConnectPoint)
                                {
                                    if (function.CheckPointInRect(b.p1, p.connect_area))
                                    {
                                        b.p1_class = this;
                                        b.p1_flag = this.ID;
                                        p.association.Add(ass);
                                    }
                                    else if (function.CheckPointInRect(b.p2, p.connect_area))
                                    {
                                        b.p2_class = this;
                                        b.p2_flag = this.ID;
                                        p.association.Add(ass);
                                    }
                                    else if (function.CheckPointInRect(b.p3, p.connect_area))
                                    {
                                        b.p3_class = this;
                                        b.p3_flag = this.ID;
                                        p.association.Add(ass);
                                    }
                                }
                                break;
                            case ObjectType.Nary:
                                DrawNary n = (DrawNary)ass;
                                foreach (ConnectPoint p in ListConnectPoint)
                                {
                                    if (function.CheckPointInRect(n.p1, p.connect_area))
                                    {
                                        n.p1_class = this;
                                        n.p1_flag = this.ID;
                                        p.association.Add(ass);
                                    }
                                    else if (function.CheckPointInRect(n.p2, p.connect_area))
                                    {
                                        n.p2_class = this;
                                        n.p2_flag = this.ID;
                                        p.association.Add(ass);
                                    }
                                    else if (function.CheckPointInRect(n.p3, p.connect_area))
                                    {
                                        n.p3_class = this;
                                        n.p3_flag = this.ID;
                                        p.association.Add(ass);
                                    }
                                    else if (function.CheckPointInRect(n.p4, p.connect_area))
                                    {
                                        n.p4_class = this;
                                        n.p4_flag = this.ID;
                                        p.association.Add(ass);
                                    }
                                }
                                break;
                            case ObjectType.ExtraAssociation:
                                DrawExtraAssociation ex = (DrawExtraAssociation)ass;
                                foreach (ConnectPoint p in ListConnectPoint)
                                {
                                    if (function.CheckPointInRect(ex.startPoint, p.connect_area))
                                    {
                                        ex.start_flag = this.ID;
                                        ex.start_class = this;
                                        p.association.Add(ass);
                                    }
                                    else if (function.CheckPointInRect(ex.endPoint, p.connect_area))
                                    {
                                        ex.end_flag = this.ID;
                                        ex.end_class = this;
                                        p.association.Add(ass);
                                    }
                                }
                                break;
                        }
                    }
                }

                ListObjectConnectIndex = null;
            }
        }

        //set attributes type and operations type
        public List<Attri.Type> get_a_type(List<Attri> l)
        {
            List<Attri.Type> ll = new List<Attri.Type>();
            for (int i = 0; i < l.Count; i++)
            {
                ll.Add(l[i].DataType);
            }
            return ll;
        }

        public List<bool> get_a_pk(List<Attri> l)
        {
            List<bool> ll = new List<bool>();
            for (int i = 0; i < l.Count; i++)
            {
                ll.Add(l[i].pk);
            }
            return ll;
        }

        public List<Opers.OpType> get_o_type(List<Opers> l)
        {
            List<Opers.OpType> ll = new List<Opers.OpType>();
            for (int i = 0; i < l.Count; i++)
            {
                ll.Add(l[i].OpTypes);
            }
            return ll;
        }

        public List<string> get_a_name(List<Attri> l)
        {
            List<string> ll = new List<string>();
            for (int i = 0; i < l.Count; i++)
            {
                ll.Add(l[i].Name);
            }
            return ll;
        }

        public List<Attri.Kind> get_a_kind(List<Attri> l)
        {
            List<Attri.Kind> ll = new List<Attri.Kind>();
            for (int i = 0; i < l.Count; i++)
            {
                ll.Add(l[i].AttriKind);
            }
            return ll;
        }


        public List<string> get_a_kind_name(List<Attri> l)
        {
            List<string> ll = new List<string>();
            for (int i = 0; i < l.Count; i++)
            {
                switch (l[i].AttriKind)
                {
                    case Attri.Kind.composite:
                        ll.Add(l[i].composited);
                        break;
                    case Attri.Kind.derived:
                        ll.Add(l[i].striggername);
                        break;
                    case Attri.Kind.multivalued:
                        ll.Add(l[i].multivaluename);
                        break;
                    case Attri.Kind.normal:
                        ll.Add("");
                        break;
                }
             
            }
            return ll;
        }


        public List<string> get_o_name(List<Opers> l)
        {
            List<string> ll = new List<string>();
            for (int i = 0; i < l.Count; i++)
            {
                ll.Add(l[i].Name);
            }
            return ll;
        }
		#endregion Helper Functions
	}
}


