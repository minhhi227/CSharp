﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Reflection;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;

using DesignDatabaseTools.Methods;
using DesignDatabaseTools.Tools;

namespace DesignDatabaseTools.DrawObject
{
   public class DrawRecurcyLine : DrawObject
    {
        #region Attributes

        public Point startPoint;
        public Point center1;
        public Point center2;
        public Point center3;
        public Point center4;

		public Point endPoint;

        public bool ConnectBool = false;

		private const string entryStart = "Start";
		private const string entryEnd = "End";
        private const string entryCenter1= "center1";
        private const string entryCenter2 = "center2";
        private const string entryCenter3 = "center3";
        private const string entryCenter4 = "center4";

        private const string entryMulLeft = "MulLeft";
        private const string entryMulRight = "MulRight";
        private const string entryRole = "RoleName";
        

		private GraphicsPath areaPath = null;
        public DrawAssociationClass AssClass = null;
		private Pen areaPen = null;
		private Region areaRegion = null;

        SubFunction func = new SubFunction();
        private DrawArea _Area;

        ToolObject tools = new ToolObject();

        public DrawClass recury_class;
        //public DrawClass end_class;

        public DrawText RoleName;
        public DrawText mul1;
        public DrawText mul2;

        int index_mul_left = -1;
        int index_mul_right = -1;
        int index_role = -1;

        //public int start_flag = -1;      //xac dinh connect dau hay cuoi
        //public int end_flag = -1;

        //public List<DrawObject> ListMultiplicity = new List<DrawObject>();       //list multiplicity
        //public List<DrawObject> ListClass = new List<DrawObject>();       //list class

        public List<ConnectPoint> ListConnectPoint = new List<ConnectPoint>();   //list nhung diem connectpoint
        public bool connect = false;
        public int diemsang = -1;

        #endregion

        #region Get/Set Function

        public DrawArea Area
        {
            get { return _Area; }
            set { _Area = value; }
        }

        protected GraphicsPath AreaPath
        {
            get { return areaPath; }
            set { areaPath = value; }
        }

        protected Pen AreaPen
        {
            get { return areaPen; }
            set { areaPen = value; }
        }

        protected Region AreaRegion
        {
            get { return areaRegion; }
            set { areaRegion = value; }
        }
        #endregion

        #region Constructor


        public override DrawObject Clone()
        {
            DrawRecurcyLine drawLine = new DrawRecurcyLine();
            drawLine.startPoint = startPoint;
            drawLine.endPoint = endPoint;
        

            FillDrawObjectFields(drawLine);
            return drawLine;
        }


        public DrawRecurcyLine()
		{
            startPoint = new Point(0, 0);
            endPoint = new Point(1, 1);
			ZOrder = 0;

			Initialize();
		}

		public DrawRecurcyLine(int x1, int y1, int x2, int y2)
		{
            Center = new Point((x1 + x2) / 2, (y1 + y2) / 2);
            startPoint = new Point(x1, y1);
            endPoint = new Point(x2, y2);
			ZOrder = 0;
			
			Initialize();
		}

      

        public DrawRecurcyLine(Point start,Point end, Color lineColor, int lineWidth,DrawArea area)
		{
            Center = new Point(center1.X, (center1.Y+center2.Y)/2);
            startPoint = start;
            endPoint = end;
            center1 = new Point(startPoint.X, startPoint.Y - 20);
            center2 = new Point(endPoint.X + 20, center1.Y);
            center3 = new Point(center2.X, endPoint.Y);
            center4 = endPoint;

            //add role, multiplicity
            string t;
            Color c = Color.Black;
            Font f = new Font("Tahoma", 10, FontStyle.Regular);

            t = "0..1";
            mul1 = new DrawText(startPoint.X-30, startPoint.Y - 15, 40, 20, t, f, c,Area);
            mul2 = new DrawText(endPoint.X +5 , endPoint.Y + 5, 40, 20, t, f, c,Area);
            tools.AddNewObject(area, mul1, DrawObject.ObjectType.text);
            tools.AddNewObject(area, mul2, DrawObject.ObjectType.text);

            t = "role";
            RoleName = new DrawText(center1.X+10, center1.Y - 15, 40, 20, t, f, c,Area);
            tools.AddNewObject(area, RoleName, DrawObject.ObjectType.text);

            if (recury_class == null)
            {
                recury_class = (DrawClass)area.Graphics.GetObjectWithID(area.ID_class_recurcy); ;
                recury_class.ID_recurcy = area.Graphics.Count+1;
                recury_class.Recurcys = this;
                
            }

            ListConnectPoint = func.SetConnectPointRec(this);

			Color = lineColor;
			PenWidth = lineWidth;
			ZOrder = 0;
            

            _Area = area;

            

			Initialize();
		}


        public void turn_on_connect_point(Graphics g)
        {
            if (connect == true && this.ObjType == ObjectType.RecurcyLine)
            {
                SolidBrush brush = new SolidBrush(Color.Black);
                foreach (ConnectPoint p in ListConnectPoint)
                {
                    Rectangle temp = p.connect_area;
                    g.DrawLine(new Pen(Color.Green), temp.Location, new Point(temp.X + temp.Width, temp.Y + temp.Height));
                    g.DrawLine(new Pen(Color.Green), new Point(temp.X, temp.Y + temp.Height), new Point(temp.X + temp.Width, temp.Y));
                }
                if (diemsang >= 0)
                {
                    Rectangle temp1 = ListConnectPoint[diemsang].connect_area;
                    g.DrawRectangle(new Pen(Color.Red, 3), temp1);
                }
            }
        }


        #endregion
        
        //ham ve association
        public override void Draw(Graphics g)
		{
            //TODO: ham draw ve association
            
			g.SmoothingMode = SmoothingMode.AntiAlias;

			Pen pen;
			pen = new Pen(Color, PenWidth);
			
			
			GraphicsPath gp = new GraphicsPath();

            gp.AddLine(startPoint, center1);
            gp.AddLine(center1, center2);
            gp.AddLine(center2,center3);
            gp.AddLine(center3, center4);
            gp.AddLine(center4, endPoint);

            if (Area != null)
            {
                Set_subitems();
            }

            turn_on_connect_point(g);

			g.DrawPath(pen, gp);
			gp.Dispose();
			pen.Dispose();
		}

        
        #region Select effect

        public override int HandleCount
		{
			get { return 5; }
		}

		
		public override Point GetHandle(int handleNumber)
		{
            
			GraphicsPath gp = new GraphicsPath();
			Matrix m = new Matrix();
			gp.AddLine(center1, center2);
			RectangleF pathBounds = gp.GetBounds();
			m.RotateAt(Rotation, new PointF(pathBounds.Left + (pathBounds.Width / 2), pathBounds.Top + (pathBounds.Height / 2)), MatrixOrder.Append);
			gp.Transform(m);
			Point start, end;
			start = Point.Truncate(gp.PathPoints[0]);
			end = Point.Truncate(gp.PathPoints[1]);
			gp.Dispose();
			m.Dispose();
		
            int x = startPoint.X;
            int y = startPoint.Y;

            switch (handleNumber)
            {
                case 1:
                    x = startPoint.X;
                    y = startPoint.Y;
                    break;
                case 2:
                    x = center1.X;
                    y = center1.Y;
                    break;
                case 3:
                    x = center2.X;
                    y = center2.Y;
                    break;
                case 4:
                    x = center3.X;
                    y = center3.Y;
                    break;
                case 5:
                    x = center4.X;
                    y = center4.Y;
                    break;
                case 6:
                    x = endPoint.X;
                    y = endPoint.Y;
                    break;

               
              
            }
            return new Point(x, y);
		}

		
		public override int HitTest(Point point)
		{
			if (Selected)
				for (int i = 1; i <= HandleCount; i++)
				{
					GraphicsPath gp = new GraphicsPath();
					gp.AddRectangle(GetHandleRectangle(i));
					bool vis = gp.IsVisible(point);
					gp.Dispose();
					if (vis)
						return i;
				}
			// OK, so the point is not on a selection handle, is it anywhere else on the line?
			if (PointInObject(point))
				return 0;
			return -1;
		}

		protected override bool PointInObject(Point point)
		{
			CreateObjects();
			return AreaRegion.IsVisible(point);
		}

		public override bool IntersectsWith(Rectangle rectangle)
		{
			CreateObjects();
			return AreaRegion.IsVisible(rectangle);
		}

		public override Cursor GetHandleCursor(int handleNumber)
		{
			switch (handleNumber)
			{
				case 1:
				case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                    return Cursors.SizeAll;
				default:
					return Cursors.Default;
			}
		}

		public override void MoveHandleTo(Point point, int handleNumber)
		{

            switch (handleNumber)
            {
                case 1:
                case 6:
                    //startPoint.X = point.X;
                    break;
                case 2:
                    center1.Y = point.Y;
                    center2.Y = point.Y;
                    break;
                case 3:
                    center2.X = point.X;
                    center3.X = point.X;
                    break;
                case 4:
                    center3.Y = point.Y;
                    center4.Y = point.Y;
                    break;
                case 5:
                    center4.X = point.X;
                    endPoint.X = point.X;;
                    break;
                
              
            }

            //show connect point
            //func.GetObjectConnectPoint(this, Area.Graphics.GetListObject());
            ListConnectPoint = func.SetConnectPointRec(this);

			Dirty = true;
			Invalidate();
		}

		public override void Move(int deltaX, int deltaY)
		{
            /*
			startPoint.X += deltaX;
			startPoint.Y += deltaY;

			endPoint.X += deltaX;
			endPoint.Y += deltaY;

            center1.X += deltaX;
            center1.Y += deltaY;

            center2.X += deltaX;
            center2.Y += deltaY;

            //show connect point
            //MessageBox.Show("hieu");
            func.GetObjectConnectPoint(this, Area.Graphics.GetListObject());
            
			Dirty = true;
			Invalidate();
             */
		}

        #endregion

        #region Stream

        public override void SaveToStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryStart, orderNumber, objectIndex),
				startPoint);

            

			info.AddValue(
				String.Format(CultureInfo.InvariantCulture,
							  "{0}{1}-{2}",
							  entryEnd, orderNumber, objectIndex),
				endPoint);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryCenter1, orderNumber, objectIndex),
                center1);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryCenter2, orderNumber, objectIndex),
                center2);
            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryCenter3, orderNumber, objectIndex),
                center3);

            info.AddValue(
                String.Format(CultureInfo.InvariantCulture,
                              "{0}{1}-{2}",
                              entryCenter4, orderNumber, objectIndex),
                center4);
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulLeft, orderNumber, objectIndex),
               Area.Graphics.GetIndex(mul1));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulRight, orderNumber, objectIndex),
               Area.Graphics.GetIndex(mul2));
            info.AddValue(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRole, orderNumber, objectIndex),
               Area.Graphics.GetIndex(RoleName));

			base.SaveToStream(info, orderNumber, objectIndex);
		}

		public override void LoadFromStream(SerializationInfo info, int orderNumber, int objectIndex)
		{
			startPoint = (Point)info.GetValue(
									String.Format(CultureInfo.InvariantCulture,
												  "{0}{1}-{2}",
												  entryStart, orderNumber, objectIndex),
									typeof(Point));

			endPoint = (Point)info.GetValue(
								String.Format(CultureInfo.InvariantCulture,
											  "{0}{1}-{2}",
											  entryEnd, orderNumber, objectIndex),
								typeof(Point));

            center1 = (Point)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entryCenter1, orderNumber, objectIndex),
                                typeof(Point));

            center2 = (Point)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entryCenter2, orderNumber, objectIndex),
                                typeof(Point));
            center3 = (Point)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entryCenter3, orderNumber, objectIndex),
                                typeof(Point));

            center4 = (Point)info.GetValue(
                                String.Format(CultureInfo.InvariantCulture,
                                              "{0}{1}-{2}",
                                              entryCenter4, orderNumber, objectIndex),
                                typeof(Point));
            index_mul_left = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulLeft, orderNumber, objectIndex));
            index_mul_right = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryMulRight, orderNumber, objectIndex));
            index_role = info.GetInt32(
               String.Format(CultureInfo.InvariantCulture,
                             "{0}{1}-{2}",
                             entryRole, orderNumber, objectIndex));

			base.LoadFromStream(info, orderNumber, objectIndex);
		}

        #endregion

        #region Others function
        protected void Invalidate()
		{
			if (AreaPath != null)
			{
				AreaPath.Dispose();
				AreaPath = null;
			}

			if (AreaPen != null)
			{
				AreaPen.Dispose();
				AreaPen = null;
			}

			if (AreaRegion != null)
			{
				AreaRegion.Dispose();
				AreaRegion = null;
			}
		}

		
		protected virtual void CreateObjects()
		{
			if (AreaPath != null)
				return;

			AreaPath = new GraphicsPath();
		
			AreaPen = new Pen(Color.Black, PenWidth < 7 ? 7 : PenWidth);
		
			if (center2.Equals((Point)center3))
			{
				center2.X++;
				center2.Y++;
			}
			
            AreaPath.AddLine(center2.X, center2.Y, center3.X, center3.Y);
			AreaPath.Widen(AreaPen);
	
			if (Rotation != 0)
			{
				RectangleF pathBounds = AreaPath.GetBounds();
				Matrix m = new Matrix();
				m.RotateAt(Rotation, new PointF(pathBounds.Left + (pathBounds.Width / 2), pathBounds.Top + (pathBounds.Height / 2)), MatrixOrder.Append);
				AreaPath.Transform(m);
				m.Dispose();
			}

			// Create region from the path
			AreaRegion = new Region(AreaPath);
		}

        public void Set_subitems()
        {
            if (index_mul_left != -1)
            {
                mul1= (DrawText)Area.Graphics[index_mul_left];
                index_mul_left = -1;
            }
            if (index_mul_right != -1)
            {
                mul2 = (DrawText)Area.Graphics[index_mul_right];
                index_mul_right = -1;
            }
            if (index_role != -1)
            {
                RoleName = (DrawText)Area.Graphics[index_role];
                index_role = -1;
            }
           

        }
        #endregion

       
    }
}
