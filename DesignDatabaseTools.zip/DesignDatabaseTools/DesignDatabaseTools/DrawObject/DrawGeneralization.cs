﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.Serialization;
using System.Windows.Forms;

namespace DesignDatabaseTools.DrawObject
{
    class DrawGeneralization : DrawAssociation
    {
        //private Point startPoint;
		//private Point endPoint;

        #region Constructor

        public override DrawObject Clone() 
        {
            DrawGeneralization drawLine = new DrawGeneralization();
            drawLine.startPoint = startPoint;
            drawLine.endPoint = endPoint;

            FillDrawObjectFields(drawLine);
            return drawLine;
        }


        public DrawGeneralization() : base()
		{
            
		}

        public DrawGeneralization(int x1, int y1, int x2, int y2, Color lineColor, int lineWidth,DrawArea a)
        
		{
            base.DrawOthersAssociation(x1, y1, x2, y2, lineColor, lineWidth, a, 4);
		}

        #endregion

        public override void Draw(Graphics g)
        {
            base.Draw(g,1);
        }
    }
}
