﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Globalization;
using System.Security;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using Microsoft.Win32;
using System.Diagnostics;
using System.Threading;



using DesignDatabaseTools.MainFuction;
using Word = Microsoft.Office.Interop.Word;
using DesignDatabaseTools.Methods;
using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools
{
    public partial class ResultForm : Form
    {
        #region KeyWord

        public const string CreateType = "CREATE OR REPLACE TYPE ";
        public const string CreateTable = "CREATE TABLE ";
        public const string AsObject = "AS OBJECT ";
        public const string AsTable = "AS TABLE OF ";

        public const string Interger = "INTERGER";
        public const string Varchar2 = "VARCHAR";
        public const string Number = "NUMBER";
        public const string Date = "DATE";
        public const string Double = "DOUBLE";
        public const string Float = "FLOAT";
        public const string Decimal = "DECIMAL";
        public const string Datetime = "DATETIME";
        public const string Boolean = "BOOLEAN";
        public const string Char = "BOOLEAN";

        public const string Ref = "REF ";
        public const string Instantable = "INSTANTIABLE ";
        public const string Noninstantable = "NOT INSTANTIABLE ";
        public const string Final = "FINAL ";
        public const string NotFinal = "NOT FINAL ";
        public const string Under = "UNDER ";
        public const string Function = "MEMBER FUNCTION ";
        public const string Of = "OF ";
        public const string Array = "AS VARRAY";
        public const string NestedTable = "NESTED TABLE ";
        public const string StoreAs = "STORE AS ";

        public const string member = "MEMBER FUNCTION ";
        public const string statics = "STATIC FUNCTION ";
        public const string constrcutor = "CONSTRUCTOR FUNCTION ";

        #endregion

        #region members
        private List<PrimaryKey> pklist = new List<PrimaryKey>();
        private List<trigger> ptrigger = new List<trigger>();
       private List<string> final;
       private List<TableType> _Tables=new List<TableType>();
       private List<UDTDefinition> _UDTs=new List<UDTDefinition>();

       private List<string> attlist = new List<string>();
       private int width = 0;

        public List<string> FinalResult
        {
            get { return final; }
            set { final = value; }
        }

        public List<TableType> Tables
        {
            get { return _Tables; }
            set { _Tables = value; }
        }

        public List<UDTDefinition> UDTs
        {
            get { return _UDTs; }
            set { _UDTs = value; }
        }

        #endregion

        public ResultForm()
        {
            InitializeComponent();
            final = new List<string>();
         
        }

        private void ResultFormLoad(object sender, EventArgs e)
        {
            LoadText();

            AddDatatype();

            AddObjecttype();

            width = panelEx1.Width - ResultText.Width;
        }

        #region Event

        private void Save_Click(object sender, EventArgs e)
        {
           // Stream myStream;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory = @"F:\Users\MINHHIEU";
            saveFileDialog1.Title = "Save Files";
            //saveFileDialog1.CheckFileExists = true;
           // saveFileDialog1.CheckPathExists = true;
            saveFileDialog1.Filter = "Sql files (*.sql)|*.sql|Txt files (*.txt)|*.txt|Word Document (*.docx)|*.docx|PDF file (*.pdf)|*.pdf|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            DialogResult Result = saveFileDialog1.ShowDialog();//Show the dialog to save the file.
            //Test result and determine whether the user selected a file name from the saveFileDialog.
            if ((Result == DialogResult.OK) && (saveFileDialog1.FileName.Length > 0))
            {
                if (saveFileDialog1.FilterIndex == 1 
                    || saveFileDialog1.FilterIndex == 2
                    ||saveFileDialog1.FilterIndex == 5)
                {
                    StreamWriter sw = new StreamWriter(saveFileDialog1.FileName);
                    String[] contents = ResultText.Lines.ToArray();
                    for (int i = 0; i < contents.Length; i++)
                    {
                        sw.WriteLine(contents[i]);
                    }
                    sw.Close();
                }
                else if (saveFileDialog1.FilterIndex == 3)
                {
                    Word.Application oWord = new Word.Application();
                    oWord.Visible = true;
                    object oMissing = System.Reflection.Missing.Value;
                    Word.Document oDoc = oWord.Documents.Add (ref oMissing, ref oMissing,ref oMissing, ref oMissing);


                    Word.Paragraph oPara1;
                    oPara1 = oDoc.Paragraphs.Add(ref oMissing);
                    oPara1.Range.Text = ResultText.Text;
                    oPara1.Range.InsertParagraphAfter();

                    //save
                    object fileName = saveFileDialog1.FileName;
                    oDoc.SaveAs (ref fileName,
                    ref oMissing, ref oMissing,
                    ref oMissing, ref oMissing,
                    ref oMissing, ref oMissing,
                    ref oMissing, ref oMissing,
                    ref oMissing, ref oMissing);
                    
                        //oDoc.Close (ref oMissing, ref oMissing, ref oMissing);
                        //oWord.Quit(ref oMissing, ref oMissing, ref oMissing);
                        //oWord = null; // Free up any memory used

                }
                else
                {
                    //pdf file
                    Word.Application oWord = new Word.Application();
                    oWord.Visible = true;
                    object oMissing = System.Reflection.Missing.Value;
                    Word.Document oDoc = oWord.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);


                    Word.Paragraph oPara1;
                    oPara1 = oDoc.Paragraphs.Add(ref oMissing);
                    oPara1.Range.Text = ResultText.Text;
                    oPara1.Range.InsertParagraphAfter();

                    //save
                    object fileName = saveFileDialog1.FileName;
                    object SavePDFFormat = Word.WdSaveFormat.wdFormatPDF;

                    oDoc.SaveAs(ref fileName,
                    SavePDFFormat, ref oMissing,
                    ref oMissing, ref oMissing,
                    ref oMissing, ref oMissing,
                    ref oMissing, ref oMissing,
                    ref oMissing, ref oMissing);

                    //oDoc.Close(ref oMissing, ref oMissing, ref oMissing);
                    //oWord.Quit(ref oMissing, ref oMissing, ref oMissing);
                    //oWord = null; // Free up any memory used
                    
                }
              } 

        }

        static void WriteAllText(string path, string txt)
        {
            var bytes = Encoding.UTF8.GetBytes(txt);
            using (var f = File.OpenWrite(path))
            {
                f.Write(bytes, 0, bytes.Length);
               
            }
        }

        private void ResultText_TextChanged(object sender, EventArgs e)
        {

        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Preview_Click(object sender, EventArgs e)
        {
            //to do something
        }

        #endregion

        #region  text color

        private void showRed(String a)
        {
            Font font = new Font("Courier New", 9, FontStyle.Bold);
            ResultText.SelectionFont = font;
            ResultText.SelectionColor = Color.Red;
            ResultText.SelectedText = a;
        }
        private void showYellow(String a)
        {
            Font font = new Font("Courier New", 9, FontStyle.Regular);
            ResultText.SelectionFont = font;
            ResultText.SelectionColor = Color.Yellow;
            ResultText.SelectedText = a;
        }
        private void showGreen(String a)
        {
            Font font = new Font("Courier New", 9, FontStyle.Bold);
            ResultText.SelectionFont = font;
            ResultText.SelectionColor = Color.Green;
            ResultText.SelectedText = a;
        }

        private void showBlackBold(String a)
        {
            Font font = new Font("Courier New", 9, FontStyle.Bold);
            ResultText.SelectionFont = font;
            ResultText.SelectionColor = Color.Blue;
            ResultText.SelectedText = a;
        }
        private void showBlack(String a)
        {
            Font font = new Font("Courier New", 9, FontStyle.Regular);
            ResultText.SelectionFont = font;
            ResultText.SelectionColor = Color.Black;
            ResultText.SelectedText = a;
        }

        private void showBlackItalic(String a)
        {
            Font font = new Font("Courier New", 9, FontStyle.Regular);
            ResultText.SelectionFont = font;
            ResultText.SelectionColor = Color.Black;
            ResultText.SelectedText = a.ToUpper();
        }

        private void showBlacktable(String a)
        {
            Font font = new Font("Courier New", 9, FontStyle.Regular);
            richTextBoxAtt.Font = font;
            richTextBoxAtt.SelectionColor = Color.Black;
            richTextBoxAtt.SelectedText = a;
        }

        #endregion

        #region Load text

        public void CollectionType(UDTDefinition UDT)
        {
            //string nested_table = "";
            //create sub type of nested table
            foreach (UDTType ass in UDT.ListAssType)
            {
                if (!ass.alter)
                {
                    switch (ass.Type)
                    {
                        case UDTType._UDTType.multiset:
                            MultiSetType m = (MultiSetType)ass;
                            if (m.REFtype.Count > 0)
                            {

                                foreach (ReferenceType fff in m.REFtype)
                                {
                                    showBlackBold(CreateType);
                                    showBlack(" T_" + fff.ClassName + " ");
                                    showBlackBold(AsTable + " " + Ref);
                                    showBlack(" " + fff.ClassName + "_ob" + ";\n\n");

                                    ObjectType.Items.Add(" T_" + fff.ClassName);
                                }
                            }
                            else if (m.ListData.Count > 0)
                            {
                                foreach (ReferenceType fff in m.ListData)
                                {
                                    showBlackBold(CreateType);
                                    showBlack(" T_" + fff.ClassName + " ");
                                    showBlackBold(AsTable);
                                    showBlack(" " + fff.ClassName + "_ob" + ";\n\n");

                                    ObjectType.Items.Add(" T_" + fff.ClassName);
                                }
                            }

                           
                            break;
                        case UDTType._UDTType.array:
                            ArrayType a = (ArrayType)ass;
                            if (a.REFtype.Count > 0)
                            {
                                foreach (ReferenceType f in a.REFtype)
                                {
                                    showBlackBold(CreateType);
                                    showBlack("A_" + f.ClassName + " ");       // ten object
                                    showBlackBold(Array + " (" + GetMaxLength(a.MaxLength) + ") " + Of + Ref);
                                    showBlack(f.ClassName + "_ob;" + "\n\n");

                                    ObjectType.Items.Add("A_" + f.ClassName);
                                }
                            }
                            else if (a.ListData.Count > 0)
                            {
                                foreach (ReferenceType f in a.ListData)
                                {
                                    showBlackBold(CreateType);
                                    showBlack("A_" + f.ClassName + " ");       // ten object
                                    showBlackBold(Array + " (" + GetMaxLength(a.MaxLength) + ") " + Of);
                                    showBlack(f.ClassName + "_ob;" + "\n\n");

                                    ObjectType.Items.Add("A_" + f.ClassName);
                                }
                            }
                            break;
                    }
                }

            }
        }


        public void CollectionTypeAtrribute(UDTDefinition UDT)
        {
            if (UDT.ListBIT.Count > 0)
            {
                for (int i = 0; i < UDT.ListBIT.Count; i++)
                {
                    UDTType att = UDT.ListBIT[i];
                    builtInDataType built = (builtInDataType)att;
                    if (built.arr)
                    {
                        showBlackBold(CreateType);
                        showBlack("A_" + att.TypeName + " ");       // ten object
                        showBlackBold(Array + " (" + GetMaxLength(built.lengtharray.ToString()) + ") " + Of);
                        if (built.BuiltInType == builtInDataType.BuiltType.VARCHAR2)
                        {
                            showBlack(built.BuiltInType.ToString() + "(50)" + ";\n");
                        }
                        else if (built.BuiltInType == builtInDataType.BuiltType.DECIMAL)
                        {
                            showBlack(built.BuiltInType.ToString() + "(10,2)" + ";\n");
                        }
                        else
                        {
                            showBlack(built.BuiltInType.ToString() + ";\n");
                        }
                        ObjectType.Items.Add("A_" + att.TypeName);
                    }
                    else if (built.nes)
                    {
                        showBlackBold(CreateType);
                        showBlack(" T_" + att.TypeName + " ");
                        showBlackBold(AsTable + " ");
                        if (built.BuiltInType == builtInDataType.BuiltType.VARCHAR2)
                        {
                            showBlack(built.BuiltInType.ToString() + "(50)" + ";\n");
                        }
                        else if (built.BuiltInType == builtInDataType.BuiltType.DECIMAL)
                        {
                            showBlack(built.BuiltInType.ToString() + "(10,2)" + ";\n");
                        }
                        else
                        {
                            showBlack(built.BuiltInType.ToString() + ";\n");
                        }

                        ObjectType.Items.Add("T_" + att.TypeName);
                    }
                }
            }
        }

        public void CreateUnder(UDTDefinition UDT)
        {
            if (UDT.under)
            {
                showBlackBold(Under);
                showBlack(" " + UDT.UnderClass + "_ob" + " ");
            }
            else
            {
                showBlackBold(AsObject);
            }
            showBlack(" (" + "\n");
        }

        public void AddAttribute(UDTDefinition UDT)
        {
            if (UDT.ListBIT.Count > 0)
            {
                bool flag1 = false;
                bool flag2 = false;

                if (!CheckAlter(UDT))
                {
                    if (UDT.ListAssType.Count == 0 && UDT.methods.Count == 0) flag1 = true;
                }
                else
                {
                    if (UDT.methods.Count == 0) flag1 = true;
                }


                for (int i = 0; i < UDT.ListBIT.Count; i++)
                {
                    UDTType att = UDT.ListBIT[i];
                    
                    
                    if (i == UDT.ListBIT.Count - 1) flag2 = true;
                   
                    //add kieu thuoc tinh
                    switch (att.Type)
                    {
                        case UDTType._UDTType.BIT:
                            showBlack(att.TypeName + " ");
                            builtInDataType built = (builtInDataType)att;
                            showBlack("\t\t\t");
                            if (built.arr)
                            {
                                if (flag1 == true && flag2 == true) showBlackItalic("A_" + att.TypeName + "\n");
                                else showBlackItalic("A_" + att.TypeName + ",\n");
                            }
                            else if (built.nes)
                            {
                                if (flag1 == true && flag2 == true) showBlackItalic("T_" + att.TypeName + "\n");
                                else showBlackItalic("T_" + att.TypeName + ",\n");
                            }
                            else if (built.obj)
                            {
                              
                                if (flag1 == true && flag2 == true)
                                {
                                    showBlack(built.objectname + "_ob" + "\n");
                                }
                                else
                                {
                                    showBlack(built.objectname + "_ob" + ",\n");
                                }
                                   
                            }
                            else if (built.trig)
                            {
                                string tempstr = "";
                                if (built.BuiltInType == builtInDataType.BuiltType.VARCHAR2)
                                {
                                    tempstr = "(50)";
                                }
                                if (flag1 == true && flag2 == true) showBlackItalic(built.BuiltInType.ToString() + tempstr + "\n");
                                else showBlackItalic(built.BuiltInType.ToString() + tempstr + ",\n");

                                ptrigger.Add(new trigger(built.strigger,built.tablename));
                            }
                            else
                            {

                                if (built.pk) pklist.Add(new PrimaryKey(UDT.Identity, att.TypeName));  // add primary key

                                string tempstr = "";
                                if (built.BuiltInType == builtInDataType.BuiltType.VARCHAR2)
                                {
                                    tempstr = "(50)";
                                }
                                else if (built.BuiltInType == builtInDataType.BuiltType.DECIMAL)
                                {
                                    tempstr = "(10,2)";
                                }

                                if (flag1 == true && flag2 == true) showBlackItalic(built.BuiltInType.ToString() + tempstr + "\n");
                                else showBlackItalic(built.BuiltInType.ToString() + tempstr + ",\n");

                            }

                            break;


                    }
                }
            }

            
        }

        public string AddAssociation(UDTDefinition UDT, string nested_table)
        {
          

            if (UDT.ListAssType.Count > 0)
            {
                bool flag3 = false;
                bool flag4 = false;
                if (UDT.methods.Count == 0) flag3 = true;

                for (int i = 0; i < UDT.ListAssType.Count; i++)
                {
                    UDTType ass = UDT.ListAssType[i];

                    if (i == UDT.ListAssType.Count - 1) flag4 = true;
                    if (!ass.alter)
                    {
                        switch (ass.Type)
                        {
                            case UDTType._UDTType._ref:

                                ReferenceType ff = (ReferenceType)ass;
                                if (ff.direct)
                                {
                                    showBlack("ref_" + ff.RefName + "\t  ");       // ten object
                                }
                                else
                                {
                                    showBlack("ref_" + ff.RefName + "\t  " + Ref);   //composition
                                }
                                if (flag3 == true && flag4 == true)
                                {
                                    showBlack(ff.ClassName + "_ob" + "\n");
                                }
                                else showBlack(ff.ClassName + "_ob" + ",\n");

                                break;
                            case UDTType._UDTType.array:

                                ArrayType a = (ArrayType)ass;
                                if (a.REFtype.Count > 0)
                                {
                                    for (int iz = 0; iz < a.REFtype.Count; iz++)
                                    {
                                        ReferenceType f = a.REFtype[iz];
                                        if (iz == a.REFtype.Count - 1)
                                        {
                                            if (flag3 == true && flag4 == true)
                                            {
                                                showBlack("ref_" + f.RefName + "\t   " + "A_" + f.ClassName + "\n");
                                            }
                                            else
                                            {
                                                showBlack("ref_" + f.RefName + "\t   " + "A_" + f.ClassName + ",\n");
                                            }
                                        }
                                        else
                                        {
                                            showBlack("ref_" + f.RefName + "\t   " + "A_" + f.ClassName + ",\n");
                                        }

                                    }
                                }
                                else if (a.ListData.Count > 0)
                                {
                                    foreach (ReferenceType f in a.ListData)
                                    {
                                        showBlack("ref_" + f.RefName + "\t   " + "A_" + f.ClassName + "\n");
                                    }
                                }

                                break;
                            case UDTType._UDTType.multiset:
                                MultiSetType m = (MultiSetType)ass;
                                if (m.REFtype.Count > 0)
                                {
                                    foreach (ReferenceType fff in m.REFtype)
                                    {
                                        if (flag3 == true && flag4 == true)
                                        {
                                            showBlack("nested_" + fff.ClassName + "\t   " + "T_" + fff.ClassName + "\n");       // ten object
                                        }
                                        else
                                        {
                                            showBlack("nested_" + fff.ClassName + "   " + "T_" + fff.ClassName + ",\n");  
                                        }
                                        nested_table += NestedTable + "nested_" + fff.ClassName + " " + StoreAs + " " + fff.ClassName + "_Table" + " TABLESPACE users; \n";

                                    }
                                }
                                else if (m.ListData.Count > 0)
                                {
                                    foreach (ReferenceType fff in m.ListData)
                                    {
                                        if (flag3 == true && flag4 == true)
                                        {
                                            showBlack("nested_" + fff.ClassName + "   " + "T_" + fff.ClassName+"\n");       // ten object
                                        }
                                        else
                                        {
                                            showBlack("nested_" + fff.ClassName + "   " + "T_" + fff.ClassName +",\n"); 
                                        }
                                        nested_table += NestedTable + "nested_" + fff.ClassName + " " + StoreAs + " " + fff.ClassName + "_Table" + " TABLESPACE users; \n";

                                    }
                                }
                                break;
                            case UDTType._UDTType.objtype:
                                objecttype oo = (objecttype)ass;
                                showBlack("oo_" + UDT.Identity + " ");
                             
                                if (flag3 == true && flag4 == true)
                                {
                                    showBlack(oo.objname + "_ob" + "\n");
                                }
                                else showBlack(oo.objname + "_ob" + ",\n");
                                break;

                            case UDTType._UDTType.rowtype:
                                break;
                            case UDTType._UDTType.UDT:
                                UDTDefinition u = (UDTDefinition)ass;
                                LoadUDT(u);
                                break;
                        }
                    }

                }
            }

            return nested_table;
        }

        public void AddMethods(UDTDefinition UDT)
        {
            if (UDT.methods.Count > 0)
            {
                bool flag5 = false;
                for (int i = 0; i < UDT.methods.Count; i++)
                {
                    Opers method = UDT.methods[i];
                    if (i == UDT.methods.Count - 1) flag5 = true;

                    if (method.OpTypes == Opers.OpType.procedure)
                    {
                        if (flag5)
                        {
                            showBlackBold("MEMBER PROCEDURE ");
                            showBlack(method.Name + "\n");
                        }
                        else
                        {
                            showBlackBold("MEMBER PROCEDURE ");
                            showBlack(method.Name + ",\n");
                        }


                    }
                    else
                    {
                        string temp = "";
                        if (method.OpTypes == Opers.OpType.DECIMAL)
                        {
                            temp = "(10,2)";
                        }
                        else if (method.OpTypes == Opers.OpType.VARCHAR2)
                        {
                            temp = "(50)";
                        }

                        if (flag5)
                        {
                            showBlackBold("MEMBER FUNCTION ");
                            showBlack(method.Name);
                            showBlackBold(" RETURN ");
                            showBlack(method.OpTypes.ToString() +temp+ "\n");
                        }
                        else
                        {
                            showBlackBold("MEMBER FUNCTION ");
                            showBlack(method.Name);
                            showBlackBold(" RETURN ");

                            showBlack(method.OpTypes.ToString() + temp+",\n");
                        }
                    }



                }
            }

        }

        public void AddKeyWord(UDTDefinition UDT)
        {

            showBlack("\n" + ")");
            if (!UDT.instant) 
            showBlack(Noninstantable + " ");
            if (UDT.final) 
            showBlack(Final + " ");
            showBlack(";\n\n");
        }

        public bool check_exist_item(ComboBox cx, string t)
        {
            foreach (string tt in cx.Items)
            {
                if (t == tt) return true;
            }
            return false;
        }

        public void AddAlterType(UDTDefinition UDT)
        {

            //1. collection type

            foreach (UDTType ass in UDT.ListAssType)
            {
                if (ass.alter)
                {
                    switch (ass.Type)
                    {
                        case UDTType._UDTType.multiset:
                            MultiSetType m = (MultiSetType)ass;
                            if (m.REFtype.Count > 0)
                            {

                                foreach (ReferenceType fff in m.REFtype)
                                {
                                    if (!check_exist_item(ObjectType, " T_" + fff.ClassName))
                                    {
                                    showBlackBold(CreateType);
                                    showBlack(" T_" + fff.ClassName + " ");
                                    showBlackBold(AsTable + " " + Ref);
                                    showBlack(" " + fff.ClassName + "_ob" + ";\n\n");

                                    ObjectType.Items.Add(" T_" + fff.ClassName);
                                    }
                                }
                            }
                            else if (m.ListData.Count > 0)
                            {
                                foreach (ReferenceType fff in m.ListData)
                                {
                                    if (!check_exist_item(ObjectType, " T_" + fff.ClassName))
                                    {
                                        showBlackBold(CreateType);
                                        showBlack(" T_" + fff.ClassName + " ");
                                        showBlackBold(AsTable);
                                        showBlack(" " + fff.ClassName + "_ob" + ";\n\n");

                                        ObjectType.Items.Add(" T_" + fff.ClassName);
                                    }
                                }
                            }
                            break;
                        case UDTType._UDTType.array:
                            ArrayType a = (ArrayType)ass;
                            if (a.REFtype.Count > 0)
                            {
                                foreach (ReferenceType f in a.REFtype)
                                {
                                    if (!check_exist_item(ObjectType, "A_" + f.ClassName))
                                    {
                                        showBlackBold(CreateType);
                                        showBlack("A_" + f.ClassName + " ");       // ten object
                                        showBlackBold(Array + " (" + GetMaxLength(a.MaxLength) + ") " + Of + Ref);
                                        showBlack(f.ClassName + "_ob;" + "\n\n");

                                        ObjectType.Items.Add("A_" + f.ClassName);
                                    }
                                }
                            }
                            else if (a.ListData.Count > 0)
                            {
                                foreach (ReferenceType f in a.ListData)
                                {
                                    if (!check_exist_item(ObjectType, "A_" + f.ClassName))
                                    {
                                        showBlackBold(CreateType);
                                        showBlack("A_" + f.ClassName + " ");       // ten object
                                        showBlackBold(Array + " (" + GetMaxLength(a.MaxLength) + ") " + Of);
                                        showBlack(f.ClassName + "_ob;" + "\n\n");

                                        ObjectType.Items.Add("A_" + f.ClassName);
                                    }
                                }
                            }
                            break;
                    }
                }

            }

            //2. alter type

            if (UDT.ListAssType.Count > 0)
            {
                for (int i = 0; i < UDT.ListAssType.Count; i++)
                {
                    UDTType ass = UDT.ListAssType[i];
            
                    if (ass.alter)
                    {
                        showBlackBold("ALTER TYPE ");
                        switch (ass.Type)
                        {
                            case UDTType._UDTType._ref:

                                ReferenceType ff = (ReferenceType)ass;
                                showBlack(ff.altername + "_ob");
                                showBlackBold(" ADD ATTRIBUTE ");
                                if (ff.direct)
                                {
                                    showBlack("ref_" + ff.RefName + ff.ClassName + " ");       // ten object
                                }
                                else
                                {
                                    showBlack("ref_" + ff.RefName + ff.ClassName+" " + Ref);   //composition
                                }

                                showBlack(ff.ClassName +"_ob");
                                showBlackBold(" CASCADE; \n");
                                
                                break;
                            case UDTType._UDTType.array:

                                ArrayType a = (ArrayType)ass;
                                if (a.REFtype.Count > 0)
                                {
                                    for (int iz = 0; iz < a.REFtype.Count; iz++)
                                    {
                                        ReferenceType f = a.REFtype[iz];

                                        showBlack(f.altername + "_ob");
                                        showBlackBold(" ADD ATTRIBUTE ");

                                        if (iz == a.REFtype.Count - 1)
                                        {   
                                            showBlack("ref_" + f.RefName + "   " + "A_" + f.ClassName );
                                        }
                                        else
                                        {
                                            showBlack("ref_" + f.RefName + "   " + "A_" + f.ClassName );
                                        }

                                        showBlackBold(" CASCADE; \n");
                                    }
                                }
                                else if (a.ListData.Count > 0)
                                {
                                    foreach (ReferenceType f in a.ListData)
                                    {
                                        showBlack(f.altername + "_ob");
                                        showBlackBold(" ADD ATTRIBUTE ");
                                        showBlack("ref_" + f.ClassName + "   " + "A_" + f.ClassName );
                                        showBlackBold(" CASCADE; \n");
                                    }
                                }

                                break;
                            case UDTType._UDTType.multiset:
                                MultiSetType m = (MultiSetType)ass;
                                if (m.REFtype.Count > 0)
                                {
                                    foreach (ReferenceType fff in m.REFtype)
                                    {
                                        showBlack(fff.altername + "_ob");
                                        showBlackBold(" ADD ATTRIBUTE ");
                                        showBlack("nested_" + fff.ClassName + "   " + "T_" + fff.ClassName);       // ten object
                                        showBlackBold(" CASCADE; \n");

                                    }
                                }
                                else if (m.ListData.Count > 0)
                                {
                                    foreach (ReferenceType fff in m.ListData)
                                    {
                                        showBlack(fff.altername + "_ob");
                                        showBlackBold(" ADD ATTRIBUTE ");
                                        showBlack("nested_" + fff.ClassName + "   " + "T_" + fff.ClassName);       // ten object
                                        showBlackBold(" CASCADE; \n");
                                    }
                                }
                                break;
                            case UDTType._UDTType.objtype:
                                objecttype oo = (objecttype)ass;

                                 showBlack(oo.altername + "_ob");
                                 showBlackBold(" ADD ATTRIBUTE ");
                                 showBlack("oo_" + UDT.Identity + " ");
                                 showBlack(oo.objname + "_ob" );
                                 showBlackBold(" CASCADE; \n");
                               
                                break;
                            case UDTType._UDTType.rowtype:
                                break;
                            case UDTType._UDTType.UDT:
                                UDTDefinition u = (UDTDefinition)ass;
                                LoadUDT(u);
                                break;
                        }
                    }

                }
            }

        }

        
        public void LoadUDT(UDTDefinition UDT)
        {
            string nested_table = "";

            //1. create collection type 
            CollectionType(UDT);

            //2. create collectiontype attribute
            CollectionTypeAtrribute(UDT);
            
            //---------CREATE TYPE <<name>> AS OBJECT (-----------------
            showBlackBold(CreateType);
            showBlack(UDT.Identity + "_ob ");       // ten object

            //3. create Under
            CreateUnder(UDT);

            //4. add thuoc tinh

            AddAttribute(UDT);

            //5. add association

            nested_table = AddAssociation(UDT, nested_table);

            //6.add methods

            AddMethods(UDT);
            
            //6.add tu khoa (qualifiers)

            AddKeyWord(UDT);

            //7.nested table 
           // showBlack(nested_table);

            //8.add alter type 
            //AddAlterType(UDT);
              
        }


        public bool CheckAlter(UDTDefinition UDT)
        {
            for (int i = 0; i < UDT.ListAssType.Count; i++)
            {
                UDTType ass = UDT.ListAssType[i];

                if (ass.alter)
                {
                    return true;
                }
            }
            return false;
        }



        public void LoadText()
        {

            for (int i = UDTs.Count - 1; i >=0; i--)
            {
                UDTDefinition UDT = UDTs[i];
                if(CheckAlter(UDT))
                {
                LoadUDT(UDT);      //ham chay chinh load text len richtextbox
                }
              
            }
            for (int i = UDTs.Count - 1; i >= 0; i--)
            {
                UDTDefinition UDT = UDTs[i];
                if (!CheckAlter(UDT))
                {
                    LoadUDT(UDT);      //ham chay chinh load text len richtextbox
                }

            }

            //add alter type
            for (int i = UDTs.Count - 1; i >= 0; i--)
            {
                UDTDefinition UDT = UDTs[i];
                AddAlterType(UDT);      //ham chay chinh load text len richtextbox
             
            }

            showBlack("\n");
        
            foreach (TableType table in Tables)
            {
                //TODO: viet ra cac table
                showBlackBold("CREATE TABLE ");
                showBlack(table.Identity + "_Table ");
                showBlackBold(Of + " ");
                showBlack(table.Identity +"_ob" + ";\n\n");
            }

            foreach (PrimaryKey k in pklist)
            {
                showBlackBold("ALTER TABLE ");
                showBlack(k.classname + "_Table ");
                showBlackBold(" ADD CONSTRAINT ");
                showBlack(k.columnname + "_pk ");
                showBlackBold(" PRIMARY KEY ");
                showBlack("(" + k.columnname + "); \n");

            }

            foreach (trigger k in ptrigger)
            {
                showBlackBold("CREATE TRIGGER ");
                showBlack(k.triggername );
                showBlackBold(" AFTER INSERT OR UPDATE OF ");
                showBlack(k.classname + "_Table" );
                showBlackBold(" FOR EACH ROW \n BEGIN \n END ; \n");
               

            }

        }

        #endregion

        #region others function

        public string GetMaxLength(string text)
        {
            
            int start = 0;
            char[] chars = text.ToCharArray();
            for (int  i=0; i<chars.Length;i++)
            {
                if (chars[i] == '.')
                {
                    if (start == 0)
                    {
                        start = i;
                    }
                }
                
            }

            
            if (start != 0)
            {
                int lower_bound = Convert.ToInt32(text.Substring(0, start));
                int under_bound = Convert.ToInt32(text.Substring(start + 2, text.Length - (start + 2)));
                return (under_bound /*- lower_bound*/).ToString();
            }
            else return text;
        }

        #endregion

        private void GetSize(object sender, EventArgs e)
        {
            ResultText.Width = panelEx1.Width - width ;
            //groupPanel1.x = groupPanel1.Location.X + width;
        }

        #region create table

        private void getatt_Click(object sender, EventArgs e)
        {
            showBlacktable(Attributename.Text + "\t" + DataType.Text + "\n");
            attlist.Add(Attributename.Text + "\t" + DataType.Text);
        }

        private void addobject_Click(object sender, EventArgs e)
        {
            showBlacktable(Attributename.Text + "\t" + ObjectType.Text + " \n");
            attlist.Add(Attributename.Text + "\t" + ObjectType.Text);
        }

        private void OK_Click(object sender, EventArgs e)
        {
            showBlackBold("CREATE TABLE ");
            showBlack(NameTable.Text + " ( \n");
            for (int i = 0; i < attlist.Count; i++)
            {
                if (i == attlist.Count - 1)
                {
                    showBlack(attlist[i]  +"\n");
                }
                else {
                    showBlack(attlist[i] + ",\n");
                }
            }
            showBlack( " );\n");
        }

        private void remove_Click(object sender, EventArgs e)
        {
            richTextBoxAtt.Clear();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            ResultText.Clear();
        }

        #endregion


        #region help function

        public void AddDatatype()
        {
            List<string> datatype = new List<string> { "NUMBER", "VARCHAR2(50)", "INTEGER","TIMESTAMP","DECIMAL","DOUBLE",
                                                       "FLOAT","CHAR"};
            foreach (string str in datatype)
            {
                DataType.Items.Add(str);
                
            }
            DataType.Text = datatype[0];
        }

        public void AddObjecttype()
        {

            foreach (UDTDefinition u in UDTs)
            {
                string temp = u.Identity + "_ob";
                ObjectType.Items.Add(temp);

            }
            if (UDTs.Count > 0)
            {
                ObjectType.Text = UDTs[0].Identity + "_ob";
            }
        }

        #endregion

      
    
       

      
    }


    public class PrimaryKey
    {
        public string classname;
        public string columnname;

      public PrimaryKey(string str1, string str2)
        {
            classname = str1;
            columnname = str2;
        }
    }

    public class trigger
    {
        public string classname;
        public string triggername;

        public trigger(string str1, string str2)
        {
            classname = str2;
            triggername = str1;
        }
    }
}
