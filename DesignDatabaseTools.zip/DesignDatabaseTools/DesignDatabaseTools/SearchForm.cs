﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using DevComponents.DotNetBar;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools
{
    public partial class SearchForm : Form
    {
        private DrawArea _Area;
        private MainForm _Owner;

        public DrawArea Area
        {
            get { return _Area; }
            set { _Area = value; }

        }

        public MainForm Owner
        {
            get { return _Owner; }
            set { _Owner = value; }

        }

        private void Search_Load(object sender, EventArgs e)
        {
            List<string> list = new List<string> { "Class", "Abstract Class", "Association Class", "Association", "N-ary" };
            foreach (string str in list)
            {
                comboBoxEx.Items.Add(str);
                comboBoxEx.Text = list[0];
            }
        }

        public SearchForm()
        {
            InitializeComponent();
        }
        //TODO: CHECK CASE SENSITIVE -> FIND ALL
        private void OK_Click(object sender, EventArgs e)
        {
            List<string> result = new List<string>();
            foreach (DrawObject.DrawObject obj in Area.Graphics.GetListObject())
            {
                switch (comboBoxEx.Text)
                {
                    case "Class":
                        if (obj.ObjType == DrawObject.DrawObject.ObjectType.Class)
                        {
                            DrawClass a = (DrawClass)obj;
                            result.Add("(UML Class) : "+a.ClassName);
                        }
                        break;
                    case "Abstract Class":
                        if (obj.ObjType == DrawObject.DrawObject.ObjectType.AbstractClass)
                        {
                            DrawAbstractClass a = (DrawAbstractClass)obj;
                            result.Add("(UML Class) : "+a.ClassName);
                        }
                        break;
                    case "Association Class":
                        /*
                        if (obj.ObjType == DrawObject.DrawObject.ObjectType.Class)
                        {
                            DrawClass a = (DrawClass)obj;
                            result.Add(a.ClassName);
                        }
                         */
                        break;
                    case "Association":
                        if (obj.ObjType == DrawObject.DrawObject.ObjectType.AssociationLine
                            ||obj.ObjType== DrawObject.DrawObject.ObjectType.Aggernation
                            ||obj.ObjType== DrawObject.DrawObject.ObjectType.Composition
                            ||obj.ObjType== DrawObject.DrawObject.ObjectType.Generalization)
                        {
                            DrawAssociation a = (DrawAssociation)obj;
                            result.Add("(UML Association) : "+a.RoleName.TheText);
                        }
                        break;
                    case "N-ary":
                        if (obj.ObjType == DrawObject.DrawObject.ObjectType.Binary)
                        {
                            DrawBinary a = (DrawBinary)obj;
                            result.Add("(UML N-ary) : "+a.RoleName);
                        }
                        else if (obj.ObjType == DrawObject.DrawObject.ObjectType.Nary)
                        {
                            DrawNary a = (DrawNary)obj;
                            result.Add("(UML N-ary) : "+a.RoleName);
                        }
                        break;

                }
            }

            foreach (string str in result)
            {
                Owner.FindRichTextBox.Text += str +"\n";
            }
            
            //timer1.Interval = 500;
            //timer1.Enabled = true;
            MessageBoxEx.EnableGlass = false;
            MessageBoxEx.Show("<font color='#000000'>" + result.Count.ToString() +" Element(s) were found !" + "</font>", " Find Result ", MessageBoxButtons.OK, MessageBoxIcon.Information);
           
            this.Close();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

       
    }
}
