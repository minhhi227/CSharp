﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DesignDatabaseTools
{
    public partial class GroupInfo : Form
    {
        public GroupInfo()
        {
            InitializeComponent();
        }

        private void GroupInfoLoad(object sender, EventArgs e)
        {
            this.Information.Text = "  Student 1 : NGUYEN MINH HIEU     ID: 50800646 \n \n" +
                                    "  Student 2 : NGUYEN VAN HA             ID: 50800550 \n ";
        }

        private void Information_Click(object sender, EventArgs e)
        {

        }

        private void Information_Click_1(object sender, EventArgs e)
        {

        }

      
    }
}
