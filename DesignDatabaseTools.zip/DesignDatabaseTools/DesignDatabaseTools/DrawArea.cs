﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;

using DevComponents.WinForms;
using DevComponents.DotNetBar;

using DesignDatabaseTools.DrawObject;
using DockToolKit;
using DesignDatabaseTools.Tools;
using DesignDatabaseTools.Command;
using DesignDatabaseTools.Methods;
using DesignDatabaseTools.ToolsTab;


namespace DesignDatabaseTools
{
    
    public partial class DrawArea : UserControl
    {
        #region String Const
        public const string ErrorAttributes = " Error ! Attribute name is invalid ";
        public const string ErrorOperation = " Error ! Operation name is invalid ";
        Regex RegxPattern = new Regex("[^a-zA-Z0-9]");
        Regex RegxPatternOp = new Regex("[^a-zA-Z0-9]"+"("+"[^,a-zA-Z0-9]"+")");
        #endregion

        #region Constructor
        //apperance
        private float zoom = 1.0f;
        private float rotation = 0f;
        private int panX = 0;
        private int panY;
        private Point movepoint;
        private int originalPanY;
        private bool panning = false;
        private Point lastPoint;
        private Color lineColor = Color.Black;
        private Color fillColor = Color.White;
        private Color _FontColor = Color.Black;

        private bool drawFilled = false;
        private int lineWidth = -1;

        //recurcy
        public Point recur1;
        public Point recur2;
        public int ID_class_recurcy=-1;
        private DrawObject.DrawObject.ObjectType objecttype;
        private Attri.Type Datatype;
        private Font font;

        //command add
        private CommandAdd command_add;
        public int IndexAdd = -1;

        public enum DrawToolType
        {
            Pointer,
            Class,
            AbstractClass,
            Association,
            ExtraAssociation,
            Recurcy,
            AssociationClass,
            Binary,
            Nary,
            Generalization,
            Dynamic,
            Disjoint,
            Aggregation,
            Composition,
            Note,
            Image,
            Connector,
            text,
            insertText,
            NumberOfDrawTools
        } ;

        
        private MainForm owner;              // Information about owner form
        private DocManager docManager;
        private UndoManager undoManager;
        private ShowHide showhide = new ShowHide();

        private DrawToolType activeTool;     // active drawing tool
        private GraphicsList _graphicsList;
        private Layer ActiveLayer;
        private Tool[] tools;                 // array of tools
        public TextBox TextboxText=new TextBox();                  // textbox nhan du lieu
        SubFunction subfunction = new SubFunction();
        
        // group selection rectangle
        private Rectangle netRectangle;
        private bool drawNetRectangle = false;

        public DrawArea()
        {
            InitializeComponent();
            this.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.DrawArea_MouseWheel);
            Graphics = new GraphicsList();

            panning = false;
            panX = 0;
            panY = 0;
            //this.LineColor = Color.Red;
        }


        #endregion


        #region Get/Set Function

        public MainForm Owner
        {
            get { return owner; }
            set { owner = value; }
        }

        public DocManager DocManager
        {
            get { return docManager; }
            set { docManager = value; }
        }

        public DrawToolType ActiveTool
        {
            get { return activeTool; }
            set { activeTool = value; }
        }

        public GraphicsList Graphics
        {
            get { return _graphicsList; }
            set { _graphicsList = value; }
        }

        public Layer TheLayer
        {
            get { return ActiveLayer; }
            set { ActiveLayer = value; }
        }

        public Font Font
        {
            get { return font; }
            set { font = value; }
        }

    

        public DrawObject.DrawObject.ObjectType ObjectType
        {
            get { return objecttype; }
            set { objecttype = value; }
        }

        public int LineWidth
        {
            get { return lineWidth; }
            set { lineWidth = value; }
        }

        public Color FillColor
        {
            get { return fillColor; }
            set { fillColor = value; }
        }

        public Color LineColor
        {
            get { return lineColor; }
            set { lineColor = value; }
        }

        public Color FontColor
        {
            get { return _FontColor; }
            set { _FontColor = value; }
        }

        public Rectangle NetRectangle
        {
            get { return netRectangle; }
            set { netRectangle = value; }
        }

        
        public bool DrawNetRectangle
        {
            get { return drawNetRectangle; }
            set { drawNetRectangle = value; }
        }

         public int PanX
         {
              get { return panX; }
              set { panX = value; }
         }   

         public int PanY
         {
             get { return panY; }
             set { panY = value; }
         }
         public int OriginalPanY
         {
             get { return originalPanY; }
             set { originalPanY = value; }
         }

         public bool Panning
         {
             get { return panning; }
             set { panning = value; }
         }

         public float Rotation
         {
             get { return rotation; }
             set { rotation = value; }
         }


         public bool DrawFilled
         {
             get { return drawFilled; }
             set { drawFilled = value; }
         }


         public bool CanUndo
         {
             get
             {
                 if (undoManager != null)
                 {
                     return undoManager.CanUndo;
                 }

                 return false;
             }
         }

         
         public bool CanRedo
         {
             get
             {
                 if (undoManager != null)
                 {
                     return undoManager.CanRedo;
                 }

                 return false;
             }
         }

         

         public float Zoom
         {
             get { return zoom; }
             set { zoom = value; }
         }

         public Attri.Type DataType
         {
             get { return Datatype; }
             set { Datatype = value; }
         }

        #endregion

        
        #region others funtion
        private void DrawArea_MouseWheel(object sender, MouseEventArgs e)
        {
        }

        public void ClearHistory()
        {
            undoManager.ClearHistory();
        }

        public void Clear()
        {
               this.Graphics.Clear();
        }
        

        public Point BackTrackMouse(Point p)
        {
            // Backtrack the mouse...
            Point[] pts = new Point[] { p };
            Matrix mx = new Matrix();
            mx.Translate(-ClientSize.Width / 2f, -ClientSize.Height / 2f, MatrixOrder.Append);
            mx.Rotate(rotation, MatrixOrder.Append);
            mx.Translate(ClientSize.Width / 2f + panX, ClientSize.Height / 2f + panY, MatrixOrder.Append);
            mx.Scale(zoom, zoom, MatrixOrder.Append);
            mx.Invert();
            mx.TransformPoints(pts);
            return pts[0];
        }


        private void DrawArea_Load(object sender, EventArgs e)
        {
            //textbox
            TextboxText.Multiline = true;
            TextboxText.Name = "";
            TextboxText.Text = "";
            TextboxText.BorderStyle = BorderStyle.Fixed3D;
            this.Controls.Add(TextboxText);
            TextboxText.Show();
            TextboxText.Visible = false;
           

        }

        #endregion

        #region Event Handlers

        private void AreaMouseMove(object sender, MouseEventArgs e)
        {
            //TODO: xu ly di chuyen chuot tren Area
            //status
            Owner.ToadoX.Text = e.X.ToString();
            Owner.ToadoY.Text = e.Y.ToString();
            //ruler
            Owner.Ruler.p = e.Location;
            Owner.Ruler1.p = e.Location;

            //Rectangle ruler = this.Bounds;
            Point curLoc = BackTrackMouse(e.Location);

            if (e.Button == MouseButtons.Left || e.Button == MouseButtons.None)
            {
                if (e.Button == MouseButtons.Left && panning)
                {
                    if (curLoc.X != lastPoint.X)
                        panX += curLoc.X - lastPoint.X;
                    if (curLoc.Y != lastPoint.Y)
                        panY += curLoc.Y - lastPoint.Y;
                    Cursor = Cursors.SizeAll;
                    //this.Location = new Point(ruler.X += curLoc.X - movepoint.X, ruler.Y += curLoc.Y - movepoint.Y);

                    Invalidate();
                }
                else
                    tools[(int)activeTool].OnMouseMove(this, e);
            }
            else
            {
                Cursor = Cursors.Default;
            }

            lastPoint = BackTrackMouse(e.Location);
            //tooltip
            tooltip(e.Location);
            
        }

        private void Area_Paint(object sender, PaintEventArgs e)
        {
            //TODO: xu ly ve tren Area
           
            Matrix mx = new Matrix();
            mx.Translate(-ClientSize.Width / 2f, -ClientSize.Height / 2f, MatrixOrder.Append);
            mx.Rotate(rotation, MatrixOrder.Append);
            mx.Translate(ClientSize.Width / 2f + panX, ClientSize.Height / 2f + panY, MatrixOrder.Append);
            mx.Scale(zoom, zoom, MatrixOrder.Append);
            e.Graphics.Transform = mx;
            // Determine center of ClientRectangle
            Point centerRectangle = new Point();
            centerRectangle.X = ClientRectangle.Left + ClientRectangle.Width / 2;
            centerRectangle.Y = ClientRectangle.Top + ClientRectangle.Height / 2;
            // Get true center point
            centerRectangle = BackTrackMouse(centerRectangle);
            // Determine offset from current mouse position

            SolidBrush brush = new SolidBrush(Color.FromArgb(255, 255, 255));
            e.Graphics.FillRectangle(brush,ClientRectangle);

            //gird
            if (Owner.GirdBox.Checked)
            {
                showhide.DrawGrid(e.Graphics, this);
            }

            //ham ve cac object

            if (this.Graphics != null)
            {
                this.Graphics.Draw(e.Graphics);   //ham ve chinh 
            }

            DrawNetSelection(e.Graphics);         //ham ve selection

            brush.Dispose();
        }

       
        private void Area_MouseDown(object sender, MouseEventArgs e)
        {
            //TODO: xu ly an chuot xuong Area
            //final 
            set_final();
            Owner.final.Checked = false;
           
            //position
            lastPoint = BackTrackMouse(e.Location);
            if (e.Button == MouseButtons.Left)
            {
                if (activeTool == DrawToolType.Recurcy)
                {
                    if (!SetRecurcy(e.Location))
                    {
                        Owner.Recurcy.Checked = false;
                        ActiveTool = DrawToolType.Pointer;
                        return;  //set recurcy
                    }
                }

                tools[(int)activeTool].OnMouseDown(this, e);     //goi ham OnMouseDown of ToolObject
           
                this.GetObjectInfo();                            //lay thong tin object do vao cho tuong ung
                Owner.SetTree();                                 //tao tree
                movepoint = new Point(e.X,e.Y);

                //add command add
              
                if (activeTool != DrawToolType.Pointer)
                {
                    command_add = new CommandAdd(this);
                    this.AddCommandToHistory(command_add);
                }
            }
            else if (e.Button == MouseButtons.Right)
            {
                if (panning) panning = false;

                ActiveTool = DrawToolType.Pointer;

                OnContextMenu(e);
            }

            //add vao status
            Owner.NumberObj.Text = number_object().ToString();         

            //confirmtextbox
            if (TextboxText.Text != "" && TextboxText.Visible == true)
            {
                //MessageBox.Show("hieu");
                ConfirmTextBox();
                Owner.set_kind_att();
            }
            else
            {
                TextboxText.Visible = false;
            }
         

            //inserttext
            if (ActiveTool == DrawToolType.insertText)
            {
                DrawObject.DrawObject obj = (DrawObject.DrawObject)this.Graphics[this.Graphics.Count - 1];
                DrawText t = (DrawText)obj;
                TextboxText.Location = t.Rectangle.Location;
                TextboxText.Size = t.Rectangle.Size;
                TextboxText.Visible = true;
            }

            //tao trang thai
            Owner.removecheck();
            ActiveTool = DrawToolType.Pointer;                              //mac dinh la chon toolpointer
            Owner.primarykey.Checked = false;
           
            
        }


        private void Area_MouseUp(object sender, MouseEventArgs e)
        {
           //TODO: xu ly su kien tha chuot tren Area

            if (e.Button == MouseButtons.Left)
            {
                tools[(int)activeTool].OnMouseUp(this, e);   //goi ham OnMouseUp of ToolObject
            }

            subfunction.reset_connect(this);     //reset connect point
        }

        private void AreaMouseDoubleClick(object sender, MouseEventArgs e)
        {
            //TODO: xu ly su kien double click
            if (this.activeTool == DrawToolType.Pointer)
            {
                tools[(int)activeTool].OnMouseDoubleClick(this, e);
            }

            ShowTextBoxText(e);
        
        }

        private void AreaDoubleClick(object sender, EventArgs e)
        {
            
        }

        #endregion

        #region xu ly textbox

        public void addAttribute(DrawClass temp)
        {
        
            if (TextboxText.Text != "")
            {
                if (Owner.Derived.Checked)
                {
                    temp.AddAttributes(TextboxText.Text, AddtypeAtt(Owner.List_datatype.Text),Attri.Kind.derived,Owner.DerivedColumn.Text,Owner.primarykey.Checked);
                }
                else if (Owner.Composite.Checked)
                {
                    temp.AddAttributes(TextboxText.Text, AddtypeAtt(Owner.List_datatype.Text), Attri.Kind.composite, Owner.CompositeName.Text, Owner.primarykey.Checked);
                }
                else if (Owner.Multivalue.Checked)
                {
                    temp.AddAttributes(TextboxText.Text, AddtypeAtt(Owner.List_datatype.Text), Attri.Kind.multivalued, Owner.MultiValues.Text, Owner.primarykey.Checked);
                }
                else
                {
                    temp.AddAttributes(TextboxText.Text, AddtypeAtt(Owner.List_datatype.Text), Attri.Kind.normal, "", Owner.primarykey.Checked);
                }

                    temp.rectangle.Height += 20;
                    temp.p2= new Point(temp.p2.X, temp.p2.Y + 20);
                    temp.ResizeRect(temp.rectangle.Y,new Point(temp.p1.X, temp.p1.Y + 20) , 
                                     temp.p2 , temp.rectangle.Y + temp.rectangle.Height);
                    
              
            }

     
            int attcount = temp.ListAttribute.Count;
            TextboxText.Location = new Point(temp.RectangleAttribute.Location.X, temp.RectangleAttribute.Location.Y + 17 * attcount);
            TextboxText.Visible = true;

        }

        public void addOperation(DrawClass temp)
        {
       
            if (TextboxText.Text != "")
            {
                temp.AddOperation(TextboxText.Text, AddOperAtt(Owner.List_Oper.Text));
                    
                    temp.rectangle.Height += 20;
                    temp.ResizeRect(temp.rectangle.Y, new Point(temp.p1.X, temp.p1.Y + 20),
                                     new Point(temp.p2.X, temp.p2.Y + 20), temp.rectangle.Y + temp.rectangle.Height);
               
                 

            }
         
            int attcount = temp.ListOperation.Count;
            TextboxText.Location = new Point(temp.RectangleOperation.Location.X, temp.RectangleOperation.Location.Y + 17 * attcount);
            TextboxText.Visible = true;

        }

        public void ShowTextBoxText(MouseEventArgs e)
        {
          
            //show textboxtext when double click

            DrawObject.DrawObject temp = this.Graphics.SelectedObject();
            if (temp != null)
            {
                switch (temp.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.text:
                    case DrawObject.DrawObject.ObjectType.insert_text:
                        DrawText o = (DrawText)temp;

                        TextboxText.Location = new Point((int)(o.Rectangle.X * this.Zoom),(int)(o.Rectangle.Y * this.Zoom));
                        TextboxText.Size = new Size((int)(o.Rectangle.Width*this.Zoom) ,(int)(o.Rectangle.Height*this.Zoom));
                      
                        TextboxText.Text = o.TheText;
                        break;
                    case DrawObject.DrawObject.ObjectType.Binary:
                        DrawBinary o2 = (DrawBinary)temp;
                        
                        TextboxText.Location = new Point((int)(o2.Rectangle.X * this.Zoom), (int)(o2.Rectangle.Y * this.Zoom));
                        TextboxText.Size = new Size((int)(o2.Rectangle.Width* this.Zoom), (int)(o2.Rectangle.Height*this.Zoom));

                        TextboxText.Text = o2.RoleName;
                        break;
                    case DrawObject.DrawObject.ObjectType.Nary:
                        DrawNary o3 = (DrawNary)temp;
                        
                        TextboxText.Location = new Point((int)(o3.Rectangle.X * this.Zoom), (int)(o3.Rectangle.Y * this.Zoom));
                        TextboxText.Size = new Size((int)(o3.Rectangle.Width * this.Zoom),(int)( o3.Rectangle.Height*this.Zoom));

                        TextboxText.Text = o3.RoleName;
                        break;
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass o1 = (DrawClass)temp;
                        int p = index(e.Location, o1);
                        int rect_x;
                        int rect_y;
                        int rect_width;
                        int rect_height;
                        
                        rect_width =(int)(o1.Rectangle.Width * this.Zoom);
                        rect_height =(int)(20 * this.Zoom);
                        
                        TextboxText.Size = new Size(rect_width, rect_height);

                        if ( p == 0)
                        {
                          TextboxText.Location = new Point((int)(o1.Rectangle.X * this.Zoom),(int)(o1.Rectangle.Y * this.Zoom));
                          TextboxText.Text = o1.ClassName;
                            
                        }
                        else if (p>=10 && p<20)
                        {
                            int k = p % 10;
                            if (o1.ListAttribute.Count > k)
                            {
                                TextboxText.Text = o1.ListAttribute[k].Name;
                                Owner.List_datatype.Text = attype_to_string(o1.ListAttribute[k].DataType);
                            }

                            rect_x = (int)(o1.RectangleAttribute.X * this.Zoom);
                            rect_y = (int)(o1.RectangleAttribute.Y * this.Zoom);
                          
                            TextboxText.Location = new Point(rect_x,(int)(rect_y+20*(this.Zoom)*k));
                     
                            
                            
                        }
                        else if(p>=20 && p<30)
                        {
                            int h = p % 20;
                            if (o1.ListOperation.Count > h)
                            {
                                TextboxText.Text = o1.ListOperation[h].Name;
                                Owner.List_Oper.Text = optype_to_string(o1.ListOperation[h].OpTypes);
                            }
                            
                            rect_x = (int)(o1.RectangleOperation.X * this.Zoom);
                            rect_y = (int)(o1.RectangleOperation.Y * this.Zoom);
                            
                            TextboxText.Location = new Point(rect_x,(int)(rect_y + 20*this.Zoom * h));
                     
                           
                        }

                        break;

                }
                TextboxText.Visible = true;
            }

        }
        public int index(Point source, DrawClass obj)
        {
            Point p1 = obj.RectangleName.Location;
            Point p2 = obj.RectangleAttribute.Location;
            Point p3 = obj.RectangleOperation.Location;
            Rectangle rect = obj.Rectangle;
            //adjust zoom
            if (this.Zoom != 1)
            {
                source = new Point((int)(source.X / this.Zoom),(int)(source.Y / this.Zoom));
            }
            if (subfunction.CheckNearPointInRect(source, rect))
            {
                source.Y += 5;
                if (source.Y >= p1.Y && source.Y< p2.Y)
                {
                    return 0;
                }
                else if (source.Y >= p2.Y && source.Y < p3.Y)
                {
                    for (int i = 0; i < (p3.Y - p2.Y) / 20; i++)
                    {
                        if (source.Y >= p2.Y + 20 * i && source.Y < p2.Y + 20 * (i + 1)) return 10 + i;
                    }
                }
                else
                {
                    for (int i = 0; i < (rect.Y + rect.Height - p3.Y) / 20; i++)
                    {
                        if (source.Y >= p3.Y + 20 * i && source.Y < p3.Y + 20 * (i + 1)) return 20 + i;
                    }
                }
            }
            return -1;
        }

        public Point adjust_point()
        {
            if (this.Zoom == 1) return TextboxText.Location;
            else return new Point((int)(TextboxText.Location.X / this.Zoom), (int)(TextboxText.Location.Y / this.Zoom));
        }


        public void set_final()
        {
            foreach (DrawObject.DrawObject obj in Graphics.GetListObject())
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass a = (DrawClass)obj;
                        if (a.Selected)
                        {
                            if (Owner.final.Checked) a.final = true;
                            else a.final = false;
                        }
                        break;
                }
                
            }
        }

        public void ConfirmTextBox()
        {
            if (TextboxText.Text != "")
            {
                //confirm add text to class and check 
                for (int i = 0; i < this.Graphics.Count; i++)
                {
                    DrawObject.DrawObject temp = (DrawObject.DrawObject)this.Graphics[i];

                    switch (temp.ObjType)
                    {
                        case DrawObject.DrawObject.ObjectType.text:
                        case DrawObject.DrawObject.ObjectType.insert_text:
                            DrawText o = (DrawText)temp;
                            if (subfunction.CheckNearPointInRect(adjust_point(),o.Rectangle))
                            {
                                o.TheText = TextboxText.Text;
                                break;
                            }
                            break;
                        case DrawObject.DrawObject.ObjectType.Class:
                        case DrawObject.DrawObject.ObjectType.AbstractClass:
                            DrawClass o1 = (DrawClass)temp;

                            //if (Owner.final.Checked) o1.final = true;  //final

                            int list_index = index(TextboxText.Location, o1);
                            if (list_index == 0)
                            {
                                o1.ClassName = TextboxText.Text;
                                break;
                            }
                            else if (list_index >= 10 && list_index < 20)
                            {

                                if ((list_index % 10) < o1.ListAttribute.Count)
                                {
                                    o1.ListAttribute[list_index % 10].Name = TextboxText.Text;
                                    o1.ListAttribute[list_index % 10].DataType = AddtypeAtt(Owner.List_datatype.Text);
                                    if (Owner.Derived.Checked)
                                    {
                                        o1.ListAttribute[list_index % 10].AttriKind = Attri.Kind.derived;
                                        o1.ListAttribute[list_index % 10].striggername = Owner.DerivedColumn.Text;
                                    }
                                    else if (Owner.Composite.Checked)
                                    {
                                        o1.ListAttribute[list_index % 10].AttriKind = Attri.Kind.composite;
                                        o1.ListAttribute[list_index % 10].composited = Owner.CompositeName.Text;
                                    }
                                    else if (Owner.Multivalue.Checked)
                                    {
                                        o1.ListAttribute[list_index % 10].AttriKind = Attri.Kind.multivalued;
                                        o1.ListAttribute[list_index % 10].multivaluename = Owner.MultiValues.Text;
                                    }
                                    else
                                    {
                                        o1.ListAttribute[list_index % 10].AttriKind = Attri.Kind.normal;
                                    }

                                    if (Owner.primarykey.Checked) o1.ListAttribute[list_index % 10].pk = true;
                                    else o1.ListAttribute[list_index % 10].pk = false;
                                }
                                else
                                {
                                    addAttribute(o1);
                                    TextboxText.Text = "";
                                }
                                break;
                            }
                            else if (list_index >= 20 && list_index < 30)
                            {
                                if ((list_index % 20) < o1.ListOperation.Count)
                                {
                                    o1.ListOperation[list_index % 20].Name = TextboxText.Text;
                                    o1.ListOperation[list_index % 20].OpTypes = AddOperAtt(Owner.List_Oper.Text);
                                    
                                }
                                else
                                {
                                    addOperation(o1);
                                    TextboxText.Text = "";
                                }
                                break;
                            }
                            break;

                        case DrawObject.DrawObject.ObjectType.Binary:
                            DrawBinary o2 = (DrawBinary)temp;
                            if (subfunction.CheckNearPointInRect(adjust_point(),o2.Rectangle))
                            {
                                o2.RoleName = TextboxText.Text;
                                break;
                            }
                            break;
                        case DrawObject.DrawObject.ObjectType.Nary:
                            DrawNary o3 = (DrawNary)temp;
                            if (subfunction.CheckNearPointInRect(adjust_point(),o3.Rectangle))
                            {
                                o3.RoleName = TextboxText.Text;
                                break;
                            }
                            break;

                    }

                }

                TextboxText.Visible = false;
                TextboxText.Text = "";
                this.Refresh();
            }
        }

        public void ShowMessage(string error,bool flag)
        {
            
            timer1.Interval = 1500;
            timer1.Enabled = true;
            MessageBoxEx.EnableGlass = false;
            if (flag)
            {
                MessageBoxEx.Show("<font color='#0000cc'>" + error + "</font>", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBoxEx.Show("<font color='#0000cc'>" + error + "</font>", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void timer_tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            SendKeys.Send("{ESC}"); // SendWait as alternative
        }

        #endregion

        #region SupertabStrip

        public void AddInfoToClass()
        {
            DrawClass temp = (DrawClass)this.Graphics.SelectedObject();
            if (temp != null)
            {

                if (TextboxText.Location.Y >= temp.RectangleAttribute.Location.Y)
                {
                    if (TextboxText.Location.Y < temp.RectangleOperation.Location.Y)
                    {
                        addAttribute(temp);
                    }
                    else if (TextboxText.Location.Y >= temp.RectangleOperation.Location.Y)
                    {
                        addOperation(temp);
                    }
                }
            }
        
            TextboxText.Text = "";
        
            this.Refresh();
        }

        public void RemoveInfoFromClass()
        {
            DrawClass obj = (DrawClass)this.Graphics.SelectedObject();
            if(index_att_op()>=10 && index_att_op() <20)
            {
              
                int i = index_att_op() % 10;
                if (i < obj.ListAttribute.Count)
                {
                    obj.ListAttribute.RemoveAt(i);
                    obj.rectAttribute.Y -= 20;
                }
            }
            else if (index_att_op() >= 20 && index_att_op() < 30)
            {
                int i = index_att_op() % 20;
                if (i < obj.ListOperation.Count)
                {
                    obj.ListOperation.RemoveAt(i);
                    obj.rectOperation.Y -= 20;
                }
            }

            TextboxText.Text = "";
            TextboxText.Visible = false;
            this.Refresh();
        }
       
        public void UpInfo()
        {
            DrawClass obj = (DrawClass)this.Graphics.SelectedObject();

            if (index_att_op() >= 10 && index_att_op() < 20)
            {
                int i = index_att_op() % 10;
                if (i > 0 && obj.ListAttribute.Count >i)
                {
                    Attri temp = obj.ListAttribute[i - 1];
                    obj.ListAttribute.RemoveAt(i - 1);
                    obj.ListAttribute.Insert(i,temp);
                }
            }
            else if (index_att_op() >= 20 && index_att_op() < 30)
            {
                int i = index_att_op() % 20;
                if (i > 0 && obj.ListOperation.Count >i)
                {
                    Opers temp = obj.ListOperation[i - 1];
                    obj.ListOperation.RemoveAt(i - 1);
                    obj.ListOperation.Insert(i, temp);
                }
            }

            TextboxText.Text = "";
            TextboxText.Visible = false;
        }

        public void DownInfo()
        {
            DrawClass obj = (DrawClass)this.Graphics.SelectedObject();

            if (index_att_op() >= 10 && index_att_op() < 20)
            {
                int i = index_att_op() % 10;
                if (i < obj.ListAttribute.Count - 1)
                {
                    Attri temp = obj.ListAttribute[i+1];
                    obj.ListAttribute.RemoveAt(i+1);
                    obj.ListAttribute.Insert(i, temp);
                }
            }
            else if (index_att_op() >= 20 && index_att_op() < 30)
            {
                int i = index_att_op() % 20;
                if (i < obj.ListOperation.Count - 1)
                {
                    Opers temp = obj.ListOperation[i + 1];
                    obj.ListOperation.RemoveAt(i + 1);
                    obj.ListOperation.Insert(i, temp);
                }
            }
            TextboxText.Text = "";
            TextboxText.Visible = false;
        }

        public int index_att_op()
        {
            DrawClass obj = (DrawClass) this.Graphics.SelectedObject();
            Point p = TextboxText.Location;
            if (obj != null)
            {
                if (p.Y >= obj.Rectangle.Y && p.Y < obj.RectangleAttribute.Y) return 0;
                else if (p.Y >= obj.RectangleAttribute.Y && p.Y < obj.RectangleOperation.Y)
                {
                    return (p.Y - obj.RectangleAttribute.Y) / 20 + 10;
                }
                else if (p.Y >= obj.RectangleOperation.Y && p.Y < obj.Rectangle.Y + obj.Rectangle.Height)
                {
                    return (p.Y - obj.RectangleOperation.Y) / 20 + 20;
                }
            }
            return -1;
        }
        #endregion

        #region others function

        public void DrawNetSelection(Graphics g)
        {
            if (!DrawNetRectangle)
                return;

            ControlPaint.DrawFocusRectangle(g, NetRectangle, Color.Black, Color.Transparent);
        }


        public void Initialize(MainForm owner, DocManager docManager)
        {
            //TODO: ham khoi tao cac gia tri ban dau

            SetStyle(ControlStyles.AllPaintingInWmPaint |ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);
            Invalidate();

            // Keep reference to owner form
            Owner = owner;
            DocManager = docManager;

            // set default tool
            activeTool = DrawToolType.Pointer;

            // Create undo manager
            undoManager = new UndoManager(this);

            //Create Layer
            ActiveLayer = new Layer();
            

            // create array of drawing tools
            tools = new Tool[(int)DrawToolType.NumberOfDrawTools];
            tools[(int)DrawToolType.Association] = new ToolAssociation();
            tools[(int)DrawToolType.ExtraAssociation] = new ToolExtraAssociation();
            tools[(int)DrawToolType.AssociationClass] = new ToolAssocationClass();
            tools[(int)DrawToolType.Pointer] = new ToolPointer();
            tools[(int)DrawToolType.Class] = new ToolClass();
            tools[(int)DrawToolType.Generalization] = new ToolGeneralization();
            tools[(int)DrawToolType.Aggregation] = new ToolAgg();
            tools[(int)DrawToolType.Composition] = new ToolComposition();
            tools[(int)DrawToolType.Note] = new ToolNote();
            tools[(int)DrawToolType.Dynamic] = new ToolDynamic();
            tools[(int)DrawToolType.Disjoint] = new ToolDisjoint();
            tools[(int)DrawToolType.Binary] = new ToolBinary();
            tools[(int)DrawToolType.Nary] = new ToolNary();
            //tools[(int)DrawToolType.Object] = new ToolClassInstant();
            tools[(int)DrawToolType.AbstractClass] = new ToolAbstractClass();
            tools[(int)DrawToolType.Image] = new ToolImage();
            tools[(int)DrawToolType.insertText] = new ToolText();
            tools[(int)DrawToolType.Recurcy] = new ToolRecurcyLine();

            LineColor = Color.Black;
            FillColor = Color.White;
            FontColor = Color.Black;
            LineWidth = -1;
        }

        #region Undo/Redo

        public void AddCommandToHistory(Command.Command command)
        {
            undoManager.AddCommandToHistory(command);
        }

        public void Undo()
        {
            undoManager.Undo();
            Refresh();
        }

        public void Redo()
        {
            undoManager.Redo();
            Refresh();
        }

        #endregion

        

        internal void Draw(Graphics g)
        {
            _graphicsList.Draw(g);
        }

        private void OnContextMenu(MouseEventArgs e)
        {
            // Change current selection if necessary

            Point point = BackTrackMouse(new Point(e.X, e.Y));
            Point menuPoint = new Point(e.X, e.Y);
            //int al = _layers.ActiveLayerIndex;
            int n = this.Graphics.Count;
            DrawObject.DrawObject o = null;

            for (int i = 0; i < n; i++)
            {
                if (this.Graphics[i].HitTest(point) == 0)
                {
                    o = this.Graphics[i];
                    break;
                }
            }

            if (o != null)
            {
                if (!o.Selected)
                    this.Graphics.UnselectAll();

                // Select clicked object
                o.Selected = true;
            }
            else
            {
                this.Graphics.UnselectAll();
            }

            Refresh();
         
            Owner.contextMenu.Show(this, menuPoint);
        }

        #endregion

        #region Mainform & Object

       

        public Attri.Type AddtypeAtt(string t)
        {
            switch (t)
            {
                case "NUMBER" :
                    return Attri.Type.number;
                   
                case "VARCHAR":
                    return Attri.Type.varchar;
                  
                case "INTEGER":
                    return Attri.Type.interger;
                  
                case "TIMESTAMP":
                    return Attri.Type.datetime;
                    
                case "DECIMAL":
                    return Attri.Type.decimals;
                 
                case "DOUBLE":
                    return  Attri.Type.doubles;
                   
                case "FLOAT":
                    return Attri.Type.floats;
                   
                case "CHAR":
                    return Attri.Type.chars;
                  
                
            }
            return Attri.Type.varchar;
        }

        public Opers.OpType AddOperAtt(string t)
        {
            switch (t)
            {
                case "NONE":
                    return Opers.OpType.procedure;
                case "NUMBER":
                    return Opers.OpType.NUMBER;
                case "VARCHAR":
                    //MessageBox.Show("hieu");
                    return Opers.OpType.VARCHAR2;
                case "INTEGER":
                    //MessageBox.Show("hieu");
                    return Opers.OpType.INTEGER;
                case "TIMESTAMP":
                    return Opers.OpType.TIMESTAMP;
                case "DECIMAL":
                    return Opers.OpType.DECIMAL;
                case "DOUBLE":
                    return Opers.OpType.DOUBLE;
                case "FLOAT":
                    return Opers.OpType.FLOAT;
                case "CHAR":
                    return Opers.OpType.CHAR;
            }
            return Opers.OpType.procedure;
        }

       

        public List<Attri> addNameAtt(List<Attri> a, Attri att,int i)
        {
            if (a.Count < i)
            {
                if (a.Count == i - 1)
                {
                    a.Add(att);

                }
                else
                {
                    for (int z = a.Count; z < i - 1; z++)
                    {
                        Attri temp = new Attri();
                        temp.Name = "";
                        a.Add(temp);
                    }

                    a.Add(att);
                }


            }
            else
            {
                a[i - 1].Name = att.Name;
                a[i - 1].DataType = att.DataType;
            }

            return a;
        }
        public List<Opers> addNameOp(List<Opers> a, Opers op, int i)
        {
            if (a.Count < i)
            {
                if (a.Count == i - 1)
                {
                    a.Add(op);

                }
                else
                {
                    for (int z = a.Count; z < i - 1; z++)
                    {
                        Opers temp=new Opers();
                        temp.Name = "";
                        a.Add(temp);
                    }

                    a.Add(op);
                }


            }
            else
            {
                a[i - 1].Name = op.Name;
                a[i - 1].OpTypes = op.OpTypes;
            }

            return a;
        }

        
        public void AddTextToObject(string text,int flag)
        {
            //chuyen doi text tu mainfrom vao object tuong ung
            DrawObject.DrawObject temp = this.Graphics.SelectedObject();
            if (temp != null)
            {
                switch (temp.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass o1 = (DrawClass)temp;
                        switch (flag)
                        {
                            case 1:
                                o1.ClassName = text;
                                break;
                            case 41:
                                //if(o1.ListAttribute.Count<1) resizeclass(o1, 0, true);       //resize class
                                Attri a1 = new Attri(text, AddtypeAtt(Owner.AttType1.Text));
                                o1.ListAttribute = addNameAtt(o1.ListAttribute, a1, 1);
                                o1.GepText();
                                break;
                            case 42:
                                if (o1.ListAttribute.Count < 2)
                                {
                                    o1.rectangle.Height += 20;
                                    o1.p2.Y += 20;
                                    o1.ResizeRect(o1.Rectangle.Y, o1.p1, o1.p2, o1.Rectangle.Y + o1.Rectangle.Height);
                                }
                                Attri a2 = new Attri(text, AddtypeAtt(Owner.AttType2.Text));
                                o1.ListAttribute = addNameAtt(o1.ListAttribute, a2, 2);
                                AddtypeAtt(Owner.AttType2.Text);
                                o1.GepText();
                                break;
                            case 43:
                                if (o1.ListAttribute.Count < 3)
                                {
                                    o1.rectangle.Height += 20;
                                    o1.p2.Y += 20;
                                    o1.ResizeRect(o1.Rectangle.Y, o1.p1, o1.p2, o1.Rectangle.Y + o1.Rectangle.Height);
                                }
                                Attri a3 = new Attri(text, AddtypeAtt(Owner.AttType3.Text));
                                o1.ListAttribute = addNameAtt(o1.ListAttribute, a3, 3);
                                AddtypeAtt(Owner.AttType3.Text);
                                o1.GepText();
                                break;
                            case 51:
                                //if(o1.ListOperation.Count<1) resizeclass(o1, 0, false);       //resize class
                                Opers op1 = new Opers(text, AddOperAtt(Owner.Optype1.Text));
                                //MessageBox.Show(op1.OpTypes.ToString());
                                o1.ListOperation = addNameOp(o1.ListOperation, op1, 1);
                                o1.GepText();
                                break;
                            case 52:
                                if (o1.ListOperation.Count < 2)
                                {
                                    o1.rectangle.Height += 20;
                                    o1.ResizeRect(o1.Rectangle.Y, o1.p1, o1.p2, o1.Rectangle.Y + o1.Rectangle.Height);
                                }
                                Opers op2 = new Opers(text, AddOperAtt(Owner.Optype2.Text));
                                o1.ListOperation = addNameOp(o1.ListOperation, op2, 2);
                                AddOperAtt(Owner.Optype2.Text);
                                o1.GepText();
                                break;
                            case 53:
                                if (o1.ListOperation.Count < 3)
                                {
                                    o1.rectangle.Height += 20;
                                    o1.ResizeRect(o1.Rectangle.Y, o1.p1, o1.p2, o1.Rectangle.Y + o1.Rectangle.Height);
                                }
                                Opers op3 = new Opers(text, AddOperAtt(Owner.Optype3.Text));
                                o1.ListOperation = addNameOp(o1.ListOperation, op3, 3);
                                o1.GepText();
                                break;
                        }

                        break;
                    case DrawObject.DrawObject.ObjectType.text:
                        DrawText o = (DrawText)temp;
                        o.TheText = Owner.NameInfo.Text;
                        break;
                    case DrawObject.DrawObject.ObjectType.Binary:
                        DrawBinary b = (DrawBinary)temp;
                        b.RoleName = Owner.NameInfo.Text;
                        break;
                    case DrawObject.DrawObject.ObjectType.Nary:
                        DrawNary n = (DrawNary)temp;
                        n.RoleName = Owner.NameInfo.Text;
                        break;
                    
                }
            }
            //this.Refresh();
        }

        
        public void GetObjectInfo()
        {
            //get info from object and add to mainform 
         
            DrawObject.DrawObject temp = this.Graphics.SelectedObject();
            if (temp != null)
            {
                GetObjectWithID(Owner, temp);
              
            }
        }
        public void GetObjectWithID(MainForm formOwner, DrawObject.DrawObject temp)
        {

            Owner.EntryInfo.Text = "Object ID:" + temp.ID;
            formOwner.EntryID2.Text = "Object ID:" + temp.ID;
            formOwner.DescriptionInfo.Text = temp.comment;
            switch (temp.ObjType)
            {
                case DrawObject.DrawObject.ObjectType.Class:
                case DrawObject.DrawObject.ObjectType.AbstractClass:
                    DrawClass o = (DrawClass)temp;
                    formOwner.NameInfo.Text = o.ClassName;
                    //add attributes
                    if (o.ListAttribute.Count > 3)
                    {
                        for (int i = 0; i < o.ListAttribute.Count; i++)
                        {
                            if (i > 3)
                            {
                                formOwner.AddMoreAttributes(o.ListAttribute[i]);
                            }
                            else
                            {
                                switch (i)
                                {
                                    case 0:
                                        formOwner.Attribute1.Text = o.ListAttribute[i].Name;
                                        formOwner.AttType1.Text = attype_to_string(o.ListAttribute[i].DataType);
                                        
                                        break;
                                    case 1:
                                        formOwner.Attribute2.Text = o.ListAttribute[i].Name;
                                        formOwner.AttType2.Text = attype_to_string(o.ListAttribute[i].DataType);

                                        break;
                                    case 2:
                                        formOwner.Attribute3.Text = o.ListAttribute[i].Name;
                                        formOwner.AttType3.Text = attype_to_string(o.ListAttribute[i].DataType);
                                        break;
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < o.ListAttribute.Count; i++)
                        {
                            switch (i)
                            {
                                case 0:
                                    formOwner.Attribute1.Text = o.ListAttribute[i].Name;
                                    formOwner.AttType1.Text = attype_to_string(o.ListAttribute[i].DataType);
                                  
                                    break;
                                case 1:
                                    formOwner.Attribute2.Text = o.ListAttribute[i].Name;
                                    formOwner.AttType2.Text = attype_to_string(o.ListAttribute[i].DataType);
                                   
                                    break;
                                case 2:
                                    formOwner.Attribute3.Text = o.ListAttribute[i].Name;
                                    formOwner.AttType3.Text = attype_to_string(o.ListAttribute[i].DataType);
                                    break;
                            }
                        }

                    }
                    //add operation
                    if (o.ListOperation.Count > 3)
                    {
                        for (int i = 0; i < o.ListOperation.Count; i++)
                        {
                            if (i > 3)
                            {
                                formOwner.AddMoreOperation(o.ListOperation[i]);
                            }
                            else
                            {
                                switch (i)
                                {
                                    case 0:
                                        formOwner.Operation1.Text = o.ListOperation[i].Name;
                                        formOwner.Optype1.Text = optype_to_string(o.ListOperation[i].OpTypes);
                                        break;
                                    case 1:
                                        formOwner.Operation2.Text = o.ListOperation[i].Name;
                                        formOwner.Optype2.Text = optype_to_string(o.ListOperation[i].OpTypes);
                                        break;
                                    case 2:
                                        formOwner.Operation3.Text = o.ListOperation[i].Name;
                                        formOwner.Optype3.Text = optype_to_string(o.ListOperation[i].OpTypes);
                                        break;
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < o.ListOperation.Count; i++)
                        {
                            switch (i)
                            {
                                case 0:
                                    formOwner.Operation1.Text = o.ListOperation[i].Name;
                                    formOwner.Optype1.Text = optype_to_string(o.ListOperation[i].OpTypes);
                                    
                                    break;
                                case 1:
                                    formOwner.Operation2.Text = o.ListOperation[i].Name;
                                    formOwner.Optype2.Text = optype_to_string(o.ListOperation[i].OpTypes);
                                    
                                    break;
                                case 2:
                                    formOwner.Operation3.Text = o.ListOperation[i].Name;
                                    formOwner.Optype3.Text = optype_to_string(o.ListOperation[i].OpTypes);
                                    break;
                            }
                        }

                    }

                    //position
                    formOwner.PositionX.Text = o.Rectangle.X.ToString();
                    formOwner.PositionY.Text = o.Rectangle.Y.ToString();
                    //size
                    formOwner.width.Text = o.Rectangle.Width.ToString();
                    formOwner.height.Text = o.Rectangle.Height.ToString();

                    break;
                case DrawObject.DrawObject.ObjectType.text:
                    DrawText o1 = (DrawText)temp;
                    formOwner.NameInfo.Text = o1.TheText;
                    //position
                    formOwner.PositionX.Text = o1.Rectangle.X.ToString();
                    formOwner.PositionY.Text = o1.Rectangle.Y.ToString();
                    //size
                    formOwner.width.Text = o1.Rectangle.Width.ToString();
                    formOwner.height.Text = o1.Rectangle.Height.ToString();
                    break;
                case DrawObject.DrawObject.ObjectType.Binary:
                    DrawBinary b = (DrawBinary)temp;
                   
                    formOwner.NameInfo.Text = b.RoleName;
                    //position
                    formOwner.PositionX.Text = b.Rectangle.X.ToString();
                    formOwner.PositionY.Text = b.Rectangle.Y.ToString();
                    //size
                    formOwner.width.Text = b.Rectangle.Width.ToString();
                    formOwner.height.Text = b.Rectangle.Height.ToString();
                    break;
                case DrawObject.DrawObject.ObjectType.Nary:
                    DrawNary n = (DrawNary)temp;
                    formOwner.NameInfo.Text = n.RoleName;
                    //position
                    formOwner.PositionX.Text = n.Rectangle.X.ToString();
                    formOwner.PositionY.Text = n.Rectangle.Y.ToString();
                    //size
                    formOwner.width.Text = n.Rectangle.Width.ToString();
                    formOwner.height.Text = n.Rectangle.Height.ToString();
                    break;
                case DrawObject.DrawObject.ObjectType.Aggernation:
                case DrawObject.DrawObject.ObjectType.AssociationLine:
                case DrawObject.DrawObject.ObjectType.Composition:
                case DrawObject.DrawObject.ObjectType.Generalization:
                    DrawAssociation ass = (DrawAssociation)temp;
                    if(ass.RoleName!=null) formOwner.NameInfo.Text = ass.RoleName.TheText;
                    //position
                    formOwner.PositionX.Text = ass.startPoint.X.ToString();
                    formOwner.PositionY.Text = ass.startPoint.Y.ToString();
                    break;
            }
        }

        public void reset_mainform( MainForm form)
        {
            
            form.DescriptionInfo.Text = "";
            form.Attribute1.Text = "";
            form.Attribute2.Text = "";
            form.Attribute3.Text = "";
            form.Operation1.Text = "";
            form.Operation2.Text = "";
            form.Operation3.Text = "";
         
        }
        #endregion

        #region recurcy

        public bool SetRecurcy(Point RecurPoint)
        {
            foreach (DrawObject.DrawObject obj in this.Graphics.GetListObject())
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                        DrawClass c = (DrawClass) obj;
                        if (subfunction.CheckPointInRect(RecurPoint, c.Rectangle))
                        {
                            if (c.Recurcys!=null) return false;
                            else 
                            {
                                this.recur1 = new Point(c.Rectangle.X + c.Rectangle.Width / 2, c.Rectangle.Y);
                                this.recur2 = new Point(c.Rectangle.X + c.Rectangle.Width, c.Rectangle.Y + c.Rectangle.Height / 2);
                                ID_class_recurcy = c.ID;
                                return true;
                            }
                            

                        }
                        break;
                }
            }
            return false;
        }

        #endregion


        #region others function

        public int number_object()
        {
            int result=0;
            for (int i = 0; i < this.Graphics.Count; i++)
            {
                DrawObject.DrawObject obj = (DrawObject.DrawObject)this.Graphics[i];
                if (obj.ObjType != DrawObject.DrawObject.ObjectType.text && obj.Hide==false) result++;

            }

            return result;
        }

        public void tooltip(Point location)
        {
            foreach (DrawObject.DrawObject obj in this.Graphics.GetListObject())
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                        DrawClass c = (DrawClass)obj;
                        if(subfunction.CheckPointInRect(location,c.Rectangle))
                        {
                            Owner.TooltipSet(location,"Double click to add text into class");
                        }
                        break;
                }
            }
        }

        public string optype_to_string(Opers.OpType type)
        {
            switch (type)
            {
                case Opers.OpType.NUMBER:
                    return "NUMBER";
                case Opers.OpType.VARCHAR2:
                    return "VACHAR";
                case Opers.OpType.INTEGER:
                    return "INTEGER";
                case Opers.OpType.FLOAT:
                    return "FLOAT";
                case Opers.OpType.DOUBLE:
                    return "DOUBLE";
                case Opers.OpType.DECIMAL:
                    return "DECIMAL";
                case Opers.OpType.TIMESTAMP:
                    return "TIMESTAMP";
                case Opers.OpType.CHAR:
                    return "CHAR";
                case Opers.OpType.boolean:
                    return "BOOLEAN";
                case Opers.OpType.procedure:
                    return "NONE";
            }
            return null;
        }

        public string attype_to_string(Attri.Type type)
        {
            switch (type)
            {
                case Attri.Type.number:
                    return "NUMBER";
                case Attri.Type.varchar:
                    return "VACHAR";
                case Attri.Type.interger:
                    return "INTERGER";
                case Attri.Type.floats:
                    return "FLOAT";                     
                case Attri.Type.doubles:
                    return "DOUBLE";
                case Attri.Type.decimals:
                    return "DECIMAL";
                case Attri.Type.datetime:
                    return "DATETIME";
                case Attri.Type.chars:
                    return "CHAR";
                case Attri.Type.boolean:
                    return "BOOLEAN";

            }
            return null;
        }
    
        #endregion

      


    }
}

