﻿using System;
using System.Drawing;
using System.Windows.Forms;
using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
	class ToolImage : ToolObject
	{
		public ToolImage()
		{
			//Cursor = new Cursor(GetType(), "Rectangle.cur");
		}

		public override void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
		{
          
			Point p = drawArea.BackTrackMouse(new Point(e.X, e.Y));
            drawArea.ObjectType = DrawObject.DrawObject.ObjectType.Image;
            AddNewObject(drawArea, new DrawImage(p.X, p.Y), drawArea.ObjectType);

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select an Image to insert into map";
            ofd.Filter = "Bitmap (*.bmp)|*.bmp|JPEG (*.jpg)|*.jpg|Fireworks (*.png)|*.png|GIF (*.gif)|*.gif|Icon (*.ico)|*.ico|All files|*.*";
            ofd.InitialDirectory = Environment.SpecialFolder.MyPictures.ToString();

            if (ofd.ShowDialog() ==
                DialogResult.OK)
                ((DrawImage)drawArea.Graphics[0]).TheImage = (Bitmap)Bitmap.FromFile(ofd.FileName);
            ofd.Dispose();

            base.OnMouseUp(drawArea, e);
		}

		public override void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
		{

		}

		public override void OnMouseUp(DrawArea drawArea, MouseEventArgs e)
		{
            
		}
	}
}