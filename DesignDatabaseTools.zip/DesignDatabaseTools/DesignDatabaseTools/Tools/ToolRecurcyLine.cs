﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
    class ToolRecurcyLine : ToolObject
    {
        public override void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
        {
           
            drawArea.ObjectType = DrawObject.DrawObject.ObjectType.RecurcyLine;   //dinh dang object
            Point p = drawArea.BackTrackMouse(new Point(e.X, e.Y));
            drawArea.LineColor = Color.Black;
                AddNewObject(drawArea, 
                    new DrawRecurcyLine(drawArea.recur1, drawArea.recur2, 
                        drawArea.LineColor, drawArea.LineWidth, drawArea), 
                        drawArea.ObjectType);
            
           
        }

        public override void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
        {
            //TODO: xu ly su kien chuot di chuyen
            
        }
    }
}
