﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
     class ToolClass : ToolObject
    {

        public override void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
        {
            Point p = drawArea.BackTrackMouse(new Point(e.X, e.Y));
            drawArea.ObjectType = DrawObject.DrawObject.ObjectType.Class;

            drawArea.LineColor = Color.Black;
            drawArea.FillColor = Color.SandyBrown;

                AddNewObject(drawArea, 
                    new DrawClass(p.X, p.Y, 100, 60, drawArea.LineColor, drawArea.FillColor, drawArea.DrawFilled, drawArea.LineWidth,drawArea), 
                    drawArea.ObjectType);
          
              
        }

        public override void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
        {
            //TODO: xu ly chuot di chuyen
        }
    }
}
