﻿
using System.Drawing;
using System.Windows.Forms;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
	
	 class ToolDynamic : ToolObject
	{
        public ToolDynamic()
		{
			//Cursor = new Cursor(GetType(), "Rectangle.cur");
		}

		public override void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
		{
			Point p = drawArea.BackTrackMouse(new Point(e.X, e.Y));
            drawArea.ObjectType = DrawObject.DrawObject.ObjectType.text;
            
            string t = "<< Dynamic >>";
            Color c = Color.Black;
            Font f = new Font("Tahoma", 10);
            AddNewObject(drawArea, new DrawText(p.X, p.Y, t, f, c), drawArea.ObjectType);

		}

		public override void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
		{
			//TODO: xu ly su kien di chuyen chuot
		}

        public override void OnMouseDoubleClick(DrawArea drawArea, MouseEventArgs e)
        {
            //TODO: xu ly su kien doubleclick


        }
	}
}
