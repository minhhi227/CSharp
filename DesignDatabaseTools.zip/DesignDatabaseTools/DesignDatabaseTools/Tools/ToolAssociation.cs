﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
    class ToolAssociation : ToolObject
    {
        public override void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
        {
            
            drawArea.ObjectType = DrawObject.DrawObject.ObjectType.AssociationLine;   
            Point p = drawArea.BackTrackMouse(new Point(e.X, e.Y));

            drawArea.LineColor = Color.Black;
            //drawArea.FillColor = Color.Lavender;

                AddNewObject(drawArea, 
                    new DrawAssociation(p.X, p.Y, p.X + 200, p.Y, drawArea.LineColor, drawArea.LineWidth, drawArea), 
                    drawArea.ObjectType);
            
        }

        public override void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
        {
            //TODO: xu ly su kien chuot di chuyen
            
        }
    }
}
