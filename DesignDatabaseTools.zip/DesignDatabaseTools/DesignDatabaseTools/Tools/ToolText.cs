﻿
using System.Drawing;
using System.Windows.Forms;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
	
	 class ToolText : ToolObject
	{
         public ToolText()
		{
			//Cursor = new Cursor(GetType(), "Rectangle.cur");
		}

		public override void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
		{
			Point p = drawArea.BackTrackMouse(new Point(e.X, e.Y));
            drawArea.ObjectType = DrawObject.DrawObject.ObjectType.insert_text;
            
            string t = "";
            Color c = Color.Black;
            Font f = new Font("Tahoma", 10);
            AddNewObject(drawArea, new DrawText(p.X, p.Y,100,20, t, f, c,drawArea), drawArea.ObjectType);

		}

		public override void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
		{
			//TODO: xu ly su kien di chuyen chuot
		}

        public override void OnMouseDoubleClick(DrawArea drawArea, MouseEventArgs e)
        {
            //TODO: xu ly su kien doubleclick


        }
	}
}
