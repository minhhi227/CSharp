﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
    class ToolComposition : ToolObject
    {
        public override void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
        {
            //TODO: xu ly su kien click chuot trai
            Point p = drawArea.BackTrackMouse(new Point(e.X, e.Y));
            drawArea.ObjectType = DrawObject.DrawObject.ObjectType.Composition;

            drawArea.LineColor = Color.Black;
            drawArea.FillColor = Color.Black;

                AddNewObject(drawArea, 
                    new DrawComposition(p.X, p.Y, p.X + 200, p.Y, drawArea.LineColor, drawArea.LineWidth, drawArea), 
                    drawArea.ObjectType);
            
           
        }


        public override void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
        {
            //TODO: xu ly su kien chuot di chuyen
            
        }
    }
}
