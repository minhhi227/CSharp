﻿using System.Windows.Forms;

namespace DesignDatabaseTools.Tools
{
	
	internal abstract class Tool
	{
		
		public virtual void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
		{
		}

		public virtual void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
		{
		}

		
		public virtual void OnMouseUp(DrawArea drawArea, MouseEventArgs e)
		{
		}

        public virtual void OnMouseDoubleClick(DrawArea drawArea, MouseEventArgs e)
        {
        }
	}
}