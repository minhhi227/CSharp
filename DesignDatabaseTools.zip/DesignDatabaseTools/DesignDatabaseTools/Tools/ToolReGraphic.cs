﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
    class ToolReGraphic : ToolObject
    {

       public List<DrawObject.DrawObject> List_Cut = new List<DrawObject.DrawObject>();
       public List<DrawObject.DrawObject> List_Copy = new List<DrawObject.DrawObject>();

       private DrawArea Olddrawarea;

        public ToolReGraphic()
        {
          
        }

        public DrawArea OldArea
        {
            get { return Olddrawarea; }
            set { Olddrawarea = value; }
        }

        #region REGRAPHICS

        #region Association
       

        public void ReAssociation(DrawArea Area, DrawAssociation temp)
        {
                temp.Color = Area.LineColor;
                temp.PenWidth = Area.LineWidth;

        }

        #endregion

      #region Class & AbstractClass

        public void ReClass(DrawArea Area, DrawClass temp)
        {
                temp.Color = Area.LineColor;
                temp.PenWidth = Area.LineWidth;
                temp.FillColor = Area.FillColor;
                temp.FontColor = Area.FontColor;
           
                if (Area.Font != null)
                {
                    temp.TheFont = Area.Font;
                }
           
                
            
        }
        #endregion
        

      #region Binary
      public void ReBinary(DrawArea Area, DrawBinary temp)
      {
              temp.Color = Area.LineColor;
              temp.PenWidth = Area.LineWidth;
              temp.FillColor = Area.FillColor;
          
      }
      #endregion

      #region Nary
      public void ReNary(DrawArea Area, DrawNary temp)
      {
              temp.Color = Area.LineColor;
              temp.PenWidth = Area.LineWidth;
              temp.FillColor = Area.FillColor;
          
      }
      #endregion

      #region Extra
      public void ReExtra(DrawArea Area, DrawExtraAssociation temp)
      {
              temp.Color = Area.LineColor;
              temp.PenWidth = Area.LineWidth;
          
      }
      #endregion

      #region DrawAssociationClass
      public void ReAssociationClass(DrawArea Area, DrawAssociationClass temp)
      {
              temp.Color = Area.LineColor;
              temp.PenWidth = Area.LineWidth;
              temp.FillColor = Area.FillColor;

          
      }
      #endregion

      #region Text
      public void ReText(DrawArea Area, DrawText temp)
      {
              temp.TheFont = Area.Font;
              temp.Color = Area.FontColor;
          
      }
      #endregion

      #region Triangle
      public void ReTriangle(DrawArea Area, DrawTriangle temp)
      {
              temp.Color = Area.LineColor;
              temp.PenWidth = Area.LineWidth;
              temp.FillColor = Area.FillColor;
              
          
      }
      #endregion


      public void RefreshGraphic(DrawArea Area,List<int> ListObjectID)
        {
            //TODO: ham ve lai graphic
            for (int i = 0; i < ListObjectID.Count; i++)
            {
               // MessageBox.Show(List_Cut.Count.ToString());
                DrawObject.DrawObject newobject = Area.Graphics.GetObjectWithID(ListObjectID[i]);
                switch (newobject.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.AssociationLine:
                    case DrawObject.DrawObject.ObjectType.Generalization:
                    case DrawObject.DrawObject.ObjectType.Aggernation:
                    case DrawObject.DrawObject.ObjectType.Composition:
                        DrawAssociation temp = (DrawAssociation)newobject;
                        ReAssociation(Area, temp);
                        break;
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                    case DrawObject.DrawObject.ObjectType.Class:
                        DrawClass temp2 = (DrawClass)newobject;
                        ReClass(Area, temp2);
                        break;
                    case DrawObject.DrawObject.ObjectType.Binary:
                        DrawBinary temp14 = (DrawBinary)newobject;
                        ReBinary(Area, temp14);
                        break;
                    case DrawObject.DrawObject.ObjectType.Nary:
                        DrawNary temp15 = (DrawNary)newobject;
                        ReNary(Area, temp15);
                        break;
                    case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                        DrawExtraAssociation temp16 = (DrawExtraAssociation)newobject;
                        ReExtra(Area, temp16);
                        break;
                    case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                        DrawAssociationClass temp17 = (DrawAssociationClass)newobject;
                        ReAssociationClass(Area, temp17);
                        break;
                    case DrawObject.DrawObject.ObjectType.others:
                        DrawTriangle tt = (DrawTriangle)newobject;
                        ReTriangle(Area, tt);
                        break;
                    case DrawObject.DrawObject.ObjectType.text:
                        DrawText temp4 = (DrawText)newobject;
                        ReText(Area, temp4);
                        break;

                }

            }

            Area.Refresh();
        }

        #endregion


      #region Copy
      //association
      public void SetText(DrawArea area,DrawText t1, DrawText t2)
      {
          if (t2!= null)
          {
              t1.rectangle.Y = t2.Rectangle.Y + 20;
              t1.TheFont = t2.TheFont;
              t1.TheText = t2.TheText;
              t1.Color = t2.Color;
          }
          else
          {
              area.Graphics.DeleteObject(t1);
          }
          
      }
      public void SetTri(DrawArea area, DrawTriangle a1, DrawTriangle a2)
      {
          if (a2 != null)
          {
              a1.rectangle.Y = a2.Rectangle.Y + 20;
              a1.FillColor = a2.FillColor;
          }
          else
          {
              area.Graphics.DeleteObject(a1);
          }
      }
      public void SetAssociation(DrawArea Area,DrawAssociation a1, DrawAssociation a2)
      {
          //mul left
          switch (a1.ObjType)
          {
              case DrawObject.DrawObject.ObjectType.AssociationLine:
                  SetText(Area, a1.mul_left, a2.mul_left);
                  SetText(Area, a1.mul_right, a2.mul_right);
                  SetText(Area, a1.RoleName, a2.RoleName);
                  SetTri(Area, a1.role_left_tri, a2.role_left_tri);
                  SetTri(Area, a1.role_right_tri, a2.role_right_tri);
                  break;
              case DrawObject.DrawObject.ObjectType.Aggernation:
              case DrawObject.DrawObject.ObjectType.Composition:
                  SetText(Area, a1.mul_left, a2.mul_left);
                  SetText(Area, a1.mul_right, a2.mul_right);
                  SetText(Area, a1.RoleName, a2.RoleName);
                  break;
              case DrawObject.DrawObject.ObjectType.Generalization:
                  SetText(Area, a1.RoleName, a2.RoleName);
                  break;
              case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                  break;
          }
      }
      public void CopyAss(DrawArea Area, DrawAssociation temp)
      {

          switch (temp.ObjType)
          {
              case DrawObject.DrawObject.ObjectType.AssociationLine:
                  DrawAssociation ass = new DrawAssociation(temp.startPoint.X, temp.startPoint.Y + 20, temp.endPoint.X, temp.endPoint.Y + 20, temp.Color, temp.PenWidth, Area);
                  AddNewObject(Area, ass, DrawObject.DrawObject.ObjectType.AssociationLine);
                  SetAssociation(Area, ass, temp);
                  break;
              case DrawObject.DrawObject.ObjectType.Aggernation:
                  DrawAgg agg = new DrawAgg(temp.startPoint.X, temp.startPoint.Y + 20, temp.endPoint.X, temp.endPoint.Y + 20, temp.Color, temp.PenWidth, Area);
                  AddNewObject(Area, agg, DrawObject.DrawObject.ObjectType.Aggernation);
                  SetAssociation(Area, agg, temp);
                  break;
              case DrawObject.DrawObject.ObjectType.Composition:
                  DrawComposition comp = new DrawComposition(temp.startPoint.X, temp.startPoint.Y + 20, temp.endPoint.X, temp.endPoint.Y + 20, temp.Color, temp.PenWidth, Area);
                  AddNewObject(Area, comp, DrawObject.DrawObject.ObjectType.Composition);
                  SetAssociation(Area, comp, temp);
                  break;
              case DrawObject.DrawObject.ObjectType.Generalization:
                  DrawGeneralization ger = new DrawGeneralization(temp.startPoint.X, temp.startPoint.Y + 20, temp.endPoint.X, temp.endPoint.Y + 20, temp.Color, temp.PenWidth, Area);
                  AddNewObject(Area, ger, DrawObject.DrawObject.ObjectType.Generalization);
                  SetAssociation(Area, ger, temp);
                  break;
              case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                  DrawAssociationClass assc = new DrawAssociationClass(temp.startPoint.X, temp.startPoint.Y + 20, temp.endPoint.X, temp.endPoint.Y + 20, temp.Color, temp.PenWidth, Area);
                  AddNewObject(Area, assc, DrawObject.DrawObject.ObjectType.AssociationClassLine);
                  SetAssociation(Area, assc, temp);
                  break;

          }
              
      }
    //class
      public void SetClass(DrawArea Area, DrawClass c1, DrawClass c2)
      {
          c1.ClassName = c2.ClassName;
          foreach (Attri a in c2.ListAttribute)
          {
              c1.ListAttribute.Add(a);
          }
          foreach (Opers o in c2.ListOperation)
          {
              c1.ListOperation.Add(o);
          }

          if (c2.Recurcys != null)
          {
              DrawRecurcyLine recu=new DrawRecurcyLine(new Point(c2.Recurcys.startPoint.X + 30,c2.Recurcys.startPoint.Y + 30),
                                                       new Point(c2.Recurcys.endPoint.X + 30,c2.Recurcys.endPoint.Y + 30),
                                                       c2.Recurcys.Color, c2.Recurcys.PenWidth, Area);
              AddNewObject(Area,recu,DrawObject.DrawObject.ObjectType.RecurcyLine);

              c1.Recurcys = recu;
              recu.recury_class = c1;

              SetText(Area, c1.Recurcys.mul1, c2.Recurcys.mul1);
              SetText(Area, c1.Recurcys.mul2, c2.Recurcys.mul2);
              SetText(Area, c1.Recurcys.RoleName, c2.Recurcys.RoleName);

          }
      }

      public void CopyClass(DrawArea Area, DrawClass temp)
      {
          switch(temp.ObjType)
          {
              case DrawObject.DrawObject.ObjectType.Class:
                  DrawClass Newc=new DrawClass(temp.Rectangle.X+30, temp.Rectangle.Y+30, temp.Rectangle.Width, temp.Rectangle.Height, temp.Color, temp.FillColor, temp.Filled, temp.PenWidth, Area);
                  AddNewObject(Area,Newc,DrawObject.DrawObject.ObjectType.Class);
                  SetClass(Area, Newc, temp);
                  break;
              case DrawObject.DrawObject.ObjectType.AbstractClass:
                  DrawAbstractClass Newab = new DrawAbstractClass(temp.Rectangle.X + 30, temp.Rectangle.Y + 30, temp.Rectangle.Width, temp.Rectangle.Height, temp.Color, temp.FillColor, temp.Filled, temp.PenWidth, Area);
                  AddNewObject(Area,Newab,DrawObject.DrawObject.ObjectType.AbstractClass);
                  SetClass(Area, Newab, temp);
                  break;
          }
          
      }

    //binary
      public void CopyBinary(DrawArea Area, DrawBinary temp)
      {
          DrawBinary binary=new DrawBinary(temp.Rectangle.X+30, temp.Rectangle.Y+30, temp.Rectangle.Width,temp.Rectangle.Height, temp.Color, temp.FillColor, temp.Filled, temp.PenWidth, Area);

          AddNewObject(Area, binary, DrawObject.DrawObject.ObjectType.Binary);
          for (int i = 0; i < temp.list_mul.Length; i++)
          {
              SetText(Area, binary.list_mul[i], temp.list_mul[i]);

          }
          binary.p1 = new Point(temp.p1.X + 30, temp.p1.Y + 30);
          binary.p2 = new Point(temp.p2.X + 30, temp.p2.Y + 30);
          binary.p3 = new Point(temp.p3.X + 30, temp.p3.Y + 30);
      }
      //nary
      public void CopyNary(DrawArea Area, DrawNary temp)
      {
          DrawNary nary = new DrawNary(temp.Rectangle.X + 30, temp.Rectangle.Y + 30, temp.Rectangle.Width, temp.Rectangle.Height, temp.Color, temp.FillColor, temp.Filled, temp.PenWidth, Area);

          AddNewObject(Area, nary, DrawObject.DrawObject.ObjectType.Nary);
          for (int i = 0; i < temp.list_mul.Length; i++)
          {
              SetText(Area, nary.list_mul[i], temp.list_mul[i]);

          }
          nary.p1 = new Point(temp.p1.X + 30, temp.p1.Y + 30);
          nary.p2 = new Point(temp.p2.X + 30, temp.p2.Y + 30);
          nary.p3 = new Point(temp.p3.X + 30, temp.p3.Y + 30);
          nary.p4 = new Point(temp.p4.X + 30, temp.p4.Y + 30);
      }
    //exassociation
      public void CopyExAss(DrawArea Area, DrawExtraAssociation temp)
      {
          DrawExtraAssociation ex = new DrawExtraAssociation(new Point(temp.startPoint.X + 30, temp.startPoint.Y + 30), 
                                                             new Point(temp.center1.X + 30, temp.center1.Y + 30), 
                                                             new Point(temp.center2.X+30,temp.center2.Y+30), 
                                                             new Point(temp.endPoint.X+30, temp.endPoint.Y+30),
                                                             temp.Color, temp.PenWidth, Area);
          AddNewObject(Area,ex, DrawObject.DrawObject.ObjectType.ExtraAssociation);

          SetText(Area, ex.mul_left, temp.mul_left);
          SetText(Area, ex.mul_right, temp.mul_right);
          SetText(Area, ex.RoleName, temp.RoleName);
          SetTri(Area, ex.role_left_tri, temp.role_left_tri);
          SetTri(Area, ex.role_right_tri, temp.role_right_tri);

      }
    //
      public void CopyCutImplement(DrawArea Area,int flag)
      {
          List<DrawObject.DrawObject> temp;
          if(flag==1) temp = List_Copy;
          else temp = List_Cut;

          foreach (DrawObject.DrawObject obj in temp)
          {
              switch (obj.ObjType)
              {
                  case DrawObject.DrawObject.ObjectType.AssociationLine:
                  case DrawObject.DrawObject.ObjectType.Generalization:
                  case DrawObject.DrawObject.ObjectType.Composition:
                  case DrawObject.DrawObject.ObjectType.Aggernation:
                  case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                      DrawAssociation ass = (DrawAssociation)obj;
                      CopyAss(Area, ass);
                      break;
                  case DrawObject.DrawObject.ObjectType.Class:
                  case DrawObject.DrawObject.ObjectType.AbstractClass:
                      DrawClass c=(DrawClass)obj;
                      CopyClass(Area, c);
                      break;
                  case DrawObject.DrawObject.ObjectType.Binary:
                      DrawBinary b = (DrawBinary)obj;
                      CopyBinary(Area, b);
                      break;
                  case DrawObject.DrawObject.ObjectType.Nary:
                      DrawNary n = (DrawNary)obj;
                      CopyNary(Area, n);
                      break;
                  case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                      DrawExtraAssociation ex = (DrawExtraAssociation)obj;
                      CopyExAss(Area, ex);
                      break;
                  case DrawObject.DrawObject.ObjectType.text:
                      DrawText t = (DrawText)obj;

                      break;
              }
          }
      }

      public void CopyManager(DrawArea Area)
      {
          if (List_Copy != null)
          {
              CopyCutImplement(Area,1);
          }
      }

      #endregion

      #region Cut


      public void CutManager(DrawArea Area)
      {
          if (List_Cut != null)
          {
              //MessageBox.Show(OldArea.Graphics.Count.ToString());
              CopyCutImplement(Area,2);
              Area.Graphics.UnselectAll();
              foreach (DrawObject.DrawObject obj in List_Cut)
              {
                  obj.Selected=true;
              }
              if (OldArea == Area)
              {
                  Area.Graphics.DeleteSelection();
              }
              else
              {
                  OldArea.Graphics.DeleteSelection();
              }

              List_Cut.Clear();
              //MessageBox.Show(OldArea.Graphics.Count.ToString());
          }
      }

      #endregion 
    }
}
