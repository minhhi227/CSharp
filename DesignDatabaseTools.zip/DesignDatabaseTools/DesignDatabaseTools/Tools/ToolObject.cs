﻿
using System.Windows.Forms;
using DesignDatabaseTools.DrawObject;


namespace DesignDatabaseTools.Tools
{
	
 class ToolObject : Tool
	{

		private Cursor cursor;

		protected Cursor Cursor
		{
			get { return cursor; }
			set { cursor = value; }
		}


        public override void OnMouseUp(DrawArea drawArea, MouseEventArgs e)
		{
			//TODO: xu ly su kien tha chuot (ap dung cho tat ca cac object)

            if (drawArea.Graphics.Count > 0)  drawArea.Graphics[0].Normalize();

			drawArea.Capture = false;
			drawArea.Refresh();
		}

	
		public void AddNewObject(DrawArea drawArea, DrawObject.DrawObject o, DrawObject.DrawObject.ObjectType type)
		{
			//TODO: add object GraphicList

            drawArea.Graphics.UnselectAll();
            o.Selected = true;
            o.Dirty = true;
            o.ID = drawArea.Graphics.Count + 1;
            o.ObjType = type;
            drawArea.Graphics.Add(o);    // add vao graphic list
           
            drawArea.Owner.EntryInfo.Items.Add("Object ID:" + o.ID);   // add vao entryinfo
            drawArea.Owner.EntryID2.Items.Add("Object ID:" + o.ID);   // add vao entryinfo
                                                                     // add object type
            drawArea.Capture = true;
            drawArea.Refresh();

		}
	}
}