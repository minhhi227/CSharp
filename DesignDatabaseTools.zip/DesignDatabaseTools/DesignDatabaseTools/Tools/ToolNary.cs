﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Tools
{
    class ToolNary : ToolObject
    {
        public override void OnMouseDown(DrawArea drawArea, MouseEventArgs e)
        {
            Point p = drawArea.BackTrackMouse(new Point(e.X, e.Y));
            drawArea.ObjectType = DrawObject.DrawObject.ObjectType.Nary;
            drawArea.LineColor = Color.Black;
            drawArea.DrawFilled = false;
                AddNewObject(drawArea, 
                    new DrawNary(p.X, p.Y, 30, 30, drawArea.LineColor, drawArea.FillColor, drawArea.DrawFilled, drawArea.LineWidth,drawArea), 
                    drawArea.ObjectType);
            
        }

        public override void OnMouseMove(DrawArea drawArea, MouseEventArgs e)
        {
            //TODO: xu ly chuot di chuyen
        }
    }
}
