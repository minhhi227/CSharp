﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace DesignDatabaseTools.ViewTab
{
    class SildeShow
    {

        int countImage = 0;
        int count = 0;
        string[] imgSet;

        private string GetDirectory(string fileName)
        {
            int i = 0;
            for (i = fileName.Length - 1; i > 0; i--)
                if (fileName[i] == '\\')
                    break;
            string s = fileName.Substring(0, i);
            return s;
        }

        private void GetImageFile(string[] dir)
        {
            for (int i = 0; i < dir.Length - 1; i++)
            {
                string exten = Path.GetExtension(dir[i]).ToLower();
                if (exten == ".jpg" || exten == ".bmp")
                    imgSet[countImage++] = dir[i];
            }
        }

        /*
     private void SlideShowClick_Click(object sender, EventArgs e)
     {
         if (image != null)
         {
             countImage = 0;
             imgSet = null;
             count = 0;

             if (tmrDisplay.Enabled == true)
             {
                 tmrDisplay.Stop();
             }
             else
             {
                 string dir = GetDirectory(strFileName);
                 string[] fileDir = Directory.GetFiles(dir);
                 imgSet = new string[fileDir.Length];
                 GetImageFile(fileDir);

                 tmrDisplay.Start();
             }
         }
     }

     private void Back_Click(object sender, EventArgs e)
     {
         if (image != null)
         {
             if (imgSet == null)
             {
                 string dir = GetDirectory(strFileName);
                 string[] fileDir = Directory.GetFiles(dir);
                 imgSet = new string[fileDir.Length];
                 GetImageFile(fileDir);
             }

             if (imgSet != null)
             {
                 //Tim vi tri hinh trong thu muc
                 for (int i = 0; i < countImage; i++)
                     if (strFileName == imgSet[i])
                     {
                         count = i - 1;
                         if (count == -1)
                             count = countImage - 1;
                         break;
                     }
                 Display(sender, e);
             }
         }
     }

     private void Next_Click(object sender, EventArgs e)
     {
         if (image != null)
         {
             if (imgSet == null)
             {
                 string dir = GetDirectory(strFileName);
                 string[] fileDir = Directory.GetFiles(dir);
                 imgSet = new string[fileDir.Length];
                 GetImageFile(fileDir);
             }

             if (imgSet != null)
             {
                 //Tim vi tri hinh trong thu muc
                 for (int i = 0; i < countImage; i++)
                     if (strFileName == imgSet[i])
                     {
                         count = i + 1;
                         if (count == countImage)
                             count = 0;
                         break;
                     }
                 Display(sender, e);
             }
         


         }
     }

        
     */


    }
}
