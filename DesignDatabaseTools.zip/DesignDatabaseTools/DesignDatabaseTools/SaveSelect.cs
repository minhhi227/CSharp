﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Word = Microsoft.Office.Interop.Word;
using System.Reflection;

namespace DesignDatabaseTools
{
    public partial class SaveSelect : Form
    {

        private ResultForm frmowner;

        public ResultForm FrmOwner
        {
            get { return frmowner; }
            set { frmowner = value; }
        }


        public SaveSelect()
        {
            InitializeComponent();
        }

        private void Word_Click(object sender, EventArgs e)
        {
            if (FrmOwner.ResultText.Text.Length > 0)
            {
                Dictionary<string, string> dKeywords = new Dictionary<string, string>();

                dKeywords.Add("Name", FrmOwner.ResultText.Text);

                Process(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\MyDocument.docx",
                    Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Output.pdf",
                    dKeywords, 1);

            }
            else
            {
                MessageBox.Show("ERROR");
            }
        }

        private void Pdf_Click(object sender, EventArgs e)
        {
            
            if (FrmOwner.ResultText.Text.Length > 0)
            {
                Dictionary<string, string> dKeywords = new Dictionary<string, string>();

                dKeywords.Add("Name", FrmOwner.ResultText.Text);

                Process(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\MyDocument.docx",
                    Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Output.pdf",
                    dKeywords,2);

                //I'll open the PDF for you but it is located on your desktop
                System.Diagnostics.Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Output.pdf");
            }
            else
            {
                MessageBox.Show("ERROR");
            }

        }

        public static bool Process(string strWordDoc, string strPDFDoc, Dictionary<string, string> dReplacements,int flag)
        {
            //A set of objects needed to pass into the calls
            object oMissing = System.Reflection.Missing.Value;
            object oFalse = false;
            object oTrue = true;

            //The variable that will store the return value
            bool bolOutput = true;

            //Creates the needed objects (the application and the document)
            Word._Application oWord;
            Word._Document oDoc;

            //Checks to see if the file does not exist (which would throw an error)
            if (!System.IO.File.Exists(strWordDoc))
            {
                MessageBox.Show("The file does not exist on the path specified.");
                return false;
            }

            try
            {

                //Start up Microsoft Word
                oWord = new Word.Application();
                oWord.Visible = true;
                if (flag == 1)
                {
                    oDoc = oWord.Documents.Open(strWordDoc, oFalse, oTrue);
                  
                    foreach (Word.Range oRange in oDoc.StoryRanges)
                    {
                        //Loops through our Dictionary looking for the keys to replace
                        foreach (KeyValuePair<string, string> dEntry in dReplacements)
                        {
                            oRange.Find.Text = dEntry.Key.ToString();
                            oRange.Find.Replacement.Text = dEntry.Value.ToString();
                            oRange.Find.Wrap = Word.WdFindWrap.wdFindContinue;
                            oRange.Find.Execute(Replace: Word.WdReplace.wdReplaceAll);
                        }
                    }
                }
                else
                {
                    oDoc = oWord.Documents.Open(strWordDoc, oFalse, oTrue);

                    foreach (Word.Range oRange in oDoc.StoryRanges)
                    {
                        //Loops through our Dictionary looking for the keys to replace
                        foreach (KeyValuePair<string, string> dEntry in dReplacements)
                        {
                            oRange.Find.Text = dEntry.Key.ToString();
                            oRange.Find.Replacement.Text = dEntry.Value.ToString();
                            oRange.Find.Wrap = Word.WdFindWrap.wdFindContinue;
                            oRange.Find.Execute(Replace: Word.WdReplace.wdReplaceAll);
                        }
                    }


                    oDoc.ExportAsFixedFormat(strPDFDoc, Word.WdExportFormat.wdExportFormatPDF);
                    oDoc.Close(oFalse, oMissing, oMissing);
                    oWord.Quit(oFalse, oMissing, oMissing);
                    bolOutput = true;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                bolOutput = false;
            }
            finally
            {
                oDoc = null;
                oWord = null;
            }

            return bolOutput;

        }
    }
}
