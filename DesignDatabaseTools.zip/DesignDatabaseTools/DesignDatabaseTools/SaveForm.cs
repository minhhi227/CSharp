﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using DockToolKit;

using DevComponents.WinForms;
using DevComponents.DotNetBar;


namespace DesignDatabaseTools
{
    public partial class SaveForm : Form
    {
          
        private bool flag;   //close application-true or close tab-false
        private MainForm owner;
        private DocManager docManager;
        private const string registryPath = "Software\\AlexF\\DrawTools";
        DockTabClosingEventArgs DockTabEvent;

        public bool Flag
        {
            get { return flag; }
            set { flag = value; }
        }

        public MainForm Owner
        {
            get { return owner; }
            set { owner = value; }
        }

        public DockTabClosingEventArgs Event
        {
            get { return DockTabEvent; }
            set { DockTabEvent = value; }
        }
       
        public void Init()
        {
            DocManagerData data = new DocManagerData();
            data.FormOwner = this;
            data.UpdateTitle = true;
            data.FileDialogFilter = "DrawTools files (*.dtl)|*.dtl|All Files (*.*)|*.*";
            data.NewDocName = "Untitled.dtl";
            data.RegistryPath = registryPath;

            docManager = new DocManager(data);
            docManager.RegisterFileType("dtl", "dtlfile", "DrawTools File");

            

        }
        public SaveForm()
        {
            Init();
            InitializeComponent();

        }

        private void SaveFormLoad(object sender, EventArgs e)
        {
            this.Question.Text = "Do you want to save changes you made to this document ?";
        }

        public DockContainerItem checknew()
        {
            for (int i = 0; i < Owner.CenterBar.Items.Count-1; i++)
            {
                DockContainerItem temp = (DockContainerItem)Owner.CenterBar.Items[i];
                string name = temp.Text.Substring(0, 4);
                if (name == "Page" && temp.Visible == true)
                {
                    temp.Enabled = true;
                    return temp;
                }
            }

            return null;
        }


        private void Save_Click(object sender, EventArgs e)
        {
            //TODO: sao luu document
            docManager.SaveDocument(DocManager.SaveType.Save);

            if (flag == true)
            {
                    if (checknew()!=null)
                    {
                      
                        SaveForm newform = new SaveForm();
                        newform.Owner = this.Owner;
                        newform.Flag = true;
                        newform.Show();

                        checknew().Visible = false;
                        this.Close();
                    }
                    else
                    {
                        Owner.Close();
                    }

            }

            else
            {
                Close();
                DockTabEvent.DockContainerItem.Visible = false;
            }
        
        }
       

        private void NoSave_Click(object sender, EventArgs e)
        {
           
            if (flag == true)
            {
                if (checknew()!=null)
                {
                    
                    SaveForm newform = new SaveForm();
                    newform.Owner = this.Owner;
                    newform.Flag = true;
                    newform.Show();

                    checknew().Visible = false;
                    this.Close();
                }
                else
                {
                    Owner.Close();
                }
                
            }
            else
            {
                 Close();
                 DockTabEvent.DockContainerItem.Visible = false;
            }

         
            
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Close();
           
        }

        

        
    }
}
