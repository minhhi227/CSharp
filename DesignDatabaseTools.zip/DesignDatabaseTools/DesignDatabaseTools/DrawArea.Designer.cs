﻿namespace DesignDatabaseTools
{
    partial class DrawArea
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer_tick);
            // 
            // DrawArea
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ForeColor = System.Drawing.SystemColors.Window;
            this.Name = "DrawArea";
            this.Load += new System.EventHandler(this.DrawArea_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Area_Paint);
            this.DoubleClick += new System.EventHandler(this.AreaDoubleClick);
            this.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.AreaMouseDoubleClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Area_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.AreaMouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Area_MouseUp);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
    }
}
