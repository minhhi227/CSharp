﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Globalization;
using System.Security;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using Microsoft.Win32;
using System.Diagnostics;
using System.Threading;

using DevComponents.WinForms;
using DevComponents.DotNetBar;


using DesignDatabaseTools.HomeTab;
using DesignDatabaseTools.ImageProcess;
using DesignDatabaseTools.ToolsTab;
using DesignDatabaseTools.DrawObject;
using DesignDatabaseTools.Methods;
using DesignDatabaseTools.Tools;
using DockToolKit;
using DesignDatabaseTools.MainFuction;
using DesignDatabaseTools.Command;
using UMLDes.GUI;

namespace DesignDatabaseTools
{
    public partial class MainForm : Form
    {
        #region attributes
        //ConvertForm ConvertFrm = new ConvertForm();
        ProcessImage image = new ProcessImage();
        FileMenu file = new FileMenu();
        ShowHide showhide = new ShowHide();
        Property Property = new Property();
        AreaFunction areafunc = new AreaFunction();
        CheckProperClass check_diagram = new CheckProperClass();
       
        private DrawArea MainArea;                           //MAIN AREA ACTIVE
        List<DrawArea> ListArea = new List<DrawArea>();

        private DocManager docManager;
        private MruManager mruManager;
        private DragDropManager dragDropManager;
        private CopyCutManager CopyPaste;
        private ToolReGraphic Regraphic;
        private Layer ActiveLayer;                            //layer chua graphic khi mo file

        //command
        private CommandDelete command_delete;
     

        private bool _controlKey = false;
        private bool _shiftkey = false;
        private bool _panMode = false;

        private const string registryPath = "Software\\AlexF\\DrawTools";
        //rulers
        public Rulers Ruler;
        public Rulers Ruler1;
        public List<Rulers> list_ruler_ngang = new List<Rulers>();
        public List<Rulers> list_ruler_doc = new List<Rulers>();
        public int current_ruler = 0;
        //file name
        string[] ListPathFileName = new string [5];

        #endregion

        #region get/set

        public DocManager DocManager
        {
            get { return docManager; }
            set { docManager = value; }
        }

        #endregion

        #region Constructor

        public MainForm()
        {
            InitializeComponent();
            MouseWheel += new MouseEventHandler(MainForm_MouseWheel);
            
        }

        private void Init()
        {
            
            //ZOOM
            this.slider1.Text =(this.slider1.Value*2).ToString() + "%";
            
            this.ZoomValue.Items.Add("10%");
            this.ZoomValue.Items.Add("30%");
            this.ZoomValue.Items.Add("50%");
            this.ZoomValue.Items.Add("80%");
            this.ZoomValue.Items.Add("100%");
            this.ZoomValue.Items.Add("150%");
            this.ZoomValue.Items.Add("200%");
            this.ZoomValue.Items.Add("300%");
            this.ZoomValue.Items.Add("500%");

            this.ZoomValue.SelectedIndex = 4;
          
            //TOOLBAR
            this.View.Checked = true;
            this.Insert.Checked = true;
            this.DesignTools.Checked = true;
            this.Toolbox.Checked = true;
            this.Status.Checked = true;
            this.Properties.Checked = true;

            //show/hide
            this.checkRuler.Checked = true;
           // this.GirdBox.Checked = true;

            //load font

            LoadFont();
            //datatype
            AddDatatype(List_datatype);
          //  DatatypeTabStrip.Visible = false;
            AddOpertype(List_Oper);
           // OperTabStrip.Visible = false;
            //tabstrip
           // superTabStrip.Visible = false;
            //check
            StopCheck.Enabled = false;
            //run
            StopRun.Enabled = false;
            PauseRun.Enabled = false;
            RefreshRun.Enabled = false;
            Panning_reset.Enabled = false;

            //options

            DerivedColumn.Enabled = false;
            CompositeName.Enabled = false;
            MultiValues.Enabled = false;

            //tools
            Insertext.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            
            // Helper objects (DocManager and others)
           InitializeHelperObjects();

           this.Init();
           //Init Area
           DrawArea ogrinalArea= new DrawArea();
           ogrinalArea.Location = new Point(50, 50);
           ogrinalArea.Size = new Size(4900, 4900);
           ogrinalArea.Owner = this;
           
           ListArea.Add(ogrinalArea);
           Page1.Control.Controls.Add(ogrinalArea);
           ogrinalArea.Initialize(this, docManager);

           MainArea = ogrinalArea;

           LoadSettingsFromRegistry();
           // Submit to Idle event to set controls state at idle time
           Application.Idle += delegate { SetStateOfControls(); };

           //Copy manager
           CopyPaste = new CopyCutManager();
           CopyPaste.Area = MainArea;

            //Regraphic
           Regraphic = new ToolReGraphic();
            //add datatype
           AddDatatype(AttType1);
           AddDatatype(AttType2);
           AddDatatype(AttType3);
            //add oper
           AddOpertype(Optype1);
           AddOpertype(Optype2);
           AddOpertype(Optype3);
            //ruler
           Rulers rr1 = rulerngang(0,0);
           Rulers rr2 = rulerdoc(0,0);
           Page1.Control.Controls.Add(rr1);
           Page1.Control.Controls.Add(rr2);
           list_ruler_ngang.Add(rr1);
           list_ruler_doc.Add(rr2);
           Ruler = rr1;
           Ruler1 = rr2;
           
           selectfont();  //font
        }

        

        #endregion

        #region tooltip
        public SuperTooltipInfo tip_info(string text)
        {
            SuperTooltipInfo tip = new SuperTooltipInfo();
            //tip.HeaderText = "Description";
            //tip.FooterText = "Click Help for more details";
            tip.BodyText = text;
           
            return tip;
        }
        public void TooltipSet(Point location, string text)
        {

            //superTooltip.ShowTooltip(tip_info(text), location);
            //superTooltip.SetSuperTooltip(MainArea, tip_info(text));
            
        }
        #endregion

        //----------------------------------------------Others Function----------------------------------------

        #region MainForm Maintain

        private void MainFormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (!docManager.CloseDocument())
                    e.Cancel = true;
            }

            SaveSettingsToRegistry();
           
        }

        private void MainFormResize(object sender, EventArgs e)
        {
            if (WindowState != FormWindowState.Minimized &&  MainArea != null)
            {
                //ResizeDrawArea();
            }
            
        }

        #endregion

        #region Mouse Functions

        private void MainForm_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta != 0)
            {
                if (_controlKey)
                {
                    // We are panning up or down using the wheel
                    if (e.Delta > 0)
                        MainArea.PanY += 10;
                    else
                        MainArea.PanY -= 10;
                    Invalidate();
                }
                else
                {
                    // We are zooming in or out using the wheel
                    
                    if (e.Delta > 0)
                        AdjustZoom(.1f);
                    else
                        AdjustZoom(-.1f);
                     
                }

                SetStateOfControls();
                return;
            }
        }

        public void SetStateOfControls()
        {
            //TODO: Tao cac trang thai tren cac menu
            this.Association.Checked = (MainArea.ActiveTool == DrawArea.DrawToolType.Association);

            //Undo,redo
            this.Undo.Enabled = MainArea.CanUndo;
            this.Redo.Enabled = MainArea.CanRedo;
            //Paste
            this.Paste.Enabled = CopyPaste.CanPaste;

            
        }


       
        #endregion 

        #region DocManager Control

        private void InitializeHelperObjects()
        {
            // DocManager
            DocManagerData data = new DocManagerData();
            data.FormOwner = this;
            data.UpdateTitle = true;
            data.FileDialogFilter = "DrawTools files (*.dtl)|*.dtl|All Files (*.*)|*.*";
            data.NewDocName = "Untitled.dtl";
            data.RegistryPath = registryPath;

            docManager = new DocManager(data);
            docManager.RegisterFileType("dtl", "dtlfile", "DrawTools File");

            // Subscribe to DocManager events.
            docManager.SaveEvent += docManager_SaveEvent;
            docManager.LoadEvent += docManager_LoadEvent;

            // Make "inline subscription" using anonymous methods.
            docManager.OpenEvent += delegate(object sender, OpenFileEventArgs e)
            {
                // Update MRU List
                if (e.Succeeded)
                    mruManager.Add(e.FileName);
                else
                    mruManager.Remove(e.FileName);
            };

            docManager.DocChangedEvent += delegate
            {
                MainArea.Refresh();
                MainArea.ClearHistory();
            };

            docManager.ClearEvent += delegate
            {
                bool haveObjects = false;
              /*
                if (MainArea.Graphics != null)
                {
                    if (MainArea.Graphics.Count > 1)
                    {
                        haveObjects = true;

                    }
                }
                */
                if (haveObjects)
                {
                    MainArea.Clear();
                    MainArea.ClearHistory();
                    MainArea.Refresh();
                }
            };

            docManager.NewDocument();
            
            // DragDropManager
            dragDropManager = new DragDropManager(this);
            dragDropManager.FileDroppedEvent += delegate(object sender, FileDroppedEventArgs e) { docManager.OpenDocument(e.FileArray.GetValue(0).ToString()); };

            // MruManager
            mruManager = new MruManager();
            mruManager.Initialize(this,registryPath); // Registry path to keep MRU list

            mruManager.MruOpenEvent += delegate(object sender, MruFileOpenEventArgs e) { docManager.OpenDocument(e.FileName); };
        }

        private void docManager_LoadEvent(object sender, SerializationEventArgs e)
        {
            try
            {
               
               ActiveLayer = (Layer) e.Formatter.Deserialize(e.SerializationStream);
                
            }
            catch (ArgumentNullException ex)
            {
                HandleLoadException(ex, e);
            }
            catch (SerializationException ex)
            {
                HandleLoadException(ex, e);
            }
            catch (SecurityException ex)
            {
                HandleLoadException(ex, e);
            }
        }


        private void docManager_SaveEvent(object sender, SerializationEventArgs e)
        {
            // DocManager asks to save document to supplied stream
            try
            {
                e.Formatter.Serialize(e.SerializationStream, MainArea.TheLayer);
            }
            catch (ArgumentNullException ex)
            {
                HandleSaveException(ex, e);
            }
            catch (SerializationException ex)
            {
                HandleSaveException(ex, e);
            }
            catch (SecurityException ex)
            {
                HandleSaveException(ex, e);
            }
        }

        #endregion

        #region Registry
        private void LoadSettingsFromRegistry()
        {
            try
            {
                RegistryKey key = Registry.CurrentUser.CreateSubKey(registryPath);

                DrawObject.DrawObject.LastUsedColor = Color.FromArgb((int)key.GetValue(
                                                                "Color",
                                                                Color.Black.ToArgb()));

                DrawObject.DrawObject.LastUsedPenWidth = (int)key.GetValue(
                                                    "Width",
                                                    1);
            }
            catch (ArgumentNullException ex)
            {
                HandleRegistryException(ex);
            }
            catch (SecurityException ex)
            {
                HandleRegistryException(ex);
            }
            catch (ArgumentException ex)
            {
                HandleRegistryException(ex);
            }
            catch (ObjectDisposedException ex)
            {
                HandleRegistryException(ex);
            }
            catch (UnauthorizedAccessException ex)
            {
                HandleRegistryException(ex);
            }
        }

        
        private void SaveSettingsToRegistry()
        {
            try
            {
                RegistryKey key = Registry.CurrentUser.CreateSubKey(registryPath);

                key.SetValue("Color", DrawObject.DrawObject.LastUsedColor.ToArgb());
                key.SetValue("Width", DrawObject.DrawObject.LastUsedPenWidth);
            }
            catch (SecurityException ex)
            {
                HandleRegistryException(ex);
            }
            catch (ArgumentException ex)
            {
                HandleRegistryException(ex);
            }
            catch (ObjectDisposedException ex)
            {
                HandleRegistryException(ex);
            }
            catch (UnauthorizedAccessException ex)
            {
                HandleRegistryException(ex);
            }
        }

        private void HandleRegistryException(Exception ex)
        {
            Trace.WriteLine("Registry operation failed: " + ex.Message);
        }

        #endregion

        #region Exception Handler

        private void HandleLoadException(Exception ex, SerializationEventArgs e)
        {
            MessageBox.Show(this,
                            "Open File operation failed. File name: " + e.FileName + "\n" +
                            "Reason: " + ex.Message,
                            Application.ProductName);

            e.Error = true;
        }

        private void HandleSaveException(Exception ex, SerializationEventArgs e)
        {
            MessageBox.Show(this,
                            "Save File operation failed. File name: " + e.FileName + "\n" +
                            "Reason: " + ex.Message,
                            Application.ProductName);

            e.Error = true;
        }

        #endregion

        #region DockTab event

        //updtate recentfile
        public void UpdateRecentFile(string newfilename)
        {
            for (int i = 4; i > 0; i--)
            {
                ListPathFileName[i] = ListPathFileName[i - 1];
            }
            ListPathFileName[0] = newfilename;

            this.RecentFile5.Text = Path.GetFileName(ListPathFileName[4]);
            this.RecentFile4.Text = Path.GetFileName(ListPathFileName[3]);
            this.RecentFile3.Text = Path.GetFileName(ListPathFileName[2]);
            this.RecentFile2.Text = Path.GetFileName(ListPathFileName[1]); 
            this.RecentFile1.Text = Path.GetFileName(ListPathFileName[0]); 
        }

     
        private void DockTab_Chage(object sender, DockTabChangeEventArgs e)
        {
           //TODO: xu ly su kien tab change
            //status bar
            this.PageName.Text = e.NewTab.Text;
            //change mainarea
            
            int temp2 = Convert.ToInt32(e.NewTab.Name.Substring(4));
            MainArea = ListArea[temp2-1];

            this.NumberObj.Text = MainArea.Graphics.Count.ToString();
            //change copypase
            CopyPaste.Area = MainArea;
            //rulers
            if (temp2 - 1 < list_ruler_ngang.Count)
            {
                Ruler = list_ruler_ngang[temp2 - 1];
            }
            if (temp2 - 1 < list_ruler_doc.Count)
            {
                Ruler1 = list_ruler_doc[temp2 - 1];
            }
                   
            //superstabstip
            DockContainerItem d = (DockContainerItem)e.NewTab;
          
            d.Control.Controls.Add(MainArea);
           
        }

        private void DockTab_Closed(object sender, DockTabClosingEventArgs e)
        {
            
        }

        private void DockTab_Closing(object sender, DockTabClosingEventArgs e)
        {
            //TODO: su ly su kien closed tab
            e.Cancel = true;
            string name = e.DockContainerItem.Text.Substring(0, 4);

            if (name == "Page")
            {
                SaveForm Saveform = new SaveForm();
                Saveform.Owner = this;
                Saveform.Flag = false;
                Saveform.Event = e;
                Saveform.Show();
            }
            else
            {
                e.DockContainerItem.Visible = false;
            }
            

        }


        #endregion

        //----------------------------------------------File Tab------------------------------------------------

        #region region1

        //TODO:thao tac voi NEW,OPEN,SAVE AS
        private void OpenDocument_Click(object sender, EventArgs e)
        {
            docManager.OpenDocument("");
            OpenTab(docManager.FileName, ActiveLayer);
            MainArea.DrawFilled = true;
            this.Refresh();
            SetTree();
        }

        private void NewDocument_Click(object sender, EventArgs e)
        {
            OpenTab(null, null);
            this.Refresh();
            SetTree();
        }

        private void SaveAs_Click(object sender, EventArgs e)
        {
            docManager.SaveDocument(DocManager.SaveType.SaveAs);

        }


        #endregion

        #region region2

        // TODO: thao tac voi SHARE,PRINT

        #endregion

        #region region3

        //TODO: thao tac voi CLOSE
        private void Close_App()
        {

            SaveForm Saveform = new SaveForm();
            Saveform.Owner = this;
            Saveform.Flag = true;
            Saveform.Show();
        }
        private void Close_Click(object sender, EventArgs e)
        {
            Close_App();
        }

        #endregion

        #region Recent File
        public void OpenRecentFile(string pathname)
        {
            if (docManager.OpenDocument2(pathname))
            {

                MainArea.Clear();
                MainArea.Refresh();

                if (ActiveLayer != null) MainArea.Graphics = ActiveLayer.Graphics;
                areafunc.AssignArea(MainArea.Graphics, MainArea);
                MainArea.DrawFilled = true;

                this.Refresh();
                SetTree();
            }
        }

        private void RecentFile1_Click(object sender, EventArgs e)
        {
            OpenRecentFile(ListPathFileName[0]);
        }

        private void RecentFile2_Click(object sender, EventArgs e)
        {
            OpenRecentFile(ListPathFileName[1]);
        }

        private void RecentFile3_Click(object sender, EventArgs e)
        {
            OpenRecentFile(ListPathFileName[2]);
        }

        private void RecentFile4_Click(object sender, EventArgs e)
        {
            OpenRecentFile(ListPathFileName[3]);
        }

        private void RecentFile5_Click(object sender, EventArgs e)
        {
            OpenRecentFile(ListPathFileName[4]);
        }

       
        #endregion

        //----------------------------------------------Home Tab------------------------------------------------

        #region MenuFile

        private void OpenTab(string filename, Layer layer)
        {
            //new dock tab
            DockContainerItem newpage = new DockContainerItem();

            if (filename == null)
            {
                newpage.Text = "Page " + (CenterBar.Items.Count + 1).ToString();
                newpage.Name = "Page" +  (ListArea.Count + 1).ToString();
            }
            else
            {
                newpage.Text = filename;
                newpage.Name = "Page" + (ListArea.Count + 1).ToString();
            }

            PanelDockContainer NewPaneldock = new PanelDockContainer();
            NewPaneldock.Style.BackColor1.Color = MainRegion.Style.BackColor1.Color;
            NewPaneldock.Style.BackColor2.Color = MainRegion.Style.BackColor2.Color;
            NewPaneldock.AutoScroll = true;
            newpage.Control = NewPaneldock;

            //supertabstrip
         //   NewPaneldock.Controls.Add(superTabStrip);
           // NewPaneldock.Controls.Add(DatatypeTabStrip);
          //  NewPaneldock.Controls.Add(OperTabStrip);

            //new area
            DrawArea NewArea = new DrawArea();
            NewArea.Location = new Point(50, 50);
            NewArea.Size = new Size(4900, 4900);
            NewArea.Owner = this;

            if (layer != null) NewArea.Graphics = ActiveLayer.Graphics;  //set listgraphic cho area

            ListArea.Add(NewArea);

            newpage.Control.Controls.Add(NewArea);
            NewArea.Initialize(this, docManager);
            //set active area
            MainArea = NewArea;

            //add tab
            CenterBar.Items.Add(newpage);
            newpage.Visible = true;
            newpage.Selected= true;

            //assign area to object need to get area
            areafunc.AssignArea(NewArea.Graphics, NewArea);

            
            //add rule
            Rulers r1;
            Rulers r2;
            if (CenterBar.DockTabControl.Tabs.Count>1)
            {
                r1 = rulerngang(-50, -50);
                r2 = rulerdoc(-50, -50);
            }
            else
            {
                r1 = rulerngang(0, 20);
                r2 = rulerdoc(0, 0);
            }
            newpage.Control.Controls.Add(r1);
            newpage.Control.Controls.Add(r2);
            list_ruler_ngang.Add(r1);
            list_ruler_doc.Add(r2);
            Ruler = r1;
            Ruler1 = r2;

        }

        private void New_Document()
        {
            OpenTab(null, null);
            this.Refresh();
            SetTree();
        }
        private void New_Click(object sender, EventArgs e)
        {
            New_Document();
        }
        private void Open_Document()
        {
            if (docManager.OpenDocument(""))
            {
                OpenTab(docManager.FileName, ActiveLayer);
                MainArea.DrawFilled = true;
                this.Refresh();
                SetTree();
                //add list object ID into entryinfo
                EntryInfo.Items.Clear();
                EntryID2.Items.Clear();
                foreach (DrawObject.DrawObject o in MainArea.Graphics.GetListObject())
                {
                    EntryInfo.Items.Add("Object ID:" + o.ID);
                    EntryID2.Items.Add("Object ID:" + o.ID);
                }
            }
        }
        private void Open_Click(object sender, EventArgs e)
        {
            Open_Document();
        }
        private void Save_Document()
        {

            //change page name
            for (int i = 0; i < CenterBar.Items.Count; i++)
            {
                DockContainerItem temp = (DockContainerItem)CenterBar.Items[i];
                if (temp.Selected == true)
                {
                    if (temp.Text.Substring(0, 4) == "Page")
                    {
                        docManager.FileName = "";

                        MainArea.TheLayer.Graphics = MainArea.Graphics;
                        docManager.SaveDocument(DocManager.SaveType.Save);

                        if (docManager.FileName != "")
                        {
                            temp.Text = docManager.FileName;
                        }

                    }
                    else
                    {
                        MainArea.TheLayer.Graphics = MainArea.Graphics;
                        docManager.SaveDocument(DocManager.SaveType.Save);
                    }

                    break;
                }
            }

            //this.RecentFile1.Text = docManager.PathFileName;
            this.UpdateRecentFile(docManager.PathFileName);
        }
        private void Save_Click(object sender, EventArgs e)
        {
            Save_Document();
        }


        private void Paste_Click(object sender, EventArgs e)
        {
            CopyPaste.Area = MainArea;
            CopyPaste.Paste();
        }

        private void PasteMouseClick(object sender, MouseEventArgs e)
        {
        }

        private void Copy_Click(object sender, EventArgs e)
        {
            CopyPaste.Area = MainArea;
            CopyPaste.Copy();
        }

        private void Cut_Click(object sender, EventArgs e)
        {
            CopyPaste.Area = MainArea;
            CopyPaste.Cut();
        }

        #endregion 

        #region FontMenu
        
        //TODO:thao tac voi Font
        private void OpenFontBox()
        {

            FontDialog font = new FontDialog();
            if (font.ShowDialog() == DialogResult.OK)
            {
                //TODO: apply font vao text
                MainArea.Font = font.Font;
                ReGraphicCall(1);
            }
        }
        private void Fontbox_Click(object sender, EventArgs e)
        {
            OpenFontBox();
        }

        private void FontNameChanged(object sender, EventArgs e)
        {
            if (MainArea != null)
            {
                selectfont();
                ReGraphicCall(1);
            }
        }

        private void SizeFontChanged(object sender, EventArgs e)
        {
            if (MainArea != null)
            {
                selectfont();
                ReGraphicCall(1);
            }
        }

        private void StyleFontChanged(object sender, EventArgs e)
        {
            if (MainArea != null)
            {
                selectfont();
                ReGraphicCall(1);
            }
        }

        private void BackFontColorChanged(object sender, EventArgs e)
        {
            List<DrawObject.DrawObject> temp = MainArea.Graphics.ListSelected();
            //bo cac doi tuong text
            if (temp != null)
            {
                foreach (DrawObject.DrawObject obj in temp)
                {
                    if (obj.ObjType == DrawObject.DrawObject.ObjectType.text)
                    {
                        DrawText t = (DrawText)obj;
                        //Todo: lam back color
                    }
                }
            }
        }

        private void FontColorChanged(object sender, EventArgs e)
        {
            MainArea.FontColor = this.TextColor.SelectedColor;
            ReGraphicCall(1);

            this.TextColor.ForeColor = this.TextColor.SelectedColor;
        }

        #endregion

        #region BasicTools

        // TODO: thao tac voi BasicTools 

        private void Select_Click(object sender, EventArgs e)
        {
            //this.Select.Visible = true;
            if (this.Select.Checked)
            {
                this.Select.Checked = false;
            }
            else
            {
                this.Select.Checked = true;
                MainArea.ActiveTool = DrawArea.DrawToolType.Pointer;
            }
           
        }

        private void Undo_Click(object sender, EventArgs e)
        {
            MainArea.Undo();
        }

        private void Redo_Click(object sender, EventArgs e)
        {
            MainArea.Redo();
        }

        private void Panning_Click(object sender, EventArgs e)
        {
            Panning_reset.Enabled = true;

            _panMode = !_panMode;
            if (_panMode)
                Panning.Checked = true;
            else
                Panning.Checked = false;
            MainArea.ActiveTool = DrawArea.DrawToolType.Pointer;
            MainArea.Panning = _panMode;
            
        }

        private void Panning_reset_Click(object sender, EventArgs e)
        {
            _panMode = false;
            if (Panning.Checked)
                Panning.Checked = false;
            MainArea.Panning = false;
            MainArea.PanX = 0;
            MainArea.PanY = MainArea.OriginalPanY;
            MainArea.Invalidate();

            Panning_reset.Enabled = false;
        }

        private void OpenFindBox()
        {
            SearchForm find = new SearchForm();
            find.Area = MainArea;
            find.Owner = this;
            find.Show();
        }
        private void Find_Click(object sender, EventArgs e)
        {
            OpenFindBox();
        }

        #endregion

        #region ZoomMenu

        //TODO: thao tac voi Zoom

        private void ZoomOut_Click(object sender, EventArgs e)
        {
            AdjustZoom(-.1f);
        }

        private void ZoomIn_Click(object sender, EventArgs e)
        {
            AdjustZoom(.1f);
        }

        private void ZoomValue_Click(object sender, EventArgs e)
        {
            //Nothing
        }
        private void ZoomValueChage(object sender, EventArgs e)
        {
            if (MainArea != null)
            {
                switch (this.ZoomValue.Text)
                {

                    case "10%":
                        MainArea.Zoom = .1f;
                        break;

                    case "30%":
                        MainArea.Zoom = .3f;
                        break;
                    case "50%":
                        MainArea.Zoom = .5f;
                        break;
                    case "80%":
                        MainArea.Zoom = .8f;
                        break;
                    case "100%":
                        MainArea.Zoom = 1f;
                        break;
                    case "150%":
                        MainArea.Zoom = 1.5f;
                        break;
                    case "200%":
                        MainArea.Zoom = 2f;
                        break;
                    case "300%":
                        MainArea.Zoom = 3f;
                        break;
                    case "500%":
                        MainArea.Zoom = 5f;
                        break;

                }
                Refresh();
            }

            slider1.Text = ZoomValue.Text ;
            
        }

        


        #endregion

        //--------------------------------------Insert Tab-------------------------------------------------------

        #region PageMenu

        //TODO:thao tac voi Page
        private void InsertNewPage_Click(object sender, EventArgs e)
        {
            MainArea.Clear();
            MainArea.Refresh();
        }

        private void InsertOldPage_Click(object sender, EventArgs e)
        {
            docManager.OpenDocument("");
            
            MainArea.Clear();
            MainArea.Refresh();

            if (ActiveLayer != null) MainArea.Graphics = ActiveLayer.Graphics;
            areafunc.AssignArea(MainArea.Graphics, MainArea);
            MainArea.DrawFilled = true;

            this.Refresh();
            SetTree();
        }


        #endregion

        #region TextMenu

        private void Insertext_Click(object sender, EventArgs e)
        {
            removecheck();
            this.Insertext.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.insertText;

        }

        // TODO: thao tac voi Text 
        private void InsertImage_Click(object sender, EventArgs e)
        {
            removecheck();
            this.InsertImage.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Image;
          
        }


        private void Comment_Click(object sender, EventArgs e)
        {
            CommentForm form = new CommentForm();
            form.Area = MainArea;
            form.Show();
        }

      

        #endregion

        #region SymbolsMenu

        //TODO: thao tac voi Symbols

        #endregion

        //------------------------------------------View Tab---------------------------------------------------------

        #region PageSettup

        //TODO:thao tac voi PageSettup
     

        private void AreaColor_SelectedColorChanged(object sender, EventArgs e)
        {
            MainArea.BackColor = AreaColor.SelectedColor;
            AreaColor.ForeColor = AreaColor.SelectedColor;
            MainArea.Refresh();
        }

        #endregion

        #region SlideShow

        // TODO: thao tac voi SlideShow 
        private void SlideShowClick_Click(object sender, EventArgs e)
        {
            Slide Slideform = new Slide();
            List<Image> Images = new List<Image>();
            foreach (DrawArea area in ListArea)
            {
                Bitmap b = new Bitmap(area.Width, area.Height);
                Graphics g = Graphics.FromImage(b);
                if (SlideBack.SelectedColor != Color.Empty)
                {
                    g.Clear(SlideBack.SelectedColor);
                }
                else
                {
                    g.Clear(Color.White);
                }
                area.Draw(g);
                Images.Add(b);
            }
            Slideform.ListImage = Images;
            Slideform.Show();
        }


        #endregion

        #region Themes

        //TODO: thao tac voi  Themes

        #endregion

        #region ruler/gird


        private void CRuler_Click(object sender, EventArgs e)
        {
            Ruler1.pixels = Ruler.pixels = false;
            Ruler1.inches = Ruler.inches = false;
            Ruler1.centimeter = Ruler.centimeter = true;

            Ruler.Invalidate();
            Ruler.Refresh();

            Ruler1.Invalidate();
            Ruler1.Refresh();
        }

        private void IRuler_Click(object sender, EventArgs e)
        {
            Ruler1.pixels = Ruler.pixels = false;
            Ruler1.inches = Ruler.inches = true;
            Ruler1.centimeter = Ruler.centimeter = false;

            Ruler.Invalidate();
            Ruler.Refresh();

            Ruler1.Invalidate();
            Ruler1.Refresh();
        }

        private void PRuler_Click(object sender, EventArgs e)
        {
            Ruler1.pixels = Ruler.pixels = true;
            Ruler1.inches = Ruler.inches = false;
            Ruler1.centimeter = Ruler.centimeter = false;

            Ruler.Invalidate();
            Ruler.Refresh();

            Ruler1.Invalidate();
            Ruler1.Refresh();
        }


       
        #endregion

        //--------------------------------------Design tools Tab(cong cu chinh)--------------------------------------------

        #region others function
        public void removecheck()
        {
            this.Class.Checked = false;
            this.AbstractClass.Checked = false;
            this.Association.Checked = false;
            this.Binary.Checked = false;
            this.Nary.Checked = false;
            this.Generalization.Checked = false;
            this.Dymamic.Checked = false;
            this.Disjoint.Checked = false;
            this.Aggregation.Checked = false;
            this.Composition.Checked = false;
            this.Note.Checked = false;
            this.ExtraAssociation.Checked = false;
            this.AssociationClass.Checked = false;
            this.InsertImage.Checked = false;
            this.Insertext.Checked = false;
            this.Recurcy.Checked = false;
        }

        #endregion

        #region Class
        //TODO: thao tac voi Class,object,abstract class

        private void Select_Class()
        {
            removecheck();
            this.Class.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Class;
            MainArea.DrawFilled = true;
        }

        private void Class_Click(object sender, EventArgs e)
        {
            Select_Class();
        }

        private void Select_Abstractclass()
        {
            removecheck();
            this.AbstractClass.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.AbstractClass;
            MainArea.DrawFilled = true;
        }
        private void AbstractClass_Click(object sender, EventArgs e)
        {
            Select_Abstractclass();
        }

        #endregion


        #region Association

        //TODO: thao tac voi  Association

        private void Select_ASS()
        {
            removecheck();
            MainArea.ActiveTool = DrawArea.DrawToolType.Association;
            this.Association.Checked = true;
        }
        private void Association_Click(object sender, EventArgs e)
        {
            Select_ASS();
        }

        private void Select_EXASS()
        {
            removecheck();
            MainArea.ActiveTool = DrawArea.DrawToolType.ExtraAssociation;
            this.ExtraAssociation.Checked = true;
        }

        private void ExtraAssociation_Click(object sender, EventArgs e)
        {
            Select_EXASS();
        }
        private void Select_Binary()
        {
            removecheck();
            this.Binary.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Binary;
        }

        private void Binary_Click(object sender, EventArgs e)
        {
            Select_Binary();
        }
        private void Select_Nary()
        {
            removecheck();
            this.Nary.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Nary;
        }
        private void Nary_Click(object sender, EventArgs e)
        {
            Select_Nary();
        }
        private void Select_AssClass()
        {
            removecheck();
            this.AssociationClass.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.AssociationClass;
        }
        private void AssociationClass_Click(object sender, EventArgs e)
        {
            Select_AssClass();
        }
        private void Select_Recurcy()
        {
            removecheck();
            this.Recurcy.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Recurcy;
        }
        private void Recurcy_Click(object sender, EventArgs e)
        {
            Select_Recurcy();
        }
        #endregion

        #region Generalazition

        //TODO: thao tac voi  Generalazition
        private void Select_Ger()
        {
            removecheck();
            this.Generalization.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Generalization;
        }
        private void Generalization_Click(object sender, EventArgs e)
        {
            Select_Ger();
        }

        private void Select_Dynamic()
        {
            removecheck();
            this.Dymamic.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Dynamic;
        }
        private void Dymamic_Click(object sender, EventArgs e)
        {
            Select_Dynamic();
        }

        private void Select_Disjoint()
        {
            removecheck();
            this.Disjoint.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Disjoint;
        }
        private void Disjoint_Click(object sender, EventArgs e)
        {
            Select_Disjoint();
        }
        #endregion

        #region Aggergation

        //TODO: thao tac voi  Aggergation
        private void Select_Agg()
        {
            removecheck();
            this.Aggregation.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Aggregation;
        }
        private void Aggregation_Click(object sender, EventArgs e)
        {
            Select_Agg();
        }
        private void Select_Comp()
        {
            removecheck();
            this.Composition.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Composition;
        }
        private void Composition_Click(object sender, EventArgs e)
        {
            Select_Comp();
        }
        #endregion

        #region Note

        //TODO: thao tac voi  Note
        private void Select_Note()
        {
            removecheck();
            this.Note.Checked = true;
            MainArea.ActiveTool = DrawArea.DrawToolType.Note;
        }
        private void Note_Click(object sender, EventArgs e)
        {
            Select_Note();
        }

        #endregion

        #region PenType,PenWidth...

        public void ReGraphicCall(int flag)
        {
            List<int> temp = MainArea.Graphics.ListSelectedID();
            List<int> temp2 = new List<int>();
            if (temp != null)
            {
                    foreach (int index in temp)
                    {
                        DrawObject.DrawObject obj = MainArea.Graphics.GetObjectWithID(index);
                        if (flag == 1)
                        {
                            //danh cho text
                           
                            if (obj.ObjType != DrawObject.DrawObject.ObjectType.text 
                                && obj.ObjType != DrawObject.DrawObject.ObjectType.Class 
                                && obj.ObjType != DrawObject.DrawObject.ObjectType.AbstractClass)
                            {
                                obj.Selected = false;
                                temp2.Add(index);
                            }
                        }
                        else if (flag == 2)
                        {
                            //danh cho ko fai text
                            if (obj.ObjType == DrawObject.DrawObject.ObjectType.text)
                            {
                                obj.Selected = false;
                                temp2.Add(index);
                            }
                        }
                        else break;
                    }
            }

            foreach (int o in temp2)
            {
                temp.Remove(o);
            }

            if (temp != null)
            {
                Regraphic.RefreshGraphic(MainArea, temp);
            }
        }
       
        private void Thinest_Click(object sender, EventArgs e)
        {
            MainArea.LineWidth = -1;
            ReGraphicCall(2);
        }

        private void Thin_Click(object sender, EventArgs e)
        {
            MainArea.LineWidth = 2;
            ReGraphicCall(2);
        }

        private void Thick_Click(object sender, EventArgs e)
        {
            MainArea.LineWidth = 5;
            ReGraphicCall(2);
        }

        private void Thicker_Click(object sender, EventArgs e)
        {
            MainArea.LineWidth = 10;
            ReGraphicCall(2);
        }

        private void Thickest_Click(object sender, EventArgs e)
        {
            MainArea.LineWidth = 15;
            ReGraphicCall(2);
        }


        #endregion

        #region Line color, fill color

        private void FillColor_SelectedColorChanged(object sender, EventArgs e)
        {
           MainArea.FillColor=  this.FillColor.SelectedColor;
           MainArea.DrawFilled = true;
           ReGraphicCall(2);

           this.FillColor.ForeColor = this.FillColor.SelectedColor;
         
        }

        private void LineColor_SelectedColorChanged(object sender, EventArgs e)
        {
            MainArea.LineColor = this.LineColor.SelectedColor;
            ReGraphicCall(2);

            this.LineColor.ForeColor = this.LineColor.SelectedColor;
        }

        #endregion

        //----------------------------------Convert Tab( main function)-------------------------------------

        #region Progress

        //TODO: thao tac voi  Progress
        private void Start_Progress()
        {
            StopRun.Enabled = true;
            PauseRun.Enabled = true;
           // RefreshRun.Enabled = true;
            /*
            CheckProperDiagram diagram = new CheckProperDiagram();
            diagram.Show();
            */
            bool flag = false;
            check_diagram.CheckClassDiagram(MainArea.Graphics);
            MessageBoxEx.EnableGlass = false;
            if (check_diagram.list_error.Count > 0)
            {

                foreach (ErrorWarning error in check_diagram.list_error)
                {
                    if (error.Type == ErrorWarning.type.error)
                    {
                        MessageBoxEx.Show("<font color='#0000cc'>" + error.name + "</font>", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        flag = true;
                    }

                }
                check_diagram.list_error.Clear();
            }
            if (!flag)
            {

                ConvertForm ConvertFrm = new ConvertForm();
                ConvertFrm.Area = MainArea;
                ConvertFrm.Show();
            }
        }
        private void Start_Click(object sender, EventArgs e)
        {
            Start_Progress();
        }

        private void Stop_progress()
        {
        }
        private void Pause_progress()
        {
        }
        private void Refresh_progress()
        {
        }
        private void StopRun_Click(object sender, EventArgs e)
        {
            Stop_progress();
        }

        private void PauseRun_Click(object sender, EventArgs e)
        {
            Pause_progress();
        }

        private void RefreshRun_Click(object sender, EventArgs e)
        {
            Refresh_progress();
        }
        #endregion

        #region Import/Export

        //TODO: thao tac voi  Import/Export
        private void Import_Func()
        {
            if (docManager.OpenDocument(""))
            {

                MainArea.Clear();
                MainArea.Refresh();

                if (ActiveLayer != null) MainArea.Graphics = ActiveLayer.Graphics;
                areafunc.AssignArea(MainArea.Graphics, MainArea);
                MainArea.DrawFilled = true;

                this.Refresh();
                SetTree();
            }

        }
        private void Export_Func()
        {

            Bitmap b = new Bitmap(MainArea.Width/3, MainArea.Height/3);
            Graphics g = Graphics.FromImage(b);
            g.Clear(Color.White);

            SaveFileDialog dlgSave = new SaveFileDialog();
            dlgSave.Filter = "Image files (*.jpg,*.png,*.bmp)|*.jpg;*.png;*.bmp|" +
                         "JPG files (*.jpg)|*.jpg|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp";

            dlgSave.DefaultExt = "jpg";
            dlgSave.RestoreDirectory = true;

            if (dlgSave.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    MainArea.Draw(g);
                    switch (Path.GetExtension(dlgSave.FileName).ToLower())
                    {
                        case ".bmp":
                            b.Save(dlgSave.FileName, ImageFormat.Bmp);
                            break;
                        case ".png":
                            b.Save(dlgSave.FileName, ImageFormat.Png);
                            break;
                        case ".jpg":
                            b.Save(dlgSave.FileName, ImageFormat.Jpeg);
                            break;
                        default:
                            MessageBox.Show("Unsupported image format was specified", "Save File",
                                MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                            return;
                    }

                }
                catch (Exception)
                {
                    MessageBox.Show("Failed to save image file ", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            g.Dispose();
            b.Dispose();
        }
        private void Export_Click(object sender, EventArgs e)
        {
            Export_Func();
        }
        private void ImportBtn_Click(object sender, EventArgs e)
        {
            Import_Func();
        }

        #endregion

        #region check diagram

        private void CheckDiagram_Func()
        {

            ResultCheck.Selected = true;
            StopCheck.Enabled = true;
            CheckResult.Clear();
            check_diagram.CheckClassDiagram(MainArea.Graphics);
            // MessageBox.Show(check_diagram.list_error.Count.ToString());
            foreach (ErrorWarning error in check_diagram.list_error)
            {
                if (error.Type == ErrorWarning.type.error)
                {
                    showReds("- Error ! " + error.name + "\n");
                }
                else
                {
                    showYellow("- Warning ! " + error.name + "\n");
                }

            }
            check_diagram.list_error.Clear();

        }
        private void Stop_Check()
        {


            showReds("-----------------------------CHECK PROGRESS HAS BEEN CANCELED-----------------------------\n");
            ResultCheck.Selected = false;
            
        }
        private void CheckDiagram_Click(object sender, EventArgs e)
        {
            CheckDiagram_Func();
        }

        private void StopCheck_Click(object sender, EventArgs e)
        {
            Stop_Check();
        }

        #endregion

        //-----------------------------------------Tool Tab-------------------------------------------------------

        #region Toolbar

        //TODO: thao tac voi  Toolbar

        private void View_Click(object sender, EventArgs e)
        {
            if (this.View.Checked == false)
            {
                this.ribbonTabItem3.Visible = false;
            }
            else
            {
                this.ribbonTabItem3.Visible = true;
            }

        }

        private void Insert_Click(object sender, EventArgs e)
        {
            if (this.Insert.Checked == false)
            {
                this.ribbonTabItem2.Visible = false;
            }
            else
            {
                this.ribbonTabItem2.Visible = true;
            }

        }

        private void DesignTools_Click(object sender, EventArgs e)
        {
            if (this.DesignTools.Checked == false)
            {
                this.ribbonTabItem4.Visible = false;
            }
            else
            {
                this.ribbonTabItem4.Visible = true;
            }
        }

        private void Toolbox_Click(object sender, EventArgs e)
        {
            if (this.Toolbox.Checked == false)
            {
                this.dockContainerItem1.Visible = false;
            }
            else
            {
                this.dockContainerItem1.Visible = true;
            }
        }

        private void Status_Click(object sender, EventArgs e)
        {
            if (this.Status.Checked == false)
            {
                this.dockContainerItem3.Visible = false;
            }
            else
            {
                this.dockContainerItem3.Visible = true;
            }
        }

        private void Properties_Click(object sender, EventArgs e)
        {
            if (this.Properties.Checked == false)
            {
                this.dockContainerItem2.Visible = false;
            }
            else
            {
                this.dockContainerItem2.Visible = true;
            }
        }



        #endregion

        #region Property

        //TODO: thao tac voi  Property

        private void ScreenShoot_Click(object sender, EventArgs e)
        {
            Property.ScreenShot();
            
        }

        #endregion


        #region Show/Hilde

        //TODO: thao tac voi  Show/Hilde

        private void GirdBox_Click(object sender, EventArgs e)
        {

            MainArea.Refresh();
          
        }
       
        private void checkRuler_Click(object sender, EventArgs e)
        {
            if (checkRuler.Checked) { Ruler.Visible = true; Ruler1.Visible = true; }
            else { Ruler.Visible = false; Ruler1.Visible = false; }

        }

        #endregion

        //---------------------------------------------Help Tab----------------------------------------------------

        #region Information

        //TODO: thao tac voi Information 
   
        private void DocumentHelp_Click(object sender, EventArgs e)
        {
            Process.Start(@"D:\2_TAI LIEU HOC TAP\1_LUAN VAN\Final report\Final Report.pdf");
            //D:\2_TAI LIEU HOC TAP\1_LUAN VAN\Final report
        }

        private void OpenWebsite_Click(object sender, EventArgs e)
        {
            Process proc = new System.Diagnostics.Process();
            proc.StartInfo.FileName = "iexplore";
            proc.StartInfo.Arguments = "www.google.com";
            proc.Start();
        }

        #endregion

        #region Messages

        //TODO: thao tac voi Messages 

        #endregion

        //--------------------------------------------Contact Tab-------------------------------------------------


        #region Group

        //TODO: thao tac voi Group
        private void GroupInfomation_Click(object sender, EventArgs e)
        {
            GroupInfo info = new GroupInfo();
            info.Show();

        }
     
        private void SoftInformation_Click(object sender, EventArgs e)
        {
            SoftInfo soft = new SoftInfo();
            soft.Show();
        }

        #endregion

        #region Copyright

        //TODO: thao tac voi Copyright 

        private void Callus_Click(object sender, EventArgs e)
        {
            CallUs call = new CallUs();
            call.Show();
        }

        private void TermOf_Click(object sender, EventArgs e)
        {
            TermOfService term = new TermOfService();
            term.Show();
        }

        #endregion
    
        //---------------------------------------Left Side-------------------------------------------------------

        #region Design

        //TODO: thao tac voi Design

        #endregion

        #region Example

        //TODO: thao tac voi Example

        private void example1_Click(object sender, EventArgs e)
        {
            OpenRecentFile("F:/Users/MINHHIEU/Desktop/ExampleThesis/N-ary.dtl");
        }

        private void example2_Click(object sender, EventArgs e)
        {
            OpenRecentFile("F:/Users/MINHHIEU/Desktop/ExampleThesis/AssociationClass.dtl");
        }

        private void example3_Click(object sender, EventArgs e)
        {
            OpenRecentFile("F:/Users/MINHHIEU/Desktop/ExampleThesis/Recursive.dtl");
        }

        private void example4_Click(object sender, EventArgs e)
        {
            OpenRecentFile("F:/Users/MINHHIEU/Desktop/ExampleThesis/Composition.dtl");
        }

        #endregion

        //-----------------------------------------Right Side--------------------------------------------------------

        #region Attributes
        public void AddDatatype(ComboBoxItem combo)
        {
            List<string> datatype = new List<string> { "NUMBER", "VARCHAR", "INTEGER","TIMESTAMP","DECIMAL","DOUBLE",
                                                       "FLOAT","CHAR"};
            foreach (string str in datatype)
            {
                combo.Items.Add(str);
                combo.Text = datatype[0];
            }
        }

        public void AddMoreAttributes(Attri at)
        {
            //TODO: expand Attributes
            ItemContainer itemcontant = new ItemContainer();
            //itemcontant.LayoutOrientation=Layout

            LabelItem newlable = new LabelItem();
            newlable.Text = "Attribute" + (AttContainer.SubItems.Count + 1).ToString() + "  ";
            newlable.Name = "Attribute" + (AttContainer.SubItems.Count + 1).ToString();
            itemcontant.SubItems.Add(newlable);

            TextBoxItem newtextbox = new TextBoxItem();
            newtextbox.TextBoxWidth = 80;
            if(at!=null) newtextbox.Text = at.Name;
            itemcontant.SubItems.Add(newtextbox);

            ComboBoxItem newcombobox = new ComboBoxItem();
            itemcontant.SubItems.Add(newcombobox);
            if (at != null) newcombobox.Text = MainArea.attype_to_string(at.DataType);
            AddDatatype(newcombobox);

            AttContainer.SubItems.Add(itemcontant);

            this.Refresh();
        }

        public void AddOpertype(ComboBoxItem combo)
        {
            List<string> datatype = new List<string> {"NONE", "NUMBER", "VARCHAR", "INTEGER","TIMESTAMP","DECIMAL","DOUBLE",
                                                       "FLOAT","CHAR"};
            foreach (string str in datatype)
            {
                combo.Items.Add(str);
                combo.Text = datatype[0];
            }
        }

        public void AddMoreOperation(Opers op)
        {
            ItemContainer itemcontant = new ItemContainer();
            //itemcontant.LayoutOrientation=Layout

            LabelItem newlable = new LabelItem();
            newlable.Text = "Operation" + (OpContainer.SubItems.Count + 1).ToString() + " ";
            newlable.Name = "Operation" + (OpContainer.SubItems.Count + 1).ToString();
            itemcontant.SubItems.Add(newlable);

            TextBoxItem newtextbox = new TextBoxItem();
            newtextbox.TextBoxWidth = 80;
            if(op!=null) newtextbox.Text = op.Name;
            itemcontant.SubItems.Add(newtextbox);

            ComboBoxItem newcombobox = new ComboBoxItem();
            itemcontant.SubItems.Add(newcombobox);
            if (op != null) newcombobox.Text = MainArea.optype_to_string(op.OpTypes);
            AddOpertype(newcombobox);

            OpContainer.SubItems.Add(itemcontant);

            this.Refresh();
        }

        public void changed(ComboBox temp)
        {
            int index = 0;

            for (int i = 0; i < temp.Text.Length; i++)
            {
                if (temp.Text[i] == ':') { index = i; break; }
            }
            //MessageBox.Show(index.ToString());
            int object_id = Convert.ToInt32(temp.Text.Substring(index + 1));

            foreach (DrawObject.DrawObject obj in MainArea.Graphics.GetListObject())
            {
                if (obj.ID == object_id)
                {
                    MainArea.GetObjectWithID(this, obj);
                    break;
                }
            }
        }

        private void EntryTextChanged(object sender, EventArgs e)
        {
            //TODO: ham nay set tat ca cac gia tri thong tin ve object khi entryinfo thay doi
            changed(EntryInfo);

        }
        private void EntryIdChanged(object sender, EventArgs e)
        {
            changed(EntryID2);
        }

        private void NameInfoTextChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(NameInfo.Text);
            MainArea.AddTextToObject(NameInfo.Text,1);
            SetTree();
        }

        private void TextInfoChanged(object sender, EventArgs e)
        {
            
        }
        private void DescriptionInfoChanged(object sender, EventArgs e)
        {
            DrawObject.DrawObject obj = MainArea.Graphics.SelectedObject();
            if (obj != null)
            {
                obj.comment = DescriptionInfo.Text;
            }
        }

        // Attributes
        private void Attribute1TextChanged(object sender, EventArgs e)
        {
            MainArea.AddTextToObject(Attribute1.Text, 41);
            SetTree();
        }

        private void Attribute2TextChanged(object sender, EventArgs e)
        {
            MainArea.AddTextToObject(Attribute2.Text, 42);
            SetTree();
        }

        private void Attribute3TextChanged(object sender, EventArgs e)
        {
            MainArea.AddTextToObject(Attribute3.Text, 43);
            SetTree();
        }

        //attribute type
        private void Type1Changed(object sender, EventArgs e)
        {
            if (Attribute1.Text != "")
            {
                MainArea.AddTextToObject(Attribute1.Text, 41);
            }
        }

        private void Type2Changed(object sender, EventArgs e)
        {
            if (Attribute2.Text != "")
            {
                MainArea.AddTextToObject(Attribute2.Text, 42);
            }
        }

        private void Type3Changed(object sender, EventArgs e)
        {
            if (Attribute3.Text != "")
            {
                MainArea.AddTextToObject(Attribute3.Text, 43);
            }
        }

        //operation
        private void Op1TextChanged(object sender, EventArgs e)
        {
            MainArea.AddTextToObject(Operation1.Text, 51);
            SetTree();
            
        }

        private void Op2TextChanged(object sender, EventArgs e)
        {
            MainArea.AddTextToObject(Operation2.Text, 52);
            SetTree();
        }

        private void Op3TextChanged(object sender, EventArgs e)
        {
            MainArea.AddTextToObject(Operation3.Text, 53);
            SetTree();
        }

        private void Optype1_Changed(object sender, EventArgs e)
        {
            if (Operation1.Text != "")
            {
                MainArea.AddTextToObject(Operation1.Text, 51);
            }

        }

        private void Optype2_Changed(object sender, EventArgs e)
        {
            if (Operation2.Text != "")
            {
                MainArea.AddTextToObject(Operation2.Text, 52);
            }
        }

        private void Optype3_Changed(object sender, EventArgs e)
        {
            if (Operation3.Text != "")
            {
                MainArea.AddTextToObject(Operation3.Text, 53);
            }

        }
        //add more
        private void MoreAtt_Click(object sender, EventArgs e)
        {
            AddMoreAttributes(null);
        }

        private void MoreOp_Click(object sender, EventArgs e)
        {
            AddMoreOperation(null);
        }

        #endregion

        #region Parameter

        //TODO: thao tac voi Parameter

        #endregion

        #region Appearance

        private void RightFillColorChanged(object sender, EventArgs e)
        {
            MainArea.FillColor = this.RightFillColor.SelectedColor;
            MainArea.DrawFilled = true;
            ReGraphicCall(2);

            this.RightFillColor.ForeColor = this.RightFillColor.SelectedColor;
        }

        private void RightLineColorChanged(object sender, EventArgs e)
        {
            MainArea.LineColor = this.RightLineColor.SelectedColor;
            ReGraphicCall(2);

            this.RightLineColor.ForeColor = this.RightLineColor.SelectedColor;
        }

        private void Hide_Click(object sender, EventArgs e)
        {
            if (HideCheck.Checked)
            {
                foreach (DrawObject.DrawObject obj in MainArea.Graphics.ListSelected())
                {
                    obj.Hide = true;
                    obj.Selected = false;
                    CopyPaste.SetHide(MainArea, true);
                }
            }
            else
            {
                MainArea.Graphics.UnHideAll();
            }
            MainArea.Refresh();
        }
        #endregion

        //------------------------------------------left side----------------------------------------------

        public void set_kind_att()
        {
            Derived.Checked = false;
            Composite.Checked = false;
            Multivalue.Checked = false;
            //final.Checked = false;
        }

         private void DerivedCheck(object sender, EventArgs e)
        {
            if (Derived.Checked)
            {
                DerivedColumn.Enabled = true;
                Composite.Enabled = false;
                Multivalue.Enabled = false;
            }
            else
            {
                DerivedColumn.Enabled = false;
                Composite.Enabled = true;
                Multivalue.Enabled = true;
            }
        }

         public bool check_exists_item(ComboBox cx,string str)
         {
             foreach (string t in cx.Items)
             {
                 if (t == str) return true;
             }
             return false;
         }

         private void CompositedCheck(object sender, EventArgs e)
         {
             if (Composite.Checked)
             {
                 CompositeName.Enabled = true;
                 Multivalue.Enabled = false;
                 Derived.Enabled = false;

             }
             else
             {
                 CompositeName.Enabled = false;
                 Multivalue.Enabled = true;
                 Derived.Enabled = true;
             }

             if (CompositeName.Enabled)
             {
                 foreach (DrawObject.DrawObject obj in MainArea.Graphics.GetListObject())
                 {
                     switch (obj.ObjType)
                     {
                         case DrawObject.DrawObject.ObjectType.Class:
                         case DrawObject.DrawObject.ObjectType.AbstractClass:
                             DrawClass cl = (DrawClass)obj;
                             if (!check_exists_item(CompositeName, cl.ClassName))
                             {
                                 CompositeName.Items.Add(cl.ClassName);
                             }
                                 
                             break;
                     }
                 }
             }
         }

         private void Multivaluedcheck(object sender, EventArgs e)
         {

             if (Multivalue.Checked)
             {
                 MultiValues.Enabled = true;
                 Derived.Enabled = false;
                 Composite.Enabled = false;
             }
             else
             {
                 MultiValues.Enabled = false;
                 Derived.Enabled = true;
                 Composite.Enabled = true;
             }
         }

        
        //------------------------------------------bottom toolbar----------------------------------------------

        #region Control
        //TODO: thao tac voi control

        private void Zoom_changing(object sender, CancelIntValueEventArgs e)
        {
            int newvalue;
            if (this.slider1.Value < 50)
            {
                newvalue=this.slider1.Value*2;
                this.slider1.Text =newvalue.ToString() + "%";
            }
            else
            {
                newvalue=(this.slider1.Value-50)*8+100;
                this.slider1.Text = newvalue.ToString() + "%";
            }
       
            float adjust =(float) newvalue/100;
            AdjustZoom(adjust-MainArea.Zoom);
            ZoomValue.Text = this.slider1.Text;
        }

        private void Zoom_changed(object sender, EventArgs e)
        {
            

        }


        #endregion

       
        #region Description

        //TODO: thao tac voi description

        #endregion

        //--------------------------------------------Key Function------------------------------------------------
        #region Key Event

        private void MainFormKeyDown(object sender, KeyEventArgs e)
        {
            
            switch (e.KeyCode)
            {
                    //delete
                case Keys.Delete:
                    command_delete = new CommandDelete(MainArea);
                    MainArea.AddCommandToHistory(command_delete);
                    MainArea.Invalidate();
                    break;
                    //zoom
                case Keys.Up:
                    if (_controlKey)
                    {
                        AdjustZoom(.1f);
                    }
                    MainArea.Invalidate();
                    break;
                case Keys.Down:
                    if (_controlKey)
                    {
                        AdjustZoom(-.1f);
                    }
                    MainArea.Invalidate();
                    break;
                    //copy cut paste
                case Keys.X:
                        if (_controlKey)
                        {
                            CopyPaste.Area = MainArea;
                            CopyPaste.Cut();
                        }
                    
                    break;
                case Keys.C:
                    if (_controlKey)
                    {
                        CopyPaste.Area = MainArea;
                        CopyPaste.Copy();
                    }
                    else if (_shiftkey)
                    {
                        Select_Class();
                    }
                    break;
                case Keys.V :
                    if (_controlKey)
                    {
                        CopyPaste.Area = MainArea;
                        CopyPaste.Paste();
                    }
                    break;
                    //select tools &  basic tools
                case Keys.A:
                    if (_shiftkey)
                    {
                        Select_Abstractclass();
                    }
                    break;
                case Keys.S:
                    if (_shiftkey)
                    {
                        Select_ASS();
                    }
                    else if (_controlKey)
                    {
                        Save_Document();
                    }
                    break;
                case Keys.E:
                    if (_shiftkey)
                    {
                        Select_EXASS();
                    }
                    else if (_controlKey)
                    {
                        Close_App();
                    }
                    break;
                case Keys.B:
                    if (_shiftkey)
                    {
                        Select_Binary();
                    }
                    break;
                case Keys.N:
                    if (_shiftkey)
                    {
                        Select_Nary();
                    }
                    else if (_controlKey)
                    {
                        New_Document();
                    }
                    break;
                case Keys.O:
                    if (_shiftkey)
                    {
                        Select_AssClass();
                    }
                    else if (_controlKey)
                    {
                        Open_Document();
                    }
                    break;
                case Keys.R:
                    if (_shiftkey)
                    {
                        Select_Recurcy();
                    }
                    else if (_controlKey)
                    {
                        MainArea.Redo();
                    }
                    break;
                case Keys.G:
                    if (_shiftkey)
                    {
                        Select_Ger();
                    }
                    break;
                case Keys.D:
                    if (_shiftkey)
                    {
                        Select_Dynamic();
                    }
                    break;
                case Keys.I:
                    if (_shiftkey)
                    {
                        Select_Disjoint();
                    }
                    break;
                case Keys.Q:
                    if (_shiftkey)
                    {
                        Select_Agg();
                    }
                    break;
                case Keys.P:
                    if (_shiftkey)
                    {
                        Select_Comp();
                    }
                    break;
                case Keys.T:
                    if (_shiftkey)
                    {
                        Select_Note();
                    }
                    else if (_controlKey)
                    {
                        OpenFontBox();
                    }
                    break;
                case Keys.U:
                    if (_controlKey)
                    {
                        MainArea.Undo();
                    }
                    break;
                case Keys.F:
                    if (_controlKey)
                    {
                        OpenFindBox();
                    }
                    break;
                    //progress
                case Keys.F11:
                    CheckDiagram_Func();
                    break;
                case Keys.F12:
                    Stop_Check();
                    break;
                case Keys.F2:
                    Import_Func();
                    break;
                case Keys.F3:
                    Export_Func();
                    break;
                case Keys.F5:
                    Start_Progress();
                    break;
                case Keys.F6:
                    Stop_progress();
                    break;
                case Keys.F7:
                    Pause_progress();
                    break;
                case Keys.F8:
                    Refresh_progress();
                    break;
                case Keys.ControlKey :
                    _controlKey = true;
                    break;
                case Keys.ShiftKey:
                    _shiftkey = true;
                    break;
                case Keys.Enter:
                    if (MainArea.TextboxText.Visible = true && MainArea.TextboxText.Text != "")
                    {
                        MainArea.ConfirmTextBox();
                        set_kind_att();
                      
                    }
                    break;
                default:
                    break;
            }
            MainArea.Invalidate();
            SetStateOfControls();
          
        }

        private void MainFormKeyUp(object sender, KeyEventArgs e)
        {
            _controlKey = false;
            _shiftkey = false;
        }

        #endregion

        //-------------------------------------------Region Zoom,Rotation Functions-----------------------------------
        #region Zoom,Rotation

        private void AdjustZoom(float _amount)
        {
            MainArea.Zoom += _amount;

            if (MainArea.Zoom < .1f) MainArea.Zoom = .1f;
            if (MainArea.Zoom > 10) MainArea.Zoom = 10f;

            MainArea.Invalidate();
            SetStateOfControls();
        }

    /*
        private void RotateObject(int p)
        {
            //int al = drawArea.TheLayers.ActiveLayerIndex;
            for (int i = 0; i <  MainArea.Graphics.Count; i++)
            {
                if ( MainArea.Graphics[i].Selected)
                    if (p == 0)
                         MainArea.Graphics[i].Rotation = 0;
                    else
                         MainArea.Graphics[i].Rotation += p;
            }
             MainArea.Invalidate();
            SetStateOfControls();
            
        }

        private void RotateDrawing(int p)
        {
            if (p == 0)
                MainArea.Rotation = 0;
            else
            {
                MainArea.Rotation += p;
                if (p < 0) // Left Rotation
                {
                    if (MainArea.Rotation <-360)
                        MainArea.Rotation = 0;
                }
                else
                {
                    if (MainArea.Rotation > 360)
                        MainArea.Rotation = 0;
                }
            }
            MainArea.Invalidate();
            SetStateOfControls();
        }
  */

        #endregion 

        //------------------------------------------  Context Menu----------------------------------------------------
        #region ConextMenu

        private void cutToolStrip_Click(object sender, EventArgs e)
        {
            CopyPaste.Area = MainArea;
            CopyPaste.Cut();
        }

        private void copyToolStrip_Click(object sender, EventArgs e)
        {
            CopyPaste.Area = MainArea;
            CopyPaste.Copy();
        }

        private void pasteToolStrip_Click(object sender, EventArgs e)
        {
            CopyPaste.Area = MainArea;
            CopyPaste.Paste();
        }

        private void deleteToolStrip_Click(object sender, EventArgs e)
        {
            MainArea.Graphics.DeleteSelection();
            MainArea.Refresh();
        }

        #endregion

        #region SubContextMenu

        private void Add_strip_Click(object sender, EventArgs e)
        {
            MainArea.AddInfoToClass();
        }

        private void Remove_strip_Click(object sender, EventArgs e)
        {
            MainArea.RemoveInfoFromClass();
        }

        private void Up_strip_Click(object sender, EventArgs e)
        {
            MainArea.UpInfo();
        }

        private void Down_strip_Click(object sender, EventArgs e)
        {
            MainArea.DownInfo();
        }

        #endregion

        //----------------------------------------Rulers--------------------------------------------------------------
        #region Rulers

        private void flipRulers_Click(object sender, EventArgs e)
        {
            Ruler.Horizontals = !Ruler.Horizontals;
            Ruler.Invalidate();
            Ruler.Refresh();
        }

        private void pixels_Click(object sender, EventArgs e)
        {
           Ruler1.pixels = Ruler.pixels = true;
           Ruler1.inches = Ruler.inches = false;
           Ruler1.centimeter = Ruler.centimeter = false;

            Ruler.Invalidate();
            Ruler.Refresh();

            Ruler1.Invalidate();
            Ruler1.Refresh();
        }

        private void inches_Click(object sender, EventArgs e)
        {
            Ruler1.pixels = Ruler.pixels = false;
            Ruler1.inches = Ruler.inches = true;
            Ruler1.centimeter = Ruler.centimeter = false;

            Ruler.Invalidate();
            Ruler.Refresh();

            Ruler1.Invalidate();
            Ruler1.Refresh();
        }

        private void centimeters_Click(object sender, EventArgs e)
        {
          Ruler1.pixels =  Ruler.pixels = false;
          Ruler1.inches =   Ruler.inches = false;
          Ruler1.centimeter =  Ruler.centimeter = true;

            Ruler.Invalidate();
            Ruler.Refresh();

            Ruler1.Invalidate();
            Ruler1.Refresh();
        }

        private void exitRuler_Click(object sender, EventArgs e)
        {
            Ruler.Visible = false;
            Ruler1.Visible = false;
        }

        public Rulers rulerngang(int x,int y)
        {
            Rulers R1 = new Rulers();
            R1.FormSize = new Size(5000, 25);
            R1.Owner = this;
            R1.Location = new Point(x,y);
            R1.Horizontals = true;
            if (this.checkRuler.Checked)
            {
                R1.Visible = true;
            }
            else
            {
                R1.Visible = false;
            }
            return R1;
        }

        public Rulers rulerdoc(int x, int y)
        {
            Rulers R2 = new Rulers();
            R2.FormSize = new Size(25, 5000);
            R2.Owner = this;
            R2.Location = new Point(x,y);
            R2.Horizontals = false;

            if (this.checkRuler.Checked)
            {
                R2.Visible = true;
            }
            else
            {
                R2.Visible = false;
            }
            return R2;
        }

        #endregion

        //----------------------------------------Load Font----------------------------------------------------
        #region load font
        public void LoadFont()
        {
            List<string> LFontName = new List<string> { "Tahoma","Times New Roman","Arial","Arial Narrow","VNI-Times","Calibri (Body)" };
            List<string> LFontSize = new List<string> { "8", "9", "10", "11", "12", "14", "16", "18", "20", "24", "30", "40", "50", "60" };
            List<string> LFontStyle = new List<string> { "Regular","Italic","Bold" };

            foreach (string str in LFontName)
            {
                Font.Items.Add(str);
            }
            Font.SelectedIndex= 0;
            foreach (string str in LFontSize)
            {
                SizeFont.Items.Add(str);
            }
            SizeFont.SelectedIndex = 0;
            foreach (string str in LFontStyle)
            {
                Style.Items.Add(str);
            }
            Style.SelectedIndex = 0;
       
            
        }

        public void selectfont()
        {
            switch (Style.Text)
            {
                case "Regular":
                    MainArea.Font = new Font(Font.Text, Convert.ToInt32(SizeFont.Text), FontStyle.Regular);
                    break;

                case "Italic":
                    MainArea.Font = new Font(Font.Text, Convert.ToInt32(SizeFont.Text), FontStyle.Italic);
                    break;

                case "Bold":
                    MainArea.Font = new Font(Font.Text, Convert.ToInt32(SizeFont.Text), FontStyle.Bold);
                    break;

            }
        }

        #endregion

        //------------------------------------tree view---------------------------------------

        #region tree
        
        public void SetTree()
        {
            if (MainArea.Graphics !=null)
            {
                treeView.Nodes.Clear();
                foreach (DockContainerItem o in CenterBar.Items)
                {
                    if (o.Visible == true)
                    {
                        TreeNode node = new TreeNode(o.Text);
                        treeView.Nodes.Add(node);

                        TreeNode c = new TreeNode("Class");
                        TreeNode a = new TreeNode("Abstract Class");
                        TreeNode ass = new TreeNode("Association");
                        TreeNode n = new TreeNode("Note");
                        TreeNode assc = new TreeNode("Association Class");
                        node.Nodes.Add(c);
                        node.Nodes.Add(a);
                        node.Nodes.Add(assc);
                        node.Nodes.Add(ass);
                        node.Nodes.Add(n);
                        
                    }
                }

                TreeNode page = findnode(treeView.Nodes, CenterBar.SelectedDockContainerItem.Text);
                foreach (DrawObject.DrawObject obj in MainArea.Graphics.GetListObject())
                {
                    switch (obj.ObjType)
                    {
                        case DrawObject.DrawObject.ObjectType.Class:
                        
                            DrawClass c = (DrawClass)obj;
                            //add class
                            TreeNode newc = new TreeNode(c.ClassName);      //node class
                            TreeNode cl = findnode(page.Nodes, "Class");
                            cl.Nodes.Add(newc);
                            //add thuoc tinh
                            TreeNode att = new TreeNode( "Attributes");
                            newc.Nodes.Add(att);
                            foreach (Attri attribute in c.ListAttribute)
                            {
                                att.Nodes.Add(new TreeNode(attribute.Name));
                               
                            }
                            //add operation
                            TreeNode op= new TreeNode("Operations");
                            newc.Nodes.Add(op);
                            foreach (Opers str in c.ListOperation)
                            {
                                op.Nodes.Add(new TreeNode(str.Name));
                            }

                            break;
                        case DrawObject.DrawObject.ObjectType.AbstractClass:
                            DrawAbstractClass ab = (DrawAbstractClass)obj;
                            //add class
                            TreeNode newab = new TreeNode(ab.ClassName);      //node class
                            TreeNode cll = findnode(page.Nodes, "Abstract Class");
                            cll.Nodes.Add(newab);
                            //add thuoc tinh
                            TreeNode attt = new TreeNode( "Attributes");
                            newab.Nodes.Add(attt);
                            foreach (Attri attribute in ab.ListAttribute)
                            {
                                attt.Nodes.Add(new TreeNode(attribute.Name));
                               
                            }
                            //add operation
                            TreeNode opp= new TreeNode("Operations");
                            newab.Nodes.Add(opp);
                            foreach (Opers str in ab.ListOperation)
                            {
                                opp.Nodes.Add(new TreeNode(str.Name));
                            }
                            break;
                        
                    }
                }

                treeView.Refresh();
                treeView.ShowNodeToolTips = true;
                //treeView.Scrollable = true;
            }
        }

        public TreeNode findnode(TreeNodeCollection nodes,string t)
        {
            foreach (TreeNode o in nodes)
            {
                if (o.Text == t) return o;
            }
            return null;
               
        }
        public TreeNode findNode(TreeNodeCollection nodes, string t,string attop,string kind)
        {
            
            switch (kind)
            {
                case "Class":
                case "Abstract Class":
                case "Association":
                case "Association Class":
                case "Note":
                    TreeNode temp = findnode(nodes, kind);
                    return findnode(temp.Nodes, t);
                case "Attributes":
                case "Operations":
                    TreeNode temp2 = findnode(nodes, "Class");
                    TreeNode temp3 = findnode(temp2.Nodes, t);
                    return findnode(findnode(temp3.Nodes,"Attributes").Nodes, attop);
               
            }
            return null;
        }

        #endregion

        #region help function

        private void showYellow(String a)
        {
            Font font = new Font("Consolas", 10, FontStyle.Regular);
            CheckResult.SelectionFont = font;
            CheckResult.SelectionColor = Color.Black;
            CheckResult.SelectedText = a;
        }
        private void showReds(String a)
        {
            Font font = new Font("Consolas", 10, FontStyle.Regular);
            CheckResult.SelectionFont = font;
            CheckResult.SelectionColor = Color.Red;
            CheckResult.SelectedText = a;
        }


        #endregion

    
        
    }
}
