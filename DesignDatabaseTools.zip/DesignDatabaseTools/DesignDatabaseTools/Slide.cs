﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DesignDatabaseTools
{
    public partial class Slide : Form
    {
        private List<Image> images = new List<Image>();
        private int selected = 0;

        public List<Image> ListImage
        {
            get { return images; }
            set { images = value; }
        }

        public Slide()
        {
            InitializeComponent();
        }

        private void Slide_Load(object sender, EventArgs e)
        {
            showImage(ListImage[selected]);
            
        }
       
        private void showImage(Image imgtemp)
        {
            //pictureBox.Width = panel.Width;
            //pictureBox.Height = panel.Height-50;
            pictureBox.Image = imgtemp;
        }

        private void prevImage()
        {
            if (selected > 0)
            {
                showImage(ListImage[selected - 1]);
                selected--;
            }
        }

        private void nextImage()
        {
            if (selected < ListImage.Count - 1)
            {
                showImage(ListImage[selected + 1]);
                selected++;
            }
        }

        private void timer_Tick(object sender, System.EventArgs e)
        {
            nextImage();
        }

        private void Form1_Load(object sender, System.EventArgs e)
        {
            Slides.Enabled = false;
            Pre.Enabled = false;
            Next.Enabled = false;
        }


        private void Pre_Click(object sender, EventArgs e)
        {
            prevImage();
        }

        private void Slides_Click(object sender, EventArgs e)
        {
            if (timer.Enabled == true)
            {
                timer.Enabled = false;
                Slides.Text = " START ";
            }
            else
            {
                timer.Enabled = true;
                Slides.Text = " STOP ";
            }
        }

        private void Next_Click(object sender, EventArgs e)
        {
            nextImage();
        }

       

        
    }
}
