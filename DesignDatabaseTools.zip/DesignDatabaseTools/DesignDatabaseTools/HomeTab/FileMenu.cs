﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

using DevComponents.WinForms;
using DevComponents.DotNetBar;
using DevComponents;

namespace DesignDatabaseTools.HomeTab
{
    class FileMenu
    {
        DrawArea drawarea;

        public void OpenFile()
        {
            OpenFileDialog openFileDia = new OpenFileDialog();
            openFileDia.Filter = "Image files (*.jpg,*.png,*.bmp)|*.jpg;*.png;*.bmp|" +
                          "JPG files (*.jpg)|*.jpg|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp";
            openFileDia.Title = "Open File";
            if (openFileDia.ShowDialog() == DialogResult.OK)
            {

            }
        }


        public void SaveFile(PictureBox SelectPage)
        {
            if (SelectPage != null)
            {

                SaveFileDialog dlgSave = new SaveFileDialog();
                dlgSave.Filter = "Image files (*.jpg,*.png,*.bmp)|*.jpg;*.png;*.bmp|" +
                             "JPG files (*.jpg)|*.jpg|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp";

                dlgSave.DefaultExt = "jpg";
                dlgSave.RestoreDirectory = true;

                if (dlgSave.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        switch (Path.GetExtension(dlgSave.FileName).ToLower())
                        {
                            case ".bmp":
                                SelectPage.Image.Save(dlgSave.FileName, ImageFormat.Bmp);
                                break;
                            case ".png":
                                SelectPage.Image.Save(dlgSave.FileName, ImageFormat.Png);
                                break;
                            case ".jpg":
                                SelectPage.Image.Save(dlgSave.FileName, ImageFormat.Jpeg);
                                break;
                            default:
                                MessageBox.Show("Unsupported image format was specified", "Save File",
                                    MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                                return;
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Failed to save image file ", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        public void NewPage(DockContainerItem mainpage)
        {
            mainpage.Visible = true;
        }

        //Save Image
        /*
        private void saveJpeg(string path, Bitmap img, long quality)
        {
            // Encoder parameter for image quality
            EncoderParameter qualityParam =
                new EncoderParameter(Encoder.quality, quality);

            // Jpeg image codec
            ImageCodecInfo jpegCodec = getEncoderInfo("image/jpeg");

            if (jpegCodec == null)
                return;

            EncoderParameters encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = qualityParam;

            img.Save(path, jpegCodec, encoderParams);
        }
        */
        private ImageCodecInfo getEncoderInfo(string mimeType)
        {
            // Get image codecs for all image formats
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageEncoders();

            // Find the correct image codec
            for (int i = 0; i < codecs.Length; i++)
                if (codecs[i].MimeType == mimeType)
                    return codecs[i];
            return null;
        }

        


    }
}
