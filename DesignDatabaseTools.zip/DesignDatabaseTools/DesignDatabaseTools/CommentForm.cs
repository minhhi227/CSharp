﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools
{
    public partial class CommentForm : Form
    {
        private List<string> _ListObject = new List<string>();
        private List<int> list_id = new List<int>();
        private DrawArea area;


        public DrawArea Area
        {
            get { return area; }
            set { area = value; }
        }

        public List<string> ListObject
        {
            get { return _ListObject; }
            set { _ListObject = value; }
        }

        public void get_list()
        {
            foreach (DrawObject.DrawObject obj in Area.Graphics.GetListObject())
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                    case DrawObject.DrawObject.ObjectType.Class:
                        DrawClass c = (DrawClass)obj;
                        _ListObject.Add(c.ClassName);
                        list_id.Add(c.ID);
                        break;
                    case DrawObject.DrawObject.ObjectType.Aggernation:
                    case DrawObject.DrawObject.ObjectType.AssociationLine:
                    case DrawObject.DrawObject.ObjectType.Composition:
                    case DrawObject.DrawObject.ObjectType.Generalization:
                        DrawAssociation ass = (DrawAssociation)obj;
                        _ListObject.Add(ass.RoleName.TheText);
                        list_id.Add(ass.ID);
                        break;
                    case DrawObject.DrawObject.ObjectType.Nary:
                        DrawNary n = (DrawNary)obj;
                        _ListObject.Add(n.RoleName);
                        list_id.Add(n.ID);
                        break;
                    case DrawObject.DrawObject.ObjectType.Binary:
                        DrawBinary b = (DrawBinary)obj;
                        _ListObject.Add(b.RoleName);
                        list_id.Add(b.ID);
                        break;
                    case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                        break;
                }
            }
        }
        private void Comment_Load(object sender, EventArgs e)
        {
            get_list();
            if (ListObject.Count > 0)
            {
                foreach (string str in ListObject)
                {
                    List_Entry.Items.Add(str);
                }
                List_Entry.Text = ListObject[0];
            }
        }

        public CommentForm()
        {
            InitializeComponent();
        }

        private void OK_Click(object sender, EventArgs e)
        {
           int id = ListObject.IndexOf(List_Entry.Text);
           foreach (DrawObject.DrawObject o in Area.Graphics.GetListObject())
           {
               if (o.ID == list_id[id]) { o.comment = richTextBox.Text; break; }
           }
           this.Close();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TextChange(object sender, EventArgs e)
        {
            int id = ListObject.IndexOf(List_Entry.Text);
            foreach (DrawObject.DrawObject o in Area.Graphics.GetListObject())
            {
                if (o.ID == list_id[id]) { richTextBox.Text = o.comment; }
            }

        }

  

     
    }
}
