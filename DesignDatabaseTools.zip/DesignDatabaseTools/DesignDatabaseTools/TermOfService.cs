﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DesignDatabaseTools
{
    public partial class TermOfService : Form
    {
        public TermOfService()
        {
            InitializeComponent();
        }

        private void TermLoad(object sender, EventArgs e)
        {
            
        }

        private void Term_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

     
    }
}
