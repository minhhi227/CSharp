﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DesignDatabaseTools
{
    public partial class CheckProperDiagram : Form
    {
        public CheckProperDiagram()
        {
            InitializeComponent();
        }

        private void CheckDiagramLoad(object sender, EventArgs e)
        {
            this.Question.Text = "Do you want to check the accuration of this diagram ?";
        }


        private void Question_Click(object sender, EventArgs e)
        {

        }

        private void Yes_Click(object sender, EventArgs e)
        {
            //check tinh hop le rui bao nguoi dung bit co mun chuyen tiep ko
            ConvertForm ConvertFrm = new ConvertForm();
            ConvertFrm.Show();
            this.Close();
        }

        private void No_Click(object sender, EventArgs e)
        {
            //convert luon khong can check tinh hop le
            ConvertForm ConvertFrm = new ConvertForm();
            ConvertFrm.Show();
            this.Close();
        }

     
       
    }
}
