﻿namespace DesignDatabaseTools
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ribbonControl1 = new DevComponents.DotNetBar.RibbonControl();
            this.ribbonPanel5 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar19 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer14 = new DevComponents.DotNetBar.ItemContainer();
            this.CheckDiagram = new DevComponents.DotNetBar.ButtonItem();
            this.StopCheck = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar21 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer46 = new DevComponents.DotNetBar.ItemContainer();
            this.ImportBtn = new DevComponents.DotNetBar.ButtonItem();
            this.Export = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar20 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer45 = new DevComponents.DotNetBar.ItemContainer();
            this.Start = new DevComponents.DotNetBar.ButtonItem();
            this.StopRun = new DevComponents.DotNetBar.ButtonItem();
            this.PauseRun = new DevComponents.DotNetBar.ButtonItem();
            this.RefreshRun = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel4 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar10 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer57 = new DevComponents.DotNetBar.ItemContainer();
            this.LineColor = new DevComponents.DotNetBar.ColorPickerDropDown();
            this.FillColor = new DevComponents.DotNetBar.ColorPickerDropDown();
            this.itemContainer59 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem17 = new DevComponents.DotNetBar.ButtonItem();
            this.Thinest = new DevComponents.DotNetBar.ButtonItem();
            this.Thin = new DevComponents.DotNetBar.ButtonItem();
            this.Thick = new DevComponents.DotNetBar.ButtonItem();
            this.Thicker = new DevComponents.DotNetBar.ButtonItem();
            this.Thickest = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar18 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer56 = new DevComponents.DotNetBar.ItemContainer();
            this.Note = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar17 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer55 = new DevComponents.DotNetBar.ItemContainer();
            this.Aggregation = new DevComponents.DotNetBar.ButtonItem();
            this.Composition = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar16 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer54 = new DevComponents.DotNetBar.ItemContainer();
            this.Generalization = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer53 = new DevComponents.DotNetBar.ItemContainer();
            this.Dymamic = new DevComponents.DotNetBar.ButtonItem();
            this.Disjoint = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar15 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer50 = new DevComponents.DotNetBar.ItemContainer();
            this.Association = new DevComponents.DotNetBar.ButtonItem();
            this.AssociationClass = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer58 = new DevComponents.DotNetBar.ItemContainer();
            this.Nary = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer34 = new DevComponents.DotNetBar.ItemContainer();
            this.Binary = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer33 = new DevComponents.DotNetBar.ItemContainer();
            this.ExtraAssociation = new DevComponents.DotNetBar.ButtonItem();
            this.Recurcy = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar14 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer49 = new DevComponents.DotNetBar.ItemContainer();
            this.Class = new DevComponents.DotNetBar.ButtonItem();
            this.AbstractClass = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel7 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar8 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer41 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem60 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem61 = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar31 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer39 = new DevComponents.DotNetBar.ItemContainer();
            this.DocumentHelp = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer40 = new DevComponents.DotNetBar.ItemContainer();
            this.OpenWebsite = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel8 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar37 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer44 = new DevComponents.DotNetBar.ItemContainer();
            this.TermOf = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer47 = new DevComponents.DotNetBar.ItemContainer();
            this.Callus = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar36 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer43 = new DevComponents.DotNetBar.ItemContainer();
            this.SoftInformation = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer42 = new DevComponents.DotNetBar.ItemContainer();
            this.GroupInfomation = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel2 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer18 = new DevComponents.DotNetBar.ItemContainer();
            this.Insertext = new DevComponents.DotNetBar.ButtonItem();
            this.InsertImage = new DevComponents.DotNetBar.ButtonItem();
            this.Comment = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar2 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer13 = new DevComponents.DotNetBar.ItemContainer();
            this.InsertNewPage = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer16 = new DevComponents.DotNetBar.ItemContainer();
            this.InsertOldPage = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel3 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar13 = new DevComponents.DotNetBar.RibbonBar();
            this.RulerUnit = new DevComponents.DotNetBar.ButtonItem();
            this.CRuler = new DevComponents.DotNetBar.ButtonItem();
            this.IRuler = new DevComponents.DotNetBar.ButtonItem();
            this.PRuler = new DevComponents.DotNetBar.ButtonItem();
            this.AreaColor = new DevComponents.DotNetBar.ColorPickerDropDown();
            this.ribbonBar11 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer36 = new DevComponents.DotNetBar.ItemContainer();
            this.SlideShowClick = new DevComponents.DotNetBar.ButtonItem();
            this.SlideBack = new DevComponents.DotNetBar.ColorPickerDropDown();
            this.ribbonPanel1 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar6 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer9 = new DevComponents.DotNetBar.ItemContainer();
            this.ZoomOut = new DevComponents.DotNetBar.ButtonItem();
            this.ZoomIn = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer17 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer19 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem3 = new DevComponents.DotNetBar.LabelItem();
            this.ZoomValue = new DevComponents.DotNetBar.ComboBoxItem();
            this.ribbonBar5 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer15 = new DevComponents.DotNetBar.ItemContainer();
            this.Select = new DevComponents.DotNetBar.ButtonItem();
            this.Find = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer20 = new DevComponents.DotNetBar.ItemContainer();
            this.Undo = new DevComponents.DotNetBar.ButtonItem();
            this.Redo = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer51 = new DevComponents.DotNetBar.ItemContainer();
            this.Panning = new DevComponents.DotNetBar.ButtonItem();
            this.Panning_reset = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar4 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer5 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer10 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem1 = new DevComponents.DotNetBar.LabelItem();
            this.Font = new DevComponents.DotNetBar.ComboBoxItem();
            this.itemContainer11 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem2 = new DevComponents.DotNetBar.LabelItem();
            this.SizeFont = new DevComponents.DotNetBar.ComboBoxItem();
            this.itemContainer77 = new DevComponents.DotNetBar.ItemContainer();
            this.StyleFont = new DevComponents.DotNetBar.LabelItem();
            this.Style = new DevComponents.DotNetBar.ComboBoxItem();
            this.itemContainer35 = new DevComponents.DotNetBar.ItemContainer();
            this.TextColor = new DevComponents.DotNetBar.ColorPickerDropDown();
            this.Fontbox = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar3 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer6 = new DevComponents.DotNetBar.ItemContainer();
            this.Open = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer7 = new DevComponents.DotNetBar.ItemContainer();
            this.New = new DevComponents.DotNetBar.ButtonItem();
            this.Save = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer8 = new DevComponents.DotNetBar.ItemContainer();
            this.Cut = new DevComponents.DotNetBar.ButtonItem();
            this.Copy = new DevComponents.DotNetBar.ButtonItem();
            this.Paste = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel6 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar28 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer21 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer22 = new DevComponents.DotNetBar.ItemContainer();
            this.checkRuler = new DevComponents.DotNetBar.CheckBoxItem();
            this.itemContainer23 = new DevComponents.DotNetBar.ItemContainer();
            this.GirdBox = new DevComponents.DotNetBar.CheckBoxItem();
            this.itemContainer24 = new DevComponents.DotNetBar.ItemContainer();
            this.checkBoxItem3 = new DevComponents.DotNetBar.CheckBoxItem();
            this.itemContainer25 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer26 = new DevComponents.DotNetBar.ItemContainer();
            this.checkBoxItem4 = new DevComponents.DotNetBar.CheckBoxItem();
            this.itemContainer27 = new DevComponents.DotNetBar.ItemContainer();
            this.checkBoxItem5 = new DevComponents.DotNetBar.CheckBoxItem();
            this.ribbonBar26 = new DevComponents.DotNetBar.RibbonBar();
            this.itemContainer28 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer29 = new DevComponents.DotNetBar.ItemContainer();
            this.View = new DevComponents.DotNetBar.CheckBoxItem();
            this.itemContainer30 = new DevComponents.DotNetBar.ItemContainer();
            this.Insert = new DevComponents.DotNetBar.CheckBoxItem();
            this.itemContainer31 = new DevComponents.DotNetBar.ItemContainer();
            this.DesignTools = new DevComponents.DotNetBar.CheckBoxItem();
            this.itemContainer32 = new DevComponents.DotNetBar.ItemContainer();
            this.Toolbox = new DevComponents.DotNetBar.CheckBoxItem();
            this.Status = new DevComponents.DotNetBar.CheckBoxItem();
            this.Properties = new DevComponents.DotNetBar.CheckBoxItem();
            this.office2007StartButton1 = new DevComponents.DotNetBar.Office2007StartButton();
            this.itemContainer1 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer2 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer3 = new DevComponents.DotNetBar.ItemContainer();
            this.NewDocument = new DevComponents.DotNetBar.ButtonItem();
            this.OpenDocument = new DevComponents.DotNetBar.ButtonItem();
            this.SaveAs = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem5 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem6 = new DevComponents.DotNetBar.ButtonItem();
            this.Close = new DevComponents.DotNetBar.ButtonItem();
            this.RecentFile = new DevComponents.DotNetBar.GalleryContainer();
            this.labelItem8 = new DevComponents.DotNetBar.LabelItem();
            this.RecentFile1 = new DevComponents.DotNetBar.ButtonItem();
            this.RecentFile2 = new DevComponents.DotNetBar.ButtonItem();
            this.RecentFile3 = new DevComponents.DotNetBar.ButtonItem();
            this.RecentFile4 = new DevComponents.DotNetBar.ButtonItem();
            this.RecentFile5 = new DevComponents.DotNetBar.ButtonItem();
            this.itemContainer4 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem12 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem13 = new DevComponents.DotNetBar.ButtonItem();
            this.Home = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem2 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem3 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem4 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem5 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem6 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem1 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem7 = new DevComponents.DotNetBar.RibbonTabItem();
            this.buttonItem1 = new DevComponents.DotNetBar.ButtonItem();
            this.qatCustomizeItem1 = new DevComponents.DotNetBar.QatCustomizeItem();
            this.styleManager1 = new DevComponents.DotNetBar.StyleManager(this.components);
            this.ribbonClientPanel1 = new DevComponents.DotNetBar.Ribbon.RibbonClientPanel();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.buttonItem14 = new DevComponents.DotNetBar.ButtonItem();
            this.columnHeader1 = new DevComponents.AdvTree.ColumnHeader();
            this.dotNetBarManager1 = new DevComponents.DotNetBar.DotNetBarManager(this.components);
            this.dockSite4 = new DevComponents.DotNetBar.DockSite();
            this.bar3 = new DevComponents.DotNetBar.Bar();
            this.panelDockContainer3 = new DevComponents.DotNetBar.PanelDockContainer();
            this.slider1 = new DevComponents.DotNetBar.Controls.Slider();
            this.PageName = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.NumberObj = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.ToadoY = new DevComponents.DotNetBar.LabelX();
            this.ToadoX = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.panelDockContainer4 = new DevComponents.DotNetBar.PanelDockContainer();
            this.CheckResult = new System.Windows.Forms.RichTextBox();
            this.panelDockContainer5 = new DevComponents.DotNetBar.PanelDockContainer();
            this.FindRichTextBox = new System.Windows.Forms.RichTextBox();
            this.dockContainerItem3 = new DevComponents.DotNetBar.DockContainerItem();
            this.ResultCheck = new DevComponents.DotNetBar.DockContainerItem();
            this.FindResult = new DevComponents.DotNetBar.DockContainerItem();
            this.dockSite9 = new DevComponents.DotNetBar.DockSite();
            this.CenterBar = new DevComponents.DotNetBar.Bar();
            this.MainRegion = new DevComponents.DotNetBar.PanelDockContainer();
            this.Page1 = new DevComponents.DotNetBar.DockContainerItem();
            this.dockSite1 = new DevComponents.DotNetBar.DockSite();
            this.bar1 = new DevComponents.DotNetBar.Bar();
            this.panelDockContainer7 = new DevComponents.DotNetBar.PanelDockContainer();
            this.ribbonClientPanel2 = new DevComponents.DotNetBar.Ribbon.RibbonClientPanel();
            this.final = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.primarykey = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.CompositeName = new System.Windows.Forms.ComboBox();
            this.DerivedColumn = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.MultiValues = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.Multivalue = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.Composite = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.Derived = new DevComponents.DotNetBar.Controls.CheckBoxX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.OperTabStrip = new DevComponents.DotNetBar.SuperTabStrip();
            this.List_Oper = new DevComponents.DotNetBar.ComboBoxItem();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.superTabStrip = new DevComponents.DotNetBar.SuperTabStrip();
            this.Add_strip = new DevComponents.DotNetBar.ButtonItem();
            this.Remove_strip = new DevComponents.DotNetBar.ButtonItem();
            this.Up_strip = new DevComponents.DotNetBar.ButtonItem();
            this.Down_strip = new DevComponents.DotNetBar.ButtonItem();
            this.DatatypeTabStrip = new DevComponents.DotNetBar.SuperTabStrip();
            this.List_datatype = new DevComponents.DotNetBar.ComboBoxItem();
            this.panelDockContainer1 = new DevComponents.DotNetBar.PanelDockContainer();
            this.example4 = new DevComponents.DotNetBar.ButtonX();
            this.example3 = new DevComponents.DotNetBar.ButtonX();
            this.example2 = new DevComponents.DotNetBar.ButtonX();
            this.example1 = new DevComponents.DotNetBar.ButtonX();
            this.panelDockContainer2 = new DevComponents.DotNetBar.PanelDockContainer();
            this.treeView = new System.Windows.Forms.TreeView();
            this.dockContainerItem1 = new DevComponents.DotNetBar.DockContainerItem();
            this.dockContainerItem4 = new DevComponents.DotNetBar.DockContainerItem();
            this.Options = new DevComponents.DotNetBar.DockContainerItem();
            this.dockSite2 = new DevComponents.DotNetBar.DockSite();
            this.bar2 = new DevComponents.DotNetBar.Bar();
            this.panelDockContainer6 = new DevComponents.DotNetBar.PanelDockContainer();
            this.explorerBar2 = new DevComponents.DotNetBar.ExplorerBar();
            this.explorerBarGroupItem2 = new DevComponents.DotNetBar.ExplorerBarGroupItem();
            this.itemContainer64 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer68 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem15 = new DevComponents.DotNetBar.LabelItem();
            this.RightFillColor = new DevComponents.DotNetBar.ColorPickerDropDown();
            this.itemContainer72 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem16 = new DevComponents.DotNetBar.LabelItem();
            this.RightLineColor = new DevComponents.DotNetBar.ColorPickerDropDown();
            this.explorerBarGroupItem3 = new DevComponents.DotNetBar.ExplorerBarGroupItem();
            this.itemContainer73 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer74 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem17 = new DevComponents.DotNetBar.LabelItem();
            this.HideCheck = new DevComponents.DotNetBar.CheckBoxItem();
            this.itemContainer75 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem18 = new DevComponents.DotNetBar.LabelItem();
            this.PositionX = new DevComponents.DotNetBar.TextBoxItem();
            this.PositionY = new DevComponents.DotNetBar.TextBoxItem();
            this.itemContainer76 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem19 = new DevComponents.DotNetBar.LabelItem();
            this.width = new DevComponents.DotNetBar.TextBoxItem();
            this.height = new DevComponents.DotNetBar.TextBoxItem();
            this.EntryID2 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.RightDock = new DevComponents.DotNetBar.PanelDockContainer();
            this.explorerBar1 = new DevComponents.DotNetBar.ExplorerBar();
            this.explorerBarGroupItem1 = new DevComponents.DotNetBar.ExplorerBarGroupItem();
            this.itemContainer60 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer61 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem5 = new DevComponents.DotNetBar.LabelItem();
            this.NameInfo = new DevComponents.DotNetBar.TextBoxItem();
            this.itemContainer63 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem7 = new DevComponents.DotNetBar.LabelItem();
            this.DescriptionInfo = new DevComponents.DotNetBar.TextBoxItem();
            this.AttributeBarGroup = new DevComponents.DotNetBar.ExplorerBarGroupItem();
            this.AttContainer = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer65 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem9 = new DevComponents.DotNetBar.LabelItem();
            this.Attribute1 = new DevComponents.DotNetBar.TextBoxItem();
            this.AttType1 = new DevComponents.DotNetBar.ComboBoxItem();
            this.itemContainer66 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem10 = new DevComponents.DotNetBar.LabelItem();
            this.Attribute2 = new DevComponents.DotNetBar.TextBoxItem();
            this.AttType2 = new DevComponents.DotNetBar.ComboBoxItem();
            this.itemContainer67 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem11 = new DevComponents.DotNetBar.LabelItem();
            this.Attribute3 = new DevComponents.DotNetBar.TextBoxItem();
            this.AttType3 = new DevComponents.DotNetBar.ComboBoxItem();
            this.MoreAtt = new DevComponents.DotNetBar.ButtonItem();
            this.OperationBarGroup = new DevComponents.DotNetBar.ExplorerBarGroupItem();
            this.OpContainer = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer69 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem12 = new DevComponents.DotNetBar.LabelItem();
            this.Operation1 = new DevComponents.DotNetBar.TextBoxItem();
            this.Optype1 = new DevComponents.DotNetBar.ComboBoxItem();
            this.itemContainer70 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem13 = new DevComponents.DotNetBar.LabelItem();
            this.Operation2 = new DevComponents.DotNetBar.TextBoxItem();
            this.Optype2 = new DevComponents.DotNetBar.ComboBoxItem();
            this.itemContainer71 = new DevComponents.DotNetBar.ItemContainer();
            this.labelItem14 = new DevComponents.DotNetBar.LabelItem();
            this.Operation3 = new DevComponents.DotNetBar.TextBoxItem();
            this.Optype3 = new DevComponents.DotNetBar.ComboBoxItem();
            this.MoreOp = new DevComponents.DotNetBar.ButtonItem();
            this.EntryInfo = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.dockContainerItem2 = new DevComponents.DotNetBar.DockContainerItem();
            this.Appearance = new DevComponents.DotNetBar.DockContainerItem();
            this.dockSite8 = new DevComponents.DotNetBar.DockSite();
            this.dockSite5 = new DevComponents.DotNetBar.DockSite();
            this.dockSite6 = new DevComponents.DotNetBar.DockSite();
            this.dockSite7 = new DevComponents.DotNetBar.DockSite();
            this.dockSite3 = new DevComponents.DotNetBar.DockSite();
            this.contextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cutToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.deleteToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.addAttributesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RulercontextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.flipRulers = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.pixels = new System.Windows.Forms.ToolStripMenuItem();
            this.inches = new System.Windows.Forms.ToolStripMenuItem();
            this.centimeters = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.exitRuler = new System.Windows.Forms.ToolStripMenuItem();
            this.DescriptionTool = new System.Windows.Forms.ToolTip(this.components);
            this.balloonTip = new DevComponents.DotNetBar.BalloonTip();
            this.superTooltip = new DevComponents.DotNetBar.SuperTooltip();
            this.ribbonControl1.SuspendLayout();
            this.ribbonPanel5.SuspendLayout();
            this.ribbonPanel4.SuspendLayout();
            this.ribbonPanel7.SuspendLayout();
            this.ribbonPanel8.SuspendLayout();
            this.ribbonPanel2.SuspendLayout();
            this.ribbonPanel3.SuspendLayout();
            this.ribbonPanel1.SuspendLayout();
            this.ribbonPanel6.SuspendLayout();
            this.dockSite4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar3)).BeginInit();
            this.bar3.SuspendLayout();
            this.panelDockContainer3.SuspendLayout();
            this.panelDockContainer4.SuspendLayout();
            this.panelDockContainer5.SuspendLayout();
            this.dockSite9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CenterBar)).BeginInit();
            this.CenterBar.SuspendLayout();
            this.dockSite1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar1)).BeginInit();
            this.bar1.SuspendLayout();
            this.panelDockContainer7.SuspendLayout();
            this.ribbonClientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OperTabStrip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.superTabStrip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DatatypeTabStrip)).BeginInit();
            this.panelDockContainer1.SuspendLayout();
            this.panelDockContainer2.SuspendLayout();
            this.dockSite2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bar2)).BeginInit();
            this.bar2.SuspendLayout();
            this.panelDockContainer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.explorerBar2)).BeginInit();
            this.RightDock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.explorerBar1)).BeginInit();
            this.contextMenu.SuspendLayout();
            this.RulercontextMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            // 
            // 
            // 
            this.ribbonControl1.BackgroundStyle.Class = "";
            this.ribbonControl1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonControl1.CaptionVisible = true;
            this.ribbonControl1.Controls.Add(this.ribbonPanel7);
            this.ribbonControl1.Controls.Add(this.ribbonPanel2);
            this.ribbonControl1.Controls.Add(this.ribbonPanel4);
            this.ribbonControl1.Controls.Add(this.ribbonPanel6);
            this.ribbonControl1.Controls.Add(this.ribbonPanel8);
            this.ribbonControl1.Controls.Add(this.ribbonPanel5);
            this.ribbonControl1.Controls.Add(this.ribbonPanel3);
            this.ribbonControl1.Controls.Add(this.ribbonPanel1);
            this.ribbonControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribbonControl1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.office2007StartButton1,
            this.Home,
            this.ribbonTabItem2,
            this.ribbonTabItem3,
            this.ribbonTabItem4,
            this.ribbonTabItem5,
            this.ribbonTabItem6,
            this.ribbonTabItem1,
            this.ribbonTabItem7});
            this.ribbonControl1.KeyTipsFont = new System.Drawing.Font("Tahoma", 7F);
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.ribbonControl1.Size = new System.Drawing.Size(1117, 154);
            this.ribbonControl1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonControl1.SystemText.MaximizeRibbonText = "&Maximize the Ribbon";
            this.ribbonControl1.SystemText.MinimizeRibbonText = "Mi&nimize the Ribbon";
            this.ribbonControl1.SystemText.QatAddItemText = "&Add to Quick Access Toolbar";
            this.ribbonControl1.SystemText.QatCustomizeMenuLabel = "<b>Customize Quick Access Toolbar</b>";
            this.ribbonControl1.SystemText.QatCustomizeText = "&Customize Quick Access Toolbar...";
            this.ribbonControl1.SystemText.QatDialogAddButton = "&Add >>";
            this.ribbonControl1.SystemText.QatDialogCancelButton = "Cancel";
            this.ribbonControl1.SystemText.QatDialogCaption = "Customize Quick Access Toolbar";
            this.ribbonControl1.SystemText.QatDialogCategoriesLabel = "&Choose commands from:";
            this.ribbonControl1.SystemText.QatDialogOkButton = "OK";
            this.ribbonControl1.SystemText.QatDialogPlacementCheckbox = "&Place Quick Access Toolbar below the Ribbon";
            this.ribbonControl1.SystemText.QatDialogRemoveButton = "&Remove";
            this.ribbonControl1.SystemText.QatPlaceAboveRibbonText = "&Place Quick Access Toolbar above the Ribbon";
            this.ribbonControl1.SystemText.QatPlaceBelowRibbonText = "&Place Quick Access Toolbar below the Ribbon";
            this.ribbonControl1.SystemText.QatRemoveItemText = "&Remove from Quick Access Toolbar";
            this.ribbonControl1.TabGroupHeight = 14;
            this.ribbonControl1.TabIndex = 0;
            this.ribbonControl1.Text = "ribbonControl1";
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel5.Controls.Add(this.ribbonBar19);
            this.ribbonPanel5.Controls.Add(this.ribbonBar21);
            this.ribbonPanel5.Controls.Add(this.ribbonBar20);
            this.ribbonPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel5.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel5.Name = "ribbonPanel5";
            this.ribbonPanel5.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel5.Size = new System.Drawing.Size(1117, 99);
            // 
            // 
            // 
            this.ribbonPanel5.Style.Class = "";
            this.ribbonPanel5.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel5.StyleMouseDown.Class = "";
            this.ribbonPanel5.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel5.StyleMouseOver.Class = "";
            this.ribbonPanel5.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel5.TabIndex = 5;
            this.ribbonPanel5.Visible = false;
            // 
            // ribbonBar19
            // 
            this.ribbonBar19.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar19.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar19.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar19.BackgroundStyle.Class = "";
            this.ribbonBar19.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar19.ContainerControlProcessDialogKey = true;
            this.ribbonBar19.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar19.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer14});
            this.ribbonBar19.Location = new System.Drawing.Point(429, 0);
            this.ribbonBar19.Name = "ribbonBar19";
            this.ribbonBar19.Size = new System.Drawing.Size(158, 96);
            this.ribbonBar19.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar19.TabIndex = 2;
            this.ribbonBar19.Text = "Check Diagram";
            // 
            // 
            // 
            this.ribbonBar19.TitleStyle.Class = "";
            this.ribbonBar19.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar19.TitleStyleMouseOver.Class = "";
            this.ribbonBar19.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer14
            // 
            // 
            // 
            // 
            this.itemContainer14.BackgroundStyle.Class = "";
            this.itemContainer14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer14.Name = "itemContainer14";
            this.itemContainer14.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.CheckDiagram,
            this.StopCheck});
            this.itemContainer14.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // CheckDiagram
            // 
            this.CheckDiagram.Image = global::DesignDatabaseTools.Properties.Resources.tools_check_spelling2;
            this.CheckDiagram.ImagePaddingHorizontal = 30;
            this.CheckDiagram.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.CheckDiagram.Name = "CheckDiagram";
            this.superTooltip.SetSuperTooltip(this.CheckDiagram, new DevComponents.DotNetBar.SuperTooltipInfo("Check ( F8)", "Click Help for more details", "Click here to vertify diagram component", global::DesignDatabaseTools.Properties.Resources.tools_check_spelling2, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.CheckDiagram.Text = "Check";
            this.CheckDiagram.Click += new System.EventHandler(this.CheckDiagram_Click);
            // 
            // StopCheck
            // 
            this.StopCheck.Image = global::DesignDatabaseTools.Properties.Resources.no;
            this.StopCheck.ImagePaddingHorizontal = 30;
            this.StopCheck.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.StopCheck.Name = "StopCheck";
            this.superTooltip.SetSuperTooltip(this.StopCheck, new DevComponents.DotNetBar.SuperTooltipInfo("Stop Check (F9)", "Click Help for more details", "Click here to stop vertify diagram", global::DesignDatabaseTools.Properties.Resources.no, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.StopCheck.Text = "Stop";
            this.StopCheck.Click += new System.EventHandler(this.StopCheck_Click);
            // 
            // ribbonBar21
            // 
            this.ribbonBar21.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar21.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar21.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar21.BackgroundStyle.Class = "";
            this.ribbonBar21.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar21.ContainerControlProcessDialogKey = true;
            this.ribbonBar21.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar21.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer46});
            this.ribbonBar21.Location = new System.Drawing.Point(292, 0);
            this.ribbonBar21.Name = "ribbonBar21";
            this.ribbonBar21.Size = new System.Drawing.Size(137, 96);
            this.ribbonBar21.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar21.TabIndex = 1;
            this.ribbonBar21.Text = "Import/Export";
            // 
            // 
            // 
            this.ribbonBar21.TitleStyle.Class = "";
            this.ribbonBar21.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar21.TitleStyleMouseOver.Class = "";
            this.ribbonBar21.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer46
            // 
            // 
            // 
            // 
            this.itemContainer46.BackgroundStyle.Class = "";
            this.itemContainer46.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer46.Name = "itemContainer46";
            this.itemContainer46.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ImportBtn,
            this.Export});
            this.itemContainer46.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // ImportBtn
            // 
            this.ImportBtn.Image = global::DesignDatabaseTools.Properties.Resources.import11;
            this.ImportBtn.ImagePaddingHorizontal = 30;
            this.ImportBtn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.ImportBtn.Name = "ImportBtn";
            this.ImportBtn.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.ImportBtn, new DevComponents.DotNetBar.SuperTooltipInfo("Import ( Ctrl+ F6)", "Click Help for more details", "Click here to import diagram file", global::DesignDatabaseTools.Properties.Resources.import11, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.ImportBtn.Text = "Import";
            this.ImportBtn.Click += new System.EventHandler(this.ImportBtn_Click);
            // 
            // Export
            // 
            this.Export.Image = global::DesignDatabaseTools.Properties.Resources.export11;
            this.Export.ImagePaddingHorizontal = 30;
            this.Export.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Export.Name = "Export";
            this.Export.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.Export, new DevComponents.DotNetBar.SuperTooltipInfo("Export (Ctrl + F7)", "Click Help for more details", "Click here to export diagram to bitmap", global::DesignDatabaseTools.Properties.Resources.export11, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Export.Text = "Export";
            this.Export.Click += new System.EventHandler(this.Export_Click);
            // 
            // ribbonBar20
            // 
            this.ribbonBar20.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar20.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar20.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar20.BackgroundStyle.Class = "";
            this.ribbonBar20.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar20.ContainerControlProcessDialogKey = true;
            this.ribbonBar20.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar20.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer45});
            this.ribbonBar20.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar20.Name = "ribbonBar20";
            this.ribbonBar20.Size = new System.Drawing.Size(289, 96);
            this.ribbonBar20.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar20.TabIndex = 0;
            this.ribbonBar20.Text = "Progress";
            // 
            // 
            // 
            this.ribbonBar20.TitleStyle.Class = "";
            this.ribbonBar20.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar20.TitleStyleMouseOver.Class = "";
            this.ribbonBar20.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer45
            // 
            // 
            // 
            // 
            this.itemContainer45.BackgroundStyle.Class = "";
            this.itemContainer45.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer45.Name = "itemContainer45";
            this.itemContainer45.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Start,
            this.StopRun,
            this.PauseRun,
            this.RefreshRun});
            this.itemContainer45.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Start
            // 
            this.Start.Image = global::DesignDatabaseTools.Properties.Resources.playconvert;
            this.Start.ImagePaddingHorizontal = 30;
            this.Start.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Start.Name = "Start";
            this.Start.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.Start, new DevComponents.DotNetBar.SuperTooltipInfo("Start (F5)", "Click Help for more details", "Click here to start converting class diagram to relational object Oracle", global::DesignDatabaseTools.Properties.Resources.playconvert, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Start.Text = "Start";
            this.Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // StopRun
            // 
            this.StopRun.Image = global::DesignDatabaseTools.Properties.Resources.stopconvert;
            this.StopRun.ImagePaddingHorizontal = 30;
            this.StopRun.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.StopRun.Name = "StopRun";
            this.StopRun.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.StopRun, new DevComponents.DotNetBar.SuperTooltipInfo("Stop (Esc)", "Click Help for more details", "Click here to stop progress of  transforming diagram", global::DesignDatabaseTools.Properties.Resources.stopconvert, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.StopRun.Text = "Stop";
            this.StopRun.Click += new System.EventHandler(this.StopRun_Click);
            // 
            // PauseRun
            // 
            this.PauseRun.Image = global::DesignDatabaseTools.Properties.Resources.media_playback_pause;
            this.PauseRun.ImagePaddingHorizontal = 30;
            this.PauseRun.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.PauseRun.Name = "PauseRun";
            this.PauseRun.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.PauseRun, new DevComponents.DotNetBar.SuperTooltipInfo("Pause ( F2)", "Click Help for more details", "Click here to pause progress of transforming diagram. Click start to continue pro" +
            "gress", global::DesignDatabaseTools.Properties.Resources.media_playback_pause, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.PauseRun.Text = "Pause";
            this.PauseRun.Click += new System.EventHandler(this.PauseRun_Click);
            // 
            // RefreshRun
            // 
            this.RefreshRun.Image = global::DesignDatabaseTools.Properties.Resources.refresh11;
            this.RefreshRun.ImagePaddingHorizontal = 30;
            this.RefreshRun.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.RefreshRun.Name = "RefreshRun";
            this.superTooltip.SetSuperTooltip(this.RefreshRun, new DevComponents.DotNetBar.SuperTooltipInfo("Refresh (F4)", "Click Help for more details", "Click here to refresh progress", global::DesignDatabaseTools.Properties.Resources.refresh11, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.RefreshRun.Text = "Refresh";
            this.RefreshRun.Click += new System.EventHandler(this.RefreshRun_Click);
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel4.Controls.Add(this.ribbonBar10);
            this.ribbonPanel4.Controls.Add(this.ribbonBar18);
            this.ribbonPanel4.Controls.Add(this.ribbonBar17);
            this.ribbonPanel4.Controls.Add(this.ribbonBar16);
            this.ribbonPanel4.Controls.Add(this.ribbonBar15);
            this.ribbonPanel4.Controls.Add(this.ribbonBar14);
            this.ribbonPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel4.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel4.Name = "ribbonPanel4";
            this.ribbonPanel4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel4.Size = new System.Drawing.Size(1117, 99);
            // 
            // 
            // 
            this.ribbonPanel4.Style.Class = "";
            this.ribbonPanel4.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseDown.Class = "";
            this.ribbonPanel4.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseOver.Class = "";
            this.ribbonPanel4.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel4.TabIndex = 4;
            this.ribbonPanel4.Visible = false;
            // 
            // ribbonBar10
            // 
            this.ribbonBar10.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar10.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar10.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar10.BackgroundStyle.Class = "";
            this.ribbonBar10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar10.ContainerControlProcessDialogKey = true;
            this.ribbonBar10.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar10.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer57,
            this.itemContainer59});
            this.ribbonBar10.Location = new System.Drawing.Point(874, 0);
            this.ribbonBar10.Name = "ribbonBar10";
            this.ribbonBar10.Size = new System.Drawing.Size(148, 96);
            this.ribbonBar10.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar10.TabIndex = 5;
            this.ribbonBar10.Text = "Layout";
            // 
            // 
            // 
            this.ribbonBar10.TitleStyle.Class = "";
            this.ribbonBar10.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar10.TitleStyleMouseOver.Class = "";
            this.ribbonBar10.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer57
            // 
            // 
            // 
            // 
            this.itemContainer57.BackgroundStyle.Class = "";
            this.itemContainer57.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer57.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer57.Name = "itemContainer57";
            this.itemContainer57.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.LineColor,
            this.FillColor});
            this.itemContainer57.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // LineColor
            // 
            this.LineColor.Image = global::DesignDatabaseTools.Properties.Resources.color_linexx;
            this.LineColor.ImagePaddingHorizontal = 30;
            this.LineColor.Name = "LineColor";
            this.superTooltip.SetSuperTooltip(this.LineColor, new DevComponents.DotNetBar.SuperTooltipInfo("Line color", "Click Help for more details", "Click here to pick color for text or line", global::DesignDatabaseTools.Properties.Resources.pencil2, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.LineColor.Text = "Line Color";
            this.LineColor.SelectedColorChanged += new System.EventHandler(this.LineColor_SelectedColorChanged);
            // 
            // FillColor
            // 
            this.FillColor.Image = global::DesignDatabaseTools.Properties.Resources.color_fill;
            this.FillColor.Name = "FillColor";
            this.superTooltip.SetSuperTooltip(this.FillColor, new DevComponents.DotNetBar.SuperTooltipInfo("Fiiled color", "Click Help for more details", "Click here to pick color for background of component", global::DesignDatabaseTools.Properties.Resources.color_fill, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.FillColor.Text = "Fill Color";
            this.FillColor.SelectedColorChanged += new System.EventHandler(this.FillColor_SelectedColorChanged);
            // 
            // itemContainer59
            // 
            // 
            // 
            // 
            this.itemContainer59.BackgroundStyle.Class = "";
            this.itemContainer59.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer59.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer59.Name = "itemContainer59";
            this.itemContainer59.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem17});
            this.itemContainer59.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // buttonItem17
            // 
            this.buttonItem17.Image = global::DesignDatabaseTools.Properties.Resources.format_line_spacing_normal;
            this.buttonItem17.Name = "buttonItem17";
            this.buttonItem17.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Thinest,
            this.Thin,
            this.Thick,
            this.Thicker,
            this.Thickest});
            this.superTooltip.SetSuperTooltip(this.buttonItem17, new DevComponents.DotNetBar.SuperTooltipInfo("Line width", "Click Help for more details", "Click here to change line width", global::DesignDatabaseTools.Properties.Resources.format_line_spacing_normal, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.buttonItem17.Text = "PenWidth";
            // 
            // Thinest
            // 
            this.Thinest.Name = "Thinest";
            this.Thinest.Text = "Thinest";
            this.Thinest.Click += new System.EventHandler(this.Thinest_Click);
            // 
            // Thin
            // 
            this.Thin.Name = "Thin";
            this.Thin.Text = "Thin";
            this.Thin.Click += new System.EventHandler(this.Thin_Click);
            // 
            // Thick
            // 
            this.Thick.Name = "Thick";
            this.Thick.Text = "Thick";
            this.Thick.Click += new System.EventHandler(this.Thick_Click);
            // 
            // Thicker
            // 
            this.Thicker.Name = "Thicker";
            this.Thicker.Text = "Thicker";
            this.Thicker.Click += new System.EventHandler(this.Thicker_Click);
            // 
            // Thickest
            // 
            this.Thickest.Name = "Thickest";
            this.Thickest.Text = "Thickest";
            this.Thickest.Click += new System.EventHandler(this.Thickest_Click);
            // 
            // ribbonBar18
            // 
            this.ribbonBar18.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar18.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar18.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar18.BackgroundStyle.Class = "";
            this.ribbonBar18.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar18.ContainerControlProcessDialogKey = true;
            this.ribbonBar18.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar18.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer56});
            this.ribbonBar18.Location = new System.Drawing.Point(789, 0);
            this.ribbonBar18.Name = "ribbonBar18";
            this.ribbonBar18.Size = new System.Drawing.Size(85, 96);
            this.ribbonBar18.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar18.TabIndex = 4;
            this.ribbonBar18.Text = "Note";
            // 
            // 
            // 
            this.ribbonBar18.TitleStyle.Class = "";
            this.ribbonBar18.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar18.TitleStyleMouseOver.Class = "";
            this.ribbonBar18.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer56
            // 
            // 
            // 
            // 
            this.itemContainer56.BackgroundStyle.Class = "";
            this.itemContainer56.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer56.Name = "itemContainer56";
            this.itemContainer56.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Note});
            this.itemContainer56.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Note
            // 
            this.Note.Image = global::DesignDatabaseTools.Properties.Resources.design8;
            this.Note.Name = "Note";
            this.superTooltip.SetSuperTooltip(this.Note, new DevComponents.DotNetBar.SuperTooltipInfo("Note", "Click Help for more details", "Click here to create qick note", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Note.Text = "{Note}";
            this.Note.Click += new System.EventHandler(this.Note_Click);
            // 
            // ribbonBar17
            // 
            this.ribbonBar17.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar17.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar17.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar17.BackgroundStyle.Class = "";
            this.ribbonBar17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar17.ContainerControlProcessDialogKey = true;
            this.ribbonBar17.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar17.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer55});
            this.ribbonBar17.Location = new System.Drawing.Point(628, 0);
            this.ribbonBar17.Name = "ribbonBar17";
            this.ribbonBar17.Size = new System.Drawing.Size(161, 96);
            this.ribbonBar17.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar17.TabIndex = 3;
            this.ribbonBar17.Text = "Aggregation";
            // 
            // 
            // 
            this.ribbonBar17.TitleStyle.Class = "";
            this.ribbonBar17.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar17.TitleStyleMouseOver.Class = "";
            this.ribbonBar17.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer55
            // 
            // 
            // 
            // 
            this.itemContainer55.BackgroundStyle.Class = "";
            this.itemContainer55.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer55.Name = "itemContainer55";
            this.itemContainer55.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Aggregation,
            this.Composition});
            this.itemContainer55.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Aggregation
            // 
            this.Aggregation.Image = global::DesignDatabaseTools.Properties.Resources.design11;
            this.Aggregation.Name = "Aggregation";
            this.superTooltip.SetSuperTooltip(this.Aggregation, new DevComponents.DotNetBar.SuperTooltipInfo("Simple aggregation", "Click Help for more details", "Click here to create aggregation association", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Aggregation.Text = "Aggregation";
            this.Aggregation.Click += new System.EventHandler(this.Aggregation_Click);
            // 
            // Composition
            // 
            this.Composition.Image = global::DesignDatabaseTools.Properties.Resources.design10;
            this.Composition.Name = "Composition";
            this.superTooltip.SetSuperTooltip(this.Composition, new DevComponents.DotNetBar.SuperTooltipInfo("Composition", "Click Help for more details", "Click here to create composition association", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Composition.Text = "Composition";
            this.Composition.Click += new System.EventHandler(this.Composition_Click);
            // 
            // ribbonBar16
            // 
            this.ribbonBar16.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar16.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar16.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar16.BackgroundStyle.Class = "";
            this.ribbonBar16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar16.ContainerControlProcessDialogKey = true;
            this.ribbonBar16.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar16.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer54,
            this.itemContainer53});
            this.ribbonBar16.Location = new System.Drawing.Point(468, 0);
            this.ribbonBar16.Name = "ribbonBar16";
            this.ribbonBar16.Size = new System.Drawing.Size(160, 96);
            this.ribbonBar16.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar16.TabIndex = 2;
            this.ribbonBar16.Text = "Generalization";
            // 
            // 
            // 
            this.ribbonBar16.TitleStyle.Class = "";
            this.ribbonBar16.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar16.TitleStyleMouseOver.Class = "";
            this.ribbonBar16.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer54
            // 
            // 
            // 
            // 
            this.itemContainer54.BackgroundStyle.Class = "";
            this.itemContainer54.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer54.Name = "itemContainer54";
            this.itemContainer54.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Generalization});
            this.itemContainer54.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Generalization
            // 
            this.Generalization.Image = global::DesignDatabaseTools.Properties.Resources.design12;
            this.Generalization.Name = "Generalization";
            this.superTooltip.SetSuperTooltip(this.Generalization, new DevComponents.DotNetBar.SuperTooltipInfo("Generlization", "Click Help for more details", "Click here to create generlization association ", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Generalization.Text = "Generalization";
            this.Generalization.Click += new System.EventHandler(this.Generalization_Click);
            // 
            // itemContainer53
            // 
            // 
            // 
            // 
            this.itemContainer53.BackgroundStyle.Class = "";
            this.itemContainer53.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer53.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer53.Name = "itemContainer53";
            this.itemContainer53.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Dymamic,
            this.Disjoint});
            this.itemContainer53.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Dymamic
            // 
            this.Dymamic.Image = global::DesignDatabaseTools.Properties.Resources.design14;
            this.Dymamic.Name = "Dymamic";
            this.superTooltip.SetSuperTooltip(this.Dymamic, new DevComponents.DotNetBar.SuperTooltipInfo("Dynamic", "Click Help for more details", "Click here to create dynamic note ", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Dymamic.Text = "<<Dynamic>>";
            this.Dymamic.Click += new System.EventHandler(this.Dymamic_Click);
            // 
            // Disjoint
            // 
            this.Disjoint.Image = global::DesignDatabaseTools.Properties.Resources.design9;
            this.Disjoint.Name = "Disjoint";
            this.superTooltip.SetSuperTooltip(this.Disjoint, new DevComponents.DotNetBar.SuperTooltipInfo("Disjoint", "Click Help for more details", "Click here to create disjoint note", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Disjoint.Text = "{Disjoint}";
            this.Disjoint.Click += new System.EventHandler(this.Disjoint_Click);
            // 
            // ribbonBar15
            // 
            this.ribbonBar15.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar15.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar15.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar15.BackgroundStyle.Class = "";
            this.ribbonBar15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar15.ContainerControlProcessDialogKey = true;
            this.ribbonBar15.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar15.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer50,
            this.itemContainer58,
            this.itemContainer34,
            this.itemContainer33});
            this.ribbonBar15.Location = new System.Drawing.Point(169, 0);
            this.ribbonBar15.Name = "ribbonBar15";
            this.ribbonBar15.Size = new System.Drawing.Size(299, 96);
            this.ribbonBar15.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar15.TabIndex = 1;
            this.ribbonBar15.Text = "Association";
            // 
            // 
            // 
            this.ribbonBar15.TitleStyle.Class = "";
            this.ribbonBar15.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar15.TitleStyleMouseOver.Class = "";
            this.ribbonBar15.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer50
            // 
            // 
            // 
            // 
            this.itemContainer50.BackgroundStyle.Class = "";
            this.itemContainer50.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer50.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer50.Name = "itemContainer50";
            this.itemContainer50.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Association,
            this.AssociationClass});
            this.itemContainer50.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Association
            // 
            this.Association.Image = global::DesignDatabaseTools.Properties.Resources.design2;
            this.Association.Name = "Association";
            this.superTooltip.SetSuperTooltip(this.Association, new DevComponents.DotNetBar.SuperTooltipInfo("Association (binary)", "Click Help for more details", "Click here to create an association ", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Association.Text = "Association ";
            this.Association.Click += new System.EventHandler(this.Association_Click);
            // 
            // AssociationClass
            // 
            this.AssociationClass.Image = global::DesignDatabaseTools.Properties.Resources.design1;
            this.AssociationClass.Name = "AssociationClass";
            this.AssociationClass.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.AssociationClass, new DevComponents.DotNetBar.SuperTooltipInfo("Association class line", "Click Help for more details", "Click here to create an association class link", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.AssociationClass.Click += new System.EventHandler(this.AssociationClass_Click);
            // 
            // itemContainer58
            // 
            // 
            // 
            // 
            this.itemContainer58.BackgroundStyle.Class = "";
            this.itemContainer58.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer58.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer58.Name = "itemContainer58";
            this.itemContainer58.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Nary});
            this.itemContainer58.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Nary
            // 
            this.Nary.Image = global::DesignDatabaseTools.Properties.Resources.design5;
            this.Nary.Name = "Nary";
            this.superTooltip.SetSuperTooltip(this.Nary, new DevComponents.DotNetBar.SuperTooltipInfo("N-ary ", "Click Help for more details", "Click here to create n-ary association link to 4 class or abstract class", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Nary.Text = "N-ary >3";
            this.Nary.Click += new System.EventHandler(this.Nary_Click);
            // 
            // itemContainer34
            // 
            // 
            // 
            // 
            this.itemContainer34.BackgroundStyle.Class = "";
            this.itemContainer34.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer34.Name = "itemContainer34";
            this.itemContainer34.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Binary});
            this.itemContainer34.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Binary
            // 
            this.Binary.Image = global::DesignDatabaseTools.Properties.Resources.design4;
            this.Binary.Name = "Binary";
            this.superTooltip.SetSuperTooltip(this.Binary, new DevComponents.DotNetBar.SuperTooltipInfo("N-ary", "Click Help for more details", "Click here to create n-ary association link to 3 class or abstract class", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Binary.Text = "N-ary 3";
            this.Binary.Click += new System.EventHandler(this.Binary_Click);
            // 
            // itemContainer33
            // 
            // 
            // 
            // 
            this.itemContainer33.BackgroundStyle.Class = "";
            this.itemContainer33.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer33.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer33.Name = "itemContainer33";
            this.itemContainer33.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ExtraAssociation,
            this.Recurcy});
            this.itemContainer33.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // ExtraAssociation
            // 
            this.ExtraAssociation.Image = global::DesignDatabaseTools.Properties.Resources.design3;
            this.ExtraAssociation.Name = "ExtraAssociation";
            this.superTooltip.SetSuperTooltip(this.ExtraAssociation, new DevComponents.DotNetBar.SuperTooltipInfo("Extra association", "Click Help for more details", "Click here to create an ex association", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.ExtraAssociation.Text = "buttonItem2";
            this.ExtraAssociation.Click += new System.EventHandler(this.ExtraAssociation_Click);
            // 
            // Recurcy
            // 
            this.Recurcy.Image = global::DesignDatabaseTools.Properties.Resources.design13;
            this.Recurcy.Name = "Recurcy";
            this.Recurcy.Text = "Recurcy";
            this.Recurcy.Click += new System.EventHandler(this.Recurcy_Click);
            // 
            // ribbonBar14
            // 
            this.ribbonBar14.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar14.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar14.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar14.BackgroundStyle.Class = "";
            this.ribbonBar14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar14.ContainerControlProcessDialogKey = true;
            this.ribbonBar14.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar14.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer49});
            this.ribbonBar14.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar14.Name = "ribbonBar14";
            this.ribbonBar14.Size = new System.Drawing.Size(166, 96);
            this.ribbonBar14.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar14.TabIndex = 0;
            this.ribbonBar14.Text = "Class";
            // 
            // 
            // 
            this.ribbonBar14.TitleStyle.Class = "";
            this.ribbonBar14.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar14.TitleStyleMouseOver.Class = "";
            this.ribbonBar14.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer49
            // 
            // 
            // 
            // 
            this.itemContainer49.BackgroundStyle.Class = "";
            this.itemContainer49.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer49.Name = "itemContainer49";
            this.itemContainer49.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Class,
            this.AbstractClass});
            this.itemContainer49.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Class
            // 
            this.Class.Image = global::DesignDatabaseTools.Properties.Resources.c1c1;
            this.Class.Name = "Class";
            this.superTooltip.SetSuperTooltip(this.Class, new DevComponents.DotNetBar.SuperTooltipInfo("Class", "Click Help for more details", "Click here to create a class into diagram", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Class.Text = "Class";
            this.Class.Click += new System.EventHandler(this.Class_Click);
            // 
            // AbstractClass
            // 
            this.AbstractClass.Image = global::DesignDatabaseTools.Properties.Resources.c1c2;
            this.AbstractClass.Name = "AbstractClass";
            this.superTooltip.SetSuperTooltip(this.AbstractClass, new DevComponents.DotNetBar.SuperTooltipInfo("Abstract class", "Click Help for more details", "Click here to create an abstract class into diagram", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.AbstractClass.Text = "Abstract Class";
            this.AbstractClass.Click += new System.EventHandler(this.AbstractClass_Click);
            // 
            // ribbonPanel7
            // 
            this.ribbonPanel7.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel7.Controls.Add(this.ribbonBar8);
            this.ribbonPanel7.Controls.Add(this.ribbonBar31);
            this.ribbonPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel7.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel7.Name = "ribbonPanel7";
            this.ribbonPanel7.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel7.Size = new System.Drawing.Size(1117, 99);
            // 
            // 
            // 
            this.ribbonPanel7.Style.Class = "";
            this.ribbonPanel7.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel7.StyleMouseDown.Class = "";
            this.ribbonPanel7.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel7.StyleMouseOver.Class = "";
            this.ribbonPanel7.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel7.TabIndex = 7;
            // 
            // ribbonBar8
            // 
            this.ribbonBar8.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar8.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar8.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar8.BackgroundStyle.Class = "";
            this.ribbonBar8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar8.ContainerControlProcessDialogKey = true;
            this.ribbonBar8.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar8.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer41});
            this.ribbonBar8.Location = new System.Drawing.Point(216, 0);
            this.ribbonBar8.Name = "ribbonBar8";
            this.ribbonBar8.Size = new System.Drawing.Size(214, 96);
            this.ribbonBar8.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar8.TabIndex = 1;
            this.ribbonBar8.Text = "Messages";
            // 
            // 
            // 
            this.ribbonBar8.TitleStyle.Class = "";
            this.ribbonBar8.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar8.TitleStyleMouseOver.Class = "";
            this.ribbonBar8.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer41
            // 
            // 
            // 
            // 
            this.itemContainer41.BackgroundStyle.Class = "";
            this.itemContainer41.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer41.Name = "itemContainer41";
            this.itemContainer41.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem60,
            this.buttonItem61});
            this.itemContainer41.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // buttonItem60
            // 
            this.buttonItem60.Image = global::DesignDatabaseTools.Properties.Resources.chat;
            this.buttonItem60.ImagePaddingHorizontal = 50;
            this.buttonItem60.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem60.Name = "buttonItem60";
            this.superTooltip.SetSuperTooltip(this.buttonItem60, new DevComponents.DotNetBar.SuperTooltipInfo("Messages(Ctrl+M)", "Click Help for more details", "Click here to give messages to our group", global::DesignDatabaseTools.Properties.Resources.chat, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.buttonItem60.Text = "Messages";
            // 
            // buttonItem61
            // 
            this.buttonItem61.Image = global::DesignDatabaseTools.Properties.Resources.help_and_support;
            this.buttonItem61.ImagePaddingHorizontal = 50;
            this.buttonItem61.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem61.Name = "buttonItem61";
            this.superTooltip.SetSuperTooltip(this.buttonItem61, new DevComponents.DotNetBar.SuperTooltipInfo("Question (Ctrl+Q)", "Click Help for more details", "Click here to raise a question to our group", global::DesignDatabaseTools.Properties.Resources.help_and_support, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.buttonItem61.Text = "Question";
            // 
            // ribbonBar31
            // 
            this.ribbonBar31.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar31.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar31.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar31.BackgroundStyle.Class = "";
            this.ribbonBar31.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar31.ContainerControlProcessDialogKey = true;
            this.ribbonBar31.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar31.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer39,
            this.itemContainer40});
            this.ribbonBar31.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar31.Name = "ribbonBar31";
            this.ribbonBar31.Size = new System.Drawing.Size(213, 96);
            this.ribbonBar31.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar31.TabIndex = 0;
            this.ribbonBar31.Text = "Information";
            // 
            // 
            // 
            this.ribbonBar31.TitleStyle.Class = "";
            this.ribbonBar31.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar31.TitleStyleMouseOver.Class = "";
            this.ribbonBar31.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer39
            // 
            // 
            // 
            // 
            this.itemContainer39.BackgroundStyle.Class = "";
            this.itemContainer39.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer39.Name = "itemContainer39";
            this.itemContainer39.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.DocumentHelp});
            this.itemContainer39.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // DocumentHelp
            // 
            this.DocumentHelp.Image = global::DesignDatabaseTools.Properties.Resources.apple_address_book1111;
            this.DocumentHelp.ImagePaddingHorizontal = 50;
            this.DocumentHelp.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.DocumentHelp.Name = "DocumentHelp";
            this.DocumentHelp.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.DocumentHelp, new DevComponents.DotNetBar.SuperTooltipInfo("User guide (Ctrl + U)", "Click Help for more details", "Click here to open user guide document", global::DesignDatabaseTools.Properties.Resources.apple_address_book1111, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.DocumentHelp.Text = "Document";
            this.DocumentHelp.Click += new System.EventHandler(this.DocumentHelp_Click);
            // 
            // itemContainer40
            // 
            // 
            // 
            // 
            this.itemContainer40.BackgroundStyle.Class = "";
            this.itemContainer40.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer40.Name = "itemContainer40";
            this.itemContainer40.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.OpenWebsite});
            this.itemContainer40.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // OpenWebsite
            // 
            this.OpenWebsite.Image = global::DesignDatabaseTools.Properties.Resources.website111;
            this.OpenWebsite.ImagePaddingHorizontal = 50;
            this.OpenWebsite.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.OpenWebsite.Name = "OpenWebsite";
            this.OpenWebsite.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.OpenWebsite, new DevComponents.DotNetBar.SuperTooltipInfo("Website (Ctrl + W)", "Click Help for more details", "Click here to open a website that have some necessary information ", global::DesignDatabaseTools.Properties.Resources.website111, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.OpenWebsite.Text = "Website";
            this.OpenWebsite.Click += new System.EventHandler(this.OpenWebsite_Click);
            // 
            // ribbonPanel8
            // 
            this.ribbonPanel8.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel8.Controls.Add(this.ribbonBar37);
            this.ribbonPanel8.Controls.Add(this.ribbonBar36);
            this.ribbonPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel8.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel8.Name = "ribbonPanel8";
            this.ribbonPanel8.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel8.Size = new System.Drawing.Size(1117, 99);
            // 
            // 
            // 
            this.ribbonPanel8.Style.Class = "";
            this.ribbonPanel8.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel8.StyleMouseDown.Class = "";
            this.ribbonPanel8.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel8.StyleMouseOver.Class = "";
            this.ribbonPanel8.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel8.TabIndex = 8;
            this.ribbonPanel8.Visible = false;
            // 
            // ribbonBar37
            // 
            this.ribbonBar37.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar37.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar37.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar37.BackgroundStyle.Class = "";
            this.ribbonBar37.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar37.ContainerControlProcessDialogKey = true;
            this.ribbonBar37.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar37.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer44,
            this.itemContainer47});
            this.ribbonBar37.Location = new System.Drawing.Point(232, 0);
            this.ribbonBar37.Name = "ribbonBar37";
            this.ribbonBar37.Size = new System.Drawing.Size(183, 96);
            this.ribbonBar37.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar37.TabIndex = 1;
            this.ribbonBar37.Text = "Copyright";
            // 
            // 
            // 
            this.ribbonBar37.TitleStyle.Class = "";
            this.ribbonBar37.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar37.TitleStyleMouseOver.Class = "";
            this.ribbonBar37.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer44
            // 
            // 
            // 
            // 
            this.itemContainer44.BackgroundStyle.Class = "";
            this.itemContainer44.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer44.Name = "itemContainer44";
            this.itemContainer44.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.TermOf});
            this.itemContainer44.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // TermOf
            // 
            this.TermOf.Image = global::DesignDatabaseTools.Properties.Resources.copyrightxx;
            this.TermOf.ImagePaddingHorizontal = 50;
            this.TermOf.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.TermOf.Name = "TermOf";
            this.TermOf.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.TermOf, new DevComponents.DotNetBar.SuperTooltipInfo("Term of service", "Click Help for more details", "Click here to know about some regulations to use this application", global::DesignDatabaseTools.Properties.Resources.copyrightxx, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.TermOf.Text = "Term of service";
            this.TermOf.Click += new System.EventHandler(this.TermOf_Click);
            // 
            // itemContainer47
            // 
            // 
            // 
            // 
            this.itemContainer47.BackgroundStyle.Class = "";
            this.itemContainer47.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer47.Name = "itemContainer47";
            this.itemContainer47.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Callus});
            this.itemContainer47.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Callus
            // 
            this.Callus.Image = global::DesignDatabaseTools.Properties.Resources.telephone_green;
            this.Callus.ImagePaddingHorizontal = 50;
            this.Callus.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Callus.Name = "Callus";
            this.Callus.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.Callus, new DevComponents.DotNetBar.SuperTooltipInfo("Call Us", "Click Help for more details", "Click here to contact us", global::DesignDatabaseTools.Properties.Resources.telephone_green, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Callus.Text = "Call us";
            this.Callus.Click += new System.EventHandler(this.Callus_Click);
            // 
            // ribbonBar36
            // 
            this.ribbonBar36.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar36.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar36.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar36.BackgroundStyle.Class = "";
            this.ribbonBar36.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar36.ContainerControlProcessDialogKey = true;
            this.ribbonBar36.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar36.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer43,
            this.itemContainer42});
            this.ribbonBar36.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar36.Name = "ribbonBar36";
            this.ribbonBar36.Size = new System.Drawing.Size(229, 96);
            this.ribbonBar36.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar36.TabIndex = 0;
            this.ribbonBar36.Text = "Group";
            // 
            // 
            // 
            this.ribbonBar36.TitleStyle.Class = "";
            this.ribbonBar36.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar36.TitleStyleMouseOver.Class = "";
            this.ribbonBar36.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer43
            // 
            // 
            // 
            // 
            this.itemContainer43.BackgroundStyle.Class = "";
            this.itemContainer43.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer43.Name = "itemContainer43";
            this.itemContainer43.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.SoftInformation});
            this.itemContainer43.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // SoftInformation
            // 
            this.SoftInformation.Image = global::DesignDatabaseTools.Properties.Resources.info;
            this.SoftInformation.ImagePaddingHorizontal = 50;
            this.SoftInformation.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.SoftInformation.Name = "SoftInformation";
            this.SoftInformation.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.SoftInformation, new DevComponents.DotNetBar.SuperTooltipInfo("Soft Information", "Click Help for more details", "Click here to know about this application", global::DesignDatabaseTools.Properties.Resources.info, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.SoftInformation.Text = "Soft Infomation";
            this.SoftInformation.Click += new System.EventHandler(this.SoftInformation_Click);
            // 
            // itemContainer42
            // 
            // 
            // 
            // 
            this.itemContainer42.BackgroundStyle.Class = "";
            this.itemContainer42.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer42.Name = "itemContainer42";
            this.itemContainer42.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.GroupInfomation});
            this.itemContainer42.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // GroupInfomation
            // 
            this.GroupInfomation.Image = global::DesignDatabaseTools.Properties.Resources.group;
            this.GroupInfomation.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.GroupInfomation.Name = "GroupInfomation";
            this.GroupInfomation.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.GroupInfomation, new DevComponents.DotNetBar.SuperTooltipInfo("Group Information", "Click Help for more details", "Click here to know about our group", global::DesignDatabaseTools.Properties.Resources.group, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.GroupInfomation.Text = "GroupInformation";
            this.GroupInfomation.Click += new System.EventHandler(this.GroupInfomation_Click);
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel2.Controls.Add(this.ribbonBar1);
            this.ribbonPanel2.Controls.Add(this.ribbonBar2);
            this.ribbonPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel2.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel2.Name = "ribbonPanel2";
            this.ribbonPanel2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel2.Size = new System.Drawing.Size(1117, 99);
            // 
            // 
            // 
            this.ribbonPanel2.Style.Class = "";
            this.ribbonPanel2.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel2.StyleMouseDown.Class = "";
            this.ribbonPanel2.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel2.StyleMouseOver.Class = "";
            this.ribbonPanel2.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel2.TabIndex = 2;
            this.ribbonPanel2.Visible = false;
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar1.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundStyle.Class = "";
            this.ribbonBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer18});
            this.ribbonBar1.Location = new System.Drawing.Point(178, 0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(200, 96);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar1.TabIndex = 1;
            this.ribbonBar1.Text = "Text";
            // 
            // 
            // 
            this.ribbonBar1.TitleStyle.Class = "";
            this.ribbonBar1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyleMouseOver.Class = "";
            this.ribbonBar1.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer18
            // 
            // 
            // 
            // 
            this.itemContainer18.BackgroundStyle.Class = "";
            this.itemContainer18.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer18.Name = "itemContainer18";
            this.itemContainer18.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Insertext,
            this.InsertImage,
            this.Comment});
            this.itemContainer18.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Insertext
            // 
            this.Insertext.Image = global::DesignDatabaseTools.Properties.Resources.text3333;
            this.Insertext.ImagePaddingHorizontal = 25;
            this.Insertext.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Insertext.Name = "Insertext";
            this.superTooltip.SetSuperTooltip(this.Insertext, new DevComponents.DotNetBar.SuperTooltipInfo("Insert Text (Alt + I)", "Click Help for more details", "Click here to insert text into diagram", global::DesignDatabaseTools.Properties.Resources.text3333, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Insertext.Text = "Text";
            this.Insertext.Click += new System.EventHandler(this.Insertext_Click);
            // 
            // InsertImage
            // 
            this.InsertImage.Image = global::DesignDatabaseTools.Properties.Resources.folder_imageddd;
            this.InsertImage.ImagePaddingHorizontal = 25;
            this.InsertImage.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.InsertImage.Name = "InsertImage";
            this.superTooltip.SetSuperTooltip(this.InsertImage, new DevComponents.DotNetBar.SuperTooltipInfo("Insert Image(Alt+M)", "Click Help for more details", "Click here to insert images into diagram", global::DesignDatabaseTools.Properties.Resources.folder_imageddd, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.InsertImage.Text = "Image";
            this.InsertImage.Click += new System.EventHandler(this.InsertImage_Click);
            // 
            // Comment
            // 
            this.Comment.Image = global::DesignDatabaseTools.Properties.Resources.chat_2eeee;
            this.Comment.ImagePaddingHorizontal = 25;
            this.Comment.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Comment.Name = "Comment";
            this.superTooltip.SetSuperTooltip(this.Comment, new DevComponents.DotNetBar.SuperTooltipInfo("Insert comment(Alt+C)", "Click Help for more details", "Click here to insert comments into diagram", global::DesignDatabaseTools.Properties.Resources.chat_2eeee, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Comment.Text = "Comment";
            this.Comment.Click += new System.EventHandler(this.Comment_Click);
            // 
            // ribbonBar2
            // 
            this.ribbonBar2.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar2.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundStyle.Class = "";
            this.ribbonBar2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar2.ContainerControlProcessDialogKey = true;
            this.ribbonBar2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer13,
            this.itemContainer16});
            this.ribbonBar2.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar2.Name = "ribbonBar2";
            this.ribbonBar2.Size = new System.Drawing.Size(175, 96);
            this.ribbonBar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar2.TabIndex = 0;
            this.ribbonBar2.Text = "Page";
            // 
            // 
            // 
            this.ribbonBar2.TitleStyle.Class = "";
            this.ribbonBar2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.TitleStyleMouseOver.Class = "";
            this.ribbonBar2.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer13
            // 
            // 
            // 
            // 
            this.itemContainer13.BackgroundStyle.Class = "";
            this.itemContainer13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer13.Name = "itemContainer13";
            this.itemContainer13.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.InsertNewPage});
            this.itemContainer13.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // InsertNewPage
            // 
            this.InsertNewPage.Image = global::DesignDatabaseTools.Properties.Resources.new_file1111;
            this.InsertNewPage.ImagePaddingHorizontal = 50;
            this.InsertNewPage.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.InsertNewPage.Name = "InsertNewPage";
            this.InsertNewPage.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.InsertNewPage, new DevComponents.DotNetBar.SuperTooltipInfo("New Page (Alt + N)", "Click Help for more details", "Click here to open a new page", global::DesignDatabaseTools.Properties.Resources.new_file1111, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.InsertNewPage.Text = "New Page";
            this.InsertNewPage.Click += new System.EventHandler(this.InsertNewPage_Click);
            // 
            // itemContainer16
            // 
            // 
            // 
            // 
            this.itemContainer16.BackgroundStyle.Class = "";
            this.itemContainer16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer16.Name = "itemContainer16";
            this.itemContainer16.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.InsertOldPage});
            this.itemContainer16.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // InsertOldPage
            // 
            this.InsertOldPage.Image = global::DesignDatabaseTools.Properties.Resources.old_versions;
            this.InsertOldPage.ImagePaddingHorizontal = 50;
            this.InsertOldPage.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.InsertOldPage.Name = "InsertOldPage";
            this.InsertOldPage.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.InsertOldPage, new DevComponents.DotNetBar.SuperTooltipInfo("Old Page ( Alt + O )", "Click Help for more details", "Click here to insert old page", global::DesignDatabaseTools.Properties.Resources.old_versions, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.InsertOldPage.Text = "Old Page";
            this.InsertOldPage.Click += new System.EventHandler(this.InsertOldPage_Click);
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel3.Controls.Add(this.ribbonBar13);
            this.ribbonPanel3.Controls.Add(this.ribbonBar11);
            this.ribbonPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel3.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel3.Name = "ribbonPanel3";
            this.ribbonPanel3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel3.Size = new System.Drawing.Size(1117, 99);
            // 
            // 
            // 
            this.ribbonPanel3.Style.Class = "";
            this.ribbonPanel3.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel3.StyleMouseDown.Class = "";
            this.ribbonPanel3.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel3.StyleMouseOver.Class = "";
            this.ribbonPanel3.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel3.TabIndex = 3;
            this.ribbonPanel3.Visible = false;
            // 
            // ribbonBar13
            // 
            this.ribbonBar13.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar13.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar13.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar13.BackgroundStyle.Class = "";
            this.ribbonBar13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar13.ContainerControlProcessDialogKey = true;
            this.ribbonBar13.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar13.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.RulerUnit,
            this.AreaColor});
            this.ribbonBar13.Location = new System.Drawing.Point(146, 0);
            this.ribbonBar13.Name = "ribbonBar13";
            this.ribbonBar13.Size = new System.Drawing.Size(156, 96);
            this.ribbonBar13.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar13.TabIndex = 4;
            this.ribbonBar13.Text = "Ruler /Page";
            // 
            // 
            // 
            this.ribbonBar13.TitleStyle.Class = "";
            this.ribbonBar13.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar13.TitleStyleMouseOver.Class = "";
            this.ribbonBar13.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // RulerUnit
            // 
            this.RulerUnit.Image = global::DesignDatabaseTools.Properties.Resources.rulers1;
            this.RulerUnit.ImagePaddingHorizontal = 25;
            this.RulerUnit.Name = "RulerUnit";
            this.RulerUnit.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.CRuler,
            this.IRuler,
            this.PRuler});
            this.RulerUnit.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.RulerUnit, new DevComponents.DotNetBar.SuperTooltipInfo("Ruler", "Click Help for more details", "Click here to select ruler measure", global::DesignDatabaseTools.Properties.Resources.rulers, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.RulerUnit.Text = "Ruler Unit";
            // 
            // CRuler
            // 
            this.CRuler.Name = "CRuler";
            this.CRuler.Text = "Centimeters";
            this.CRuler.Click += new System.EventHandler(this.CRuler_Click);
            // 
            // IRuler
            // 
            this.IRuler.Name = "IRuler";
            this.IRuler.Text = "Inches";
            this.IRuler.Click += new System.EventHandler(this.IRuler_Click);
            // 
            // PRuler
            // 
            this.PRuler.Name = "PRuler";
            this.PRuler.Text = "Pixels";
            this.PRuler.Click += new System.EventHandler(this.PRuler_Click);
            // 
            // AreaColor
            // 
            this.AreaColor.Image = global::DesignDatabaseTools.Properties.Resources.background1111;
            this.AreaColor.Name = "AreaColor";
            this.AreaColor.SubItemsExpandWidth = 14;
            this.AreaColor.Text = "Page Color";
            this.AreaColor.SelectedColorChanged += new System.EventHandler(this.AreaColor_SelectedColorChanged);
            // 
            // ribbonBar11
            // 
            this.ribbonBar11.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar11.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar11.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar11.BackgroundStyle.Class = "";
            this.ribbonBar11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar11.ContainerControlProcessDialogKey = true;
            this.ribbonBar11.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar11.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer36});
            this.ribbonBar11.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar11.Name = "ribbonBar11";
            this.ribbonBar11.Size = new System.Drawing.Size(143, 96);
            this.ribbonBar11.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar11.TabIndex = 2;
            this.ribbonBar11.Text = "Slide Show";
            // 
            // 
            // 
            this.ribbonBar11.TitleStyle.Class = "";
            this.ribbonBar11.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar11.TitleStyleMouseOver.Class = "";
            this.ribbonBar11.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer36
            // 
            // 
            // 
            // 
            this.itemContainer36.BackgroundStyle.Class = "";
            this.itemContainer36.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer36.Name = "itemContainer36";
            this.itemContainer36.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.SlideShowClick,
            this.SlideBack});
            this.itemContainer36.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // SlideShowClick
            // 
            this.SlideShowClick.Image = global::DesignDatabaseTools.Properties.Resources.player_play;
            this.SlideShowClick.ImagePaddingHorizontal = 20;
            this.SlideShowClick.Name = "SlideShowClick";
            this.superTooltip.SetSuperTooltip(this.SlideShowClick, new DevComponents.DotNetBar.SuperTooltipInfo("Slide(Ctrl+Alt+S)", "Click Help for more details", "Click here to run slide show", global::DesignDatabaseTools.Properties.Resources.player_play, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.SlideShowClick.Text = "From Beginning";
            this.SlideShowClick.Click += new System.EventHandler(this.SlideShowClick_Click);
            // 
            // SlideBack
            // 
            this.SlideBack.Image = global::DesignDatabaseTools.Properties.Resources.background;
            this.SlideBack.ImagePaddingHorizontal = 20;
            this.SlideBack.Name = "SlideBack";
            this.superTooltip.SetSuperTooltip(this.SlideBack, new DevComponents.DotNetBar.SuperTooltipInfo("Slide Background", "Click Help for more details", "Click here to choose color for slide page", global::DesignDatabaseTools.Properties.Resources.background, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.SlideBack.Text = "Background";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel1.Controls.Add(this.ribbonBar6);
            this.ribbonPanel1.Controls.Add(this.ribbonBar5);
            this.ribbonPanel1.Controls.Add(this.ribbonBar4);
            this.ribbonPanel1.Controls.Add(this.ribbonBar3);
            this.ribbonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel1.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel1.Name = "ribbonPanel1";
            this.ribbonPanel1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel1.Size = new System.Drawing.Size(1117, 99);
            // 
            // 
            // 
            this.ribbonPanel1.Style.Class = "";
            this.ribbonPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel1.StyleMouseDown.Class = "";
            this.ribbonPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel1.StyleMouseOver.Class = "";
            this.ribbonPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel1.TabIndex = 1;
            this.ribbonPanel1.Visible = false;
            // 
            // ribbonBar6
            // 
            this.ribbonBar6.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar6.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar6.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar6.BackgroundStyle.Class = "";
            this.ribbonBar6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar6.ContainerControlProcessDialogKey = true;
            this.ribbonBar6.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar6.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer9,
            this.itemContainer17});
            this.ribbonBar6.Location = new System.Drawing.Point(779, 0);
            this.ribbonBar6.Name = "ribbonBar6";
            this.ribbonBar6.Size = new System.Drawing.Size(258, 96);
            this.ribbonBar6.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar6.TabIndex = 4;
            this.ribbonBar6.Text = "Zoom";
            // 
            // 
            // 
            this.ribbonBar6.TitleStyle.Class = "";
            this.ribbonBar6.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar6.TitleStyleMouseOver.Class = "";
            this.ribbonBar6.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer9
            // 
            // 
            // 
            // 
            this.itemContainer9.BackgroundStyle.Class = "";
            this.itemContainer9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer9.Name = "itemContainer9";
            this.itemContainer9.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ZoomOut,
            this.ZoomIn});
            this.itemContainer9.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // ZoomOut
            // 
            this.ZoomOut.Image = global::DesignDatabaseTools.Properties.Resources.magnifier_zoom_out;
            this.ZoomOut.ImagePaddingHorizontal = 30;
            this.ZoomOut.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.ZoomOut.Name = "ZoomOut";
            this.superTooltip.SetSuperTooltip(this.ZoomOut, new DevComponents.DotNetBar.SuperTooltipInfo("Zoom out ( Ctrl + Alt + Up)", "Click Help for more details ", "Click here to zoom out", global::DesignDatabaseTools.Properties.Resources.zoom_in1111, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.ZoomOut.Text = "Zoom out";
            this.ZoomOut.Click += new System.EventHandler(this.ZoomOut_Click);
            // 
            // ZoomIn
            // 
            this.ZoomIn.Image = global::DesignDatabaseTools.Properties.Resources.zoom_in1111;
            this.ZoomIn.ImagePaddingHorizontal = 30;
            this.ZoomIn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.ZoomIn.Name = "ZoomIn";
            this.superTooltip.SetSuperTooltip(this.ZoomIn, new DevComponents.DotNetBar.SuperTooltipInfo("Zoom In ( Ctrl + Alt + Down)", "Click Help for more details ", "Click here to zoom in ", global::DesignDatabaseTools.Properties.Resources.magnifier_zoom_out, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.ZoomIn.Text = "Zoom in";
            this.ZoomIn.Click += new System.EventHandler(this.ZoomIn_Click);
            // 
            // itemContainer17
            // 
            // 
            // 
            // 
            this.itemContainer17.BackgroundStyle.Class = "";
            this.itemContainer17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer17.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer17.Name = "itemContainer17";
            this.itemContainer17.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer19});
            this.itemContainer17.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // itemContainer19
            // 
            // 
            // 
            // 
            this.itemContainer19.BackgroundStyle.Class = "";
            this.itemContainer19.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer19.Name = "itemContainer19";
            this.itemContainer19.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem3,
            this.ZoomValue});
            // 
            // labelItem3
            // 
            this.labelItem3.Image = global::DesignDatabaseTools.Properties.Resources.Zoom;
            this.labelItem3.Name = "labelItem3";
            this.labelItem3.Text = "Size";
            // 
            // ZoomValue
            // 
            this.ZoomValue.DropDownHeight = 106;
            this.ZoomValue.Name = "ZoomValue";
            this.superTooltip.SetSuperTooltip(this.ZoomValue, new DevComponents.DotNetBar.SuperTooltipInfo("Size ", "Click Help for more details", "Click here to select the size of component", global::DesignDatabaseTools.Properties.Resources.Zoom, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.ZoomValue.SelectedIndexChanged += new System.EventHandler(this.ZoomValueChage);
            this.ZoomValue.Click += new System.EventHandler(this.ZoomValue_Click);
            // 
            // ribbonBar5
            // 
            this.ribbonBar5.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar5.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar5.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar5.BackgroundStyle.Class = "";
            this.ribbonBar5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar5.ContainerControlProcessDialogKey = true;
            this.ribbonBar5.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar5.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer15,
            this.itemContainer20,
            this.itemContainer51});
            this.ribbonBar5.Location = new System.Drawing.Point(501, 0);
            this.ribbonBar5.Name = "ribbonBar5";
            this.ribbonBar5.Size = new System.Drawing.Size(278, 96);
            this.ribbonBar5.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar5.TabIndex = 3;
            this.ribbonBar5.Text = "Basic Tools";
            // 
            // 
            // 
            this.ribbonBar5.TitleStyle.Class = "";
            this.ribbonBar5.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar5.TitleStyleMouseOver.Class = "";
            this.ribbonBar5.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer15
            // 
            // 
            // 
            // 
            this.itemContainer15.BackgroundStyle.Class = "";
            this.itemContainer15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer15.Name = "itemContainer15";
            this.itemContainer15.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Select,
            this.Find});
            this.itemContainer15.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Select
            // 
            this.Select.Image = global::DesignDatabaseTools.Properties.Resources.mouse_pointer;
            this.Select.ImagePaddingHorizontal = 20;
            this.Select.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Select.Name = "Select";
            this.superTooltip.SetSuperTooltip(this.Select, new DevComponents.DotNetBar.SuperTooltipInfo("Select ( Ctrl + Alt )", "Click Help for more details ", "Click here to change to select mode", global::DesignDatabaseTools.Properties.Resources.mouse_pointer, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Select.Text = "Select";
            this.Select.Click += new System.EventHandler(this.Select_Click);
            // 
            // Find
            // 
            this.Find.Image = global::DesignDatabaseTools.Properties.Resources.find1222;
            this.Find.ImagePaddingHorizontal = 20;
            this.Find.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Find.Name = "Find";
            this.superTooltip.SetSuperTooltip(this.Find, new DevComponents.DotNetBar.SuperTooltipInfo("Search(Ctrl+F)", "Click Help for more details ", "Click here to search component in diagram", global::DesignDatabaseTools.Properties.Resources.find1222, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Find.Text = "Search";
            this.Find.Click += new System.EventHandler(this.Find_Click);
            // 
            // itemContainer20
            // 
            // 
            // 
            // 
            this.itemContainer20.BackgroundStyle.Class = "";
            this.itemContainer20.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer20.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer20.Name = "itemContainer20";
            this.itemContainer20.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Undo,
            this.Redo});
            this.itemContainer20.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Undo
            // 
            this.Undo.Image = global::DesignDatabaseTools.Properties.Resources.Undo;
            this.Undo.ImagePaddingHorizontal = 20;
            this.Undo.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Undo.Name = "Undo";
            this.superTooltip.SetSuperTooltip(this.Undo, new DevComponents.DotNetBar.SuperTooltipInfo("Undo ( Ctrl + U )", "ClickHelp for more details ", "Click here to recover to last activity", global::DesignDatabaseTools.Properties.Resources.Undo, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Undo.Text = "Undo";
            this.Undo.Click += new System.EventHandler(this.Undo_Click);
            // 
            // Redo
            // 
            this.Redo.Image = global::DesignDatabaseTools.Properties.Resources.Redo;
            this.Redo.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Redo.Name = "Redo";
            this.superTooltip.SetSuperTooltip(this.Redo, new DevComponents.DotNetBar.SuperTooltipInfo("Redo ( Ctrl + R )", "Click Help for more details ", "Click here to recover of last undo activity", global::DesignDatabaseTools.Properties.Resources.Redo, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Redo.Text = "Redo";
            this.Redo.Click += new System.EventHandler(this.Redo_Click);
            // 
            // itemContainer51
            // 
            // 
            // 
            // 
            this.itemContainer51.BackgroundStyle.Class = "";
            this.itemContainer51.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer51.Name = "itemContainer51";
            this.itemContainer51.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Panning,
            this.Panning_reset});
            this.itemContainer51.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Panning
            // 
            this.Panning.Image = global::DesignDatabaseTools.Properties.Resources.move2red;
            this.Panning.ImagePaddingHorizontal = 20;
            this.Panning.Name = "Panning";
            this.Panning.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.Panning, new DevComponents.DotNetBar.SuperTooltipInfo("Panning", "Click Help for more details ", "Click here to move main area", global::DesignDatabaseTools.Properties.Resources.move2red, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Panning.Text = "Pan";
            this.Panning.Click += new System.EventHandler(this.Panning_Click);
            // 
            // Panning_reset
            // 
            this.Panning_reset.Image = global::DesignDatabaseTools.Properties.Resources.undo_red;
            this.Panning_reset.Name = "Panning_reset";
            this.Panning_reset.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.Panning_reset, new DevComponents.DotNetBar.SuperTooltipInfo("Panning Reset", "Click Help for more details", "Click here to reset panning", global::DesignDatabaseTools.Properties.Resources.undo_red, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Panning_reset.Text = "Panning reset";
            this.Panning_reset.Click += new System.EventHandler(this.Panning_reset_Click);
            // 
            // ribbonBar4
            // 
            this.ribbonBar4.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar4.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar4.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar4.BackgroundStyle.Class = "";
            this.ribbonBar4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar4.ContainerControlProcessDialogKey = true;
            this.ribbonBar4.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar4.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer5,
            this.itemContainer35});
            this.ribbonBar4.Location = new System.Drawing.Point(200, 0);
            this.ribbonBar4.Name = "ribbonBar4";
            this.ribbonBar4.Size = new System.Drawing.Size(301, 96);
            this.ribbonBar4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar4.TabIndex = 2;
            this.ribbonBar4.Text = "Font";
            // 
            // 
            // 
            this.ribbonBar4.TitleStyle.Class = "";
            this.ribbonBar4.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar4.TitleStyleMouseOver.Class = "";
            this.ribbonBar4.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer5
            // 
            // 
            // 
            // 
            this.itemContainer5.BackgroundStyle.Class = "";
            this.itemContainer5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer5.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer5.Name = "itemContainer5";
            this.itemContainer5.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer10,
            this.itemContainer11,
            this.itemContainer77});
            this.itemContainer5.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // itemContainer10
            // 
            // 
            // 
            // 
            this.itemContainer10.BackgroundStyle.Class = "";
            this.itemContainer10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer10.Name = "itemContainer10";
            this.itemContainer10.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem1,
            this.Font});
            // 
            // labelItem1
            // 
            this.labelItem1.Name = "labelItem1";
            this.labelItem1.Text = "Font ";
            // 
            // Font
            // 
            this.Font.ComboWidth = 100;
            this.Font.DropDownHeight = 106;
            this.Font.Name = "Font";
            this.superTooltip.SetSuperTooltip(this.Font, new DevComponents.DotNetBar.SuperTooltipInfo("Font Family", "Click Help for more details ", "Click here to choose font Family", global::DesignDatabaseTools.Properties.Resources.fonts1, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Font.Text = "comboBoxItem1";
            this.Font.TextChanged += new System.EventHandler(this.FontNameChanged);
            // 
            // itemContainer11
            // 
            // 
            // 
            // 
            this.itemContainer11.BackgroundStyle.Class = "";
            this.itemContainer11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer11.Name = "itemContainer11";
            this.itemContainer11.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem2,
            this.SizeFont});
            // 
            // labelItem2
            // 
            this.labelItem2.Name = "labelItem2";
            this.labelItem2.Text = "Size ";
            // 
            // SizeFont
            // 
            this.SizeFont.ComboWidth = 100;
            this.SizeFont.DropDownHeight = 106;
            this.SizeFont.Name = "SizeFont";
            this.superTooltip.SetSuperTooltip(this.SizeFont, new DevComponents.DotNetBar.SuperTooltipInfo("Font Size", "Click Help for more details ", "Click here to select font size", global::DesignDatabaseTools.Properties.Resources.fonts1, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.SizeFont.Text = "comboBoxItem2";
            this.SizeFont.TextChanged += new System.EventHandler(this.SizeFontChanged);
            // 
            // itemContainer77
            // 
            // 
            // 
            // 
            this.itemContainer77.BackgroundStyle.Class = "";
            this.itemContainer77.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer77.Name = "itemContainer77";
            this.itemContainer77.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.StyleFont,
            this.Style});
            // 
            // StyleFont
            // 
            this.StyleFont.Name = "StyleFont";
            this.StyleFont.Text = "Style";
            // 
            // Style
            // 
            this.Style.ComboWidth = 100;
            this.Style.DropDownHeight = 106;
            this.Style.Name = "Style";
            this.superTooltip.SetSuperTooltip(this.Style, new DevComponents.DotNetBar.SuperTooltipInfo("Font Style", "Click Help for more details ", "Click here to select font style", global::DesignDatabaseTools.Properties.Resources.fonts1, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Style.Text = "comboBoxItem1";
            this.Style.TextChanged += new System.EventHandler(this.StyleFontChanged);
            // 
            // itemContainer35
            // 
            // 
            // 
            // 
            this.itemContainer35.BackgroundStyle.Class = "";
            this.itemContainer35.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer35.Name = "itemContainer35";
            this.itemContainer35.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.TextColor,
            this.Fontbox});
            this.itemContainer35.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // TextColor
            // 
            this.TextColor.Image = global::DesignDatabaseTools.Properties.Resources.fontaaaa;
            this.TextColor.ImagePaddingHorizontal = 30;
            this.TextColor.Name = "TextColor";
            this.superTooltip.SetSuperTooltip(this.TextColor, new DevComponents.DotNetBar.SuperTooltipInfo("Font Style Color", "Click Help for more details ", "Click here to select font style and color", global::DesignDatabaseTools.Properties.Resources.fontaaaa, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.TextColor.Text = "Text Color     ";
            this.TextColor.SelectedColorChanged += new System.EventHandler(this.FontColorChanged);
            // 
            // Fontbox
            // 
            this.Fontbox.Image = global::DesignDatabaseTools.Properties.Resources.fonts;
            this.Fontbox.ImagePaddingHorizontal = 30;
            this.Fontbox.Name = "Fontbox";
            this.Fontbox.SubItemsExpandWidth = 14;
            this.superTooltip.SetSuperTooltip(this.Fontbox, new DevComponents.DotNetBar.SuperTooltipInfo("Font Dialog", "Click Help for more details ", "Click here to open font dialog", global::DesignDatabaseTools.Properties.Resources.fonts, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Fontbox.Text = "Font box";
            this.Fontbox.Click += new System.EventHandler(this.Fontbox_Click);
            // 
            // ribbonBar3
            // 
            this.ribbonBar3.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar3.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar3.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar3.BackgroundStyle.Class = "";
            this.ribbonBar3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar3.ContainerControlProcessDialogKey = true;
            this.ribbonBar3.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar3.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer6,
            this.itemContainer7,
            this.itemContainer8});
            this.ribbonBar3.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar3.Name = "ribbonBar3";
            this.ribbonBar3.Size = new System.Drawing.Size(197, 96);
            this.ribbonBar3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar3.TabIndex = 1;
            this.ribbonBar3.Text = "File";
            // 
            // 
            // 
            this.ribbonBar3.TitleStyle.Class = "";
            this.ribbonBar3.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar3.TitleStyleMouseOver.Class = "";
            this.ribbonBar3.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer6
            // 
            // 
            // 
            // 
            this.itemContainer6.BackgroundStyle.Class = "";
            this.itemContainer6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer6.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer6.Name = "itemContainer6";
            this.itemContainer6.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Open});
            this.itemContainer6.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Open
            // 
            this.Open.Image = global::DesignDatabaseTools.Properties.Resources.Folder;
            this.Open.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Open.Name = "Open";
            this.superTooltip.SetSuperTooltip(this.Open, new DevComponents.DotNetBar.SuperTooltipInfo("Open ( Ctrl + O)", "Click Help for more details", "Click here to open stored diagram", global::DesignDatabaseTools.Properties.Resources.Folder, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Open.Text = "  Open      ";
            this.Open.Click += new System.EventHandler(this.Open_Click);
            // 
            // itemContainer7
            // 
            // 
            // 
            // 
            this.itemContainer7.BackgroundStyle.Class = "";
            this.itemContainer7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer7.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer7.Name = "itemContainer7";
            this.itemContainer7.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.New,
            this.Save});
            this.itemContainer7.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // New
            // 
            this.New.Image = global::DesignDatabaseTools.Properties.Resources.New_document;
            this.New.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.New.Name = "New";
            this.superTooltip.SetSuperTooltip(this.New, new DevComponents.DotNetBar.SuperTooltipInfo("New ( Ctrl + N )", "Click Help for more details", "Click here to open a new page ", global::DesignDatabaseTools.Properties.Resources.New_document, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.New.Text = "   New   ";
            this.New.Click += new System.EventHandler(this.New_Click);
            // 
            // Save
            // 
            this.Save.Image = global::DesignDatabaseTools.Properties.Resources.Save;
            this.Save.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Save.Name = "Save";
            this.superTooltip.SetSuperTooltip(this.Save, new DevComponents.DotNetBar.SuperTooltipInfo("Save ( Ctrl + S )", "Click Help for more details ", "Click here to save diagram", global::DesignDatabaseTools.Properties.Resources.Save, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Save.Text = "Save";
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // itemContainer8
            // 
            // 
            // 
            // 
            this.itemContainer8.BackgroundStyle.Class = "";
            this.itemContainer8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer8.Name = "itemContainer8";
            this.itemContainer8.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Cut,
            this.Copy,
            this.Paste});
            this.itemContainer8.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // Cut
            // 
            this.Cut.Image = global::DesignDatabaseTools.Properties.Resources.Cut;
            this.Cut.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Cut.Name = "Cut";
            this.superTooltip.SetSuperTooltip(this.Cut, new DevComponents.DotNetBar.SuperTooltipInfo("Cut ( Ctrl + X )", "Click Help for more details ", "Click here to cut selected component from current diagram", global::DesignDatabaseTools.Properties.Resources.Cut, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Cut.Text = "Cut";
            this.Cut.Click += new System.EventHandler(this.Cut_Click);
            // 
            // Copy
            // 
            this.Copy.Image = global::DesignDatabaseTools.Properties.Resources.Copy;
            this.Copy.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Copy.Name = "Copy";
            this.superTooltip.SetSuperTooltip(this.Copy, new DevComponents.DotNetBar.SuperTooltipInfo("Copy ( Ctrl + C )", "Click Help for more details ", "Click here to copy a selected component from diagram", global::DesignDatabaseTools.Properties.Resources.Copy, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Copy.Text = "Copy";
            this.Copy.Click += new System.EventHandler(this.Copy_Click);
            // 
            // Paste
            // 
            this.Paste.Image = global::DesignDatabaseTools.Properties.Resources.Paste;
            this.Paste.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.Paste.Name = "Paste";
            this.superTooltip.SetSuperTooltip(this.Paste, new DevComponents.DotNetBar.SuperTooltipInfo("Paste ( Ctrl + P )", "Click Help for more details ", "Click here to paste a component which was selected", global::DesignDatabaseTools.Properties.Resources.Paste, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Paste.Text = "Paste";
            this.Paste.Click += new System.EventHandler(this.Paste_Click);
            this.Paste.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PasteMouseClick);
            // 
            // ribbonPanel6
            // 
            this.ribbonPanel6.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel6.Controls.Add(this.ribbonBar28);
            this.ribbonPanel6.Controls.Add(this.ribbonBar26);
            this.ribbonPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel6.Location = new System.Drawing.Point(0, 53);
            this.ribbonPanel6.Name = "ribbonPanel6";
            this.ribbonPanel6.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel6.Size = new System.Drawing.Size(1117, 99);
            // 
            // 
            // 
            this.ribbonPanel6.Style.Class = "";
            this.ribbonPanel6.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel6.StyleMouseDown.Class = "";
            this.ribbonPanel6.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel6.StyleMouseOver.Class = "";
            this.ribbonPanel6.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel6.TabIndex = 6;
            this.ribbonPanel6.Visible = false;
            // 
            // ribbonBar28
            // 
            this.ribbonBar28.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar28.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar28.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar28.BackgroundStyle.Class = "";
            this.ribbonBar28.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar28.ContainerControlProcessDialogKey = true;
            this.ribbonBar28.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar28.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer21,
            this.itemContainer25});
            this.ribbonBar28.Location = new System.Drawing.Point(216, 0);
            this.ribbonBar28.Name = "ribbonBar28";
            this.ribbonBar28.Size = new System.Drawing.Size(226, 96);
            this.ribbonBar28.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar28.TabIndex = 2;
            this.ribbonBar28.Text = "Show/Hide";
            // 
            // 
            // 
            this.ribbonBar28.TitleStyle.Class = "";
            this.ribbonBar28.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar28.TitleStyleMouseOver.Class = "";
            this.ribbonBar28.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer21
            // 
            // 
            // 
            // 
            this.itemContainer21.BackgroundStyle.Class = "";
            this.itemContainer21.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer21.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer21.Name = "itemContainer21";
            this.itemContainer21.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer22,
            this.itemContainer23,
            this.itemContainer24});
            // 
            // itemContainer22
            // 
            // 
            // 
            // 
            this.itemContainer22.BackgroundStyle.Class = "";
            this.itemContainer22.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer22.Name = "itemContainer22";
            this.itemContainer22.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.checkRuler});
            // 
            // checkRuler
            // 
            this.checkRuler.Name = "checkRuler";
            this.checkRuler.Text = "Rulers";
            this.checkRuler.Click += new System.EventHandler(this.checkRuler_Click);
            // 
            // itemContainer23
            // 
            // 
            // 
            // 
            this.itemContainer23.BackgroundStyle.Class = "";
            this.itemContainer23.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer23.Name = "itemContainer23";
            this.itemContainer23.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.GirdBox});
            // 
            // GirdBox
            // 
            this.GirdBox.Name = "GirdBox";
            this.GirdBox.Text = "Gird";
            this.GirdBox.Click += new System.EventHandler(this.GirdBox_Click);
            // 
            // itemContainer24
            // 
            // 
            // 
            // 
            this.itemContainer24.BackgroundStyle.Class = "";
            this.itemContainer24.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer24.Name = "itemContainer24";
            this.itemContainer24.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.checkBoxItem3});
            // 
            // checkBoxItem3
            // 
            this.checkBoxItem3.Name = "checkBoxItem3";
            this.checkBoxItem3.Text = "GuideLines";
            // 
            // itemContainer25
            // 
            // 
            // 
            // 
            this.itemContainer25.BackgroundStyle.Class = "";
            this.itemContainer25.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer25.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer25.Name = "itemContainer25";
            this.itemContainer25.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer26,
            this.itemContainer27});
            // 
            // itemContainer26
            // 
            // 
            // 
            // 
            this.itemContainer26.BackgroundStyle.Class = "";
            this.itemContainer26.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer26.Name = "itemContainer26";
            this.itemContainer26.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.checkBoxItem4});
            // 
            // checkBoxItem4
            // 
            this.checkBoxItem4.Name = "checkBoxItem4";
            this.checkBoxItem4.Text = "Connect point";
            // 
            // itemContainer27
            // 
            // 
            // 
            // 
            this.itemContainer27.BackgroundStyle.Class = "";
            this.itemContainer27.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer27.Name = "itemContainer27";
            this.itemContainer27.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.checkBoxItem5});
            // 
            // checkBoxItem5
            // 
            this.checkBoxItem5.Name = "checkBoxItem5";
            this.checkBoxItem5.Text = "Messages";
            // 
            // ribbonBar26
            // 
            this.ribbonBar26.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar26.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar26.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar26.BackgroundStyle.Class = "";
            this.ribbonBar26.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar26.ContainerControlProcessDialogKey = true;
            this.ribbonBar26.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar26.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer28,
            this.itemContainer32});
            this.ribbonBar26.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar26.Name = "ribbonBar26";
            this.ribbonBar26.Size = new System.Drawing.Size(213, 96);
            this.ribbonBar26.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar26.TabIndex = 0;
            this.ribbonBar26.Text = "Toolbar";
            // 
            // 
            // 
            this.ribbonBar26.TitleStyle.Class = "";
            this.ribbonBar26.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar26.TitleStyleMouseOver.Class = "";
            this.ribbonBar26.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // itemContainer28
            // 
            // 
            // 
            // 
            this.itemContainer28.BackgroundStyle.Class = "";
            this.itemContainer28.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer28.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer28.Name = "itemContainer28";
            this.itemContainer28.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer29,
            this.itemContainer30,
            this.itemContainer31});
            // 
            // itemContainer29
            // 
            // 
            // 
            // 
            this.itemContainer29.BackgroundStyle.Class = "";
            this.itemContainer29.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer29.Name = "itemContainer29";
            this.itemContainer29.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.View});
            // 
            // View
            // 
            this.View.Name = "View";
            this.View.Text = "View";
            this.View.Click += new System.EventHandler(this.View_Click);
            // 
            // itemContainer30
            // 
            // 
            // 
            // 
            this.itemContainer30.BackgroundStyle.Class = "";
            this.itemContainer30.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer30.Name = "itemContainer30";
            this.itemContainer30.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Insert});
            // 
            // Insert
            // 
            this.Insert.Name = "Insert";
            this.Insert.Text = "Insert";
            this.Insert.Click += new System.EventHandler(this.Insert_Click);
            // 
            // itemContainer31
            // 
            // 
            // 
            // 
            this.itemContainer31.BackgroundStyle.Class = "";
            this.itemContainer31.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer31.Name = "itemContainer31";
            this.itemContainer31.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.DesignTools});
            // 
            // DesignTools
            // 
            this.DesignTools.Name = "DesignTools";
            this.DesignTools.Text = "Design Tools";
            this.DesignTools.Click += new System.EventHandler(this.DesignTools_Click);
            // 
            // itemContainer32
            // 
            // 
            // 
            // 
            this.itemContainer32.BackgroundStyle.Class = "";
            this.itemContainer32.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer32.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer32.Name = "itemContainer32";
            this.itemContainer32.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Toolbox,
            this.Status,
            this.Properties});
            // 
            // Toolbox
            // 
            this.Toolbox.Name = "Toolbox";
            this.Toolbox.Text = "ToolsBox";
            this.Toolbox.Click += new System.EventHandler(this.Toolbox_Click);
            // 
            // Status
            // 
            this.Status.Name = "Status";
            this.Status.Text = "Status";
            this.Status.Click += new System.EventHandler(this.Status_Click);
            // 
            // Properties
            // 
            this.Properties.Name = "Properties";
            this.Properties.Text = "Properties";
            this.Properties.Click += new System.EventHandler(this.Properties_Click);
            // 
            // office2007StartButton1
            // 
            this.office2007StartButton1.AutoExpandOnClick = true;
            this.office2007StartButton1.CanCustomize = false;
            this.office2007StartButton1.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.office2007StartButton1.Image = ((System.Drawing.Image)(resources.GetObject("office2007StartButton1.Image")));
            this.office2007StartButton1.ImageFixedSize = new System.Drawing.Size(16, 16);
            this.office2007StartButton1.ImagePaddingHorizontal = 0;
            this.office2007StartButton1.ImagePaddingVertical = 0;
            this.office2007StartButton1.Name = "office2007StartButton1";
            this.office2007StartButton1.ShowSubItems = false;
            this.office2007StartButton1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer1});
            this.office2007StartButton1.Text = "&File";
            // 
            // itemContainer1
            // 
            // 
            // 
            // 
            this.itemContainer1.BackgroundStyle.Class = "RibbonFileMenuContainer";
            this.itemContainer1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer1.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer1.Name = "itemContainer1";
            this.itemContainer1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer2,
            this.itemContainer4});
            // 
            // itemContainer2
            // 
            // 
            // 
            // 
            this.itemContainer2.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer2.ItemSpacing = 0;
            this.itemContainer2.Name = "itemContainer2";
            this.itemContainer2.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer3,
            this.RecentFile});
            // 
            // itemContainer3
            // 
            // 
            // 
            // 
            this.itemContainer3.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer3.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer3.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer3.Name = "itemContainer3";
            this.itemContainer3.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.NewDocument,
            this.OpenDocument,
            this.SaveAs,
            this.buttonItem5,
            this.buttonItem6,
            this.Close});
            // 
            // NewDocument
            // 
            this.NewDocument.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.NewDocument.Image = ((System.Drawing.Image)(resources.GetObject("NewDocument.Image")));
            this.NewDocument.Name = "NewDocument";
            this.NewDocument.SubItemsExpandWidth = 24;
            this.NewDocument.Text = "&New";
            this.NewDocument.Click += new System.EventHandler(this.NewDocument_Click);
            // 
            // OpenDocument
            // 
            this.OpenDocument.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.OpenDocument.Image = ((System.Drawing.Image)(resources.GetObject("OpenDocument.Image")));
            this.OpenDocument.Name = "OpenDocument";
            this.OpenDocument.SubItemsExpandWidth = 24;
            this.OpenDocument.Text = "&Open...";
            this.OpenDocument.Click += new System.EventHandler(this.OpenDocument_Click);
            // 
            // SaveAs
            // 
            this.SaveAs.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.SaveAs.Image = ((System.Drawing.Image)(resources.GetObject("SaveAs.Image")));
            this.SaveAs.Name = "SaveAs";
            this.SaveAs.SubItemsExpandWidth = 24;
            this.SaveAs.Text = "&Save...";
            this.SaveAs.Click += new System.EventHandler(this.SaveAs_Click);
            // 
            // buttonItem5
            // 
            this.buttonItem5.BeginGroup = true;
            this.buttonItem5.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem5.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem5.Image")));
            this.buttonItem5.Name = "buttonItem5";
            this.buttonItem5.SubItemsExpandWidth = 24;
            this.buttonItem5.Text = "S&hare...";
            // 
            // buttonItem6
            // 
            this.buttonItem6.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem6.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem6.Image")));
            this.buttonItem6.Name = "buttonItem6";
            this.buttonItem6.SubItemsExpandWidth = 24;
            this.buttonItem6.Text = "&Print...";
            // 
            // Close
            // 
            this.Close.BeginGroup = true;
            this.Close.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.Close.Image = ((System.Drawing.Image)(resources.GetObject("Close.Image")));
            this.Close.Name = "Close";
            this.Close.SubItemsExpandWidth = 24;
            this.Close.Text = "&Close";
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // RecentFile
            // 
            // 
            // 
            // 
            this.RecentFile.BackgroundStyle.Class = "RibbonFileMenuColumnTwoContainer";
            this.RecentFile.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.RecentFile.EnableGalleryPopup = false;
            this.RecentFile.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.RecentFile.MinimumSize = new System.Drawing.Size(180, 240);
            this.RecentFile.MultiLine = false;
            this.RecentFile.Name = "RecentFile";
            this.RecentFile.PopupUsesStandardScrollbars = false;
            this.RecentFile.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem8,
            this.RecentFile1,
            this.RecentFile2,
            this.RecentFile3,
            this.RecentFile4,
            this.RecentFile5});
            // 
            // labelItem8
            // 
            this.labelItem8.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.labelItem8.BorderType = DevComponents.DotNetBar.eBorderType.Etched;
            this.labelItem8.CanCustomize = false;
            this.labelItem8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.labelItem8.Name = "labelItem8";
            this.labelItem8.PaddingBottom = 2;
            this.labelItem8.PaddingTop = 2;
            this.labelItem8.Stretch = true;
            this.labelItem8.Text = "Recent Documents";
            // 
            // RecentFile1
            // 
            this.RecentFile1.Name = "RecentFile1";
            this.RecentFile1.Click += new System.EventHandler(this.RecentFile1_Click);
            // 
            // RecentFile2
            // 
            this.RecentFile2.Name = "RecentFile2";
            this.RecentFile2.Click += new System.EventHandler(this.RecentFile2_Click);
            // 
            // RecentFile3
            // 
            this.RecentFile3.Name = "RecentFile3";
            this.RecentFile3.Click += new System.EventHandler(this.RecentFile3_Click);
            // 
            // RecentFile4
            // 
            this.RecentFile4.Name = "RecentFile4";
            this.RecentFile4.Click += new System.EventHandler(this.RecentFile4_Click);
            // 
            // RecentFile5
            // 
            this.RecentFile5.Name = "RecentFile5";
            this.RecentFile5.Click += new System.EventHandler(this.RecentFile5_Click);
            // 
            // itemContainer4
            // 
            // 
            // 
            // 
            this.itemContainer4.BackgroundStyle.Class = "RibbonFileMenuBottomContainer";
            this.itemContainer4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer4.HorizontalItemAlignment = DevComponents.DotNetBar.eHorizontalItemsAlignment.Right;
            this.itemContainer4.Name = "itemContainer4";
            this.itemContainer4.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem12,
            this.buttonItem13});
            // 
            // buttonItem12
            // 
            this.buttonItem12.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem12.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem12.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem12.Image")));
            this.buttonItem12.Name = "buttonItem12";
            this.buttonItem12.SubItemsExpandWidth = 24;
            this.buttonItem12.Text = "Opt&ions";
            // 
            // buttonItem13
            // 
            this.buttonItem13.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem13.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonItem13.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem13.Image")));
            this.buttonItem13.Name = "buttonItem13";
            this.buttonItem13.SubItemsExpandWidth = 24;
            this.buttonItem13.Text = "E&xit";
            // 
            // Home
            // 
            this.Home.Name = "Home";
            this.Home.Panel = this.ribbonPanel1;
            this.Home.Text = "Home";
            // 
            // ribbonTabItem2
            // 
            this.ribbonTabItem2.Name = "ribbonTabItem2";
            this.ribbonTabItem2.Panel = this.ribbonPanel2;
            this.ribbonTabItem2.Text = "Insert";
            // 
            // ribbonTabItem3
            // 
            this.ribbonTabItem3.Name = "ribbonTabItem3";
            this.ribbonTabItem3.Panel = this.ribbonPanel3;
            this.ribbonTabItem3.Text = "View";
            // 
            // ribbonTabItem4
            // 
            this.ribbonTabItem4.Name = "ribbonTabItem4";
            this.ribbonTabItem4.Panel = this.ribbonPanel4;
            this.ribbonTabItem4.Text = "Design Tools";
            // 
            // ribbonTabItem5
            // 
            this.ribbonTabItem5.Name = "ribbonTabItem5";
            this.ribbonTabItem5.Panel = this.ribbonPanel5;
            this.ribbonTabItem5.Text = "Convert";
            // 
            // ribbonTabItem6
            // 
            this.ribbonTabItem6.Name = "ribbonTabItem6";
            this.ribbonTabItem6.Panel = this.ribbonPanel6;
            this.ribbonTabItem6.Text = "Option";
            // 
            // ribbonTabItem1
            // 
            this.ribbonTabItem1.Checked = true;
            this.ribbonTabItem1.Name = "ribbonTabItem1";
            this.ribbonTabItem1.Panel = this.ribbonPanel7;
            this.ribbonTabItem1.Text = "Help";
            // 
            // ribbonTabItem7
            // 
            this.ribbonTabItem7.Name = "ribbonTabItem7";
            this.ribbonTabItem7.Panel = this.ribbonPanel8;
            this.ribbonTabItem7.Text = "Contact";
            // 
            // buttonItem1
            // 
            this.buttonItem1.Name = "buttonItem1";
            this.buttonItem1.Text = "Main Button";
            // 
            // qatCustomizeItem1
            // 
            this.qatCustomizeItem1.Name = "qatCustomizeItem1";
            // 
            // styleManager1
            // 
            this.styleManager1.ManagerStyle = DevComponents.DotNetBar.eStyle.Office2010Blue;
            // 
            // ribbonClientPanel1
            // 
            this.ribbonClientPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.ribbonClientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonClientPanel1.Location = new System.Drawing.Point(0, 154);
            this.ribbonClientPanel1.Name = "ribbonClientPanel1";
            this.ribbonClientPanel1.Size = new System.Drawing.Size(1117, 358);
            // 
            // 
            // 
            this.ribbonClientPanel1.Style.Class = "RibbonClientPanel";
            this.ribbonClientPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonClientPanel1.StyleMouseDown.Class = "";
            this.ribbonClientPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonClientPanel1.StyleMouseOver.Class = "";
            this.ribbonClientPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonClientPanel1.TabIndex = 1;
            this.ribbonClientPanel1.Text = "ribbonClientPanel1";
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(4, 29);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(75, 23);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem14});
            this.buttonX1.TabIndex = 0;
            this.buttonX1.Text = "buttonX1";
            // 
            // buttonItem14
            // 
            this.buttonItem14.GlobalItem = false;
            this.buttonItem14.Name = "buttonItem14";
            this.buttonItem14.Text = "buttonItem14";
            // 
            // columnHeader1
            // 
            this.columnHeader1.Name = "columnHeader1";
            this.columnHeader1.Text = "Column";
            this.columnHeader1.Width.Absolute = 150;
            // 
            // dotNetBarManager1
            // 
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.F1);
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlC);
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlA);
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlV);
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlX);
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlZ);
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlY);
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.Del);
            this.dotNetBarManager1.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.Ins);
            this.dotNetBarManager1.BottomDockSite = this.dockSite4;
            this.dotNetBarManager1.EnableFullSizeDock = false;
            this.dotNetBarManager1.FillDockSite = this.dockSite9;
            this.dotNetBarManager1.LeftDockSite = this.dockSite1;
            this.dotNetBarManager1.ParentForm = this;
            this.dotNetBarManager1.RightDockSite = this.dockSite2;
            this.dotNetBarManager1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.dotNetBarManager1.ToolbarBottomDockSite = this.dockSite8;
            this.dotNetBarManager1.ToolbarLeftDockSite = this.dockSite5;
            this.dotNetBarManager1.ToolbarRightDockSite = this.dockSite6;
            this.dotNetBarManager1.ToolbarTopDockSite = this.dockSite7;
            this.dotNetBarManager1.TopDockSite = this.dockSite3;
            // 
            // dockSite4
            // 
            this.dockSite4.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite4.Controls.Add(this.bar3);
            this.dockSite4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dockSite4.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer(new DevComponents.DotNetBar.DocumentBaseContainer[] {
            ((DevComponents.DotNetBar.DocumentBaseContainer)(new DevComponents.DotNetBar.DocumentBarContainer(this.bar3, 1117, 87)))}, DevComponents.DotNetBar.eOrientation.Vertical);
            this.dockSite4.Location = new System.Drawing.Point(0, 512);
            this.dockSite4.Name = "dockSite4";
            this.dockSite4.Size = new System.Drawing.Size(1117, 90);
            this.dockSite4.TabIndex = 5;
            this.dockSite4.TabStop = false;
            // 
            // bar3
            // 
            this.bar3.AccessibleDescription = "DotNetBar Bar (bar3)";
            this.bar3.AccessibleName = "DotNetBar Bar";
            this.bar3.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.bar3.AutoSyncBarCaption = true;
            this.bar3.CloseSingleTab = true;
            this.bar3.Controls.Add(this.panelDockContainer3);
            this.bar3.Controls.Add(this.panelDockContainer4);
            this.bar3.Controls.Add(this.panelDockContainer5);
            this.bar3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bar3.GrabHandleStyle = DevComponents.DotNetBar.eGrabHandleStyle.Caption;
            this.bar3.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.dockContainerItem3,
            this.ResultCheck,
            this.FindResult});
            this.bar3.LayoutType = DevComponents.DotNetBar.eLayoutType.DockContainer;
            this.bar3.Location = new System.Drawing.Point(0, 3);
            this.bar3.Name = "bar3";
            this.bar3.SelectedDockTab = 0;
            this.bar3.Size = new System.Drawing.Size(1117, 87);
            this.bar3.Stretch = true;
            this.bar3.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.bar3.TabIndex = 0;
            this.bar3.TabStop = false;
            this.bar3.Text = "Control";
            // 
            // panelDockContainer3
            // 
            this.panelDockContainer3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer3.Controls.Add(this.slider1);
            this.panelDockContainer3.Controls.Add(this.PageName);
            this.panelDockContainer3.Controls.Add(this.labelX5);
            this.panelDockContainer3.Controls.Add(this.NumberObj);
            this.panelDockContainer3.Controls.Add(this.labelX4);
            this.panelDockContainer3.Controls.Add(this.ToadoY);
            this.panelDockContainer3.Controls.Add(this.ToadoX);
            this.panelDockContainer3.Controls.Add(this.labelX3);
            this.panelDockContainer3.Controls.Add(this.labelX2);
            this.panelDockContainer3.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer3.Name = "panelDockContainer3";
            this.panelDockContainer3.Size = new System.Drawing.Size(1111, 36);
            this.panelDockContainer3.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer3.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer3.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer3.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer3.Style.GradientAngle = 90;
            this.superTooltip.SetSuperTooltip(this.panelDockContainer3, new DevComponents.DotNetBar.SuperTooltipInfo("Control bar", "Click Help for more details", "This bar include some qick button and status of class diagram", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.panelDockContainer3.TabIndex = 0;
            // 
            // slider1
            // 
            this.slider1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.slider1.BackgroundStyle.Class = "";
            this.slider1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.slider1.Location = new System.Drawing.Point(3, 6);
            this.slider1.Name = "slider1";
            this.slider1.Size = new System.Drawing.Size(150, 23);
            this.slider1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.superTooltip.SetSuperTooltip(this.slider1, new DevComponents.DotNetBar.SuperTooltipInfo("Zoom control", "Click Help for more details", "Click here to adjust zoom of view", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.slider1.TabIndex = 5;
            this.slider1.Text = "Zoom";
            this.slider1.Value = 50;
            this.slider1.ValueChanged += new System.EventHandler(this.Zoom_changed);
            this.slider1.ValueChanging += new DevComponents.DotNetBar.CancelIntValueEventHandler(this.Zoom_changing);
            // 
            // PageName
            // 
            this.PageName.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.PageName.BackgroundStyle.Class = "";
            this.PageName.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.PageName.Location = new System.Drawing.Point(769, 5);
            this.PageName.Name = "PageName";
            this.PageName.Size = new System.Drawing.Size(72, 23);
            this.superTooltip.SetSuperTooltip(this.PageName, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Number of pages", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.PageName.TabIndex = 13;
            this.PageName.Text = "Page 1";
            // 
            // labelX5
            // 
            this.labelX5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Location = new System.Drawing.Point(719, 4);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(44, 23);
            this.labelX5.TabIndex = 12;
            this.labelX5.Text = "Page :";
            // 
            // NumberObj
            // 
            this.NumberObj.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.NumberObj.BackgroundStyle.Class = "";
            this.NumberObj.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.NumberObj.Location = new System.Drawing.Point(949, 7);
            this.NumberObj.Name = "NumberObj";
            this.NumberObj.Size = new System.Drawing.Size(22, 23);
            this.superTooltip.SetSuperTooltip(this.NumberObj, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Number of objects", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.NumberObj.TabIndex = 11;
            this.NumberObj.Text = "0";
            // 
            // labelX4
            // 
            this.labelX4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Location = new System.Drawing.Point(847, 6);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(96, 23);
            this.labelX4.TabIndex = 10;
            this.labelX4.Text = "Number of objects :";
            // 
            // ToadoY
            // 
            this.ToadoY.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.ToadoY.BackgroundStyle.Class = "";
            this.ToadoY.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ToadoY.Location = new System.Drawing.Point(1066, 6);
            this.ToadoY.Name = "ToadoY";
            this.ToadoY.Size = new System.Drawing.Size(42, 23);
            this.superTooltip.SetSuperTooltip(this.ToadoY, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Y coordinates", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.ToadoY.TabIndex = 9;
            // 
            // ToadoX
            // 
            this.ToadoX.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.ToadoX.BackgroundStyle.Class = "";
            this.ToadoX.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ToadoX.Location = new System.Drawing.Point(1000, 6);
            this.ToadoX.Name = "ToadoX";
            this.ToadoX.Size = new System.Drawing.Size(38, 23);
            this.superTooltip.SetSuperTooltip(this.ToadoX, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "X coordinates", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.ToadoX.TabIndex = 8;
            // 
            // labelX3
            // 
            this.labelX3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Location = new System.Drawing.Point(1044, 7);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(16, 23);
            this.labelX3.TabIndex = 7;
            this.labelX3.Text = "Y=";
            // 
            // labelX2
            // 
            this.labelX2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Location = new System.Drawing.Point(977, 7);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(17, 23);
            this.labelX2.TabIndex = 6;
            this.labelX2.Text = "X=";
            // 
            // panelDockContainer4
            // 
            this.panelDockContainer4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer4.Controls.Add(this.CheckResult);
            this.panelDockContainer4.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer4.Name = "panelDockContainer4";
            this.panelDockContainer4.Size = new System.Drawing.Size(1111, 36);
            this.panelDockContainer4.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer4.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer4.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer4.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer4.Style.GradientAngle = 90;
            this.panelDockContainer4.TabIndex = 4;
            // 
            // CheckResult
            // 
            this.CheckResult.BackColor = System.Drawing.SystemColors.Window;
            this.CheckResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CheckResult.Location = new System.Drawing.Point(0, 0);
            this.CheckResult.Name = "CheckResult";
            this.CheckResult.ReadOnly = true;
            this.CheckResult.Size = new System.Drawing.Size(1111, 36);
            this.superTooltip.SetSuperTooltip(this.CheckResult, new DevComponents.DotNetBar.SuperTooltipInfo("Check diagram result", "Click Help for more details", "This region show result of checking class diagram", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.CheckResult.TabIndex = 0;
            this.CheckResult.Text = "";
            // 
            // panelDockContainer5
            // 
            this.panelDockContainer5.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer5.Controls.Add(this.FindRichTextBox);
            this.panelDockContainer5.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer5.Name = "panelDockContainer5";
            this.panelDockContainer5.Size = new System.Drawing.Size(1111, 36);
            this.panelDockContainer5.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer5.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer5.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer5.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer5.Style.GradientAngle = 90;
            this.panelDockContainer5.TabIndex = 6;
            // 
            // FindRichTextBox
            // 
            this.FindRichTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.FindRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FindRichTextBox.Location = new System.Drawing.Point(0, 0);
            this.FindRichTextBox.Name = "FindRichTextBox";
            this.FindRichTextBox.ReadOnly = true;
            this.FindRichTextBox.Size = new System.Drawing.Size(1111, 36);
            this.superTooltip.SetSuperTooltip(this.FindRichTextBox, new DevComponents.DotNetBar.SuperTooltipInfo("Find result", "Click Help for more details", "This region shows result of finding element of class diagram", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.FindRichTextBox.TabIndex = 0;
            this.FindRichTextBox.Text = "";
            // 
            // dockContainerItem3
            // 
            this.dockContainerItem3.Control = this.panelDockContainer3;
            this.dockContainerItem3.Name = "dockContainerItem3";
            this.dockContainerItem3.Text = "Control";
            // 
            // ResultCheck
            // 
            this.ResultCheck.Control = this.panelDockContainer4;
            this.ResultCheck.Name = "ResultCheck";
            this.ResultCheck.Text = "Check Diagram";
            // 
            // FindResult
            // 
            this.FindResult.Control = this.panelDockContainer5;
            this.FindResult.Name = "FindResult";
            this.FindResult.Text = "Find result";
            // 
            // dockSite9
            // 
            this.dockSite9.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite9.Controls.Add(this.CenterBar);
            this.dockSite9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockSite9.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer(new DevComponents.DotNetBar.DocumentBaseContainer[] {
            ((DevComponents.DotNetBar.DocumentBaseContainer)(new DevComponents.DotNetBar.DocumentBarContainer(this.CenterBar, 646, 358)))}, DevComponents.DotNetBar.eOrientation.Horizontal);
            this.dockSite9.Location = new System.Drawing.Point(207, 154);
            this.dockSite9.Name = "dockSite9";
            this.dockSite9.Size = new System.Drawing.Size(646, 358);
            this.dockSite9.TabIndex = 10;
            this.dockSite9.TabStop = false;
            // 
            // CenterBar
            // 
            this.CenterBar.AccessibleDescription = "DotNetBar Bar (CenterBar)";
            this.CenterBar.AccessibleName = "DotNetBar Bar";
            this.CenterBar.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.CenterBar.AlwaysDisplayDockTab = true;
            this.CenterBar.CanCustomize = false;
            this.CenterBar.CanDockBottom = false;
            this.CenterBar.CanDockDocument = true;
            this.CenterBar.CanDockLeft = false;
            this.CenterBar.CanDockRight = false;
            this.CenterBar.CanDockTop = false;
            this.CenterBar.CanHide = true;
            this.CenterBar.Controls.Add(this.MainRegion);
            this.CenterBar.DockTabAlignment = DevComponents.DotNetBar.eTabStripAlignment.Top;
            this.CenterBar.DockTabCloseButtonVisible = true;
            this.CenterBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CenterBar.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Page1});
            this.CenterBar.LayoutType = DevComponents.DotNetBar.eLayoutType.DockContainer;
            this.CenterBar.Location = new System.Drawing.Point(0, 0);
            this.CenterBar.Name = "CenterBar";
            this.CenterBar.SelectedDockTab = 0;
            this.CenterBar.Size = new System.Drawing.Size(646, 358);
            this.CenterBar.Stretch = true;
            this.CenterBar.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.CenterBar.TabIndex = 0;
            this.CenterBar.TabNavigation = true;
            this.CenterBar.TabStop = false;
            this.CenterBar.DockTabChange += new DevComponents.DotNetBar.DotNetBarManager.DockTabChangeEventHandler(this.DockTab_Chage);
            this.CenterBar.DockTabClosing += new DevComponents.DotNetBar.DockTabClosingEventHandler(this.DockTab_Closing);
            this.CenterBar.DockTabClosed += new DevComponents.DotNetBar.DockTabClosingEventHandler(this.DockTab_Closed);
            // 
            // MainRegion
            // 
            this.MainRegion.AutoScroll = true;
            this.MainRegion.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.MainRegion.Location = new System.Drawing.Point(3, 28);
            this.MainRegion.Name = "MainRegion";
            this.MainRegion.Size = new System.Drawing.Size(640, 327);
            this.MainRegion.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.MainRegion.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.MainRegion.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.MainRegion.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.MainRegion.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.MainRegion.Style.GradientAngle = 90;
            this.MainRegion.TabIndex = 0;
            // 
            // Page1
            // 
            this.Page1.Control = this.MainRegion;
            this.Page1.Name = "Page1";
            this.Page1.Text = "Page 1";
            // 
            // dockSite1
            // 
            this.dockSite1.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite1.Controls.Add(this.bar1);
            this.dockSite1.Dock = System.Windows.Forms.DockStyle.Left;
            this.dockSite1.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer(new DevComponents.DotNetBar.DocumentBaseContainer[] {
            ((DevComponents.DotNetBar.DocumentBaseContainer)(new DevComponents.DotNetBar.DocumentBarContainer(this.bar1, 204, 358)))}, DevComponents.DotNetBar.eOrientation.Horizontal);
            this.dockSite1.Location = new System.Drawing.Point(0, 154);
            this.dockSite1.Name = "dockSite1";
            this.dockSite1.Size = new System.Drawing.Size(207, 358);
            this.dockSite1.TabIndex = 2;
            this.dockSite1.TabStop = false;
            // 
            // bar1
            // 
            this.bar1.AccessibleDescription = "DotNetBar Bar (bar1)";
            this.bar1.AccessibleName = "DotNetBar Bar";
            this.bar1.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.bar1.AutoSyncBarCaption = true;
            this.bar1.CloseSingleTab = true;
            this.bar1.Controls.Add(this.panelDockContainer7);
            this.bar1.Controls.Add(this.panelDockContainer1);
            this.bar1.Controls.Add(this.panelDockContainer2);
            this.bar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bar1.GrabHandleStyle = DevComponents.DotNetBar.eGrabHandleStyle.Caption;
            this.bar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.dockContainerItem1,
            this.dockContainerItem4,
            this.Options});
            this.bar1.LayoutType = DevComponents.DotNetBar.eLayoutType.DockContainer;
            this.bar1.Location = new System.Drawing.Point(0, 0);
            this.bar1.Name = "bar1";
            this.bar1.SelectedDockTab = 2;
            this.bar1.Size = new System.Drawing.Size(204, 358);
            this.bar1.Stretch = true;
            this.bar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.bar1.TabIndex = 0;
            this.bar1.TabStop = false;
            this.bar1.Text = "Options";
            // 
            // panelDockContainer7
            // 
            this.panelDockContainer7.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer7.Controls.Add(this.ribbonClientPanel2);
            this.panelDockContainer7.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer7.Name = "panelDockContainer7";
            this.panelDockContainer7.Size = new System.Drawing.Size(198, 307);
            this.panelDockContainer7.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer7.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer7.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer7.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer7.Style.GradientAngle = 90;
            this.panelDockContainer7.TabIndex = 6;
            // 
            // ribbonClientPanel2
            // 
            this.ribbonClientPanel2.CanvasColor = System.Drawing.SystemColors.Control;
            this.ribbonClientPanel2.Controls.Add(this.final);
            this.ribbonClientPanel2.Controls.Add(this.primarykey);
            this.ribbonClientPanel2.Controls.Add(this.CompositeName);
            this.ribbonClientPanel2.Controls.Add(this.DerivedColumn);
            this.ribbonClientPanel2.Controls.Add(this.MultiValues);
            this.ribbonClientPanel2.Controls.Add(this.Multivalue);
            this.ribbonClientPanel2.Controls.Add(this.Composite);
            this.ribbonClientPanel2.Controls.Add(this.Derived);
            this.ribbonClientPanel2.Controls.Add(this.labelX6);
            this.ribbonClientPanel2.Controls.Add(this.OperTabStrip);
            this.ribbonClientPanel2.Controls.Add(this.labelX1);
            this.ribbonClientPanel2.Controls.Add(this.superTabStrip);
            this.ribbonClientPanel2.Controls.Add(this.DatatypeTabStrip);
            this.ribbonClientPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonClientPanel2.Location = new System.Drawing.Point(0, 0);
            this.ribbonClientPanel2.Name = "ribbonClientPanel2";
            this.ribbonClientPanel2.Size = new System.Drawing.Size(198, 307);
            // 
            // 
            // 
            this.ribbonClientPanel2.Style.Class = "RibbonClientPanel";
            this.ribbonClientPanel2.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonClientPanel2.StyleMouseDown.Class = "";
            this.ribbonClientPanel2.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonClientPanel2.StyleMouseOver.Class = "";
            this.ribbonClientPanel2.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonClientPanel2.TabIndex = 0;
            this.ribbonClientPanel2.Text = "ribbonClientPanel2";
            // 
            // final
            // 
            // 
            // 
            // 
            this.final.BackgroundStyle.Class = "";
            this.final.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.final.Location = new System.Drawing.Point(96, 220);
            this.final.Name = "final";
            this.final.Size = new System.Drawing.Size(48, 23);
            this.final.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.final.TabIndex = 24;
            this.final.Text = "Final";
            // 
            // primarykey
            // 
            // 
            // 
            // 
            this.primarykey.BackgroundStyle.Class = "";
            this.primarykey.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.primarykey.Location = new System.Drawing.Point(10, 220);
            this.primarykey.Name = "primarykey";
            this.primarykey.Size = new System.Drawing.Size(39, 23);
            this.primarykey.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.primarykey.TabIndex = 23;
            this.primarykey.Text = "PK";
            // 
            // CompositeName
            // 
            this.CompositeName.FormattingEnabled = true;
            this.CompositeName.Location = new System.Drawing.Point(96, 143);
            this.CompositeName.Name = "CompositeName";
            this.CompositeName.Size = new System.Drawing.Size(89, 21);
            this.CompositeName.TabIndex = 22;
            // 
            // DerivedColumn
            // 
            // 
            // 
            // 
            this.DerivedColumn.Border.Class = "TextBoxBorder";
            this.DerivedColumn.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.DerivedColumn.Location = new System.Drawing.Point(96, 104);
            this.DerivedColumn.Name = "DerivedColumn";
            this.DerivedColumn.Size = new System.Drawing.Size(89, 20);
            this.DerivedColumn.TabIndex = 21;
            // 
            // MultiValues
            // 
            // 
            // 
            // 
            this.MultiValues.Border.Class = "TextBoxBorder";
            this.MultiValues.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.MultiValues.Location = new System.Drawing.Point(95, 183);
            this.MultiValues.Name = "MultiValues";
            this.MultiValues.Size = new System.Drawing.Size(90, 20);
            this.MultiValues.TabIndex = 19;
            // 
            // Multivalue
            // 
            // 
            // 
            // 
            this.Multivalue.BackgroundStyle.Class = "";
            this.Multivalue.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Multivalue.Location = new System.Drawing.Point(10, 183);
            this.Multivalue.Name = "Multivalue";
            this.Multivalue.Size = new System.Drawing.Size(79, 20);
            this.Multivalue.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Multivalue.TabIndex = 18;
            this.Multivalue.Text = "Multivalued";
            this.Multivalue.CheckedChanged += new System.EventHandler(this.Multivaluedcheck);
            // 
            // Composite
            // 
            // 
            // 
            // 
            this.Composite.BackgroundStyle.Class = "";
            this.Composite.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Composite.Location = new System.Drawing.Point(10, 143);
            this.Composite.Name = "Composite";
            this.Composite.Size = new System.Drawing.Size(79, 20);
            this.Composite.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Composite.TabIndex = 17;
            this.Composite.Text = "Composite";
            this.Composite.CheckedChanged += new System.EventHandler(this.CompositedCheck);
            // 
            // Derived
            // 
            // 
            // 
            // 
            this.Derived.BackgroundStyle.Class = "";
            this.Derived.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Derived.Location = new System.Drawing.Point(9, 104);
            this.Derived.Name = "Derived";
            this.Derived.Size = new System.Drawing.Size(80, 19);
            this.Derived.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Derived.TabIndex = 16;
            this.Derived.Text = "Derived";
            this.Derived.CheckedChanged += new System.EventHandler(this.DerivedCheck);
            // 
            // labelX6
            // 
            this.labelX6.BackColor = System.Drawing.Color.LightSteelBlue;
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Location = new System.Drawing.Point(9, 54);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(77, 23);
            this.labelX6.TabIndex = 15;
            this.labelX6.Text = "Op Type :";
            // 
            // OperTabStrip
            // 
            this.OperTabStrip.AutoSelectAttachedControl = false;
            // 
            // 
            // 
            this.OperTabStrip.BackgroundStyle.Class = "";
            this.OperTabStrip.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.OperTabStrip.ContainerControlProcessDialogKey = true;
            // 
            // 
            // 
            // 
            // 
            // 
            this.OperTabStrip.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.OperTabStrip.ControlBox.MenuBox.Name = "";
            this.OperTabStrip.ControlBox.Name = "";
            this.OperTabStrip.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.OperTabStrip.ControlBox.MenuBox,
            this.OperTabStrip.ControlBox.CloseBox});
            this.OperTabStrip.Location = new System.Drawing.Point(96, 54);
            this.OperTabStrip.Name = "OperTabStrip";
            this.OperTabStrip.ReorderTabsEnabled = true;
            this.OperTabStrip.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.OperTabStrip.SelectedTabIndex = -1;
            this.OperTabStrip.Size = new System.Drawing.Size(89, 24);
            this.OperTabStrip.TabCloseButtonHot = null;
            this.OperTabStrip.TabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OperTabStrip.TabIndex = 2;
            this.OperTabStrip.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.List_Oper});
            this.OperTabStrip.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.OneNote2007;
            this.OperTabStrip.Text = "OperTabStrip";
            // 
            // List_Oper
            // 
            this.List_Oper.ComboWidth = 90;
            this.List_Oper.DropDownHeight = 106;
            this.List_Oper.ItemHeight = 14;
            this.List_Oper.Name = "List_Oper";
            // 
            // labelX1
            // 
            this.labelX1.BackColor = System.Drawing.Color.LightSteelBlue;
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX1.Location = new System.Drawing.Point(9, 13);
            this.labelX1.Name = "labelX1";
            this.labelX1.SingleLineColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelX1.Size = new System.Drawing.Size(77, 23);
            this.labelX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.labelX1.TabIndex = 14;
            this.labelX1.Text = "Data Type :";
            // 
            // superTabStrip
            // 
            this.superTabStrip.AllowDrop = true;
            this.superTabStrip.AutoSelectAttachedControl = false;
            this.superTabStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            // 
            // 
            // 
            this.superTabStrip.BackgroundStyle.Class = "";
            this.superTabStrip.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.superTabStrip.ContainerControlProcessDialogKey = true;
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabStrip.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabStrip.ControlBox.MenuBox.Name = "";
            this.superTabStrip.ControlBox.Name = "";
            this.superTabStrip.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabStrip.ControlBox.MenuBox,
            this.superTabStrip.ControlBox.CloseBox});
            this.superTabStrip.Location = new System.Drawing.Point(10, 257);
            this.superTabStrip.Name = "superTabStrip";
            this.superTabStrip.ReorderTabsEnabled = true;
            this.superTabStrip.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.superTabStrip.SelectedTabIndex = -1;
            this.superTabStrip.Size = new System.Drawing.Size(175, 24);
            this.superTabStrip.TabCloseButtonHot = null;
            this.superTabStrip.TabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.superTabStrip.TabIndex = 0;
            this.superTabStrip.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.Add_strip,
            this.Remove_strip,
            this.Up_strip,
            this.Down_strip});
            this.superTabStrip.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.OneNote2007;
            this.superTabStrip.Text = "superTabStrip1";
            // 
            // Add_strip
            // 
            this.Add_strip.Name = "Add_strip";
            this.Add_strip.Text = "Add";
            this.Add_strip.Click += new System.EventHandler(this.Add_strip_Click);
            // 
            // Remove_strip
            // 
            this.Remove_strip.Name = "Remove_strip";
            this.Remove_strip.Text = "Remove";
            this.Remove_strip.Click += new System.EventHandler(this.Remove_strip_Click);
            // 
            // Up_strip
            // 
            this.Up_strip.Name = "Up_strip";
            this.Up_strip.Text = "Up";
            this.Up_strip.Click += new System.EventHandler(this.Up_strip_Click);
            // 
            // Down_strip
            // 
            this.Down_strip.Name = "Down_strip";
            this.Down_strip.Text = "Down";
            this.Down_strip.Click += new System.EventHandler(this.Down_strip_Click);
            // 
            // DatatypeTabStrip
            // 
            this.DatatypeTabStrip.AutoSelectAttachedControl = false;
            // 
            // 
            // 
            this.DatatypeTabStrip.BackgroundStyle.Class = "";
            this.DatatypeTabStrip.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.DatatypeTabStrip.ContainerControlProcessDialogKey = true;
            // 
            // 
            // 
            // 
            // 
            // 
            this.DatatypeTabStrip.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.DatatypeTabStrip.ControlBox.MenuBox.Name = "";
            this.DatatypeTabStrip.ControlBox.Name = "";
            this.DatatypeTabStrip.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.DatatypeTabStrip.ControlBox.MenuBox,
            this.DatatypeTabStrip.ControlBox.CloseBox});
            this.DatatypeTabStrip.Location = new System.Drawing.Point(96, 12);
            this.DatatypeTabStrip.Name = "DatatypeTabStrip";
            this.DatatypeTabStrip.ReorderTabsEnabled = true;
            this.DatatypeTabStrip.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.DatatypeTabStrip.SelectedTabIndex = -1;
            this.DatatypeTabStrip.Size = new System.Drawing.Size(89, 24);
            this.DatatypeTabStrip.TabCloseButtonHot = null;
            this.DatatypeTabStrip.TabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DatatypeTabStrip.TabIndex = 1;
            this.DatatypeTabStrip.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.List_datatype});
            this.DatatypeTabStrip.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.OneNote2007;
            this.DatatypeTabStrip.Text = "DatatypeTabStrip";
            // 
            // List_datatype
            // 
            this.List_datatype.ComboWidth = 90;
            this.List_datatype.DropDownHeight = 106;
            this.List_datatype.ItemHeight = 14;
            this.List_datatype.Name = "List_datatype";
            // 
            // panelDockContainer1
            // 
            this.panelDockContainer1.AutoScroll = true;
            this.panelDockContainer1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer1.Controls.Add(this.example4);
            this.panelDockContainer1.Controls.Add(this.example3);
            this.panelDockContainer1.Controls.Add(this.example2);
            this.panelDockContainer1.Controls.Add(this.example1);
            this.panelDockContainer1.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer1.Name = "panelDockContainer1";
            this.panelDockContainer1.Size = new System.Drawing.Size(198, 307);
            this.panelDockContainer1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panelDockContainer1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer1.Style.GradientAngle = 90;
            this.superTooltip.SetSuperTooltip(this.panelDockContainer1, new DevComponents.DotNetBar.SuperTooltipInfo("Design ", "Click Help for more details", "This region show some qick tools of class diagram", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.panelDockContainer1.TabIndex = 0;
            // 
            // example4
            // 
            this.example4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.example4.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.example4.Image = global::DesignDatabaseTools.Properties.Resources.c4;
            this.example4.Location = new System.Drawing.Point(25, 475);
            this.example4.Name = "example4";
            this.example4.Size = new System.Drawing.Size(118, 101);
            this.example4.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.example4.TabIndex = 3;
            this.example4.Click += new System.EventHandler(this.example4_Click);
            // 
            // example3
            // 
            this.example3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.example3.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.example3.Image = global::DesignDatabaseTools.Properties.Resources.c3;
            this.example3.Location = new System.Drawing.Point(25, 325);
            this.example3.Name = "example3";
            this.example3.Size = new System.Drawing.Size(118, 101);
            this.example3.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.example3.TabIndex = 2;
            this.example3.Click += new System.EventHandler(this.example3_Click);
            // 
            // example2
            // 
            this.example2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.example2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.example2.Image = global::DesignDatabaseTools.Properties.Resources.c22;
            this.example2.Location = new System.Drawing.Point(25, 180);
            this.example2.Name = "example2";
            this.example2.Size = new System.Drawing.Size(118, 101);
            this.example2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.example2.TabIndex = 1;
            this.example2.Click += new System.EventHandler(this.example2_Click);
            // 
            // example1
            // 
            this.example1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.example1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.example1.Image = global::DesignDatabaseTools.Properties.Resources.c1;
            this.example1.Location = new System.Drawing.Point(22, 42);
            this.example1.Name = "example1";
            this.example1.Size = new System.Drawing.Size(121, 101);
            this.example1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.example1.TabIndex = 0;
            this.example1.Click += new System.EventHandler(this.example1_Click);
            // 
            // panelDockContainer2
            // 
            this.panelDockContainer2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer2.Controls.Add(this.treeView);
            this.panelDockContainer2.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer2.Name = "panelDockContainer2";
            this.panelDockContainer2.Size = new System.Drawing.Size(198, 307);
            this.panelDockContainer2.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer2.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer2.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer2.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer2.Style.GradientAngle = 90;
            this.panelDockContainer2.TabIndex = 4;
            // 
            // treeView
            // 
            this.treeView.BackColor = System.Drawing.Color.Azure;
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(198, 307);
            this.superTooltip.SetSuperTooltip(this.treeView, new DevComponents.DotNetBar.SuperTooltipInfo("Tree View", "Click Help for more details", "This region will show the tree view of class diagram", null, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.treeView.TabIndex = 0;
            // 
            // dockContainerItem1
            // 
            this.dockContainerItem1.Control = this.panelDockContainer1;
            this.dockContainerItem1.Name = "dockContainerItem1";
            this.dockContainerItem1.Text = "Example";
            // 
            // dockContainerItem4
            // 
            this.dockContainerItem4.Control = this.panelDockContainer2;
            this.dockContainerItem4.Name = "dockContainerItem4";
            this.dockContainerItem4.Text = "Tree View";
            // 
            // Options
            // 
            this.Options.Control = this.panelDockContainer7;
            this.Options.Name = "Options";
            this.Options.Text = "Options";
            // 
            // dockSite2
            // 
            this.dockSite2.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite2.Controls.Add(this.bar2);
            this.dockSite2.Dock = System.Windows.Forms.DockStyle.Right;
            this.dockSite2.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer(new DevComponents.DotNetBar.DocumentBaseContainer[] {
            ((DevComponents.DotNetBar.DocumentBaseContainer)(new DevComponents.DotNetBar.DocumentBarContainer(this.bar2, 261, 358)))}, DevComponents.DotNetBar.eOrientation.Horizontal);
            this.dockSite2.Location = new System.Drawing.Point(853, 154);
            this.dockSite2.Name = "dockSite2";
            this.dockSite2.Size = new System.Drawing.Size(264, 358);
            this.dockSite2.TabIndex = 3;
            this.dockSite2.TabStop = false;
            // 
            // bar2
            // 
            this.bar2.AccessibleDescription = "DotNetBar Bar (bar2)";
            this.bar2.AccessibleName = "DotNetBar Bar";
            this.bar2.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.bar2.AutoSyncBarCaption = true;
            this.bar2.CloseSingleTab = true;
            this.bar2.Controls.Add(this.panelDockContainer6);
            this.bar2.Controls.Add(this.RightDock);
            this.bar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bar2.GrabHandleStyle = DevComponents.DotNetBar.eGrabHandleStyle.Caption;
            this.bar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.dockContainerItem2,
            this.Appearance});
            this.bar2.LayoutType = DevComponents.DotNetBar.eLayoutType.DockContainer;
            this.bar2.Location = new System.Drawing.Point(3, 0);
            this.bar2.Name = "bar2";
            this.bar2.SelectedDockTab = 1;
            this.bar2.Size = new System.Drawing.Size(261, 358);
            this.bar2.Stretch = true;
            this.bar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.bar2.TabIndex = 0;
            this.bar2.TabStop = false;
            this.bar2.Text = "Appearance";
            // 
            // panelDockContainer6
            // 
            this.panelDockContainer6.AutoScroll = true;
            this.panelDockContainer6.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.panelDockContainer6.Controls.Add(this.explorerBar2);
            this.panelDockContainer6.Controls.Add(this.EntryID2);
            this.panelDockContainer6.Location = new System.Drawing.Point(3, 23);
            this.panelDockContainer6.Name = "panelDockContainer6";
            this.panelDockContainer6.Size = new System.Drawing.Size(255, 307);
            this.panelDockContainer6.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelDockContainer6.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.panelDockContainer6.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panelDockContainer6.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.panelDockContainer6.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.panelDockContainer6.Style.GradientAngle = 90;
            this.panelDockContainer6.TabIndex = 2;
            // 
            // explorerBar2
            // 
            this.explorerBar2.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.explorerBar2.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.explorerBar2.BackStyle.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.ExplorerBarBackground2;
            this.explorerBar2.BackStyle.BackColorGradientAngle = 90;
            this.explorerBar2.BackStyle.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ExplorerBarBackground;
            this.explorerBar2.BackStyle.Class = "";
            this.explorerBar2.BackStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBar2.Cursor = System.Windows.Forms.Cursors.Default;
            this.explorerBar2.GroupImages = null;
            this.explorerBar2.Groups.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.explorerBarGroupItem2,
            this.explorerBarGroupItem3});
            this.explorerBar2.Images = null;
            this.explorerBar2.Location = new System.Drawing.Point(4, 33);
            this.explorerBar2.Name = "explorerBar2";
            this.explorerBar2.Size = new System.Drawing.Size(231, 380);
            this.explorerBar2.StockStyle = DevComponents.DotNetBar.eExplorerBarStockStyle.SystemColors;
            this.explorerBar2.TabIndex = 1;
            this.explorerBar2.Text = "explorerBar2";
            this.explorerBar2.ThemeAware = true;
            // 
            // explorerBarGroupItem2
            // 
            // 
            // 
            // 
            this.explorerBarGroupItem2.BackStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(223)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem2.BackStyle.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem2.BackStyle.BorderBottomWidth = 1;
            this.explorerBarGroupItem2.BackStyle.BorderColor = System.Drawing.Color.White;
            this.explorerBarGroupItem2.BackStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem2.BackStyle.BorderLeftWidth = 1;
            this.explorerBarGroupItem2.BackStyle.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem2.BackStyle.BorderRightWidth = 1;
            this.explorerBarGroupItem2.BackStyle.Class = "";
            this.explorerBarGroupItem2.BackStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem2.Cursor = System.Windows.Forms.Cursors.Default;
            this.explorerBarGroupItem2.Expanded = true;
            this.explorerBarGroupItem2.Name = "explorerBarGroupItem2";
            this.explorerBarGroupItem2.StockStyle = DevComponents.DotNetBar.eExplorerBarStockStyle.SystemColors;
            this.explorerBarGroupItem2.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer64});
            this.explorerBarGroupItem2.Text = "Style";
            // 
            // 
            // 
            this.explorerBarGroupItem2.TitleHotStyle.BackColor = System.Drawing.Color.White;
            this.explorerBarGroupItem2.TitleHotStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem2.TitleHotStyle.Class = "";
            this.explorerBarGroupItem2.TitleHotStyle.CornerDiameter = 3;
            this.explorerBarGroupItem2.TitleHotStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem2.TitleHotStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem2.TitleHotStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem2.TitleHotStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.explorerBarGroupItem2.TitleStyle.BackColor = System.Drawing.Color.White;
            this.explorerBarGroupItem2.TitleStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem2.TitleStyle.Class = "";
            this.explorerBarGroupItem2.TitleStyle.CornerDiameter = 3;
            this.explorerBarGroupItem2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem2.TitleStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem2.TitleStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem2.TitleStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            // 
            // itemContainer64
            // 
            // 
            // 
            // 
            this.itemContainer64.BackgroundStyle.Class = "";
            this.itemContainer64.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer64.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer64.Name = "itemContainer64";
            this.itemContainer64.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer68,
            this.itemContainer72});
            this.itemContainer64.ThemeAware = true;
            // 
            // itemContainer68
            // 
            // 
            // 
            // 
            this.itemContainer68.BackgroundStyle.Class = "";
            this.itemContainer68.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer68.Name = "itemContainer68";
            this.itemContainer68.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem15,
            this.RightFillColor});
            this.itemContainer68.ThemeAware = true;
            // 
            // labelItem15
            // 
            this.labelItem15.Name = "labelItem15";
            this.labelItem15.Text = "BackColor         ";
            this.labelItem15.ThemeAware = true;
            // 
            // RightFillColor
            // 
            this.RightFillColor.Name = "RightFillColor";
            this.superTooltip.SetSuperTooltip(this.RightFillColor, new DevComponents.DotNetBar.SuperTooltipInfo("Element Color", "Click Help for more details", "Click here to choose color for selected elements", global::DesignDatabaseTools.Properties.Resources.gtk_color_picker, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.RightFillColor.Text = "Click";
            this.RightFillColor.ThemeAware = true;
            this.RightFillColor.SelectedColorChanged += new System.EventHandler(this.RightFillColorChanged);
            // 
            // itemContainer72
            // 
            // 
            // 
            // 
            this.itemContainer72.BackgroundStyle.Class = "";
            this.itemContainer72.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer72.Name = "itemContainer72";
            this.itemContainer72.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem16,
            this.RightLineColor});
            this.itemContainer72.ThemeAware = true;
            // 
            // labelItem16
            // 
            this.labelItem16.Name = "labelItem16";
            this.labelItem16.Text = "Border                ";
            this.labelItem16.ThemeAware = true;
            // 
            // RightLineColor
            // 
            this.RightLineColor.Name = "RightLineColor";
            this.superTooltip.SetSuperTooltip(this.RightLineColor, new DevComponents.DotNetBar.SuperTooltipInfo("Border color", "Click Help for more details", "Click here to choose color for border of selected elements", global::DesignDatabaseTools.Properties.Resources.color_linettt, global::DesignDatabaseTools.Properties.Resources.gnome_dialog_question, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.RightLineColor.Text = "Click";
            this.RightLineColor.ThemeAware = true;
            this.RightLineColor.SelectedColorChanged += new System.EventHandler(this.RightLineColorChanged);
            // 
            // explorerBarGroupItem3
            // 
            // 
            // 
            // 
            this.explorerBarGroupItem3.BackStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(223)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem3.BackStyle.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem3.BackStyle.BorderBottomWidth = 1;
            this.explorerBarGroupItem3.BackStyle.BorderColor = System.Drawing.Color.White;
            this.explorerBarGroupItem3.BackStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem3.BackStyle.BorderLeftWidth = 1;
            this.explorerBarGroupItem3.BackStyle.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem3.BackStyle.BorderRightWidth = 1;
            this.explorerBarGroupItem3.BackStyle.Class = "";
            this.explorerBarGroupItem3.BackStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem3.Cursor = System.Windows.Forms.Cursors.Default;
            this.explorerBarGroupItem3.Expanded = true;
            this.explorerBarGroupItem3.Name = "explorerBarGroupItem3";
            this.explorerBarGroupItem3.StockStyle = DevComponents.DotNetBar.eExplorerBarStockStyle.SystemColors;
            this.explorerBarGroupItem3.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer73,
            this.itemContainer75,
            this.itemContainer76});
            this.explorerBarGroupItem3.Text = "Layout";
            // 
            // 
            // 
            this.explorerBarGroupItem3.TitleHotStyle.BackColor = System.Drawing.Color.White;
            this.explorerBarGroupItem3.TitleHotStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem3.TitleHotStyle.Class = "";
            this.explorerBarGroupItem3.TitleHotStyle.CornerDiameter = 3;
            this.explorerBarGroupItem3.TitleHotStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem3.TitleHotStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem3.TitleHotStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem3.TitleHotStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.explorerBarGroupItem3.TitleStyle.BackColor = System.Drawing.Color.White;
            this.explorerBarGroupItem3.TitleStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem3.TitleStyle.Class = "";
            this.explorerBarGroupItem3.TitleStyle.CornerDiameter = 3;
            this.explorerBarGroupItem3.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem3.TitleStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem3.TitleStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem3.TitleStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            // 
            // itemContainer73
            // 
            // 
            // 
            // 
            this.itemContainer73.BackgroundStyle.Class = "";
            this.itemContainer73.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer73.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer73.Name = "itemContainer73";
            this.itemContainer73.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer74});
            this.itemContainer73.ThemeAware = true;
            // 
            // itemContainer74
            // 
            // 
            // 
            // 
            this.itemContainer74.BackgroundStyle.Class = "";
            this.itemContainer74.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer74.Name = "itemContainer74";
            this.itemContainer74.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem17,
            this.HideCheck});
            this.itemContainer74.ThemeAware = true;
            // 
            // labelItem17
            // 
            this.labelItem17.Name = "labelItem17";
            this.labelItem17.Text = "Hide                   ";
            this.labelItem17.ThemeAware = true;
            // 
            // HideCheck
            // 
            this.HideCheck.Name = "HideCheck";
            this.superTooltip.SetSuperTooltip(this.HideCheck, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Show or hide selected elements", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.HideCheck.ThemeAware = true;
            this.HideCheck.Click += new System.EventHandler(this.Hide_Click);
            // 
            // itemContainer75
            // 
            // 
            // 
            // 
            this.itemContainer75.BackgroundStyle.Class = "";
            this.itemContainer75.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer75.Name = "itemContainer75";
            this.itemContainer75.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem18,
            this.PositionX,
            this.PositionY});
            this.itemContainer75.ThemeAware = true;
            // 
            // labelItem18
            // 
            this.labelItem18.Name = "labelItem18";
            this.labelItem18.Text = "Position ";
            this.labelItem18.ThemeAware = true;
            // 
            // PositionX
            // 
            this.PositionX.Name = "PositionX";
            this.superTooltip.SetSuperTooltip(this.PositionX, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "X coordinates", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.PositionX.ThemeAware = true;
            this.PositionX.WatermarkColor = System.Drawing.SystemColors.GrayText;
            // 
            // PositionY
            // 
            this.PositionY.Name = "PositionY";
            this.superTooltip.SetSuperTooltip(this.PositionY, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Y coordinates", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.PositionY.ThemeAware = true;
            this.PositionY.WatermarkColor = System.Drawing.SystemColors.GrayText;
            // 
            // itemContainer76
            // 
            // 
            // 
            // 
            this.itemContainer76.BackgroundStyle.Class = "";
            this.itemContainer76.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer76.Name = "itemContainer76";
            this.itemContainer76.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem19,
            this.width,
            this.height});
            this.itemContainer76.ThemeAware = true;
            // 
            // labelItem19
            // 
            this.labelItem19.Name = "labelItem19";
            this.labelItem19.Text = "Size       ";
            this.labelItem19.ThemeAware = true;
            // 
            // width
            // 
            this.width.Name = "width";
            this.superTooltip.SetSuperTooltip(this.width, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Width size", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.width.ThemeAware = true;
            this.width.WatermarkColor = System.Drawing.SystemColors.GrayText;
            // 
            // height
            // 
            this.height.Name = "height";
            this.superTooltip.SetSuperTooltip(this.height, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Height size", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.height.ThemeAware = true;
            this.height.WatermarkColor = System.Drawing.SystemColors.GrayText;
            // 
            // EntryID2
            // 
            this.EntryID2.DisplayMember = "Text";
            this.EntryID2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.EntryID2.FormattingEnabled = true;
            this.EntryID2.ItemHeight = 14;
            this.EntryID2.Location = new System.Drawing.Point(4, 5);
            this.EntryID2.Name = "EntryID2";
            this.EntryID2.Size = new System.Drawing.Size(231, 20);
            this.EntryID2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.superTooltip.SetSuperTooltip(this.EntryID2, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Element ID", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.EntryID2.TabIndex = 0;
            this.EntryID2.TextChanged += new System.EventHandler(this.EntryIdChanged);
            // 
            // RightDock
            // 
            this.RightDock.AutoScroll = true;
            this.RightDock.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.RightDock.Controls.Add(this.explorerBar1);
            this.RightDock.Controls.Add(this.EntryInfo);
            this.RightDock.Location = new System.Drawing.Point(3, 23);
            this.RightDock.Name = "RightDock";
            this.RightDock.Size = new System.Drawing.Size(255, 307);
            this.RightDock.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.RightDock.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.RightDock.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.RightDock.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.RightDock.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.RightDock.Style.GradientAngle = 90;
            this.RightDock.TabIndex = 0;
            // 
            // explorerBar1
            // 
            this.explorerBar1.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
            this.explorerBar1.BackColor = System.Drawing.SystemColors.Control;
            // 
            // 
            // 
            this.explorerBar1.BackStyle.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.ExplorerBarBackground2;
            this.explorerBar1.BackStyle.BackColorGradientAngle = 90;
            this.explorerBar1.BackStyle.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ExplorerBarBackground;
            this.explorerBar1.BackStyle.Class = "";
            this.explorerBar1.BackStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBar1.Cursor = System.Windows.Forms.Cursors.Default;
            this.explorerBar1.GroupImages = null;
            this.explorerBar1.Groups.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.explorerBarGroupItem1,
            this.AttributeBarGroup,
            this.OperationBarGroup});
            this.explorerBar1.Images = null;
            this.explorerBar1.Location = new System.Drawing.Point(4, 30);
            this.explorerBar1.Name = "explorerBar1";
            this.explorerBar1.Size = new System.Drawing.Size(236, 383);
            this.explorerBar1.StockStyle = DevComponents.DotNetBar.eExplorerBarStockStyle.SystemColors;
            this.explorerBar1.TabIndex = 1;
            this.explorerBar1.Text = "explorerBar1";
            this.explorerBar1.ThemeAware = true;
            // 
            // explorerBarGroupItem1
            // 
            // 
            // 
            // 
            this.explorerBarGroupItem1.BackStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(223)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem1.BackStyle.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem1.BackStyle.BorderBottomWidth = 1;
            this.explorerBarGroupItem1.BackStyle.BorderColor = System.Drawing.Color.White;
            this.explorerBarGroupItem1.BackStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem1.BackStyle.BorderLeftWidth = 1;
            this.explorerBarGroupItem1.BackStyle.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.explorerBarGroupItem1.BackStyle.BorderRightWidth = 1;
            this.explorerBarGroupItem1.BackStyle.Class = "";
            this.explorerBarGroupItem1.BackStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem1.Cursor = System.Windows.Forms.Cursors.Default;
            this.explorerBarGroupItem1.Expanded = true;
            this.explorerBarGroupItem1.Name = "explorerBarGroupItem1";
            this.explorerBarGroupItem1.StockStyle = DevComponents.DotNetBar.eExplorerBarStockStyle.SystemColors;
            this.explorerBarGroupItem1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer60});
            this.explorerBarGroupItem1.Text = "Information";
            // 
            // 
            // 
            this.explorerBarGroupItem1.TitleHotStyle.BackColor = System.Drawing.Color.White;
            this.explorerBarGroupItem1.TitleHotStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem1.TitleHotStyle.Class = "";
            this.explorerBarGroupItem1.TitleHotStyle.CornerDiameter = 3;
            this.explorerBarGroupItem1.TitleHotStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem1.TitleHotStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem1.TitleHotStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem1.TitleHotStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.explorerBarGroupItem1.TitleStyle.BackColor = System.Drawing.Color.White;
            this.explorerBarGroupItem1.TitleStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.explorerBarGroupItem1.TitleStyle.Class = "";
            this.explorerBarGroupItem1.TitleStyle.CornerDiameter = 3;
            this.explorerBarGroupItem1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.explorerBarGroupItem1.TitleStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem1.TitleStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.explorerBarGroupItem1.TitleStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            // 
            // itemContainer60
            // 
            // 
            // 
            // 
            this.itemContainer60.BackgroundStyle.Class = "";
            this.itemContainer60.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer60.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer60.Name = "itemContainer60";
            this.itemContainer60.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer61,
            this.itemContainer63});
            this.itemContainer60.ThemeAware = true;
            this.itemContainer60.VerticalItemAlignment = DevComponents.DotNetBar.eVerticalItemsAlignment.Middle;
            // 
            // itemContainer61
            // 
            // 
            // 
            // 
            this.itemContainer61.BackgroundStyle.Class = "";
            this.itemContainer61.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer61.Name = "itemContainer61";
            this.itemContainer61.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem5,
            this.NameInfo});
            this.itemContainer61.ThemeAware = true;
            // 
            // labelItem5
            // 
            this.labelItem5.Name = "labelItem5";
            this.labelItem5.Text = "Name        ";
            this.labelItem5.ThemeAware = true;
            // 
            // NameInfo
            // 
            this.NameInfo.Name = "NameInfo";
            this.superTooltip.SetSuperTooltip(this.NameInfo, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Name of element ( Class name , Role name...)", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.NameInfo.TextBoxWidth = 150;
            this.NameInfo.ThemeAware = true;
            this.NameInfo.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.NameInfo.TextChanged += new System.EventHandler(this.NameInfoTextChanged);
            // 
            // itemContainer63
            // 
            // 
            // 
            // 
            this.itemContainer63.BackgroundStyle.Class = "";
            this.itemContainer63.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer63.Name = "itemContainer63";
            this.itemContainer63.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem7,
            this.DescriptionInfo});
            this.itemContainer63.ThemeAware = true;
            // 
            // labelItem7
            // 
            this.labelItem7.Name = "labelItem7";
            this.labelItem7.Text = "Description";
            this.labelItem7.ThemeAware = true;
            // 
            // DescriptionInfo
            // 
            this.DescriptionInfo.Name = "DescriptionInfo";
            this.superTooltip.SetSuperTooltip(this.DescriptionInfo, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Description or comment of elements", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.DescriptionInfo.TextBoxWidth = 150;
            this.DescriptionInfo.ThemeAware = true;
            this.DescriptionInfo.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.DescriptionInfo.TextChanged += new System.EventHandler(this.DescriptionInfoChanged);
            // 
            // AttributeBarGroup
            // 
            // 
            // 
            // 
            this.AttributeBarGroup.BackStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(223)))), ((int)(((byte)(247)))));
            this.AttributeBarGroup.BackStyle.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.AttributeBarGroup.BackStyle.BorderBottomWidth = 1;
            this.AttributeBarGroup.BackStyle.BorderColor = System.Drawing.Color.White;
            this.AttributeBarGroup.BackStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.AttributeBarGroup.BackStyle.BorderLeftWidth = 1;
            this.AttributeBarGroup.BackStyle.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.AttributeBarGroup.BackStyle.BorderRightWidth = 1;
            this.AttributeBarGroup.BackStyle.Class = "";
            this.AttributeBarGroup.BackStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.AttributeBarGroup.Cursor = System.Windows.Forms.Cursors.Default;
            this.AttributeBarGroup.Expanded = true;
            this.AttributeBarGroup.Name = "AttributeBarGroup";
            this.AttributeBarGroup.StockStyle = DevComponents.DotNetBar.eExplorerBarStockStyle.SystemColors;
            this.AttributeBarGroup.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.AttContainer,
            this.MoreAtt});
            this.AttributeBarGroup.Text = "Attributes";
            // 
            // 
            // 
            this.AttributeBarGroup.TitleHotStyle.BackColor = System.Drawing.Color.White;
            this.AttributeBarGroup.TitleHotStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.AttributeBarGroup.TitleHotStyle.Class = "";
            this.AttributeBarGroup.TitleHotStyle.CornerDiameter = 3;
            this.AttributeBarGroup.TitleHotStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.AttributeBarGroup.TitleHotStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.AttributeBarGroup.TitleHotStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.AttributeBarGroup.TitleHotStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.AttributeBarGroup.TitleStyle.BackColor = System.Drawing.Color.White;
            this.AttributeBarGroup.TitleStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.AttributeBarGroup.TitleStyle.Class = "";
            this.AttributeBarGroup.TitleStyle.CornerDiameter = 3;
            this.AttributeBarGroup.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.AttributeBarGroup.TitleStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.AttributeBarGroup.TitleStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.AttributeBarGroup.TitleStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            // 
            // AttContainer
            // 
            // 
            // 
            // 
            this.AttContainer.BackgroundStyle.Class = "";
            this.AttContainer.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.AttContainer.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.AttContainer.Name = "AttContainer";
            this.AttContainer.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer65,
            this.itemContainer66,
            this.itemContainer67});
            this.AttContainer.ThemeAware = true;
            // 
            // itemContainer65
            // 
            // 
            // 
            // 
            this.itemContainer65.BackgroundStyle.Class = "";
            this.itemContainer65.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer65.Name = "itemContainer65";
            this.itemContainer65.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem9,
            this.Attribute1,
            this.AttType1});
            this.itemContainer65.ThemeAware = true;
            // 
            // labelItem9
            // 
            this.labelItem9.Name = "labelItem9";
            this.labelItem9.Text = "Attribute1  ";
            this.labelItem9.ThemeAware = true;
            // 
            // Attribute1
            // 
            this.Attribute1.Name = "Attribute1";
            this.superTooltip.SetSuperTooltip(this.Attribute1, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Name of attribute 1", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Attribute1.TextBoxWidth = 80;
            this.Attribute1.ThemeAware = true;
            this.Attribute1.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.Attribute1.TextChanged += new System.EventHandler(this.Attribute1TextChanged);
            // 
            // AttType1
            // 
            this.AttType1.DropDownHeight = 106;
            this.AttType1.ItemHeight = 14;
            this.AttType1.Name = "AttType1";
            this.superTooltip.SetSuperTooltip(this.AttType1, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Data type of attribute 1", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.AttType1.Text = "comboBoxItem1";
            this.AttType1.ThemeAware = true;
            this.AttType1.TextChanged += new System.EventHandler(this.Type1Changed);
            // 
            // itemContainer66
            // 
            // 
            // 
            // 
            this.itemContainer66.BackgroundStyle.Class = "";
            this.itemContainer66.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer66.Name = "itemContainer66";
            this.itemContainer66.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem10,
            this.Attribute2,
            this.AttType2});
            this.itemContainer66.ThemeAware = true;
            // 
            // labelItem10
            // 
            this.labelItem10.Name = "labelItem10";
            this.labelItem10.Text = "Attribute2  ";
            this.labelItem10.ThemeAware = true;
            // 
            // Attribute2
            // 
            this.Attribute2.Name = "Attribute2";
            this.superTooltip.SetSuperTooltip(this.Attribute2, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Name of attribute 2", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Attribute2.TextBoxWidth = 80;
            this.Attribute2.ThemeAware = true;
            this.Attribute2.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.Attribute2.TextChanged += new System.EventHandler(this.Attribute2TextChanged);
            // 
            // AttType2
            // 
            this.AttType2.DropDownHeight = 106;
            this.AttType2.ItemHeight = 14;
            this.AttType2.Name = "AttType2";
            this.superTooltip.SetSuperTooltip(this.AttType2, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Data type of attribute 2", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.AttType2.Text = "comboBoxItem2";
            this.AttType2.ThemeAware = true;
            this.AttType2.TextChanged += new System.EventHandler(this.Type2Changed);
            // 
            // itemContainer67
            // 
            // 
            // 
            // 
            this.itemContainer67.BackgroundStyle.Class = "";
            this.itemContainer67.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer67.Name = "itemContainer67";
            this.itemContainer67.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem11,
            this.Attribute3,
            this.AttType3});
            this.itemContainer67.ThemeAware = true;
            // 
            // labelItem11
            // 
            this.labelItem11.Name = "labelItem11";
            this.labelItem11.Text = "Attribute3  ";
            this.labelItem11.ThemeAware = true;
            // 
            // Attribute3
            // 
            this.Attribute3.Name = "Attribute3";
            this.superTooltip.SetSuperTooltip(this.Attribute3, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Name of attribute 3", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Attribute3.TextBoxWidth = 80;
            this.Attribute3.ThemeAware = true;
            this.Attribute3.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.Attribute3.TextChanged += new System.EventHandler(this.Attribute3TextChanged);
            // 
            // AttType3
            // 
            this.AttType3.DropDownHeight = 106;
            this.AttType3.ItemHeight = 14;
            this.AttType3.Name = "AttType3";
            this.superTooltip.SetSuperTooltip(this.AttType3, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Data type of attribute 3", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.AttType3.Text = "comboBoxItem3";
            this.AttType3.ThemeAware = true;
            this.AttType3.TextChanged += new System.EventHandler(this.Type3Changed);
            // 
            // MoreAtt
            // 
            this.MoreAtt.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.MoreAtt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MoreAtt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            this.MoreAtt.HotFontUnderline = true;
            this.MoreAtt.HotForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            this.MoreAtt.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.None;
            this.MoreAtt.Name = "MoreAtt";
            this.MoreAtt.Text = "More";
            this.MoreAtt.Click += new System.EventHandler(this.MoreAtt_Click);
            // 
            // OperationBarGroup
            // 
            // 
            // 
            // 
            this.OperationBarGroup.BackStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(223)))), ((int)(((byte)(247)))));
            this.OperationBarGroup.BackStyle.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.OperationBarGroup.BackStyle.BorderBottomWidth = 1;
            this.OperationBarGroup.BackStyle.BorderColor = System.Drawing.Color.White;
            this.OperationBarGroup.BackStyle.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.OperationBarGroup.BackStyle.BorderLeftWidth = 1;
            this.OperationBarGroup.BackStyle.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.OperationBarGroup.BackStyle.BorderRightWidth = 1;
            this.OperationBarGroup.BackStyle.Class = "";
            this.OperationBarGroup.BackStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.OperationBarGroup.Cursor = System.Windows.Forms.Cursors.Default;
            this.OperationBarGroup.Expanded = true;
            this.OperationBarGroup.Name = "OperationBarGroup";
            this.OperationBarGroup.StockStyle = DevComponents.DotNetBar.eExplorerBarStockStyle.SystemColors;
            this.OperationBarGroup.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.OpContainer,
            this.MoreOp});
            this.OperationBarGroup.Text = "Operations";
            // 
            // 
            // 
            this.OperationBarGroup.TitleHotStyle.BackColor = System.Drawing.Color.White;
            this.OperationBarGroup.TitleHotStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.OperationBarGroup.TitleHotStyle.Class = "";
            this.OperationBarGroup.TitleHotStyle.CornerDiameter = 3;
            this.OperationBarGroup.TitleHotStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.OperationBarGroup.TitleHotStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.OperationBarGroup.TitleHotStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.OperationBarGroup.TitleHotStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.OperationBarGroup.TitleStyle.BackColor = System.Drawing.Color.White;
            this.OperationBarGroup.TitleStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(211)))), ((int)(((byte)(247)))));
            this.OperationBarGroup.TitleStyle.Class = "";
            this.OperationBarGroup.TitleStyle.CornerDiameter = 3;
            this.OperationBarGroup.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.OperationBarGroup.TitleStyle.CornerTypeTopLeft = DevComponents.DotNetBar.eCornerType.Rounded;
            this.OperationBarGroup.TitleStyle.CornerTypeTopRight = DevComponents.DotNetBar.eCornerType.Rounded;
            this.OperationBarGroup.TitleStyle.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            // 
            // OpContainer
            // 
            // 
            // 
            // 
            this.OpContainer.BackgroundStyle.Class = "";
            this.OpContainer.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.OpContainer.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.OpContainer.Name = "OpContainer";
            this.OpContainer.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer69,
            this.itemContainer70,
            this.itemContainer71});
            this.OpContainer.ThemeAware = true;
            // 
            // itemContainer69
            // 
            // 
            // 
            // 
            this.itemContainer69.BackgroundStyle.Class = "";
            this.itemContainer69.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer69.Name = "itemContainer69";
            this.itemContainer69.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem12,
            this.Operation1,
            this.Optype1});
            this.itemContainer69.ThemeAware = true;
            // 
            // labelItem12
            // 
            this.labelItem12.Name = "labelItem12";
            this.labelItem12.Text = "Operation1 ";
            this.labelItem12.ThemeAware = true;
            // 
            // Operation1
            // 
            this.Operation1.Name = "Operation1";
            this.superTooltip.SetSuperTooltip(this.Operation1, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Name of operation 1", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Operation1.TextBoxWidth = 80;
            this.Operation1.ThemeAware = true;
            this.Operation1.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.Operation1.TextChanged += new System.EventHandler(this.Op1TextChanged);
            // 
            // Optype1
            // 
            this.Optype1.DropDownHeight = 106;
            this.Optype1.ItemHeight = 14;
            this.Optype1.Name = "Optype1";
            this.superTooltip.SetSuperTooltip(this.Optype1, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Operation type of operation 1", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Optype1.Text = "comboBoxItem1";
            this.Optype1.ThemeAware = true;
            this.Optype1.TextChanged += new System.EventHandler(this.Optype1_Changed);
            // 
            // itemContainer70
            // 
            // 
            // 
            // 
            this.itemContainer70.BackgroundStyle.Class = "";
            this.itemContainer70.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer70.Name = "itemContainer70";
            this.itemContainer70.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem13,
            this.Operation2,
            this.Optype2});
            this.itemContainer70.ThemeAware = true;
            // 
            // labelItem13
            // 
            this.labelItem13.Name = "labelItem13";
            this.labelItem13.Text = "Operation2 ";
            this.labelItem13.ThemeAware = true;
            // 
            // Operation2
            // 
            this.Operation2.Name = "Operation2";
            this.superTooltip.SetSuperTooltip(this.Operation2, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Name of operation 2", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Operation2.TextBoxWidth = 80;
            this.Operation2.ThemeAware = true;
            this.Operation2.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.Operation2.TextChanged += new System.EventHandler(this.Op2TextChanged);
            // 
            // Optype2
            // 
            this.Optype2.DropDownHeight = 106;
            this.Optype2.ItemHeight = 14;
            this.Optype2.Name = "Optype2";
            this.superTooltip.SetSuperTooltip(this.Optype2, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Operation type of operation 1", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Optype2.Text = "comboBoxItem2";
            this.Optype2.ThemeAware = true;
            this.Optype2.TextChanged += new System.EventHandler(this.Optype2_Changed);
            // 
            // itemContainer71
            // 
            // 
            // 
            // 
            this.itemContainer71.BackgroundStyle.Class = "";
            this.itemContainer71.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer71.Name = "itemContainer71";
            this.itemContainer71.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.labelItem14,
            this.Operation3,
            this.Optype3});
            this.itemContainer71.ThemeAware = true;
            // 
            // labelItem14
            // 
            this.labelItem14.Name = "labelItem14";
            this.labelItem14.Text = "Operation3 ";
            this.labelItem14.ThemeAware = true;
            // 
            // Operation3
            // 
            this.Operation3.Name = "Operation3";
            this.superTooltip.SetSuperTooltip(this.Operation3, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Name of operation 3", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Operation3.TextBoxWidth = 80;
            this.Operation3.ThemeAware = true;
            this.Operation3.WatermarkColor = System.Drawing.SystemColors.GrayText;
            this.Operation3.TextChanged += new System.EventHandler(this.Op3TextChanged);
            // 
            // Optype3
            // 
            this.Optype3.DropDownHeight = 106;
            this.Optype3.ItemHeight = 14;
            this.Optype3.Name = "Optype3";
            this.superTooltip.SetSuperTooltip(this.Optype3, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Operation type of operation 1", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.Optype3.Text = "comboBoxItem3";
            this.Optype3.ThemeAware = true;
            this.Optype3.TextChanged += new System.EventHandler(this.Optype3_Changed);
            // 
            // MoreOp
            // 
            this.MoreOp.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.MoreOp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MoreOp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(93)))), ((int)(((byte)(198)))));
            this.MoreOp.HotFontUnderline = true;
            this.MoreOp.HotForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(142)))), ((int)(((byte)(255)))));
            this.MoreOp.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.None;
            this.MoreOp.Name = "MoreOp";
            this.MoreOp.Text = "More";
            this.MoreOp.Click += new System.EventHandler(this.MoreOp_Click);
            // 
            // EntryInfo
            // 
            this.EntryInfo.DisplayMember = "Text";
            this.EntryInfo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.EntryInfo.FormattingEnabled = true;
            this.EntryInfo.ItemHeight = 14;
            this.EntryInfo.Location = new System.Drawing.Point(4, 5);
            this.EntryInfo.Name = "EntryInfo";
            this.EntryInfo.Size = new System.Drawing.Size(236, 20);
            this.EntryInfo.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.superTooltip.SetSuperTooltip(this.EntryInfo, new DevComponents.DotNetBar.SuperTooltipInfo("", "", "Element ID", null, null, DevComponents.DotNetBar.eTooltipColor.Gray));
            this.EntryInfo.TabIndex = 0;
            this.EntryInfo.TextChanged += new System.EventHandler(this.EntryTextChanged);
            // 
            // dockContainerItem2
            // 
            this.dockContainerItem2.Control = this.RightDock;
            this.dockContainerItem2.Name = "dockContainerItem2";
            this.dockContainerItem2.Text = "Attributes";
            // 
            // Appearance
            // 
            this.Appearance.Control = this.panelDockContainer6;
            this.Appearance.Name = "Appearance";
            this.Appearance.Text = "Appearance";
            // 
            // dockSite8
            // 
            this.dockSite8.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dockSite8.Location = new System.Drawing.Point(0, 602);
            this.dockSite8.Name = "dockSite8";
            this.dockSite8.Size = new System.Drawing.Size(1117, 0);
            this.dockSite8.TabIndex = 9;
            this.dockSite8.TabStop = false;
            // 
            // dockSite5
            // 
            this.dockSite5.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite5.Dock = System.Windows.Forms.DockStyle.Left;
            this.dockSite5.Location = new System.Drawing.Point(0, 0);
            this.dockSite5.Name = "dockSite5";
            this.dockSite5.Size = new System.Drawing.Size(0, 602);
            this.dockSite5.TabIndex = 6;
            this.dockSite5.TabStop = false;
            // 
            // dockSite6
            // 
            this.dockSite6.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite6.Dock = System.Windows.Forms.DockStyle.Right;
            this.dockSite6.Location = new System.Drawing.Point(1117, 0);
            this.dockSite6.Name = "dockSite6";
            this.dockSite6.Size = new System.Drawing.Size(0, 602);
            this.dockSite6.TabIndex = 7;
            this.dockSite6.TabStop = false;
            // 
            // dockSite7
            // 
            this.dockSite7.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite7.Dock = System.Windows.Forms.DockStyle.Top;
            this.dockSite7.Location = new System.Drawing.Point(0, 0);
            this.dockSite7.Name = "dockSite7";
            this.dockSite7.Size = new System.Drawing.Size(1117, 0);
            this.dockSite7.TabIndex = 8;
            this.dockSite7.TabStop = false;
            // 
            // dockSite3
            // 
            this.dockSite3.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.dockSite3.Dock = System.Windows.Forms.DockStyle.Top;
            this.dockSite3.DocumentDockContainer = new DevComponents.DotNetBar.DocumentDockContainer();
            this.dockSite3.Location = new System.Drawing.Point(0, 0);
            this.dockSite3.Name = "dockSite3";
            this.dockSite3.Size = new System.Drawing.Size(1117, 0);
            this.dockSite3.TabIndex = 4;
            this.dockSite3.TabStop = false;
            // 
            // contextMenu
            // 
            this.contextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cutToolStrip,
            this.copyToolStrip,
            this.pasteToolStrip,
            this.toolStripSeparator1,
            this.deleteToolStrip});
            this.contextMenu.Name = "contextMenu";
            this.contextMenu.Size = new System.Drawing.Size(108, 98);
            // 
            // cutToolStrip
            // 
            this.cutToolStrip.Name = "cutToolStrip";
            this.cutToolStrip.Size = new System.Drawing.Size(107, 22);
            this.cutToolStrip.Text = "Cut";
            this.cutToolStrip.Click += new System.EventHandler(this.cutToolStrip_Click);
            // 
            // copyToolStrip
            // 
            this.copyToolStrip.Name = "copyToolStrip";
            this.copyToolStrip.Size = new System.Drawing.Size(107, 22);
            this.copyToolStrip.Text = "Copy";
            this.copyToolStrip.Click += new System.EventHandler(this.copyToolStrip_Click);
            // 
            // pasteToolStrip
            // 
            this.pasteToolStrip.Name = "pasteToolStrip";
            this.pasteToolStrip.Size = new System.Drawing.Size(107, 22);
            this.pasteToolStrip.Text = "Paste";
            this.pasteToolStrip.Click += new System.EventHandler(this.pasteToolStrip_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(104, 6);
            // 
            // deleteToolStrip
            // 
            this.deleteToolStrip.Name = "deleteToolStrip";
            this.deleteToolStrip.Size = new System.Drawing.Size(107, 22);
            this.deleteToolStrip.Text = "Delete";
            this.deleteToolStrip.Click += new System.EventHandler(this.deleteToolStrip_Click);
            // 
            // addAttributesToolStripMenuItem
            // 
            this.addAttributesToolStripMenuItem.Name = "addAttributesToolStripMenuItem";
            this.addAttributesToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.addAttributesToolStripMenuItem.Text = "Add Attributes";
            // 
            // RulercontextMenu
            // 
            this.RulercontextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.flipRulers,
            this.toolStripSeparator2,
            this.pixels,
            this.inches,
            this.centimeters,
            this.toolStripSeparator3,
            this.exitRuler});
            this.RulercontextMenu.Name = "RulercontextMenu";
            this.RulercontextMenu.Size = new System.Drawing.Size(139, 126);
            // 
            // flipRulers
            // 
            this.flipRulers.Name = "flipRulers";
            this.flipRulers.Size = new System.Drawing.Size(138, 22);
            this.flipRulers.Text = "Flip Ruler";
            this.flipRulers.Click += new System.EventHandler(this.flipRulers_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(135, 6);
            // 
            // pixels
            // 
            this.pixels.Name = "pixels";
            this.pixels.Size = new System.Drawing.Size(138, 22);
            this.pixels.Text = "Pixels";
            this.pixels.Click += new System.EventHandler(this.pixels_Click);
            // 
            // inches
            // 
            this.inches.Name = "inches";
            this.inches.Size = new System.Drawing.Size(138, 22);
            this.inches.Text = "Inches";
            this.inches.Click += new System.EventHandler(this.inches_Click);
            // 
            // centimeters
            // 
            this.centimeters.Name = "centimeters";
            this.centimeters.Size = new System.Drawing.Size(138, 22);
            this.centimeters.Text = "Centimeters";
            this.centimeters.Click += new System.EventHandler(this.centimeters_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(135, 6);
            // 
            // exitRuler
            // 
            this.exitRuler.Name = "exitRuler";
            this.exitRuler.Size = new System.Drawing.Size(138, 22);
            this.exitRuler.Text = "Exit";
            this.exitRuler.Click += new System.EventHandler(this.exitRuler_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1117, 602);
            this.Controls.Add(this.dockSite9);
            this.Controls.Add(this.dockSite2);
            this.Controls.Add(this.dockSite1);
            this.Controls.Add(this.ribbonClientPanel1);
            this.Controls.Add(this.ribbonControl1);
            this.Controls.Add(this.dockSite3);
            this.Controls.Add(this.dockSite4);
            this.Controls.Add(this.dockSite5);
            this.Controls.Add(this.dockSite6);
            this.Controls.Add(this.dockSite7);
            this.Controls.Add(this.dockSite8);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "MainForm";
            this.Text = "DesignDatabase";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainFormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainFormKeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainFormKeyUp);
            this.Resize += new System.EventHandler(this.MainFormResize);
            this.ribbonControl1.ResumeLayout(false);
            this.ribbonControl1.PerformLayout();
            this.ribbonPanel5.ResumeLayout(false);
            this.ribbonPanel4.ResumeLayout(false);
            this.ribbonPanel7.ResumeLayout(false);
            this.ribbonPanel8.ResumeLayout(false);
            this.ribbonPanel2.ResumeLayout(false);
            this.ribbonPanel3.ResumeLayout(false);
            this.ribbonPanel1.ResumeLayout(false);
            this.ribbonPanel6.ResumeLayout(false);
            this.dockSite4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bar3)).EndInit();
            this.bar3.ResumeLayout(false);
            this.panelDockContainer3.ResumeLayout(false);
            this.panelDockContainer4.ResumeLayout(false);
            this.panelDockContainer5.ResumeLayout(false);
            this.dockSite9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CenterBar)).EndInit();
            this.CenterBar.ResumeLayout(false);
            this.dockSite1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bar1)).EndInit();
            this.bar1.ResumeLayout(false);
            this.panelDockContainer7.ResumeLayout(false);
            this.ribbonClientPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.OperTabStrip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.superTabStrip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DatatypeTabStrip)).EndInit();
            this.panelDockContainer1.ResumeLayout(false);
            this.panelDockContainer2.ResumeLayout(false);
            this.dockSite2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bar2)).EndInit();
            this.bar2.ResumeLayout(false);
            this.panelDockContainer6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.explorerBar2)).EndInit();
            this.RightDock.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.explorerBar1)).EndInit();
            this.contextMenu.ResumeLayout(false);
            this.RulercontextMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.RibbonControl ribbonControl1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel2;
        private DevComponents.DotNetBar.Office2007StartButton office2007StartButton1;
        private DevComponents.DotNetBar.ItemContainer itemContainer1;
        private DevComponents.DotNetBar.ItemContainer itemContainer2;
        private DevComponents.DotNetBar.ItemContainer itemContainer3;
        private DevComponents.DotNetBar.ButtonItem NewDocument;
        private DevComponents.DotNetBar.ButtonItem OpenDocument;
        private DevComponents.DotNetBar.ButtonItem SaveAs;
        private DevComponents.DotNetBar.ButtonItem buttonItem5;
        private DevComponents.DotNetBar.ButtonItem buttonItem6;
        private DevComponents.DotNetBar.ButtonItem Close;
        private DevComponents.DotNetBar.LabelItem labelItem8;
        private DevComponents.DotNetBar.ItemContainer itemContainer4;
        private DevComponents.DotNetBar.ButtonItem buttonItem12;
        private DevComponents.DotNetBar.ButtonItem buttonItem13;
        private DevComponents.DotNetBar.RibbonTabItem Home;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem2;
        private DevComponents.DotNetBar.ButtonItem buttonItem1;
        private DevComponents.DotNetBar.QatCustomizeItem qatCustomizeItem1;
        private DevComponents.DotNetBar.StyleManager styleManager1;
        private DevComponents.DotNetBar.Ribbon.RibbonClientPanel ribbonClientPanel1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar6;
        private DevComponents.DotNetBar.RibbonBar ribbonBar5;
        private DevComponents.DotNetBar.RibbonBar ribbonBar4;
        private DevComponents.DotNetBar.RibbonBar ribbonBar3;
        private DevComponents.DotNetBar.RibbonBar ribbonBar2;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel3;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel4;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel5;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel6;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem3;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem4;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem5;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem6;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.ButtonItem buttonItem14;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel8;
        private DevComponents.DotNetBar.RibbonBar ribbonBar37;
        private DevComponents.DotNetBar.RibbonBar ribbonBar36;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel7;
        private DevComponents.DotNetBar.RibbonBar ribbonBar31;
        private DevComponents.DotNetBar.RibbonBar ribbonBar28;
        private DevComponents.DotNetBar.RibbonBar ribbonBar26;
        private DevComponents.DotNetBar.RibbonBar ribbonBar21;
        private DevComponents.DotNetBar.RibbonBar ribbonBar20;
        private DevComponents.DotNetBar.RibbonBar ribbonBar17;
        private DevComponents.DotNetBar.RibbonBar ribbonBar16;
        private DevComponents.DotNetBar.RibbonBar ribbonBar15;
        private DevComponents.DotNetBar.RibbonBar ribbonBar14;
        private DevComponents.DotNetBar.RibbonBar ribbonBar1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar11;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem1;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem7;
        private DevComponents.DotNetBar.ItemContainer itemContainer5;
        private DevComponents.DotNetBar.ItemContainer itemContainer10;
        private DevComponents.DotNetBar.LabelItem labelItem1;
        private DevComponents.DotNetBar.ComboBoxItem Font;
        private DevComponents.DotNetBar.ItemContainer itemContainer11;
        private DevComponents.DotNetBar.LabelItem labelItem2;
        private DevComponents.DotNetBar.ComboBoxItem SizeFont;
        private DevComponents.DotNetBar.ColorPickerDropDown TextColor;
        private DevComponents.DotNetBar.ItemContainer itemContainer6;
        private DevComponents.DotNetBar.ButtonItem Open;
        private DevComponents.DotNetBar.ItemContainer itemContainer17;
        private DevComponents.DotNetBar.ItemContainer itemContainer19;
        private DevComponents.DotNetBar.LabelItem labelItem3;
        private DevComponents.DotNetBar.ComboBoxItem ZoomValue;
        private DevComponents.DotNetBar.ItemContainer itemContainer15;
        private DevComponents.DotNetBar.ButtonItem Select;
        private DevComponents.DotNetBar.ButtonItem Find;
        private DevComponents.DotNetBar.RibbonBar ribbonBar18;
        private DevComponents.DotNetBar.ButtonItem OpenWebsite;
        private DevComponents.DotNetBar.ButtonItem TermOf;
        private DevComponents.DotNetBar.ButtonItem SoftInformation;
        private DevComponents.DotNetBar.ItemContainer itemContainer20;
        private DevComponents.DotNetBar.ButtonItem Undo;
        private DevComponents.DotNetBar.ButtonItem Redo;
        private DevComponents.DotNetBar.ButtonItem Start;
        private DevComponents.DotNetBar.ButtonItem StopRun;
        private DevComponents.DotNetBar.ButtonItem PauseRun;
        private DevComponents.DotNetBar.ItemContainer itemContainer21;
        private DevComponents.DotNetBar.ItemContainer itemContainer22;
        private DevComponents.DotNetBar.CheckBoxItem checkRuler;
        private DevComponents.DotNetBar.ItemContainer itemContainer23;
        private DevComponents.DotNetBar.ItemContainer itemContainer24;
        private DevComponents.DotNetBar.CheckBoxItem checkBoxItem3;
        private DevComponents.DotNetBar.ItemContainer itemContainer25;
        private DevComponents.DotNetBar.ItemContainer itemContainer26;
        private DevComponents.DotNetBar.CheckBoxItem checkBoxItem4;
        private DevComponents.DotNetBar.ItemContainer itemContainer27;
        private DevComponents.DotNetBar.CheckBoxItem checkBoxItem5;
        private DevComponents.DotNetBar.ItemContainer itemContainer28;
        private DevComponents.DotNetBar.ItemContainer itemContainer29;
        private DevComponents.DotNetBar.CheckBoxItem View;
        private DevComponents.DotNetBar.ItemContainer itemContainer30;
        private DevComponents.DotNetBar.CheckBoxItem Insert;
        private DevComponents.DotNetBar.ItemContainer itemContainer31;
        private DevComponents.DotNetBar.CheckBoxItem DesignTools;
        private DevComponents.DotNetBar.ItemContainer itemContainer32;
        private DevComponents.DotNetBar.CheckBoxItem Toolbox;
        private DevComponents.DotNetBar.CheckBoxItem Status;
        private DevComponents.DotNetBar.CheckBoxItem Properties;
        private DevComponents.DotNetBar.ButtonItem ImportBtn;
        private DevComponents.DotNetBar.ButtonItem Export;
        private DevComponents.DotNetBar.ItemContainer itemContainer7;
        private DevComponents.DotNetBar.ButtonItem New;
        private DevComponents.DotNetBar.ButtonItem Save;
        private DevComponents.DotNetBar.ItemContainer itemContainer8;
        private DevComponents.DotNetBar.ButtonItem Cut;
        private DevComponents.DotNetBar.ButtonItem Copy;
        private DevComponents.DotNetBar.ButtonItem Paste;
        private DevComponents.DotNetBar.ItemContainer itemContainer9;
        private DevComponents.DotNetBar.ButtonItem ZoomOut;
        private DevComponents.DotNetBar.ButtonItem InsertNewPage;
        private DevComponents.DotNetBar.ButtonItem InsertOldPage;
        private DevComponents.DotNetBar.ItemContainer itemContainer13;
        private DevComponents.DotNetBar.ItemContainer itemContainer16;
        private DevComponents.DotNetBar.ItemContainer itemContainer18;
        private DevComponents.DotNetBar.ButtonItem Insertext;
        private DevComponents.DotNetBar.ButtonItem InsertImage;
        private DevComponents.DotNetBar.ButtonItem Comment;
        private DevComponents.DotNetBar.ItemContainer itemContainer36;
        private DevComponents.DotNetBar.ButtonItem SlideShowClick;
        private DevComponents.DotNetBar.ColorPickerDropDown SlideBack;
        private DevComponents.DotNetBar.ItemContainer itemContainer39;
        private DevComponents.DotNetBar.ItemContainer itemContainer40;
        private DevComponents.DotNetBar.RibbonBar ribbonBar8;
        private DevComponents.DotNetBar.ItemContainer itemContainer41;
        private DevComponents.DotNetBar.ButtonItem buttonItem60;
        private DevComponents.DotNetBar.ButtonItem buttonItem61;
        private DevComponents.DotNetBar.ItemContainer itemContainer43;
        private DevComponents.DotNetBar.ItemContainer itemContainer44;
        private DevComponents.DotNetBar.ItemContainer itemContainer45;
        private DevComponents.DotNetBar.ButtonItem RefreshRun;
        private DevComponents.DotNetBar.ItemContainer itemContainer46;
        private DevComponents.DotNetBar.ItemContainer itemContainer47;
        private DevComponents.DotNetBar.ButtonItem Callus;
        private DevComponents.AdvTree.ColumnHeader columnHeader1;
        private DevComponents.DotNetBar.ItemContainer itemContainer56;
        private DevComponents.DotNetBar.ButtonItem Note;
        private DevComponents.DotNetBar.ItemContainer itemContainer55;
        private DevComponents.DotNetBar.ButtonItem Aggregation;
        private DevComponents.DotNetBar.ButtonItem Composition;
        private DevComponents.DotNetBar.ItemContainer itemContainer54;
        private DevComponents.DotNetBar.ButtonItem Generalization;
        private DevComponents.DotNetBar.ButtonItem Dymamic;
        private DevComponents.DotNetBar.ButtonItem Disjoint;
        private DevComponents.DotNetBar.ItemContainer itemContainer50;
        private DevComponents.DotNetBar.ButtonItem Association;
        private DevComponents.DotNetBar.ButtonItem Binary;
        private DevComponents.DotNetBar.ButtonItem Nary;
        private DevComponents.DotNetBar.ItemContainer itemContainer49;
        private DevComponents.DotNetBar.ButtonItem Class;
        private DevComponents.DotNetBar.ButtonItem AbstractClass;
        private DevComponents.DotNetBar.DotNetBarManager dotNetBarManager1;
        private DevComponents.DotNetBar.DockSite dockSite4;
        private DevComponents.DotNetBar.Bar bar3;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer3;
        private DevComponents.DotNetBar.DockContainerItem dockContainerItem3;
        private DevComponents.DotNetBar.DockSite dockSite9;
        private DevComponents.DotNetBar.PanelDockContainer MainRegion;
        private DevComponents.DotNetBar.DockContainerItem Page1;
        private DevComponents.DotNetBar.DockSite dockSite1;
        private DevComponents.DotNetBar.Bar bar1;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer1;
        private DevComponents.DotNetBar.DockContainerItem dockContainerItem1;
        private DevComponents.DotNetBar.DockSite dockSite2;
        private DevComponents.DotNetBar.Bar bar2;
        private DevComponents.DotNetBar.PanelDockContainer RightDock;
        private DevComponents.DotNetBar.DockContainerItem dockContainerItem2;
        private DevComponents.DotNetBar.DockSite dockSite3;
        private DevComponents.DotNetBar.DockSite dockSite5;
        private DevComponents.DotNetBar.DockSite dockSite6;
        private DevComponents.DotNetBar.DockSite dockSite7;
        private DevComponents.DotNetBar.DockSite dockSite8;
        private DevComponents.DotNetBar.Controls.Slider slider1;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.ButtonItem ZoomIn;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer6;
        private DevComponents.DotNetBar.DockContainerItem Appearance;
        public DevComponents.DotNetBar.LabelX ToadoY;
        public DevComponents.DotNetBar.LabelX ToadoX;
        private DevComponents.DotNetBar.RibbonBar ribbonBar10;
        private DevComponents.DotNetBar.ItemContainer itemContainer57;
        private DevComponents.DotNetBar.ColorPickerDropDown FillColor;
        private DevComponents.DotNetBar.ItemContainer itemContainer59;
        private DevComponents.DotNetBar.ButtonItem buttonItem17;
        private DevComponents.DotNetBar.ItemContainer itemContainer53;
        private DevComponents.DotNetBar.ItemContainer itemContainer58;
        private DevComponents.DotNetBar.ButtonItem Thinest;
        private DevComponents.DotNetBar.ButtonItem Thin;
        private DevComponents.DotNetBar.ButtonItem Thick;
        private DevComponents.DotNetBar.ButtonItem Thicker;
        private DevComponents.DotNetBar.ButtonItem Thickest;
        private DevComponents.DotNetBar.ExplorerBar explorerBar1;
        private DevComponents.DotNetBar.ExplorerBarGroupItem explorerBarGroupItem1;
        private DevComponents.DotNetBar.ItemContainer itemContainer60;
        private DevComponents.DotNetBar.ItemContainer itemContainer61;
        private DevComponents.DotNetBar.LabelItem labelItem5;
        private DevComponents.DotNetBar.ItemContainer itemContainer63;
        private DevComponents.DotNetBar.LabelItem labelItem7;
        private DevComponents.DotNetBar.ExplorerBarGroupItem AttributeBarGroup;
        private DevComponents.DotNetBar.ItemContainer AttContainer;
        private DevComponents.DotNetBar.ItemContainer itemContainer65;
        private DevComponents.DotNetBar.LabelItem labelItem9;
        private DevComponents.DotNetBar.ItemContainer itemContainer66;
        private DevComponents.DotNetBar.LabelItem labelItem10;
        private DevComponents.DotNetBar.ItemContainer itemContainer67;
        private DevComponents.DotNetBar.LabelItem labelItem11;
        private DevComponents.DotNetBar.ButtonItem MoreAtt;
        private DevComponents.DotNetBar.ExplorerBarGroupItem OperationBarGroup;
        private DevComponents.DotNetBar.ItemContainer OpContainer;
        private DevComponents.DotNetBar.ItemContainer itemContainer69;
        private DevComponents.DotNetBar.LabelItem labelItem12;
        private DevComponents.DotNetBar.ItemContainer itemContainer70;
        private DevComponents.DotNetBar.LabelItem labelItem13;
        private DevComponents.DotNetBar.ItemContainer itemContainer71;
        private DevComponents.DotNetBar.LabelItem labelItem14;
        private DevComponents.DotNetBar.ButtonItem MoreOp;
        public DevComponents.DotNetBar.Controls.ComboBoxEx EntryInfo;
        private DevComponents.DotNetBar.ButtonItem Panning;
        private DevComponents.DotNetBar.ColorPickerDropDown LineColor;
        public DevComponents.DotNetBar.Bar CenterBar;
        private System.Windows.Forms.ToolStripMenuItem cutToolStrip;
        private System.Windows.Forms.ToolStripMenuItem copyToolStrip;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStrip;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStrip;
        public System.Windows.Forms.ContextMenuStrip contextMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private DevComponents.DotNetBar.ExplorerBar explorerBar2;
        private DevComponents.DotNetBar.ExplorerBarGroupItem explorerBarGroupItem2;
        private DevComponents.DotNetBar.ItemContainer itemContainer64;
        private DevComponents.DotNetBar.ItemContainer itemContainer68;
        private DevComponents.DotNetBar.LabelItem labelItem15;
        private DevComponents.DotNetBar.ColorPickerDropDown RightFillColor;
        private DevComponents.DotNetBar.ItemContainer itemContainer72;
        private DevComponents.DotNetBar.LabelItem labelItem16;
        private DevComponents.DotNetBar.ColorPickerDropDown RightLineColor;
        private DevComponents.DotNetBar.ExplorerBarGroupItem explorerBarGroupItem3;
        private DevComponents.DotNetBar.ItemContainer itemContainer73;
        private DevComponents.DotNetBar.ItemContainer itemContainer74;
        private DevComponents.DotNetBar.LabelItem labelItem17;
        private DevComponents.DotNetBar.CheckBoxItem HideCheck;
        private DevComponents.DotNetBar.LabelX labelX4;
        public DevComponents.DotNetBar.LabelX NumberObj;
        private DevComponents.DotNetBar.LabelX PageName;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.ButtonItem Fontbox;
        public DevComponents.DotNetBar.GalleryContainer RecentFile;
        public DevComponents.DotNetBar.ButtonItem RecentFile1;
        public DevComponents.DotNetBar.ButtonItem RecentFile2;
        public DevComponents.DotNetBar.ButtonItem RecentFile3;
        public DevComponents.DotNetBar.ButtonItem RecentFile4;
        public DevComponents.DotNetBar.ButtonItem RecentFile5;
        public DevComponents.DotNetBar.TextBoxItem NameInfo;
        public DevComponents.DotNetBar.TextBoxItem DescriptionInfo;
        public DevComponents.DotNetBar.TextBoxItem Attribute1;
        public DevComponents.DotNetBar.TextBoxItem Attribute2;
        public DevComponents.DotNetBar.TextBoxItem Attribute3;
        public DevComponents.DotNetBar.TextBoxItem Operation1;
        public DevComponents.DotNetBar.TextBoxItem Operation2;
        public DevComponents.DotNetBar.TextBoxItem Operation3;
        private System.Windows.Forms.ToolStripMenuItem addAttributesToolStripMenuItem;
        private DevComponents.DotNetBar.ButtonItem ExtraAssociation;
        public DevComponents.DotNetBar.CheckBoxItem GirdBox;
        public DevComponents.DotNetBar.ComboBoxItem AttType1;
        public DevComponents.DotNetBar.ComboBoxItem AttType2;
        public DevComponents.DotNetBar.ComboBoxItem AttType3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        public System.Windows.Forms.ToolStripMenuItem flipRulers;
        public System.Windows.Forms.ToolStripMenuItem pixels;
        public System.Windows.Forms.ToolStripMenuItem inches;
        public System.Windows.Forms.ToolStripMenuItem centimeters;
        public System.Windows.Forms.ToolStripMenuItem exitRuler;
        public System.Windows.Forms.ContextMenuStrip RulercontextMenu;
        private DevComponents.DotNetBar.RibbonBar ribbonBar13;
        private DevComponents.DotNetBar.ButtonItem RulerUnit;
        private DevComponents.DotNetBar.ButtonItem CRuler;
        private DevComponents.DotNetBar.ButtonItem IRuler;
        private DevComponents.DotNetBar.ButtonItem PRuler;
        private DevComponents.DotNetBar.ItemContainer itemContainer75;
        private DevComponents.DotNetBar.LabelItem labelItem18;
        private DevComponents.DotNetBar.ItemContainer itemContainer76;
        private DevComponents.DotNetBar.LabelItem labelItem19;
        public DevComponents.DotNetBar.TextBoxItem PositionX;
        public DevComponents.DotNetBar.TextBoxItem PositionY;
        public DevComponents.DotNetBar.TextBoxItem width;
        public DevComponents.DotNetBar.TextBoxItem height;
        private DevComponents.DotNetBar.ItemContainer itemContainer77;
        private DevComponents.DotNetBar.LabelItem StyleFont;
        private DevComponents.DotNetBar.ComboBoxItem Style;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer2;
        private DevComponents.DotNetBar.DockContainerItem dockContainerItem4;
        public System.Windows.Forms.TreeView treeView;
        private DevComponents.DotNetBar.ButtonItem GroupInfomation;
        private DevComponents.DotNetBar.ItemContainer itemContainer42;
        private DevComponents.DotNetBar.ButtonItem DocumentHelp;
        private DevComponents.DotNetBar.ButtonItem AssociationClass;
        private DevComponents.DotNetBar.RibbonBar ribbonBar19;
        private DevComponents.DotNetBar.ItemContainer itemContainer14;
        private DevComponents.DotNetBar.ButtonItem CheckDiagram;
        private DevComponents.DotNetBar.ButtonItem StopCheck;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer4;
        private DevComponents.DotNetBar.DockContainerItem ResultCheck;
        private System.Windows.Forms.RichTextBox CheckResult;
        private System.Windows.Forms.ToolTip DescriptionTool;
        private DevComponents.DotNetBar.BalloonTip balloonTip;
        private DevComponents.DotNetBar.SuperTooltip superTooltip;
        private DevComponents.DotNetBar.ButtonItem Add_strip;
        private DevComponents.DotNetBar.ButtonItem Remove_strip;
        private DevComponents.DotNetBar.ButtonItem Up_strip;
        private DevComponents.DotNetBar.ButtonItem Down_strip;
        public DevComponents.DotNetBar.SuperTabStrip superTabStrip;
        public DevComponents.DotNetBar.ComboBoxItem List_datatype;
        public DevComponents.DotNetBar.SuperTabStrip DatatypeTabStrip;
        private DevComponents.DotNetBar.ButtonItem Panning_reset;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer5;
        private DevComponents.DotNetBar.DockContainerItem FindResult;
        public System.Windows.Forms.RichTextBox FindRichTextBox;
        public DevComponents.DotNetBar.SuperTabStrip OperTabStrip;
        public DevComponents.DotNetBar.ComboBoxItem Optype1;
        public DevComponents.DotNetBar.ComboBoxItem Optype2;
        public DevComponents.DotNetBar.ComboBoxItem Optype3;
        public DevComponents.DotNetBar.ComboBoxItem List_Oper;
        public DevComponents.DotNetBar.Controls.ComboBoxEx EntryID2;
        private DevComponents.DotNetBar.ButtonX example2;
        private DevComponents.DotNetBar.ButtonX example1;
        private DevComponents.DotNetBar.ButtonX example4;
        private DevComponents.DotNetBar.ButtonX example3;
        private DevComponents.DotNetBar.ItemContainer itemContainer33;
        public DevComponents.DotNetBar.ButtonItem Recurcy;
        private DevComponents.DotNetBar.ItemContainer itemContainer34;
        private DevComponents.DotNetBar.ItemContainer itemContainer51;
        private DevComponents.DotNetBar.ItemContainer itemContainer35;
        private DevComponents.DotNetBar.ColorPickerDropDown AreaColor;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.PanelDockContainer panelDockContainer7;
        private DevComponents.DotNetBar.DockContainerItem Options;
        private DevComponents.DotNetBar.Ribbon.RibbonClientPanel ribbonClientPanel2;
        public DevComponents.DotNetBar.Controls.TextBoxX DerivedColumn;
        public DevComponents.DotNetBar.Controls.TextBoxX MultiValues;
        public DevComponents.DotNetBar.Controls.CheckBoxX Multivalue;
        public DevComponents.DotNetBar.Controls.CheckBoxX Composite;
        public DevComponents.DotNetBar.Controls.CheckBoxX Derived;
        public System.Windows.Forms.ComboBox CompositeName;
        public DevComponents.DotNetBar.Controls.CheckBoxX primarykey;
        public DevComponents.DotNetBar.Controls.CheckBoxX final;
    }
}

