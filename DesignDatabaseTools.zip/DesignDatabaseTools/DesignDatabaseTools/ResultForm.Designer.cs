﻿namespace DesignDatabaseTools
{
    partial class ResultForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.Clear = new DevComponents.DotNetBar.ButtonX();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.Table = new DevComponents.DotNetBar.LabelX();
            this.NameTable = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.Attributename = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.addobject = new DevComponents.DotNetBar.ButtonX();
            this.remove = new DevComponents.DotNetBar.ButtonX();
            this.OK = new DevComponents.DotNetBar.ButtonX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.DataType = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.ObjectType = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.getatt = new DevComponents.DotNetBar.ButtonX();
            this.richTextBoxAtt = new System.Windows.Forms.RichTextBox();
            this.Save = new DevComponents.DotNetBar.ButtonX();
            this.Close = new DevComponents.DotNetBar.ButtonX();
            this.ResultText = new System.Windows.Forms.RichTextBox();
            this.panelEx1.SuspendLayout();
            this.groupPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelEx1
            // 
            this.panelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelEx1.Controls.Add(this.Clear);
            this.panelEx1.Controls.Add(this.groupPanel1);
            this.panelEx1.Controls.Add(this.Save);
            this.panelEx1.Controls.Add(this.Close);
            this.panelEx1.Controls.Add(this.ResultText);
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEx1.Location = new System.Drawing.Point(0, 0);
            this.panelEx1.MaximumSize = new System.Drawing.Size(759, 618);
            this.panelEx1.MinimumSize = new System.Drawing.Size(759, 618);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(759, 618);
            this.panelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelEx1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx1.Style.GradientAngle = 90;
            this.panelEx1.TabIndex = 0;
            // 
            // Clear
            // 
            this.Clear.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Clear.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Clear.Location = new System.Drawing.Point(103, 583);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 23);
            this.Clear.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Clear.TabIndex = 12;
            this.Clear.Text = "Clear";
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // groupPanel1
            // 
            this.groupPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.labelX3);
            this.groupPanel1.Controls.Add(this.Table);
            this.groupPanel1.Controls.Add(this.NameTable);
            this.groupPanel1.Controls.Add(this.Attributename);
            this.groupPanel1.Controls.Add(this.addobject);
            this.groupPanel1.Controls.Add(this.remove);
            this.groupPanel1.Controls.Add(this.OK);
            this.groupPanel1.Controls.Add(this.labelX2);
            this.groupPanel1.Controls.Add(this.DataType);
            this.groupPanel1.Controls.Add(this.labelX1);
            this.groupPanel1.Controls.Add(this.ObjectType);
            this.groupPanel1.Controls.Add(this.getatt);
            this.groupPanel1.Controls.Add(this.richTextBoxAtt);
            this.groupPanel1.Location = new System.Drawing.Point(574, 12);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(173, 458);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.Class = "";
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.Class = "";
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.Class = "";
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 11;
            this.groupPanel1.Text = "Create Table";
            // 
            // labelX3
            // 
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Location = new System.Drawing.Point(17, 64);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(75, 23);
            this.labelX3.TabIndex = 16;
            this.labelX3.Text = "Attribute Name";
            // 
            // Table
            // 
            // 
            // 
            // 
            this.Table.BackgroundStyle.Class = "";
            this.Table.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Table.Location = new System.Drawing.Point(17, 9);
            this.Table.Name = "Table";
            this.Table.Size = new System.Drawing.Size(75, 23);
            this.Table.TabIndex = 15;
            this.Table.Text = "Table Name";
            // 
            // NameTable
            // 
            // 
            // 
            // 
            this.NameTable.Border.Class = "TextBoxBorder";
            this.NameTable.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.NameTable.Location = new System.Drawing.Point(17, 38);
            this.NameTable.Name = "NameTable";
            this.NameTable.Size = new System.Drawing.Size(147, 20);
            this.NameTable.TabIndex = 14;
            // 
            // Attributename
            // 
            // 
            // 
            // 
            this.Attributename.Border.Class = "TextBoxBorder";
            this.Attributename.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Attributename.Location = new System.Drawing.Point(17, 87);
            this.Attributename.Name = "Attributename";
            this.Attributename.Size = new System.Drawing.Size(147, 20);
            this.Attributename.TabIndex = 13;
            // 
            // addobject
            // 
            this.addobject.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.addobject.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.addobject.Location = new System.Drawing.Point(139, 194);
            this.addobject.Name = "addobject";
            this.addobject.Size = new System.Drawing.Size(25, 23);
            this.addobject.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.addobject.TabIndex = 12;
            this.addobject.Text = ">>";
            this.addobject.Click += new System.EventHandler(this.addobject_Click);
            // 
            // remove
            // 
            this.remove.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.remove.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.remove.Location = new System.Drawing.Point(17, 399);
            this.remove.Name = "remove";
            this.remove.Size = new System.Drawing.Size(66, 23);
            this.remove.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.remove.TabIndex = 11;
            this.remove.Text = "Remove";
            this.remove.Click += new System.EventHandler(this.remove_Click);
            // 
            // OK
            // 
            this.OK.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.OK.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.OK.Location = new System.Drawing.Point(98, 399);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(66, 23);
            this.OK.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.OK.TabIndex = 10;
            this.OK.Text = "OK";
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // labelX2
            // 
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Location = new System.Drawing.Point(17, 168);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(75, 23);
            this.labelX2.TabIndex = 9;
            this.labelX2.Text = "Object Type";
            // 
            // DataType
            // 
            this.DataType.DisplayMember = "Text";
            this.DataType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.DataType.FormattingEnabled = true;
            this.DataType.ItemHeight = 14;
            this.DataType.Location = new System.Drawing.Point(17, 142);
            this.DataType.Name = "DataType";
            this.DataType.Size = new System.Drawing.Size(121, 20);
            this.DataType.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.DataType.TabIndex = 4;
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(17, 113);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(75, 23);
            this.labelX1.TabIndex = 8;
            this.labelX1.Text = "Data Type";
            // 
            // ObjectType
            // 
            this.ObjectType.DisplayMember = "Text";
            this.ObjectType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ObjectType.FormattingEnabled = true;
            this.ObjectType.ItemHeight = 14;
            this.ObjectType.Location = new System.Drawing.Point(17, 197);
            this.ObjectType.Name = "ObjectType";
            this.ObjectType.Size = new System.Drawing.Size(121, 20);
            this.ObjectType.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ObjectType.TabIndex = 5;
            // 
            // getatt
            // 
            this.getatt.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.getatt.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.getatt.Location = new System.Drawing.Point(139, 139);
            this.getatt.Name = "getatt";
            this.getatt.Size = new System.Drawing.Size(25, 23);
            this.getatt.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.getatt.TabIndex = 7;
            this.getatt.Text = ">>";
            this.getatt.Click += new System.EventHandler(this.getatt_Click);
            // 
            // richTextBoxAtt
            // 
            this.richTextBoxAtt.BackColor = System.Drawing.SystemColors.Info;
            this.richTextBoxAtt.Location = new System.Drawing.Point(17, 236);
            this.richTextBoxAtt.Name = "richTextBoxAtt";
            this.richTextBoxAtt.ReadOnly = true;
            this.richTextBoxAtt.Size = new System.Drawing.Size(147, 140);
            this.richTextBoxAtt.TabIndex = 6;
            this.richTextBoxAtt.Text = "";
            // 
            // Save
            // 
            this.Save.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Save.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Save.Location = new System.Drawing.Point(12, 583);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Save.TabIndex = 3;
            this.Save.Text = "Save";
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Close
            // 
            this.Close.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Close.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Close.Location = new System.Drawing.Point(193, 583);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(75, 23);
            this.Close.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Close.TabIndex = 1;
            this.Close.Text = "Close";
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // ResultText
            // 
            this.ResultText.BackColor = System.Drawing.SystemColors.Window;
            this.ResultText.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResultText.ForeColor = System.Drawing.Color.Black;
            this.ResultText.Location = new System.Drawing.Point(0, 0);
            this.ResultText.Name = "ResultText";
            this.ResultText.ReadOnly = true;
            this.ResultText.Size = new System.Drawing.Size(553, 568);
            this.ResultText.TabIndex = 0;
            this.ResultText.Text = "";
            this.ResultText.TextChanged += new System.EventHandler(this.ResultText_TextChanged);
            // 
            // ResultForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 618);
            this.Controls.Add(this.panelEx1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(775, 656);
            this.MinimumSize = new System.Drawing.Size(586, 656);
            this.Name = "ResultForm";
            this.Text = "ResultForm";
            this.Load += new System.EventHandler(this.ResultFormLoad);
            this.Resize += new System.EventHandler(this.GetSize);
            this.panelEx1.ResumeLayout(false);
            this.groupPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.PanelEx panelEx1;
        private DevComponents.DotNetBar.ButtonX Save;
        private DevComponents.DotNetBar.ButtonX Close;
        public System.Windows.Forms.RichTextBox ResultText;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.ButtonX OK;
        private DevComponents.DotNetBar.Controls.ComboBoxEx DataType;
        private DevComponents.DotNetBar.Controls.ComboBoxEx ObjectType;
        private DevComponents.DotNetBar.ButtonX getatt;
        private System.Windows.Forms.RichTextBox richTextBoxAtt;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.ButtonX remove;
        private DevComponents.DotNetBar.ButtonX addobject;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX Table;
        private DevComponents.DotNetBar.Controls.TextBoxX NameTable;
        private DevComponents.DotNetBar.Controls.TextBoxX Attributename;
        private DevComponents.DotNetBar.ButtonX Clear;
    }
}