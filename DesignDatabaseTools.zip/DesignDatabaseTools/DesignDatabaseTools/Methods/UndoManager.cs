﻿

using System.Collections.Generic;
using DesignDatabaseTools.Command;
using System.Windows.Forms;

namespace DesignDatabaseTools.Methods
{
	
	internal class UndoManager
	{
		#region Class Members
		//private Layers layers;

		private List<Command.Command> historyList;
		private int nextUndo;
        DrawArea drawarea;
		#endregion  Class Members

		#region Constructor
		public UndoManager(DrawArea area)
		{
            this.drawarea = area;
			ClearHistory();
		}
		#endregion Constructor

		#region Properties
		
		public bool CanUndo
		{
			get
			{
				// If the NextUndo pointer is -1, no commands to undo
				if (nextUndo < 0 ||
					nextUndo > historyList.Count - 1) // precaution
				{
					return false;
				}

				return true;
			}
		}

		
		public bool CanRedo
		{
			get
			{
				// If the NextUndo pointer points to the last item, no commands to redo
				if (nextUndo == historyList.Count - 1)
				{
					return false;
				}

				return true;
			}
		}
		#endregion Properties

		#region Public Functions
		
		public void ClearHistory()
		{
			historyList = new List<Command.Command>();
			nextUndo = -1;
		}


		
		public void AddCommandToHistory(Command.Command command)
		{
			// Purge history list
			TrimHistoryList();

            for (int i = 0; i < historyList.Count; i++)
            {
                if (historyList[i].flag == 2)
                {
                    historyList[i].Clear();
                }

            }
			// Add command and increment undo counter
            
			historyList.Add(command);
            //MessageBox.Show("hieu");
			nextUndo++;
		}

		
		public void Undo()
		{
			if (!CanUndo)
			{
				return;
			}

			// Get the Command object to be undone
			Command.Command command = historyList[nextUndo];
            
			// Execute the Command object's undo method
            command.Undo(drawarea);

			// Move the pointer up one item
			nextUndo--;
		}

	
		public void Redo()
		{
			if (!CanRedo)
			{
				return;
			}

			// Get the Command object to redo
			int itemToRedo = nextUndo + 1;

			Command.Command command = historyList[itemToRedo];

			// Execute the Command object
            command.Redo(drawarea);

			// Move the undo pointer down one item
			nextUndo++;
		}
		#endregion Public Functions

		#region Private Functions
		private void TrimHistoryList()
		{
			
			if (historyList.Count == 0)
			{
				return;
			}

			// Exit if NextUndo points to last item on the list
			if (nextUndo == historyList.Count - 1)
			{
				return;
			}
            
			// Purge all items below the NextUndo pointer
            //MessageBox.Show(historyList.Count.ToString());
            //MessageBox.Show(nextUndo.ToString());
            
			for (int i = historyList.Count-1; i > nextUndo; i--)
			{

                historyList[i].Clear();
				historyList.RemoveAt(i);
			}

            
		}
		#endregion
	}
}