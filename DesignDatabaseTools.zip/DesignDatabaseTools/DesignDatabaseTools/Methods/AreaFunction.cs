﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

using DesignDatabaseTools.MainFuction;
using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Methods
{
    class AreaFunction
    {
        public void AssignArea(GraphicsList graphics,DrawArea area)
        {
            List <DrawObject.DrawObject> listobject = graphics.GetListObject();
            foreach (DrawObject.DrawObject obj in listobject)
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.AssociationLine:
                    case DrawObject.DrawObject.ObjectType.Aggernation:
                    case DrawObject.DrawObject.ObjectType.Composition:
                    case DrawObject.DrawObject.ObjectType.Generalization:
                    case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                        DrawAssociation a = (DrawAssociation)obj;
                        a.Area = area;
                        break;
                    case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                        DrawExtraAssociation ex = (DrawExtraAssociation)obj;
                        ex.Area = area;
                        break;
                    case DrawObject.DrawObject.ObjectType.Binary:
                        DrawBinary b = (DrawBinary)obj;
                        b.Area = area;
                        break;
                    case DrawObject.DrawObject.ObjectType.Nary:
                        DrawNary n = (DrawNary)obj;
                        n.Area = area;
                        break;
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass c = (DrawClass)obj;
                        c.Area = area;
                        c.set_connected_association();
                        break;
                    case DrawObject.DrawObject.ObjectType.RecurcyLine:
                        DrawRecurcyLine l = (DrawRecurcyLine)obj;
                        l.Area = area;
                        break;
                    
                }
            }
        }
    }
}
