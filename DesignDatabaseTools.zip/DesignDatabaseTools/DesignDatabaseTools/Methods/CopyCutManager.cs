﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

using DesignDatabaseTools.DrawObject;
using DesignDatabaseTools.Tools;

namespace DesignDatabaseTools.Methods
{
    class CopyCutManager  
    {
        ToolReGraphic ReGraphicManager;
        
        DrawArea drawarea;
        bool canpaste=false;

        public CopyCutManager()
		{
            ReGraphicManager = new ToolReGraphic();
		}

        public DrawArea Area
        {
            get { return drawarea; }
            set { drawarea = value; }
        }


        public bool CanPaste
        {
            get
            { 
                return canpaste;
            }
            set
            {
                canpaste = value;
            }
        }

        public void Copy()
        {
            ReGraphicManager.List_Copy = drawarea.Graphics.ListSelected();

            if (ReGraphicManager.List_Copy != null)
            {
                ReGraphicManager.List_Cut = null;
                canpaste = true;
            }

            drawarea.Refresh();
        }

        public void Cut()
        {
            ReGraphicManager.List_Cut = drawarea.Graphics.ListSelected();
            //set hide
            drawarea.Graphics.HideSelected();
            SetHide(drawarea,true);
           // MessageBox.Show(ReGraphicManager.List_Cut.Count.ToString());

            if (ReGraphicManager.List_Cut != null)
            {
                ReGraphicManager.List_Copy = null;
                canpaste = true;
            }
            ReGraphicManager.OldArea = drawarea;
            drawarea.Refresh();
        }

        public void Paste()
        {
            //TODO: ham ve them graphic trong listcopy va ve lai trong listcut

            if (ReGraphicManager.List_Copy != null)
            {
                ReGraphicManager.CopyManager(Area);
            }

            if (ReGraphicManager.List_Cut != null)
            {
                
                ReGraphicManager.CutManager(Area);
                
            }
          
        }

        public void SetHide(DrawArea area,bool flag)
        {
            foreach (DrawObject.DrawObject obj in area.Graphics.GetListObject())
            {
                if (obj.Hide)
                {
                    switch (obj.ObjType)
                    {
                        case DrawObject.DrawObject.ObjectType.AssociationLine:
                        case DrawObject.DrawObject.ObjectType.Generalization:
                        case DrawObject.DrawObject.ObjectType.Composition:
                        case DrawObject.DrawObject.ObjectType.Aggernation:
                        case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                            DrawAssociation ass = (DrawAssociation)obj;
                            if (ass.mul_left != null) ass.mul_left.Hide = flag;
                            if (ass.mul_right != null) ass.mul_right.Hide = flag;
                            if (ass.RoleName != null) ass.RoleName.Hide = flag;
                            if (ass.role_left_tri != null) ass.role_left_tri.Hide = flag;
                            if (ass.role_right_tri != null) ass.role_right_tri.Hide = flag;
                            break;
                        case DrawObject.DrawObject.ObjectType.Class:
                        case DrawObject.DrawObject.ObjectType.AbstractClass:
                            DrawClass c = (DrawClass)obj;
                            if (c.Recurcys != null)
                            {
                                if (c.Recurcys.mul1 != null) c.Recurcys.mul1.Hide = flag;
                                if (c.Recurcys.mul2 != null) c.Recurcys.mul2.Hide = flag;
                                if (c.Recurcys.RoleName != null) c.Recurcys.RoleName.Hide = flag;
                                c.Recurcys.Hide = flag;
                                
                            }
                            break;
                        case DrawObject.DrawObject.ObjectType.Binary:
                            DrawBinary b = (DrawBinary)obj;
                            if (b.list_mul != null)
                            {
                                foreach (DrawText t in b.list_mul)
                                {
                                    t.Hide = flag;
                                }
                            }
                            break;
                        case DrawObject.DrawObject.ObjectType.Nary:
                            DrawNary n = (DrawNary)obj;
                            if (n.list_mul != null)
                            {
                                foreach (DrawText t in n.list_mul)
                                {
                                    t.Hide = flag;
                                }
                            }
                            break;
                        case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                            DrawExtraAssociation ex = (DrawExtraAssociation)obj;
                            if (ex.mul_left != null) ex.mul_left.Hide = flag;
                            if (ex.mul_right != null) ex.mul_right.Hide = flag;
                            if (ex.RoleName != null) ex.RoleName.Hide = flag;
                            if (ex.role_left_tri != null) ex.role_left_tri.Hide = flag;
                            if (ex.role_right_tri != null) ex.role_right_tri.Hide = flag;
                            break;
                        case DrawObject.DrawObject.ObjectType.text:
                            break;
                    }
                }
            }
        }

    }
}
