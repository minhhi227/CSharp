﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

using DesignDatabaseTools.MainFuction;
using DesignDatabaseTools.DrawObject;

namespace DesignDatabaseTools.Methods
{
    class SubFunction
    {
        #region Find point
        public List<double> ptrinhbac2(double pa, double pb, double pc)
        {
            List<double> nghiem = new List<double>();
            double x1 = (-pb + Math.Sqrt(Math.Pow(pb, 2) - 4 * pa * pc)) / (2 * pa);
            double x2 = (-pb - Math.Sqrt(Math.Pow(pb, 2) - 4 * pa * pc)) / (2 * pa);
            nghiem.Add(x1);
            nghiem.Add(x2);
            return nghiem;
        }
        public List<Point> GetPoint(Point start, Point end, int flag)
        {
            List<Point> result = new List<Point>();
            int a = end.X - start.X;
            int b = end.Y - start.Y;
            int c = 0;
            if (flag == 1)
            {
                //---------------------------------point 1---------------------------------------
                c = a * start.Y - b * start.X;
                double pa = Math.Pow(a, 2) + Math.Pow(b, 2);
                double pb = 2 * b * (c - a * end.Y) - 2 * end.X * Math.Pow(a, 2);
                double pc = Math.Pow(a, 2) * Math.Pow(end.X, 2) + Math.Pow((c - a * end.Y), 2) - 100 * Math.Pow(a, 2);
                //nghiem
                double nghiemx = 0;
                if (start.X <= end.X)
                {
                    nghiemx = ptrinhbac2(pa, pb, pc)[1];
                }
                else
                {
                    nghiemx = ptrinhbac2(pa, pb, pc)[0];
                }
                double nghiemy;
                if (a == 0)
                {
                    if (start.Y <= end.Y)
                    {
                        nghiemy = end.Y - 10;
                    }
                    else
                    {
                        nghiemy = end.Y + 10;
                    }
                }
                else
                {
                    nghiemy = (b * nghiemx + c) / a;
                }
                result.Add(end);
                Point newend = new Point(Convert.ToInt32(nghiemx), Convert.ToInt32(nghiemy));

                //--------------------------------point 2 & 3-----------------------------------------
                c = -(a * newend.X + b * newend.Y);
                double pa2 = Math.Pow(a, 2) + Math.Pow(b, 2);
                double pb2 = 2 * a * (c + b * newend.Y) - 2 * newend.X * Math.Pow(b, 2);
                double pc2 = Math.Pow(b, 2) * Math.Pow(newend.X, 2) + Math.Pow((c + b * newend.Y), 2) - 100 * Math.Pow(b, 2);

                double nghiemx1 = ptrinhbac2(pa2, pb2, pc2)[0];
                double nghiemx2 = ptrinhbac2(pa2, pb2, pc2)[1];
                double nghiemy1;
                double nghiemy2;
                if (b == 0)
                {
                    nghiemy1 = end.Y - 10;
                    nghiemy2 = end.Y + 10;
                }
                else
                {
                    nghiemy1 = -(a * nghiemx1 + c) / b;
                    nghiemy2 = -(a * nghiemx2 + c) / b;
                }

                result.Add(new Point(Convert.ToInt32(nghiemx1), Convert.ToInt32(nghiemy1)));
                result.Add(new Point(Convert.ToInt32(nghiemx2), Convert.ToInt32(nghiemy2)));

            }
            else
            {
                //---------------------------------point 1---------------------------------------
                c = a * start.Y - b * start.X;
                double paa = Math.Pow(a, 2) + Math.Pow(b, 2);
                double pbb = 2 * b * (c - a * start.Y) - 2 * start.X * Math.Pow(a, 2);
                double pcc = Math.Pow(a, 2) * Math.Pow(start.X, 2) + Math.Pow((c - a * start.Y), 2) - 100 * Math.Pow(a, 2);
                //nghiem
                double nghiemx1 = 0;
                if (start.X <= end.X)
                {
                    nghiemx1 = ptrinhbac2(paa, pbb, pcc)[0];
                }
                else
                {
                    nghiemx1 = ptrinhbac2(paa, pbb, pcc)[1];
                }
                double nghiemy1;
                if (a == 0)
                {
                    if (start.Y <= end.Y)
                    {
                        nghiemy1 = start.Y + 10;
                    }
                    else
                    {
                        nghiemy1 = start.Y - 10;
                    }
                }
                else
                {
                    nghiemy1 = (b * nghiemx1 + c) / a;
                }
                Point newstart = new Point(Convert.ToInt32(nghiemx1), Convert.ToInt32(nghiemy1));
                result.Add(start);

                //---------------------------------point 4---------------------------------------
                c = a * newstart.Y - b * newstart.X;
                double pa1 = Math.Pow(a, 2) + Math.Pow(b, 2);
                double pb1 = 2 * b * (c - a * newstart.Y) - 2 * newstart.X * Math.Pow(a, 2);
                double pc1 = Math.Pow(a, 2) * Math.Pow(newstart.X, 2) + Math.Pow((c - a * newstart.Y), 2) - 100 * Math.Pow(a, 2);
                //nghiem
                double nghiemx2 = 0;
                if (start.X <= end.X)
                {
                    nghiemx2 = ptrinhbac2(pa1, pb1, pc1)[0];
                }
                else
                {
                    nghiemx2 = ptrinhbac2(pa1, pb1, pc1)[1];
                }
                double nghiemy2;
                if (a == 0)
                {
                    if (start.Y <= end.Y)
                    {
                        nghiemy2 = newstart.Y + 10;
                    }
                    else
                    {
                        nghiemy2 = newstart.Y - 10;
                    }
                }
                else
                {
                    nghiemy2 = (b * nghiemx2 + c) / a;
                }
              
                result.Add(new Point(Convert.ToInt32(nghiemx2), Convert.ToInt32(nghiemy2)));
                //--------------------------------point 2 & 3-----------------------------------------

                c = -(a * newstart.X + b * newstart.Y);
                double pa2 = Math.Pow(a, 2) + Math.Pow(b, 2);
                double pb2 = 2 * a * (c + b * newstart.Y) - 2 * newstart.X * Math.Pow(b, 2);
                double pc2 = Math.Pow(b, 2) * Math.Pow(newstart.X, 2) + Math.Pow((c + b * newstart.Y), 2) - 100 * Math.Pow(b, 2);

                double nghiemx3 = ptrinhbac2(pa2, pb2, pc2)[0];
                double nghiemx4 = ptrinhbac2(pa2, pb2, pc2)[1];
                double nghiemy3;
                double nghiemy4;
                if (b == 0)
                {
                    nghiemy3 = newstart.Y - 10;
                    nghiemy4 = newstart.Y + 10;
                }
                else
                {
                    nghiemy3 = -(a * nghiemx3 + c) / b;
                    nghiemy4 = -(a * nghiemx4 + c) / b;
                }

                result.Add(new Point(Convert.ToInt32(nghiemx3), Convert.ToInt32(nghiemy3)));
                result.Add(new Point(Convert.ToInt32(nghiemx4), Convert.ToInt32(nghiemy4)));
            }
            return result;
        }

        public List<Point> GetPointFormRect(Rectangle rect)
        {
            List<Point> result = new List<Point>();

            Point p1 = new Point(rect.Location.X + rect.Size.Width / 2, rect.Location.Y);
            Point p2 = new Point(rect.Location.X, rect.Location.Y + rect.Size.Height / 2);
            Point p3 = new Point(rect.Location.X + rect.Size.Width / 2, rect.Location.Y + rect.Size.Height);
            Point p4 = new Point(rect.Location.X + rect.Size.Width, rect.Location.Y + rect.Size.Height / 2);

            result.Add(p1);
            result.Add(p2);
            result.Add(p3);
            result.Add(p4);
            return result;
        }

        public Point GetPointRect(Point start, Point end,int dodai)
        {
            
            int a = end.X - start.X;
            int b = end.Y - start.Y;
            int c = 0;
              
                c = a * start.Y - b * start.X;
                double pa = Math.Pow(a, 2) + Math.Pow(b, 2);
                double pb = 2 * b * (c - a * end.Y) - 2 * end.X * Math.Pow(a, 2);
                double pc = Math.Pow(a, 2) * Math.Pow(end.X, 2) + Math.Pow((c - a * end.Y), 2) - Math.Pow(dodai,2) * Math.Pow(a, 2);
                //nghiem
                double nghiemx = 0;
                if (start.X <= end.X)
                {
                    nghiemx = ptrinhbac2(pa, pb, pc)[0];
                }
                else
                {
                    nghiemx = ptrinhbac2(pa, pb, pc)[1];
                }
                double nghiemy;
                if (a == 0)
                {
                    if (start.Y <= end.Y)
                    {
                        nghiemy = end.Y + dodai;
                    }
                    else
                    {
                        nghiemy = end.Y - dodai;
                    }
                }
                else
                {
                    nghiemy = (b * nghiemx + c) / a;
                }


                return new Point(Convert.ToInt32(nghiemx), Convert.ToInt32(nghiemy));
        }
        #endregion

        #region Others Function

        public List<string> DevideString(string str)
        {
            List<string> result = new List<string>();
            Array strtemp = str.ToCharArray();
            int start = 0;
            int end = 0;
            for (int i = 0; i < strtemp.Length; i++)
            {
                end = i;
                if (strtemp.GetValue(i) == "\n")
                {
                   string t = str.Substring(start, end - start);
                   result.Add(t);
                   start = i+1;
                }
            }

            return result;
                 
        }

        public List<Attributes> ConvertAttributes(List<string> Liststr)
        {
            List<Attributes> result = new List<Attributes>();
            foreach (string temp in Liststr)
            {
                Attributes att = new Attributes();
              //  att.AttName = temp;
                //apply AttType
                result.Add(att);
            }
            return result;

        }
        #endregion

        #region Connect Point
        //-----------------------connect Point---------------------------------

        public List<Point> GetconnectPoint(Rectangle r)
        {
            List<Point> result = new List<Point>();
            //tren
            Point topcenter = new Point(r.X + r.Width / 2, r.Y);
            Point p1 = new Point(r.X + r.Width / 4, r.Y);
            Point p2 = new Point(r.X + r.Width * 3 / 4, r.Y);
            //trai
            Point leftcenter = new Point(r.X, r.Y + r.Height / 2);
            Point p3 = new Point(r.X, r.Y+r.Height / 4);
            Point p4 = new Point(r.X, r.Y + r.Height * 3 / 4);
            //duoi
            Point bottomcenter = new Point(topcenter.X, r.Y + r.Height);
            Point p5 = new Point(p1.X, r.Y + r.Height);
            Point p6 = new Point(p2.X,r.Y+ r.Height);
            //phai
            Point rightcenter = new Point(r.X + r.Width, leftcenter.Y);
            Point p7 = new Point(r.X + r.Width, p3.Y);
            Point p8 = new Point(r.X + r.Width, p4.Y);
            //center
            Point center = new Point(r.X + r.Width / 2, r.Y + r.Height / 2);

            result.Add(topcenter);
            result.Add(p1);
            result.Add(p2);
            result.Add(leftcenter);
            result.Add(p3);
            result.Add(p4);
            result.Add(bottomcenter);
            result.Add(p5);
            result.Add(p6);
            result.Add(rightcenter);
            result.Add(p7);
            result.Add(p8);
            result.Add(center);

            return result;
        }

        public List<ConnectPoint> ListConnectPoint(Rectangle r)
        {
            List<ConnectPoint> result = new List<ConnectPoint>();
            List<Point> list_point = GetconnectPoint(r);
            foreach (Point p in list_point)
            {
                ConnectPoint connect_point = new ConnectPoint();
                connect_point.point = p;
                connect_point.connect_area = new Rectangle(p.X - 3, p.Y - 3, 7, 7);
                result.Add(connect_point);
            }
            return result;
        }

        public int CheckDiemsang(List<ConnectPoint> listpoint, Point pnguon)
        {

            //tra ve diem dc connect
            for (int i=0;i<listpoint.Count;i++)
            {
                if (CheckPointInRect(pnguon,listpoint[i].connect_area))  return i; 
            }

            return -1;
        }

        public void ResetConnectAssociation(DrawObject.DrawObject obj,List<ConnectPoint> list_connect)
        {
            foreach (ConnectPoint p in list_connect)
            {
                if (p.association.Count > 0)
                {
                    foreach(DrawObject.DrawObject o in p.association)
                    {
                        if (o == obj)
                        {
                            p.association.Remove(o);
                            return;
                        }
                    }
                }
            }

        }
        public void reset_connect(DrawArea area)
        {
            foreach (DrawObject.DrawObject obj in area.Graphics.GetListObject())
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass c = (DrawClass)obj;
                        c.connect = false;
                        break;
                    case DrawObject.DrawObject.ObjectType.AssociationLine:
                        DrawAssociation ass = (DrawAssociation) obj;
                        ass.connect = false;
                        break;
                }
            }
                
        }
        public void get_association_class(DrawAssociation ass,List<DrawObject.DrawObject> GraphicList)
        {
            foreach (DrawObject.DrawObject obj in GraphicList)
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass c = (DrawClass)obj;
                        if (!check_exist_association(ass, c.ListConnectPoint))
                        {
                            if (CheckPointInRect(ass.startPoint, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, ass.startPoint);
                                if (c.diemsang >= 0)
                                {
                                    ass.start_flag = c.ID;
                                    ass.start_class = c;
                                    c.ListConnectPoint[c.diemsang].association.Add(ass);

                                }

                            }
                            else if (CheckPointInRect(ass.endPoint, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, ass.endPoint);
                                if (c.diemsang >= 0)
                                {
                                    ass.end_flag = c.ID;
                                    ass.end_class = c;
                                    c.ListConnectPoint[c.diemsang].association.Add(ass);

                                }

                            }

                        }
                        else
                        {

                           if (ass.start_flag == c.ID)
                            {
                                 if (CheckDiemsang(c.ListConnectPoint, ass.startPoint) == -1 )
                                 {
                                    ResetConnectAssociation(ass, c.ListConnectPoint);
                                    ass.start_class = null;
                                    ass.start_flag = -1;
                                    c.diemsang = -1;
                                 }
                                if(!CheckPointInRect(ass.startPoint, c.Rectangle))
                                {
                                    c.connect = false;
                                }
                            }
                            else if(ass.end_flag==c.ID)
                            {
                                if (CheckDiemsang(c.ListConnectPoint, ass.endPoint) == -1)
                                    {
                                        ResetConnectAssociation(ass, c.ListConnectPoint);
                                        ass.end_class = null;
                                        ass.end_flag = -1;
                                        c.diemsang = -1;
                                    }
                                if (!CheckPointInRect(ass.endPoint, c.Rectangle))
                                {
                                    c.connect = false;
                                }
                            }

                          
                        }
                        break;
                }
            }
        }

        public void get_binary_class(DrawBinary binary, List<DrawObject.DrawObject> GraphicList)
        {
            foreach (DrawObject.DrawObject obj in GraphicList)
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass c = (DrawClass)obj;
                        if (!check_exist_association(binary, c.ListConnectPoint))
                        {
                            if (CheckPointInRect(binary.p1, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, binary.p1);
                                if (c.diemsang >= 0)
                                {
                                        binary.p1_flag = c.ID;
                                        binary.p1_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(binary);

                                }

                            }
                            else if (CheckPointInRect(binary.p2, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, binary.p2);
                                if (c.diemsang >= 0)
                                {
                                        binary.p2_flag = c.ID;
                                        binary.p2_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(binary);
                                    
                                }

                            }
                            else if (CheckPointInRect(binary.p3, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, binary.p3);
                                if (c.diemsang >= 0)
                                {
                                        binary.p3_flag = c.ID;
                                        binary.p3_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(binary);
                                    
                                }

                            }
                        }
                        else
                        {

                            if (binary.p1_flag == c.ID)
                            {
                                if (CheckDiemsang(c.ListConnectPoint, binary.p1) == -1)
                                {
                                    ResetConnectAssociation(binary, c.ListConnectPoint);
                                    binary.p1_flag = -1;
                                    c.diemsang = -1;
                                    binary.p1_class = null;
                                }
                                if (!CheckPointInRect(binary.p1, c.Rectangle) )
                                {
                                    c.connect = false;
                                }
                                
                            }
                            else if (binary.p2_flag == c.ID)
                            {
                                if(CheckDiemsang(c.ListConnectPoint, binary.p2) == -1)
                                {
                                    ResetConnectAssociation(binary, c.ListConnectPoint);
                                    binary.p2_class = null;
                                    c.diemsang = -1;
                                    binary.p2_flag = -1;
                                }
                                if(!CheckPointInRect(binary.p2, c.Rectangle))
                                {
                                     c.connect = false;
                                }
                            }
                            else if (binary.p3_flag == c.ID)
                            {
                                if(CheckDiemsang(c.ListConnectPoint, binary.p3) == -1)
                                {
                                    ResetConnectAssociation(binary, c.ListConnectPoint);
                                    binary.p3_class = null;
                                    c.diemsang = -1;
                                    binary.p3_flag = -1;
                                }
                                if(!CheckPointInRect(binary.p3,c.Rectangle))
                                {
                                    c.connect = false;
                                }
                            }

                        }
                        break;
                }
            }
        }

        public void get_nary_class(DrawNary nary, List<DrawObject.DrawObject> GraphicList)
        {
            foreach (DrawObject.DrawObject obj in GraphicList)
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass c = (DrawClass)obj;
                        if (!check_exist_association(nary, c.ListConnectPoint))
                        {
                            if (CheckPointInRect(nary.p1, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, nary.p1);
                                if (c.diemsang >= 0)
                                {
                                        nary.p1_flag = c.ID;
                                        nary.p1_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(nary);

                                }

                            }
                            else if (CheckPointInRect(nary.p2, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, nary.p2);
                                if (c.diemsang >= 0)
                                {
                                        nary.p2_flag = c.ID;
                                        nary.p2_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(nary);
                                    
                                }

                            }
                            else if (CheckPointInRect(nary.p3, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, nary.p3);
                                if (c.diemsang >= 0)
                                {  
                                        nary.p3_flag = c.ID;
                                        nary.p3_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(nary);
                                   
                                }

                            }
                            else if (CheckPointInRect(nary.p4, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, nary.p4);
                                if (c.diemsang >= 0)
                                {
                                        nary.p4_flag = c.ID;
                                        nary.p4_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(nary);
                                   
                                }

                            }
                            
                        }
                        else
                        {
                            if (nary.p1_flag == c.ID)
                            {
                                if(CheckDiemsang(c.ListConnectPoint, nary.p1) == -1)
                                {
                                    ResetConnectAssociation(nary, c.ListConnectPoint);
                                    nary.p1_flag = -1;
                                    nary.p1_class = null;
                                    c.diemsang = -1;
                                }
                                if(!CheckPointInRect(nary.p1, c.Rectangle))
                                {
                                    c.connect = false;
                                }
                            }
                            else if (nary.p2_flag == c.ID)
                            {
                                if(CheckDiemsang(c.ListConnectPoint, nary.p2) == -1)
                                {
                                    ResetConnectAssociation(nary, c.ListConnectPoint);
                                    nary.p2_class = null;
                                    nary.p2_flag = -1;
                                    c.diemsang = -1;
                                }
                                if(!CheckPointInRect(nary.p2, c.Rectangle))
                                {
                                    c.connect = false;
                                }
                            }
                            else if (nary.p3_flag == c.ID)
                            {
                                if(CheckDiemsang(c.ListConnectPoint, nary.p3) == -1)
                                {
                                    ResetConnectAssociation(nary, c.ListConnectPoint);
                                    nary.p3_class = null;
                                    nary.p3_flag = -1;
                                    c.diemsang = -1;
                                }
                                if(!CheckPointInRect(nary.p3, c.Rectangle ))
                                {
                                    c.connect = false;
                                }
                            }
                            else if (nary.p4_flag == c.ID)
                            {
                                if(CheckDiemsang(c.ListConnectPoint, nary.p4) == -1)
                                {
                                    ResetConnectAssociation(nary, c.ListConnectPoint);
                                    nary.p4_flag = -1;
                                    nary.p4_class = null;
                                    c.diemsang = -1;
                                }
                                if(!CheckPointInRect(nary.p4,c.Rectangle))
                                {
                                    c.connect = false;
                                }
                            }

                        }
                        break;
                }
            }
        }

        public void get_exassociation_class(DrawExtraAssociation exass, List<DrawObject.DrawObject> GraphicList)
        {
            foreach (DrawObject.DrawObject obj in GraphicList)
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.Class:
                    case DrawObject.DrawObject.ObjectType.AbstractClass:
                        DrawClass c = (DrawClass)obj;
                        if (!check_exist_association(exass, c.ListConnectPoint))
                        {
                            if (CheckPointInRect(exass.startPoint, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, exass.startPoint);
                                if (c.diemsang >= 0)
                                {
                                        if (exass.end_flag == c.ID) exass.end_flag = -1;
                                        exass.start_flag = c.ID;
                                        exass.start_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(exass);
                                    
                                }


                            }
                            else if (CheckPointInRect(exass.endPoint, c.Rectangle))
                            {
                                c.connect = true;
                                c.diemsang = CheckDiemsang(c.ListConnectPoint, exass.endPoint);
                                if (c.diemsang >= 0)
                                {
                                        if (exass.start_flag == c.ID) exass.start_flag = -1;
                                        exass.end_flag = c.ID;
                                        exass.end_class = c;
                                        c.ListConnectPoint[c.diemsang].association.Add(exass);
                                   
                                }

                            }
                            
                        }
                        else
                        {
                            if (exass.start_flag == c.ID)
                            {
                                if (CheckDiemsang(c.ListConnectPoint, exass.startPoint) == -1)
                                {
                                    ResetConnectAssociation(exass, c.ListConnectPoint);
                                    exass.start_class = null;
                                    exass.start_flag = -1;
                                    c.diemsang = -1;
                                }
                                if (!CheckPointInRect(exass.startPoint, c.Rectangle))
                                {
                                    c.connect = false;
                                }
                            }
                            else if (exass.end_flag == c.ID)
                            {
                                if (CheckDiemsang(c.ListConnectPoint, exass.endPoint) == -1)
                                {
                                    ResetConnectAssociation(exass, c.ListConnectPoint);
                                    exass.end_class = null;
                                    exass.end_flag = -1;
                                    c.diemsang = -1;
                                }
                                if (!CheckPointInRect(exass.endPoint, c.Rectangle))
                                {
                                    c.connect = false;
                                }
                            }
                        }
                        break;
                }
            }
        }

        public void get_asso_class(DrawAssociation asso, List<DrawObject.DrawObject> GraphicList)
        {
            foreach (DrawObject.DrawObject obj in GraphicList)
            {
                switch (obj.ObjType)
                {
                    case DrawObject.DrawObject.ObjectType.AssociationLine:
                        DrawAssociation ass = (DrawAssociation)obj;
                        if (ass.AssClass==null)
                        {
                            if (check_point_in_line(asso.startPoint,ass))
                            {
                                ass.connect = true;
                                ass.diemsang = CheckDiemsang(ass.ListConnectPoint, asso.startPoint);
                                if (ass.diemsang >= 0)
                                {
                                    asso.start_flag = ass.ID;
                                    ass.AssClass =(DrawAssociationClass) asso;
                                   // ass.AssClass.Ass = ass;
                                }
                            }
                            else if (check_point_in_line(asso.endPoint, ass))
                            {
                                ass.connect = true;
                                ass.diemsang = CheckDiemsang(ass.ListConnectPoint, asso.endPoint);
                                if (ass.diemsang >= 0)
                                {
                                    asso.end_flag = ass.ID;
                                    ass.AssClass = (DrawAssociationClass)asso;
                                   // ass.AssClass.Ass = ass;
                                }

                            }
                        }
                        else
                        {
                            if (asso.start_flag == ass.ID)
                            {
                                if (CheckDiemsang(ass.ListConnectPoint, asso.startPoint) == -1)
                                {
                                    ass.AssClass = null;
                                    //ass.AssClass.Ass = null;
                                    asso.start_flag = -1;
                                    ass.diemsang = -1;
                                }
                                if (!check_point_in_line(asso.startPoint, ass))
                                {
                                    ass.connect = false;
                                }
                            }
                            else if (asso.end_flag == ass.ID)
                            {
                                if (CheckDiemsang(ass.ListConnectPoint, asso.endPoint) == -1)
                                {
                                    ass.AssClass = null;
                                    //ass.AssClass.Ass = null;
                                    asso.end_flag = -1;
                                    ass.diemsang = -1;
                                }
                                if (!check_point_in_line(asso.endPoint, ass))
                                {
                                    ass.connect = false;
                                }
                            }
                        }
                        break;
                    case DrawObject.DrawObject.ObjectType.RecurcyLine:
                        DrawRecurcyLine rec = (DrawRecurcyLine)obj;
                       
                        if (rec.AssClass == null)
                        {
                            if (check_point_in_line(asso.startPoint, rec))
                            {
                                //MessageBox.Show("hieu");
                                rec.connect = true;
                                rec.diemsang = CheckDiemsang(rec.ListConnectPoint, asso.startPoint);
                                if (rec.diemsang >= 0)
                                {
                                    asso.start_flag = rec.ID;
                                    rec.AssClass = (DrawAssociationClass)asso;
                                    // ass.AssClass.Ass = ass;
                                }

                            }
                            else if (check_point_in_line(asso.endPoint, rec))
                            {
                                rec.connect = true;
                                rec.diemsang = CheckDiemsang(rec.ListConnectPoint, asso.endPoint);
                                if (rec.diemsang >= 0)
                                {
                                    asso.end_flag = rec.ID;
                                    rec.AssClass = (DrawAssociationClass)asso;
                                    // ass.AssClass.Ass = ass;
                                }

                            }
                        }
                        else
                        {
                            if (asso.start_flag == rec.ID)
                            {
                                if (CheckDiemsang(rec.ListConnectPoint, asso.startPoint) == -1)
                                {
                                    rec.AssClass = null;
                                    //ass.AssClass.Ass = null;
                                    asso.start_flag = -1;
                                    rec.diemsang = -1;
                                }
                                if (!check_point_in_line(asso.startPoint, rec))
                                {
                                    rec.connect = false;
                                }
                            }
                            else if (asso.end_flag == rec.ID)
                            {
                                if (CheckDiemsang(rec.ListConnectPoint, asso.endPoint) == -1)
                                {
                                    rec.AssClass = null;
                                    //ass.AssClass.Ass = null;
                                    asso.end_flag = -1;
                                    rec.diemsang = -1;
                                }
                                if (!check_point_in_line(asso.endPoint, rec))
                                {
                                    rec.connect = false;
                                }
                            }
                        }
                        break;

                    case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                        DrawExtraAssociation ex = (DrawExtraAssociation)obj;
                        if (ex.AssClass==null)
                        {
                            if (check_point_in_line(asso.startPoint,ex))
                            {
                                ex.connect = true;
                                ex.diemsang = CheckDiemsang(ex.ListConnectPoint, asso.startPoint);
                                if (ex.diemsang >= 0)
                                {
                                    asso.start_flag = ex.ID;
                                    ex.AssClass =(DrawAssociationClass) asso;

                                }


                            }
                            else if (check_point_in_line(asso.endPoint, ex))
                            {
                                ex.connect = true;
                                ex.diemsang = CheckDiemsang(ex.ListConnectPoint, asso.endPoint);
                                if (ex.diemsang >= 0)
                                {
                                    asso.end_flag = ex.ID;
                                    ex.AssClass = (DrawAssociationClass)asso;

                                }

                            }
                        }
                        else
                        {
                            if (asso.start_flag == ex.ID)
                            {
                                if (CheckDiemsang(ex.ListConnectPoint, asso.startPoint) == -1)
                                {
                                    ex.AssClass = null;
                                    asso.start_flag = -1;
                                    ex.diemsang = -1;
                                }
                                if (!check_point_in_line(asso.startPoint, ex))
                                {
                                    ex.connect = false;
                                }
                            }
                            else if (asso.end_flag == ex.ID)
                            {
                                if (CheckDiemsang(ex.ListConnectPoint, asso.endPoint) == -1)
                                {
                                    ex.AssClass = null;
                                    asso.end_flag = -1;
                                    ex.diemsang = -1;
                                }
                                if (!check_point_in_line(asso.endPoint, ex))
                                {
                                    ex.connect = false;
                                }
                            }
                        }
                        break;
                    case DrawObject.DrawObject.ObjectType.Binary:
                        DrawBinary binary = (DrawBinary)obj;
                        if (binary.AssClass == null)
                        {
                            //MessageBox.Show(binary.ListConnectPoint.Count.ToString());
                            binary.diemsang = CheckDiemsang(binary.ListConnectPoint, asso.startPoint);
                            if (binary.diemsang >= 0)
                            {
                                asso.start_flag = binary.ID;
                                binary.AssClass = (DrawAssociationClass)asso;
                            }
                            else
                            {
                                binary.diemsang = CheckDiemsang(binary.ListConnectPoint, asso.endPoint);
                                if (binary.diemsang >= 0)
                                {
                                    asso.end_flag = binary.ID;
                                    binary.AssClass = (DrawAssociationClass)asso;
                                }
                            }
                            
                        }
                        else
                        {
                            if (asso.start_flag == binary.ID)
                            {
                                if (CheckDiemsang(binary.ListConnectPoint, asso.startPoint) == -1)
                                {
                                    binary.AssClass = null;
                                    asso.start_flag = -1;
                                    binary.diemsang = -1;
                                }
                            }
                            else if (asso.end_flag == binary.ID)
                            {
                                if (CheckDiemsang(binary.ListConnectPoint, asso.endPoint) == -1)
                                {
                                    binary.AssClass = null;
                                    asso.end_flag = -1;
                                    binary.diemsang = -1;
                                }
                            }
                        }
                        break;
                        /*
                    case DrawObject.DrawObject.ObjectType.Nary:
                        DrawNary nary = (DrawNary)obj;
                        if (nary.AssClass == null)
                        {
                           nary.diemsang = CheckDiemsang(nary.ListConnectPoint, asso.startPoint);
                            if (nary.diemsang >= 0)
                            {
                                asso.start_flag = nary.ID;
                                nary.AssClass = (DrawAssociationClass)asso;

                            }
                            else
                            {
                                nary.diemsang = CheckDiemsang(nary.ListConnectPoint, asso.endPoint);
                                if (nary.diemsang >= 0)
                                {
                                    asso.end_flag = nary.ID;
                                    nary.AssClass = (DrawAssociationClass)asso;

                                }
                            }
                            
                        }
                        else
                        {
                            if (asso.start_flag == nary.ID)
                            {
                                if (CheckDiemsang(nary.ListConnectPoint, asso.startPoint) == -1)
                                {
                                    nary.AssClass = null;
                                    asso.start_flag = -1;
                                    nary.diemsang = -1;
                                }
                            }
                            else if (asso.end_flag == nary.ID)
                            {
                                if (CheckDiemsang(nary.ListConnectPoint, asso.endPoint) == -1)
                                {
                                    nary.AssClass = null;
                                    asso.end_flag = -1;
                                    nary.diemsang = -1;
                                }
                            }
                        }
                        break;
                          */

                }
            }
        }

        public void GetObjectConnectPoint(DrawObject.DrawObject objects, List<DrawObject.DrawObject> GraphicList)
        {
                            switch (objects.ObjType)
                            {
                                case DrawObject.DrawObject.ObjectType.AssociationLine:
                                case DrawObject.DrawObject.ObjectType.Aggernation:
                                case DrawObject.DrawObject.ObjectType.Composition:
                                case DrawObject.DrawObject.ObjectType.Generalization:
                                    DrawAssociation ass = (DrawAssociation)objects;
                                    get_association_class(ass, GraphicList);
                                        break;
                                case DrawObject.DrawObject.ObjectType.Binary:
                                    DrawBinary binary = (DrawBinary)objects;
                                    get_binary_class(binary, GraphicList);
                                    break;
                                case DrawObject.DrawObject.ObjectType.Nary:
                                    DrawNary nary = (DrawNary)objects;
                                    get_nary_class(nary, GraphicList);
                                    break;
                                case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                                    DrawExtraAssociation exass = (DrawExtraAssociation)objects;
                                    get_exassociation_class(exass, GraphicList);
                                    break;
                                case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                                    DrawAssociation asso = (DrawAssociation)objects;
                                    get_association_class(asso, GraphicList);
                                    get_asso_class(asso, GraphicList);
                                        break;
                            }
                        
              
        
        }

        public bool check_exist_association(DrawObject.DrawObject obj, List<ConnectPoint> list)
        {
            foreach (ConnectPoint cp in list)
            {
                foreach (DrawObject.DrawObject o in cp.association)
                {
                    if (o == obj) return true;
                }
            }
            return false;
        }
        

        #endregion

        #region Class & Association

        public bool CheckAssociationClass(DrawClass c)
        {
            List<ConnectPoint> list = c.ListConnectPoint;
            foreach (ConnectPoint cp in list )
            {
                foreach (DrawObject.DrawObject o in cp.association)
                {
                    if (o.ObjType== DrawObject.DrawObject.ObjectType.AssociationClassLine) return true;
                }
            }
            return false;
            

        }
        #endregion


        #region Multiplicity & Association

        public bool CheckPointInRect(Point p, Rectangle r)
        {
            //check 1 point trong 1 rectangle
            if (p.X >= r.X && p.X <= r.X + r.Width && p.Y >= r.Y && p.Y <= r.Y + r.Height)
            {
                return true;
            }
            return false;
        }

        public bool CheckNearPointInRect(Point p, Rectangle r)
        {
            //check 1 point trong 1 rectangle
            Rectangle rect = new Rectangle(p.X - 3, p.Y - 3, 7, 7);
            List<Point> list_point = new List<Point>();
            list_point.Add(rect.Location);
            list_point.Add(new Point(rect.X + rect.Width, rect.Y));
            list_point.Add(new Point(rect.X + rect.Width, rect.Y + rect.Height));
            list_point.Add(new Point(rect.X, rect.Y + rect.Height));
            foreach (Point point in list_point)
            {
                if (point.X >= r.X && point.X <= r.X + r.Width && point.Y >= r.Y && point.Y <= r.Y + r.Height)
                {
                    return true;
                }
            }

            return false;
        }

        #endregion

        #region Association class
        //association
        public List<Point> list_point_ass(Point start, Point end)
        {
            List<Point> list = new List<Point>();
            Point center = new Point((start.X + end.X) / 2, (start.Y + end.Y) / 2);
            Point center1 = new Point((start.X + center.X) / 2, (start.Y + center.Y) / 2);
            Point center2 = new Point((center.X + end.X) / 2, (center.Y + end.Y) / 2);
            Point center11 = new Point((start.X + center1.X) / 2, (start.Y + center1.Y) / 2);
            Point center21 = new Point((center2.X + center.X) / 2, (center2.Y + center.Y) / 2);
            Point center12 = new Point((center1.X + center.X) / 2, (center1.Y + center.Y) / 2);
            Point center22 = new Point((center2.X + end.X) / 2, (center2.Y + end.Y) / 2);

            list.Add(center);
            list.Add(center1);
            list.Add(center2);
            list.Add(center11);
            list.Add(center12);
            list.Add(center21);
            list.Add(center22);

            return list;
        }

        public List<ConnectPoint> ListConnectPointAss(Point start, Point end)
        {
            List<ConnectPoint> result = new List<ConnectPoint>();
            List<Point> list_point = list_point_ass(start, end);
            foreach (Point p in list_point)
            {
                ConnectPoint connect_point = new ConnectPoint();
                connect_point.point = p;
                connect_point.connect_area = new Rectangle(p.X - 3, p.Y - 3, 7, 7);
                result.Add(connect_point);
            }
            return result;
        }

        public List<ConnectPoint> SetConnectPointExtra(DrawExtraAssociation ex)
        {
            List<ConnectPoint> result = new List<ConnectPoint>();
            foreach (ConnectPoint p in ListConnectPointAss(ex.startPoint, ex.center2))
            {
                result.Add(p);
            }
            foreach (ConnectPoint p in ListConnectPointAss(ex.center1, ex.center2))
            {
                result.Add(p);
            }
            foreach (ConnectPoint p in ListConnectPointAss(ex.center1, ex.endPoint))
            {
                result.Add(p);
            }

            return result;
        }

        public List<ConnectPoint> SetConnectPointRec(DrawRecurcyLine rec)
        {
            List<ConnectPoint> result = new List<ConnectPoint>();
            List<Point> list = new List<Point>();


            Point center1 = new Point(rec.startPoint.X , (rec.startPoint.Y + rec.center1.Y) / 2);
            Point center2 = new Point((rec.center1.X + rec.center2.X) / 2, rec.center1.Y);
            Point center3 = new Point(rec.center2.X, (rec.center2.Y + rec.center3.Y) / 2);
            Point center4 = new Point((rec.center3.X +rec.center4.X) /2  , rec.center3.Y);
            Point center5 = new Point(rec.center4.X , (rec.center4.Y + rec.endPoint.Y)/ 2);
           
            list.Add(center1);
            list.Add(center2);
            list.Add(center3);
            list.Add(center4);
            list.Add(center5);

            foreach (Point p in list)
            {
                ConnectPoint connect_point = new ConnectPoint();
                connect_point.point = p;
                connect_point.connect_area = new Rectangle(p.X - 3, p.Y - 3, 7, 7);
                result.Add(connect_point);
            }

            return result;
        }


        public ConnectPoint GetConectPointWithPoint(Point p)
        {
            ConnectPoint newp = new ConnectPoint();
            newp.point = p;
            newp.connect_area = new Rectangle(p.X - 3, p.Y - 3, 7, 7);
          
            return newp;
        }
        public List<ConnectPoint> SetConnectPointBinary(DrawBinary binary)
        {
            List<ConnectPoint> result = new List<ConnectPoint>();
            List<Point> pp = GetPointFormRect(binary.Rectangle);

            result.Add(GetConectPointWithPoint(pp[0]));
            result.Add(GetConectPointWithPoint(pp[1]));
            result.Add(GetConectPointWithPoint(pp[2]));
            result.Add(GetConectPointWithPoint(pp[3]));

            return result;
        }

        public List<ConnectPoint> SetConnectPointNary(DrawNary nary)
        {
            List<ConnectPoint> result = new List<ConnectPoint>();
            List<Point> pp = GetPointFormRect(nary.Rectangle);

            result.Add(GetConectPointWithPoint(pp[0]));
            result.Add(GetConectPointWithPoint(pp[1]));
            result.Add(GetConectPointWithPoint(pp[2]));
            result.Add(GetConectPointWithPoint(pp[3]));

            return result;
        }
        //extra association
        public bool checkInLine(Point start, Point end, Point p)
        {
            int a = end.X - start.X;
            int b = end.Y - start.Y;
            int c = a * start.Y - b * start.X;
            
            if (a != 0)
            {
               int y = (b * p.X + c) / a;
               if (p.Y == y) return true;
            }
            else if (b!=0)
            {
                int x = (a * p.Y - c) / b;
                if (p.X == x) return true;
            }
            

            return false;
        }
        public bool check_point_in_line(Point p, DrawObject.DrawObject obj)
        {
            switch(obj.ObjType)
            {
                case DrawObject.DrawObject.ObjectType.AssociationLine:
                    DrawAssociation ass = (DrawAssociation)obj;
                    if (checkInLine(ass.startPoint, ass.endPoint, p)) return true;
                    break;
                case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                    DrawExtraAssociation ex = (DrawExtraAssociation)obj;
                    if (checkInLine(ex.startPoint, ex.center2, p)
                        || checkInLine(ex.center1, ex.center2, p)
                        || checkInLine(ex.center1, ex.endPoint, p) ) return true;

                    break;
                case DrawObject.DrawObject.ObjectType.RecurcyLine:
                    DrawRecurcyLine rec = (DrawRecurcyLine)obj;
                    if (checkInLine(rec.startPoint, rec.center1, p)
                        || checkInLine(rec.center1, rec.center2, p)
                        || checkInLine(rec.center2, rec.center3, p)
                        || checkInLine(rec.center4, rec.endPoint, p)
                        ) return true;
                    break;
            }

            return false;
        }

        public DrawAssociationClass check_associoation_class(DrawClass Class)
        {
            DrawAssociationClass ttp;
            foreach (ConnectPoint p in Class.ListConnectPoint)
            {
                if (p.association.Count > 0)
                {
                    foreach (DrawObject.DrawObject obj in p.association)
                    {
                        if (obj.ObjType == DrawObject.DrawObject.ObjectType.AssociationClassLine)
                        {
                            Class.associ = (DrawAssociationClass)obj; 
                            ttp = (DrawAssociationClass) obj;
                            return ttp;
                        }
                    }
                }
            }
            return null;
        }

        public int get_index_str(string str)
        {
            List<char> list = new List<char>();
            list = str.ToList();
            return list.IndexOf(':');

        }

        public bool check_sao(string str)
        {
            int n;
           // MessageBox.Show(str.Substring(str.Length - 1, 1));
            if(str.Substring(str.Length-1,1) == "*" && int.TryParse(str.Substring(0, str.ToList().IndexOf('.')), out n))
            {
                return true;
            }
            
            return false;
        }
        #endregion
    }
}
