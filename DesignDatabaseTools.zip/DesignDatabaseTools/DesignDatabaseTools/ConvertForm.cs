﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

using DesignDatabaseTools.MainFuction;

namespace DesignDatabaseTools
{
    public partial class ConvertForm : Form
    {
        #region private area
        private const string Done = "     Done successfully !" + "\n";

        private DrawArea area;
        //convert result
        List<UDTDefinition> UDTs = new List<UDTDefinition>();
        List<TableType> Tables = new List<TableType>();
        ConvertFunction Transfrom = new ConvertFunction();   //Class chuyen doi chinh

        public Thread thread = null;
        private delegate void ShowMessageDelegateCallBack();
        public delegate void setRichBoxTextCallBack();

        private string path = "";

        public DrawArea Area
        {
            get { return area; }
            set { area = value; }
        }

        #endregion

        #region constructor
        public ConvertForm()
        {
            InitializeComponent();
        }

        private void ConvertFormLoad(object sender, EventArgs e)
        {
            Pause.Enabled = true;
            Stop.Enabled = true;
            Result.Enabled = false;


            InitializeMyObjects();
            Init();
           

            thread = new Thread(delegate()
            {
                //Part 1
                Convertfunction();
                
                //Part 2
                this.BeginInvoke((ThreadStart)delegate()
                {
                    this.Pause.Enabled = false;
                    this.Stop.Enabled = false;
                });

                //Part 3
                this.BeginInvoke((ThreadStart)delegate()
                {
                    Result.Enabled = true;
                    this.Text = "100% (Process Completed)";
                    this.Processing.Text = "100% Process Completed ";
                    ProgressRichBox.Text += showRed(Done);

                    //export result
                   // if (progressBar1.Value == progressBar1.Maximum)
                 //   {
                        ResultForm Result2 = new ResultForm();
                        Result2.Tables = Tables;
                        Result2.UDTs = UDTs;
                        Result2.Show();
                        this.Close();
                  //  }

                });
            });

            thread.Start();  //start
        }

        #endregion

        #region Event
        private void Pause_Click(object sender, EventArgs e)
        {
            if (thread == null || !thread.IsAlive)
            {
                MessageBox.Show("Process has not been started or just being already finished");
                return;
            }
            if (Pause.Text.ToUpper() == "pause".ToUpper())
            {
                Pause.Text = "Continue";
                thread.Suspend();
            }
            else
            {
                Pause.Text = "Pause";
                thread.Resume();
            }
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            if (thread.IsAlive)
            {
                if (thread.ThreadState == ThreadState.Suspended)
                {
                    thread.Resume();
                }

                thread.Abort();
                Processing.Text = "THIS PROCESS OF CONVERTING HAS BEEN ABORTED";
                Processing.Refresh();

                new Thread(delegate()
                {
                    int val = this.progressBar1.Value;
                    for (int i = 1; i <= val; Interlocked.Increment(ref i))
                    {
                       // progressBar1.Increment(-1);
                        this.BeginInvoke((ThreadStart)delegate()
                        {
                            progressBar1.Increment(-1);
                        });
                        Thread.Sleep(10);
                    }
                }).Start();
            }
            else
                Processing.Text = "PROCESS HAS BEEN ABORETD";

            Pause.Enabled = false;
            Pause.Text = "Pause";
            Stop.Enabled = false;

        }

        private void Cancel_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void Result_Click(object sender, EventArgs e)
        {
            /*
            ResultForm Result = new ResultForm();
            Result.Tables = Tables;
            Result.UDTs = UDTs;
            Result.Show();
            this.Close();
             */
        }

        #endregion

        #region  Convert Funtion

        public void Convertfunction()
        {
            //chuong trinh convert

            Transfrom.Owner = this;

            if (Area.Graphics != null)
            {
                Transfrom.Area = Area;
                List<Entry> Entries = Transfrom.TransformClassDiagram(Area.Graphics);
                if (Entries != null)
                {
                    UDTs = Transfrom.TransformClassToUDT(Entries);
                  
                    Tables = Transfrom.MappingToOracleLayer(UDTs);

                }

            }

        }


        #endregion

        #region others function
        public void InitializeMyObjects()
        {
            try
            {
              
                progressBar1.Value = 0;
                progressBar1.Maximum = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

       
        public void Init()
        {
            progressBar1.Maximum = Area.Graphics.Count*3;
            progressBar1.Step = 2;
            return;
        }

        public string showRed(String a)
        {
            Font font = new Font("Tahoma", 9, FontStyle.Regular);
            ProgressRichBox.SelectionFont = font;
            ProgressRichBox.SelectionColor = Color.Black;
            ProgressRichBox.SelectedText = a;

            return a;
        }
        #endregion


    }
}
