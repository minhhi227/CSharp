﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DesignDatabaseTools.Methods;

namespace DesignDatabaseTools.Command
{
  
    public abstract class Command
    {

        public int flag;

        public abstract void Undo(DrawArea area);

        public abstract void Redo(DrawArea area);

        public abstract void Clear();
    }
}