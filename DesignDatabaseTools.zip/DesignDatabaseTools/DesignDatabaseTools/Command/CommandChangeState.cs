﻿
using System.Collections.Generic;
using DesignDatabaseTools.DrawObject;
using System.Windows.Forms;
using System.Drawing;

namespace DesignDatabaseTools.Command
{
	
	internal class CommandChangeState : Command
	{
		
		private List<StateObject> listBefore =new List<StateObject>();

		private List<StateObject> listAfter =new List<StateObject>();

		//private int activeLayer;

		
		public CommandChangeState(DrawArea area)
		{
            flag = 3;
			// Keep objects state before operation.
			//FillList(area.Graphics, ref listBefore);
            foreach (DrawObject.DrawObject obj in area.Graphics.Selection)
            {
                listBefore.Add(FillToState(obj));
            }
		}

		
		public void NewState(DrawArea area)
		{
			// Keep objects state after operation.
			//FillList(area.Graphics, ref listAfter);
            foreach (DrawObject.DrawObject obj in area.Graphics.Selection)
            {
                listAfter.Add(FillToState(obj));
            }
		}

		public override void Undo(DrawArea area)
		{
            // Replace all objects in the list with objects from listBefore
           //ReplaceObjects(area, listBefore);
            StateToObject(area, listBefore);
		}

		public override void Redo(DrawArea area)
		{
			// Replace all objects in the list with objects from listAfter
			//ReplaceObjects(area, listAfter);
            StateToObject(area, listAfter);
		}

		

        public override void Clear()
        {
          
        }
        //-----------------------------------------------------others function--------------------------------
        //class
        public void ClassToState(DrawClass c, StateObject state)
        {
            state.position1 = c.Rectangle.Location;
            state.width = c.Rectangle.Width;
            state.height = c.Rectangle.Height;

            state.subpoint.Add(c.RectangleName.Location);
            state.subpoint.Add(c.RectangleAttribute.Location);
            state.subpoint.Add(c.RectangleOperation.Location);
            state.subpoint.Add(c.p1);
            state.subpoint.Add(c.p2);
        }

        public void StateToClass(DrawClass c, StateObject state)
        {

            c.rectangle.Location = state.position1;
            c.rectangle.Width = state.width;
            c.rectangle.Height = state.height;

            c.rectName.Location = state.subpoint[0];
            c.rectAttribute.Location = state.subpoint[1];
            c.rectOperation.Location = state.subpoint[2];
            c.p1 = state.subpoint[3];
            c.p2 = state.subpoint[4];
        }
        //association
        public void AssociationToState(DrawAssociation ass, StateObject state)
        {
            state.position1 = ass.startPoint;
            state.position2 = ass.endPoint;

            if (ass.mul_left != null) state.subobject.Add(FillToState(ass.mul_left));
            else state.subobject.Add(null);
            if (ass.mul_right != null) state.subobject.Add(FillToState(ass.mul_right));
            else state.subobject.Add(null);
            if (ass.RoleName != null) state.subobject.Add(FillToState(ass.RoleName));
            else state.subobject.Add(null);
            if (ass.role_left_tri != null) state.subobject.Add(FillToState(ass.role_left_tri));
            else state.subobject.Add(null);
            if (ass.role_right_tri != null) state.subobject.Add(FillToState(ass.role_right_tri));
            else state.subobject.Add(null);

        }
        public void StateToAssociation(DrawAssociation ass, StateObject state)
        {
            ass.startPoint = state.position1;
            ass.endPoint = state.position2;

            if (state.subobject[0] != null) StateToOneObject(ass.mul_left, state.subobject[0]);
            if (state.subobject[1] != null) StateToOneObject(ass.mul_right, state.subobject[1]);
            if (state.subobject[2] != null) StateToOneObject(ass.RoleName, state.subobject[2]);
            if (state.subobject[3] != null) StateToOneObject(ass.role_left_tri, state.subobject[3]);
            if (state.subobject[4] != null) StateToOneObject(ass.role_right_tri, state.subobject[4]);
        }

        //binary
        public void BinaryToState(DrawBinary binary, StateObject state)
        {
            state.position1 = binary.Rectangle.Location;
            state.width = binary.Rectangle.Width;
            state.height = binary.Rectangle.Height;
            state.subpoint.Add(binary.p1);
            state.subpoint.Add(binary.p2);
            state.subpoint.Add(binary.p3);

            foreach (DrawText t in binary.list_mul)
            {
                if (t != null)
                {
                    state.subobject.Add(FillToState(t));
                }
                else
                {
                    state.subobject.Add(null);
                }
            }

        }
        public void StateToBinary(DrawBinary binary, StateObject state)
        {
            binary.rectangle.Location = state.position1;
            binary.rectangle.Width = state.width;
            binary.rectangle.Height = state.height;

            binary.p1 = state.subpoint[0];
            binary.p2 = state.subpoint[1];
            binary.p3 = state.subpoint[2];

            for(int i=0;i<state.subobject.Count;i++)
            {
                StateObject temp = state.subobject[i];
                if (temp != null)
                {
                    StateToOneObject(binary.list_mul[i], temp);
                }
                else
                {
                    //todo: do nothing
                }
            }

        }
        //n-ary
        public void NaryToState(DrawNary nary, StateObject state)
        {
            state.position1 = nary.Rectangle.Location;
            state.width = nary.Rectangle.Width;
            state.height = nary.Rectangle.Height;
            state.subpoint.Add(nary.p1);
            state.subpoint.Add(nary.p2);
            state.subpoint.Add(nary.p3);
            state.subpoint.Add(nary.p4);

            foreach (DrawText t in nary.list_mul)
            {
                if (t != null)
                {
                    state.subobject.Add(FillToState(t));
                }
                else
                {
                    state.subobject.Add(null);
                }
            }
        }

        public void StateToNary(DrawNary nary, StateObject state)
        {
            nary.rectangle.Location = state.position1;
            nary.rectangle.Width = state.width;
            nary.rectangle.Height = state.height;

            nary.p1 = state.subpoint[0];
            nary.p2 = state.subpoint[1];
            nary.p3 = state.subpoint[2];
            nary.p4 = state.subpoint[3];

            for (int i = 0; i < state.subobject.Count; i++)
            {
                StateObject temp = state.subobject[i];
                if (temp != null)
                {
                    StateToOneObject(nary.list_mul[i], temp);
                }
                else
                {
                    //todo: do nothing
                }
            }
        }

        //exassociation
        public void ExAssociationToState(DrawExtraAssociation ex, StateObject state)
        {
            state.position1 = ex.startPoint;
            state.position2 = ex.endPoint;

            state.subpoint.Add(ex.center1);
            state.subpoint.Add(ex.center2);

            if (ex.mul_left != null) state.subobject.Add(FillToState(ex.mul_left));
            else state.subobject.Add(null);
            if (ex.mul_right != null) state.subobject.Add(FillToState(ex.mul_right));
            else state.subobject.Add(null);
            if (ex.RoleName != null) state.subobject.Add(FillToState(ex.RoleName));
            else state.subobject.Add(null);
            if (ex.role_left_tri != null) state.subobject.Add(FillToState(ex.role_left_tri));
            else state.subobject.Add(null);
            if (ex.role_right_tri != null) state.subobject.Add(FillToState(ex.role_right_tri));
            else state.subobject.Add(null);

        }
        public void StateToExAssociation(DrawExtraAssociation ex, StateObject state)
        {
            ex.startPoint = state.position1;
            ex.endPoint = state.position2;

            ex.center1 = state.subpoint[0];
            ex.center2 = state.subpoint[1];

            if (state.subobject[0] != null) StateToOneObject(ex.mul_left, state.subobject[0]);
            if (state.subobject[1] != null) StateToOneObject(ex.mul_right, state.subobject[1]);
            if (state.subobject[2] != null) StateToOneObject(ex.RoleName, state.subobject[2]);
            if (state.subobject[3] != null) StateToOneObject(ex.role_left_tri, state.subobject[3]);
            if (state.subobject[4] != null) StateToOneObject(ex.role_right_tri, state.subobject[4]);
        }
        //text
        public void TextToState(DrawText t, StateObject state)
        {
            state.position1 = t.Rectangle.Location;
            state.width = t.Rectangle.Width;
            state.height = t.Rectangle.Height;
            
        }
        public void StateToText(DrawText t, StateObject state)
        {
            t.rectangle.Location = state.position1;
            t.rectangle.Width = state.width;
            t.rectangle.Height = state.height;
        }
        //others

        public void OthersToState(DrawTriangle tri, StateObject state)
        {
            state.position1 = tri.Rectangle.Location;
            state.width = tri.Rectangle.Width;
            state.height = tri.Rectangle.Height;
        }
        public void StateToOthers(DrawTriangle tri, StateObject state)
        {
            tri.rectangle.Location = state.position1;
            tri.rectangle.Width = state.width;
            tri.rectangle.Height = state.height;
        }


        public StateObject FillToState(DrawObject.DrawObject obj)
        {
            StateObject state = new StateObject();
            state.ID = obj.ID;
            switch (obj.ObjType)
            {
                case DrawObject.DrawObject.ObjectType.AbstractClass:
                case DrawObject.DrawObject.ObjectType.Class:
                    DrawClass c = (DrawClass)obj;
                    ClassToState(c, state);
                    break;
                case DrawObject.DrawObject.ObjectType.Aggernation:
                case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                case DrawObject.DrawObject.ObjectType.AssociationLine:
                case DrawObject.DrawObject.ObjectType.Composition:
                case DrawObject.DrawObject.ObjectType.Generalization:
                    DrawAssociation ass = (DrawAssociation)obj;
                    AssociationToState(ass, state);
                    break;
                case DrawObject.DrawObject.ObjectType.Binary:
                    DrawBinary binary = (DrawBinary)obj;
                    BinaryToState(binary, state);
                    break;
                case DrawObject.DrawObject.ObjectType.Nary:
                    DrawNary nary = (DrawNary)obj;
                    NaryToState(nary, state);
                    break;
                case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                    DrawExtraAssociation ex = (DrawExtraAssociation)obj;
                    ExAssociationToState(ex, state);
                    break;
                case DrawObject.DrawObject.ObjectType.text:
                    DrawText t = (DrawText)obj;
                    TextToState(t, state);
                    break;
                case DrawObject.DrawObject.ObjectType.others:
                    DrawTriangle tri = (DrawTriangle)obj;
                    OthersToState(tri, state);
                    break;

            }

            return state;
        }

        public void StateToOneObject(DrawObject.DrawObject objects, StateObject state)
        {
            switch (objects.ObjType)
            {
                case DrawObject.DrawObject.ObjectType.AbstractClass:
                case DrawObject.DrawObject.ObjectType.Class:
                    DrawClass c = (DrawClass)objects;
                    StateToClass(c, state);
                    break;
                case DrawObject.DrawObject.ObjectType.Aggernation:
                case DrawObject.DrawObject.ObjectType.AssociationClassLine:
                case DrawObject.DrawObject.ObjectType.AssociationLine:
                case DrawObject.DrawObject.ObjectType.Composition:
                case DrawObject.DrawObject.ObjectType.Generalization:
                    DrawAssociation ass = (DrawAssociation)objects;
                    StateToAssociation(ass, state);
                    break;
                case DrawObject.DrawObject.ObjectType.Nary:
                    DrawNary nary = (DrawNary)objects;
                    StateToNary(nary, state);
                    break;
                case DrawObject.DrawObject.ObjectType.Binary:
                    DrawBinary binary = (DrawBinary)objects;
                    StateToBinary(binary, state);
                    break;
                case DrawObject.DrawObject.ObjectType.ExtraAssociation:
                    DrawExtraAssociation ex = (DrawExtraAssociation)objects;
                    StateToExAssociation(ex, state);
                    break;
                case DrawObject.DrawObject.ObjectType.text:
                    DrawText t = (DrawText)objects;
                    StateToText(t, state);
                    break;
                case DrawObject.DrawObject.ObjectType.others:
                    DrawTriangle tri = (DrawTriangle)objects;
                    StateToOthers(tri, state);
                    break;
            }
        }
        public void StateToObject(DrawArea Area, List<StateObject> ListState)
        {
            foreach (StateObject state in ListState)
            {
                foreach (DrawObject.DrawObject objects in Area.Graphics.GetListObject())
                {
                    if (objects.ID == state.ID)
                    {
                        objects.Selected = true;
                        StateToOneObject(objects, state);
                        break;
                    }


                }
            }
        }

	}


    public class StateObject
    {
        public int ID;
        public Point position1;
        public Point position2;

        //public List<int> Heights = new List<int>();
        public List<Point> subpoint =new List<Point>();
        public List<StateObject> subobject = new List<StateObject>();
        public int width;
        public int height;

    }
}