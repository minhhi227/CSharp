﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DesignDatabaseTools.Methods;
using System.Windows.Forms;

namespace DesignDatabaseTools.Command
{
   
    internal class CommandAdd : Command
    {
        private CopyCutManager copypaste = new CopyCutManager();
        private DrawArea _area;

        // Create this command with DrawObject instance added to the list
        public CommandAdd(DrawArea area) 
        {
            flag = 1;
            _area = area;
        }

        public override void Clear()
        {
            //MessageBox.Show("hieu");
            _area.Graphics.DeleteHidedObject();
        }
     
        public override void Undo(DrawArea area)
        {
            area.Graphics.GetLastAddedObject().Hide = true;
            area.Graphics.GetLastAddedObject().Selected = false;
            copypaste.SetHide(area,true);

            if (area.Graphics.GetLastAddedObject().Hide)
            {
                area.IndexAdd = area.Graphics.GetLastAddedObject().ID;
            }
        }

        public override void Redo(DrawArea area)
        {
            area.Graphics.GetLastAddedObject().Hide = false;
            area.Graphics.UnHideAll();
            
        }
    }
}