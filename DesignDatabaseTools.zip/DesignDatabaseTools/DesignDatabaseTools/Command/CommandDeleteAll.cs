﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignDatabaseTools.Command
{
	
	internal class CommandDeleteAll : Command
	{
		private List<DrawObject.DrawObject> cloneList;

		// Create this command BEFORE applying Delete All function.
		public CommandDeleteAll(DrawArea area)
		{
            flag = 4;
			cloneList = new List<DrawObject.DrawObject>();

            int n = area.Graphics.Count;

			for (int i = n - 1; i >= 0; i--)
			{
                cloneList.Add(area.Graphics[i].Clone());
			}
		}

        public override void Undo(DrawArea area)
		{
			foreach (DrawObject.DrawObject o in cloneList)
			{
                area.Graphics.Add(o);
			}
		}

		public override void Redo(DrawArea area)
		{
			// Clear list - make DeleteAll again
            area.Graphics.Clear();
		}

        public override void Clear()
        {
            
        }
     
	}
}