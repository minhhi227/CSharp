﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DesignDatabaseTools.Methods;

namespace DesignDatabaseTools.Command
{
	
	internal class CommandDelete : Command
	{
		private List<int> cloneList; // contains selected items which are deleted
        private DrawArea _area;
        private CopyCutManager copypaste = new CopyCutManager();
		// Create this command BEFORE applying Delete All function.
		public CommandDelete(DrawArea area)
		{
            flag = 2;
			cloneList = new List<int>();

			// Make clone of the list selection.
            _area = area;
			foreach (DrawObject.DrawObject o in area.Graphics.Selection)
			{
				//cloneList.Add(o.Clone());
                o.Hide = true;
                o.Selected = false;
                copypaste.SetHide(area, true);
                cloneList.Add(o.ID);
			}
		}

		public override void Undo(DrawArea area)
		{
            area.Graphics.UnHideAll();

		}

		public override void Redo(DrawArea area)
		{
			// Delete from list all objects kept in cloneList
            foreach (int i in cloneList)
            {
                area.Graphics.GetObjectWithID(i).Hide = true;
                copypaste.SetHide(area, true);
            }
		}

        public override void Clear()
        {
            //MessageBox.Show("hieu");
            _area.Graphics.DeleteHidedObject();
        }
     
	}
}