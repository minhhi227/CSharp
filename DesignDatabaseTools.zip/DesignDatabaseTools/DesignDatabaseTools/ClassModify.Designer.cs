﻿namespace DesignDatabaseTools
{
    partial class ClassModify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Add = new DevComponents.DotNetBar.ButtonX();
            this.Remove = new DevComponents.DotNetBar.ButtonX();
            this.Up = new DevComponents.DotNetBar.ButtonX();
            this.Down = new DevComponents.DotNetBar.ButtonX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.SuspendLayout();
            // 
            // Add
            // 
            this.Add.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Add.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Add.Image = global::DesignDatabaseTools.Properties.Resources.Add;
            this.Add.Location = new System.Drawing.Point(12, 12);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(31, 23);
            this.Add.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Add.TabIndex = 0;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Remove
            // 
            this.Remove.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Remove.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Remove.Image = global::DesignDatabaseTools.Properties.Resources.Remove;
            this.Remove.Location = new System.Drawing.Point(49, 12);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(31, 23);
            this.Remove.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Remove.TabIndex = 1;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // Up
            // 
            this.Up.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Up.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Up.Image = global::DesignDatabaseTools.Properties.Resources.Up;
            this.Up.Location = new System.Drawing.Point(86, 12);
            this.Up.Name = "Up";
            this.Up.Size = new System.Drawing.Size(28, 23);
            this.Up.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Up.TabIndex = 2;
            this.Up.Click += new System.EventHandler(this.Up_Click);
            // 
            // Down
            // 
            this.Down.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Down.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Down.Image = global::DesignDatabaseTools.Properties.Resources.Down;
            this.Down.Location = new System.Drawing.Point(120, 12);
            this.Down.Name = "Down";
            this.Down.Size = new System.Drawing.Size(29, 23);
            this.Down.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Down.TabIndex = 3;
            this.Down.Click += new System.EventHandler(this.Down_Click);
            // 
            // textBoxX1
            // 
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1.Location = new System.Drawing.Point(170, 15);
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.Size = new System.Drawing.Size(100, 20);
            this.textBoxX1.TabIndex = 4;
            // 
            // ClassModify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 44);
            this.ControlBox = false;
            this.Controls.Add(this.textBoxX1);
            this.Controls.Add(this.Down);
            this.Controls.Add(this.Up);
            this.Controls.Add(this.Remove);
            this.Controls.Add(this.Add);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ClassModify";
            this.ShowIcon = false;
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.Load += new System.EventHandler(this.ClassModify_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.ButtonX Add;
        private DevComponents.DotNetBar.ButtonX Remove;
        private DevComponents.DotNetBar.ButtonX Up;
        private DevComponents.DotNetBar.ButtonX Down;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;

    }
}