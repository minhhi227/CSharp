﻿namespace DesignDatabaseTools
{
    partial class ConvertForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.Result = new DevComponents.DotNetBar.ButtonX();
            this.Processing = new DevComponents.DotNetBar.LabelX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.Pause = new DevComponents.DotNetBar.ButtonX();
            this.Stop = new DevComponents.DotNetBar.ButtonX();
            this.Cancel = new DevComponents.DotNetBar.ButtonX();
            this.ProgressRichBox = new System.Windows.Forms.RichTextBox();
            this.progressBar1 = new DevComponents.DotNetBar.Controls.ProgressBarX();
            this.panelEx1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelEx1
            // 
            this.panelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelEx1.Controls.Add(this.Result);
            this.panelEx1.Controls.Add(this.Processing);
            this.panelEx1.Controls.Add(this.labelX1);
            this.panelEx1.Controls.Add(this.Pause);
            this.panelEx1.Controls.Add(this.Stop);
            this.panelEx1.Controls.Add(this.Cancel);
            this.panelEx1.Controls.Add(this.ProgressRichBox);
            this.panelEx1.Controls.Add(this.progressBar1);
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEx1.Location = new System.Drawing.Point(0, 0);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(512, 260);
            this.panelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelEx1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx1.Style.GradientAngle = 90;
            this.panelEx1.TabIndex = 0;
            // 
            // Result
            // 
            this.Result.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Result.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Result.Location = new System.Drawing.Point(33, 199);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(82, 36);
            this.Result.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Result.TabIndex = 7;
            this.Result.Text = "RESULT";
            this.Result.Click += new System.EventHandler(this.Result_Click);
            // 
            // Processing
            // 
            // 
            // 
            // 
            this.Processing.BackgroundStyle.Class = "";
            this.Processing.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Processing.Location = new System.Drawing.Point(93, 12);
            this.Processing.Name = "Processing";
            this.Processing.Size = new System.Drawing.Size(394, 23);
            this.Processing.TabIndex = 6;
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(12, 12);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(75, 23);
            this.labelX1.TabIndex = 5;
            this.labelX1.Text = "Processing...";
            // 
            // Pause
            // 
            this.Pause.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Pause.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Pause.Location = new System.Drawing.Point(227, 212);
            this.Pause.Name = "Pause";
            this.Pause.Size = new System.Drawing.Size(75, 23);
            this.Pause.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Pause.TabIndex = 4;
            this.Pause.Text = "Pause";
            this.Pause.Click += new System.EventHandler(this.Pause_Click);
            // 
            // Stop
            // 
            this.Stop.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Stop.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Stop.Location = new System.Drawing.Point(322, 212);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(75, 23);
            this.Stop.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Stop.TabIndex = 3;
            this.Stop.Text = "Stop";
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // Cancel
            // 
            this.Cancel.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Cancel.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Cancel.Location = new System.Drawing.Point(412, 212);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Cancel.TabIndex = 2;
            this.Cancel.Text = "Cancel";
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // ProgressRichBox
            // 
            this.ProgressRichBox.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ProgressRichBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProgressRichBox.Location = new System.Drawing.Point(12, 73);
            this.ProgressRichBox.Name = "ProgressRichBox";
            this.ProgressRichBox.ReadOnly = true;
            this.ProgressRichBox.Size = new System.Drawing.Size(475, 110);
            this.ProgressRichBox.TabIndex = 1;
            this.ProgressRichBox.Text = "";
            // 
            // progressBar1
            // 
            // 
            // 
            // 
            this.progressBar1.BackgroundStyle.Class = "";
            this.progressBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.progressBar1.Location = new System.Drawing.Point(12, 41);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(476, 23);
            this.progressBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.progressBar1.TabIndex = 0;
            // 
            // ConvertForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(512, 260);
            this.Controls.Add(this.panelEx1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConvertForm";
            this.Text = "ConvertForm";
            this.Load += new System.EventHandler(this.ConvertFormLoad);
            this.panelEx1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.PanelEx panelEx1;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.ButtonX Pause;
        private DevComponents.DotNetBar.ButtonX Stop;
        private DevComponents.DotNetBar.ButtonX Cancel;
        private DevComponents.DotNetBar.ButtonX Result;
        public DevComponents.DotNetBar.Controls.ProgressBarX progressBar1;
        public DevComponents.DotNetBar.LabelX Processing;
        public System.Windows.Forms.RichTextBox ProgressRichBox;

    }
}