﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using AssignementISS.Database;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Windows.Forms;

namespace AssignementISS.Models
{
    public class TableSelect
    {
        [Display(Name = "Table Name")]
        public string TableName { get; set; }

        [Display(Name = "Schema")]
        public string Schema { get; set; }

        public List<List<string>> tables { get; set; }
        public List<string> col { get; set; }
        public List<string> schemalist;
        public List<string> tablelist;
    }
    public class TableInsert
    {
        [Display(Name = "Table Name")]
        public string TableName { get; set; }

        [Display(Name = "Schema")]
        public string Schema { get; set; }

        public List<string> schemalist;
        public List<string> tablelist;
        public List<string> col { get; set; }
        public List<string> newvalue { get; set; }
    }
    public class TableUpdate
    {
        [Display(Name = "Table Name")]
        public string TableName { get; set; }

        [Display(Name = "Schema")]
        public string Schema { get; set; }

        [Display(Name = "Column Name")]
        public string Colname { get; set; }

        [Display(Name = "Old Value")]
        public string oldvalue { get; set; }

        [Display(Name = "New Value")]
        public string giatrimoi { get; set; }

        public List<string> schemalist;
        public List<string> oldva;
        public List<string> tablelist;
        public List<string> col { get; set; }

    }
    public class TableDelete
    {
        [Display(Name = "Table Name")]
        public string TableName { get; set; }

        [Display(Name = "Schema")]
        public string Schema { get; set; }

        public List<string> schemalist;
        public List<string> tablelist;
    }
    public class TableCreate
    {
        [Display(Name = "Table Name")]
        public string TableName { get; set; }

        [Display(Name = "Schema")]
        public string Schema { get; set; }

        [Display(Name = "ColumnName")]
        public List<string> ColumnName { get; set; }

        [Display(Name = "Type")]
        public List<string> type { get; set; }

        [Display(Name = "Length")]
        public List<string> Length { get; set; }

        [Display(Name = "Allow null")]
        public List<bool> AllowNull { get; set; }

        [Display(Name = "Add More")]
        public bool AddMore { get; set; }

        public List<string> schemalist;

    }
    public class ManageTable
    {

        public Connection objConnect;
        public createCommand objCommand;
        public string DBSource;
        public string Username;
        public string Password;
        public OracleDataReader reader;

        // ham delete
        public void Delete()
        {
            objConnect = null;
            objCommand = null;
        }

        public void Init()
        {
            objConnect = new Connection();
            objCommand = new createCommand();

        }

        public bool CreateTable(string TableName, string schema, List<string> colname, List<string> type, List<string> length, List<string> allownull, int socot)
        {
            Init();
            string query = "CREATE Table " + schema.ToUpper() + "." + TableName.ToUpper() + "(";

            for (int i = 0; i < socot; i++)
            {

                if (i == socot - 1)
                {
                    if (length[i].CompareTo("")==1)
                    {
                        
                        query += colname[i] + "  " + type[i] + "(" + length[i] + ")" + "  " + allownull[i];
                    }
                    else
                    {
                        query += colname[i] + "  " + type[i] + "  " + allownull[i];
                    }

                }
                else
                {
                    if (length[i].CompareTo("")==1)
                    {
                        
                       query += colname[i] + "  " + type[i] + "(" + length[i] + ")" + "  " + allownull[i] + ",";
                    }
                    else
                    {
                       query += colname[i] + "  " + type[i] + "  " + allownull[i] + ","; 
                    }
                }

            }

            query += ")";

            
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                
                return false;
            }
            return true;
        }

        public bool DeleteTable(string schema, string tablename)
        {
            Init();
            string query = "DROP TABLE " + schema.ToUpper() + "." + tablename.ToUpper();

            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                return false;
            }
            return true;
        }

        public List<List<string>> SelectTable(string schema, string TableName, int socot)
        {
            Init();
            List<List<string>> table = new List<List<string>>();

            string strcol = "select * from " + schema.ToUpper() + "." + TableName.ToUpper();

            objConnect.connection(DBSource, Username, Password);
            try
            {
                objCommand.createCmd(strcol, objConnect.connectOracle);
                reader = objCommand.command.ExecuteReader();

                while (reader.Read())
                {
                    List<string> row = new List<string>();
                    for (int i = 0; i < socot; i++)
                    {
                        row.Add(reader.GetValue(i).ToString());
                    }
                    table.Add(row);
                }

                reader.Close();
              
            }
            catch (Exception e)
            {
               
                MessageBox.Show("You cannot select on this table !");
            }
           
             Delete();
            return table;
        }

        public bool UpdateTable(string schema, string tablename, string newvalue, string colname, string oldvalue)
        {
            Init();
            string query = "UPDATE " + schema.ToUpper() + "." + tablename.ToUpper() + " SET " + colname + "=" + newvalue + " where " + colname + "='" + oldvalue + "'";
            
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                
                return false;
            }
            return true;
        }

        public bool InsertTable(string schema, string tablename, List<string> newvalue)
        {
            Init();
            string query = "INSERT INTO " + schema.ToUpper() + "." + tablename.ToUpper() + " VALUES ( ";
            for (int i = 0; i < newvalue.Count; i++)
            {
                if (i != newvalue.Count - 1)
                {
                    query += newvalue[i] + ",";
                }
                else
                {
                    query += newvalue[i] + ")";
                }
            }
           
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                return false;
            }
            return true;
        }

        public List<string> Selectcolvalue(string schema, string TableName, string colname)
        {
            Init();
            List<string> colvalue = new List<string>();

            string strcol = "select " + colname + " from " + schema.ToUpper() + "." + TableName.ToUpper();

            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strcol, objConnect.connectOracle);
            reader = objCommand.command.ExecuteReader();

            while (reader.Read())
            {
                colvalue.Add(reader.GetValue(0).ToString());
            }
            reader.Close();
            Delete();
            return colvalue;
        }

    }

}