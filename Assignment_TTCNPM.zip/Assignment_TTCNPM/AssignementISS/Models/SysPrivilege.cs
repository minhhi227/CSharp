﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssignementISS.Models
{
    public class SysPrivilege
    {
        public string privName;
        public string admin_opt;
        public bool assigned;

        public SysPrivilege()
        {
            assigned = false;
        }
    }
}