﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using AssignementISS.Database;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Windows.Forms;

namespace AssignementISS.Models
{
    // Phan nay cua hOang ---------------------------------------------------------
    public class Roles
    {
        public string RoleName { get; set; }
        public string RolePassword { get; set; }
        public bool NoPassword { get; set; }
        public List<SysPrivilege> SystemPrivileges { get; set; }
        public List<ObjPrivilege> ObjectPrivileges { get; set; }
        public string ObjPrivileges { get; set; }
        public string Username { get; set; }
        public string Objectname { get; set; }
        public string Columnname { get; set; }
        public bool AddminOption { get; set; }
        public bool GrantOption { get; set; }
        public string Schema { get; set; }
        public List<bool> admin_option { get; set; }
        public List<bool> select_pri { get; set; }
        public List<string> listSchema;
        public List<string> list_user;
        public List<string> objPrivs;
        public List<string> obj;
        public List<string> col;

    }

    public class CreateRoles
    {
        [Display(Name = "Role Name")]
        public string RoleName { get; set; }

        [Display(Name = "Role Password")]
        public string RolePassword { get; set; }

        [Display(Name = "No Password")]
        public bool NoPassword { get; set; }

        [Display(Name = "Grant Object Privileges")]
        public bool grantobj { get; set; }

        [Display(Name = "System Privileges")]
        public List<SysPrivilege> SystemPrivileges { get; set; }

        [Display(Name = "Object Privileges")]
        public List<ObjPrivilege> ObjectPrivileges { get; set; }

        [Display(Name = "Object Privileges")]
        public string ObjPrivileges { get; set; }

        [Display(Name = "Username")]
        public string Username { get; set; }

        [Display(Name = "Table Name")]
        public string Objectname { get; set; }

        [Display(Name = "Column Name")]
        public string Columnname { get; set; }

        public bool AddminOption { get; set; }

        public bool GrantOption { get; set; }

        [Display(Name = "Schema")]
        public string Schema { get; set; }

        public List<bool> admin_option { get; set; }
        public List<bool> select_pri { get; set; }
        public List<string> listSchema;
        public List<string> list_user;
        public List<string> objPrivs;
        public List<string> obj;
        public List<string> col;


    }



    public class DropRoles
    {

        public List<string> ListRole;

        [Display(Name = "Role Name")]
        public string RoleName { get; set; }

    }
    public class AlterRoles
    {
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        //[Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Display(Name = "Role Name")]
        public string RoleName { get; set; }
        public List<string> RolesList { get; set; }
        public Roles SelectedRole { get; set; }
        public List<SysPrivilege> SystemPrivs { get; set; }
        public List<ObjPrivilege> ObjectPrivs { get; set; }
        public string Objectname { get; set; }
        public string Columnname { get; set; }
        public bool AddminOption { get; set; }
        public bool GrantOption { get; set; }
        public string Schema { get; set; }
        public List<bool> admin_option { get; set; }
        public List<bool> select_sys { get; set; }
        public List<bool> select_obj { get; set; }
        public List<string> listSchema;
        public List<string> list_user;
        public List<string> objPrivs;
        public List<string> obj;
        public List<string> col;
        public int session { get; set; }


    }
    public class GrantRoles
    {

        public List<string> RolesList;


        public List<string> list_user;

        [Display(Name = "User Name Rev")]
        public string UserNameRev { get; set; }

        [Display(Name = "Role Name Rev")]
        public string RoleNameRev { get; set; }

        [Display(Name = "Role Name Grant")]
        public string RoleNameGrantToUser { get; set; }

        [Display(Name = "Role Name Grant")]
        public string RoleNameGrantToRole { get; set; }

        [Display(Name = "Admin Option")]
        public bool AdminOptUser { get; set; }

        [Display(Name = "Admin Option")]
        public bool AdminOptRole { get; set; }

    }

    public class MangeRoles
    {

        public Connection objConnect;
        public OracleDataReader reader;
        public createCommand objCommand;

        public void Delete()
        {
            objConnect = null;
            objCommand = null;
        }

        public bool NoneQuery(string sql)
        {
            OracleCommand cmd = new OracleCommand(sql);
            cmd.Connection = objConnect.connectOracle;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public void Init()
        {
            objConnect = new Connection();
            objCommand = new createCommand();
        }
        public bool CreateRole(string roleName, string rolePass, bool passOption)
        {
            bool result;
            Init();
            string cmd = "create role " + roleName;
            if (passOption == false)
            {
                cmd += " identified by " + rolePass;
            }
          
            objConnect.connection(Program.databaseSource, Program.adminName, Program.adminpassword);
            result = NoneQuery(cmd);
            objConnect.connectOracle.Close();
            return result;
        }

        public bool GrantSysPrivToRole(string roleName, string privName, string ad_opt)
        {
            bool result = false;
            Init();
            string cmd = "grant " + privName + " to " + roleName + ad_opt;
            
            objConnect.connection(Program.databaseSource, Program.adminName, Program.adminpassword);
            result = NoneQuery(cmd);
            objConnect.connectOracle.Close();
            Delete();
            return result;

        }

        public bool GrantObjPrivToRole(string roleName, string objPri, string columnName, string objName, string grant_option)
        {
            bool result = false;
            string privilege = objPri + " (" + columnName + ") " + " ON " + objName + " ";
            result = GrantSysPrivToRole(roleName, privilege, grant_option);
            return result;
        }
        public List<string> GetAllRolesName(string grantee)
        {
            Init();
            string cmd = "select granted_role from dba_role_privs where grantee ='" + grantee.ToUpper() + "'";

            objConnect.connection(Program.databaseSource, Program.adminName, Program.adminpassword);
            objCommand.createCmd(cmd, objConnect.connectOracle);

            List<string> allRole = new List<string>();
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
                allRole.Add(reader.GetValue(0).ToString());
            reader.Close();
            objConnect.connectOracle.Close();
            Delete();
            return allRole;

        }
        public List<List<string>> GetAllRoles()
        {
            Init();
            string cmd = "select * from dba_roles";
            objConnect.connection(Program.databaseSource, Program.adminName, Program.adminpassword);
            objCommand.createCmd(cmd, objConnect.connectOracle);

            List<List<string>> allRole = new List<List<string>>();
            List<string> row;
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                row = new List<string>();
                row.Add(reader.GetValue(0).ToString());
                row.Add(reader.GetValue(1).ToString());
                allRole.Add(row);
            }

            reader.Close();
            objConnect.connectOracle.Close();
            Delete();
            return allRole;
        }

        public bool GrantRole(string RoleName, string Grantee, string ad_opt)
        {
            bool result = true;
            Init();
            string cmd = "grant " + RoleName + " to " + Grantee + ad_opt;
            objConnect.connection(Program.databaseSource, Program.adminName, Program.adminpassword);
            try
            {
                result = NoneQuery(cmd);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            objConnect.connectOracle.Close();
            Delete();
            return result;

        }

        public bool DropRole(string RoleName)
        {
            bool result = true;
            Init();
            string cmd = "drop role " + RoleName;
            objConnect.connection(Program.databaseSource, Program.adminName, Program.adminpassword);
            try
            {
                result = NoneQuery(cmd);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            objConnect.connectOracle.Close();
            Delete();
            return result;


        }

        


    }


    // PHan nay cua Hieu ------------------Khong dong bo duoc
  
    public class ManageRoles
    {
        public Connection objConnect;
        public createCommand objCommand;
        public string DBSource;
        public string Username;
        public string Password;
        public OracleDataReader reader;

        public ManageRoles()
        {
           DBSource ="orcl";
           Username="admin";
           Password="admin";
        }
        public void Init()
        {
            objConnect = new Connection();
            objCommand = new createCommand();

        }

        public void Delete()
        {
            objConnect = null;
            objCommand = null;
        }

        public void createRole(string roleName, string passWord)
        {
            Init();
            string cmdText = "create role " + roleName.ToString() +
                (!passWord.Equals("") ? " identified by " + passWord.ToString() : "");
            objConnect.connection(Username, Password, DBSource);
            objCommand.createCmd(cmdText, objConnect.connectOracle);
            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            objConnect.connectOracle.Close();
        }

        public void changePassWord(string roleName, string newPass)
        {
            Init();
            string cmdText;
            if (newPass != "")
                cmdText = "alter role " + roleName.ToString() +
                " identified by " + newPass.ToString();
            else
                cmdText = "alter role " + roleName.ToString() + " not identified";
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(cmdText, objConnect.connectOracle);
            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            objConnect.connectOracle.Close();
        }

        public void dropRole(string roleName)
        {
            Init();
            string cmdText = "drop role " + roleName.ToString();
            objConnect.connection(Username, Password, DBSource);
            objCommand.createCmd(cmdText, objConnect.connectOracle);
            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            objConnect.connectOracle.Close();
        }

        public string existRole(string roleName)
        {
            Init();
            string cmdText = "select name, password from sys.user$ where name = '" + roleName.ToUpper() + "'";
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(cmdText, objConnect.connectOracle);
            OracleDataReader dr = objCommand.command.ExecuteReader();
            if (dr.Read())//có role
                if (!dr.IsDBNull(1))
                    return dr.GetString(1).ToString();
                else
                    return null;
            return "";//ko role >"<
        }

        public List<List<string>> selectAllRole()
        {
            Init();
            string strSelectAllRole = "select * from dba_roles";
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strSelectAllRole, objConnect.connectOracle);

            List<List<string>> allRole = new List<List<string>>();
            List<string> row;
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                row = new List<string>();
                row.Add(reader.GetValue(0).ToString());
                row.Add(reader.GetValue(1).ToString());
                allRole.Add(row);
            }

            reader.Close();
            objConnect.connectOracle.Close();
            Delete();
            return allRole;
        }


        
        public List<string> selectRoleForUser(string username)
        {
            Init();
            string strRoleForUser = "select granted_role from dba_role_privs where grantee = '" + username.ToUpper() + "'";
            objConnect.connection2(DBSource, Username, Password);
            objCommand.createCmd(strRoleForUser, objConnect.connectOracle);

            List<string> roleForUser = new List<string>();
          
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                roleForUser.Add(reader.GetValue(0).ToString());
               
            }

            reader.Close();
            objConnect.connectOracle.Close();
            Delete();
            return roleForUser;
        }
      


        private void revokeRole(string roleName, string userName)
        {
            Init();
            string strRevokeRole = "revoke " + roleName + " from " + userName;
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strRevokeRole, objConnect.connectOracle);
            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "ERROR", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }


        //Is called when uncheck in checkbox Assigned role
        public void uncheckAssignedRole(string roleName, string userName)
        {
            revokeRole(roleName, userName);
        }

        private List<string> selectRoleNotDefault(string userName)
        {
            Init();
            List<string> roleNotDefault = new List<string>();
            string strSelectNotDefault = "select granted_role from dba_role_privs where grantee = '" + userName.ToUpper() + "' and default_role = 'NO'";
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strSelectNotDefault, objConnect.connectOracle);
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                roleNotDefault.Add(reader.GetValue(0).ToString());
            }
            reader.Close();
            Delete();
            return roleNotDefault;
        }

        private List<string> selectRoleDefault(string userName)
        {
            Init();
            List<string> roleDefault = new List<string>();
            string strSelectDefault = "select granted_role from dba_role_privs where grantee = '" + userName.ToUpper() + "' and default_role = 'YES'";
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strSelectDefault, objConnect.connectOracle);
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                roleDefault.Add(reader.GetValue(0).ToString());
            }
            reader.Close();
            Delete();
            return roleDefault;
        }


        

        //Is called when check in checkbox asssigned role
        public bool grantRole(string roleName, string userName)
        {
            Init();
            string grantRole = "grant " + roleName.ToUpper() + " to " + userName.ToUpper();
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(grantRole, objConnect.connectOracle);
            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception )
            {
                
                return false;
            }
            objConnect.connectOracle.Close();
            Delete();
            return true;
        }

        public bool revokePrivFromRole(string roleName, string privName)
        {
            Init();
            string revokePriv = "revoke " + privName + " from " + roleName;
            MessageBox.Show(revokePriv);
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(revokePriv, objConnect.connectOracle);
            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

 
    }


}