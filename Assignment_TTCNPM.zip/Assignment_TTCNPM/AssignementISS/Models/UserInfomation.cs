﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssignementISS.Models
{
    public class UserInfomation
    {
         public string username; 
         public string Account_status; 
         public string Lock_date;
         public string Created_date;
         public string Default_tablespace; 
         public string Temporary_tablespace; 
         public string Quota;

    }
}