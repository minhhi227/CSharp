﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using AssignementISS.Database;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Windows.Forms;

namespace AssignementISS.Models
{
    public class ShowPrivileges
    {
        [Display(Name = "User name")]
        public string username { get; set; }

        public List<string> listuser;
        [Display(Name = "Object Privileges")]
        public List<ObjPrivilege> ObjectPrivileges { get; set; }

        [Display(Name = "System Privileges")]
        public List<SysPrivilege> SystemPrivileges { get; set; }

    }

    public class GrantPrivileges
    {
        //system privileges

        [Display(Name = "System Privileges")]
        public List<SysPrivilege> SystemPrivileges { get; set; }

        [Display(Name = "User Name")]
        public string Username { get; set; }

        [Display(Name = "Admin Option ?")]
        public bool Admin_opt { get; set; }

        public List<bool> admin_option { get; set; }
        public List<bool> select_pri { get; set; }
        public List<string> listuser;

        //object privileges

        [Display(Name = "Object Privileges")]
        public string ObjectPrivileges { get; set; }

        [Display(Name = "Schema")]
        public string Schema { get; set; }

        [Display(Name = "Table Name")]
        public string Objectname { get; set; }

        [Display(Name = "Column Name")]
        public string Columnname { get; set; }

        [Display(Name = "Grant Option ?")]
        public bool Grant_opt { get; set; }

        public List<string> listschema;
        public List<string> objPrivs;
        public List<string> obj;
        public List<string> col;
    }

    public class RevokePrivileges
    {
        [Display(Name = "System Privileges")]
        public List<SysPrivilege> SystemPrivileges { get; set; }

        [Display(Name = "Object Privileges")]
        public string ObjectPrivileges { get; set; }

        [Display(Name = "On schema")]
        public string username { get; set; }

        [Display(Name = " From user name")]
        public string revokeuser { get; set; }
        
        [Display(Name = "Table Name")]
        public string Objectname { get; set; }

        [Display(Name = "Column Name")]
        public string Columnname { get; set; }

        public List<bool> select_pri { get; set; }
        public List<string> objPrivs;
        public List<string> obj;
        public List<string> col;
        public List<string> listuser;
    }

    public class PrivilegesManager
    {

        public Connection objConnect;
        public createCommand objCommand;
        public string DBSource;
        public string Username;
        public string Password;
        public List<List<string>> ListRoleforRole = new List<List<string>>();
        //private bool flag = false;
        public OracleDataReader reader;
        public PrivilegesManager()
        {
            DBSource="orcl";
            Username="admin";
            Password = "admin";
        }
        public void Init()
        {
            objConnect = new Connection();
            objCommand = new createCommand();

        }

        // ham delete
        public void Delete()
        {
            objConnect = null;
            objCommand = null;
        }

   
        //---------------------------------------SHOW PRIVILEGES------------------------------
       
        public List<SysPrivilege> SelectSysPrivsForUser(string UserName)
        {
            Init();
            List<SysPrivilege> privsForUser = new List<SysPrivilege>();

            string strSelectPrivsForRole = "select * from dba_sys_privs where grantee='" + UserName.ToUpper() + "'";
            try
            {
                objConnect.connection2(DBSource, Username, Password);
                objCommand.createCmd(strSelectPrivsForRole, objConnect.connectOracle);
                reader = objCommand.command.ExecuteReader();
                while (reader.Read())
                {
                    SysPrivilege pri = new SysPrivilege();
                    pri.privName = reader.GetValue(1).ToString();
                    pri.admin_opt = reader.GetValue(2).ToString();
                    privsForUser.Add(pri);
                }
                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(" Insusfficent privileges !");
            }
            Delete();
            return privsForUser;
        }

        
        public List<ObjPrivilege> SelectObjPrivsForUser(string UserName)
        {
            Init();
            List<ObjPrivilege> privsForUser = new List<ObjPrivilege>();

            string strSelectPrivsForRole = "select PRIVILEGE,TABLE_NAME  from DBA_TAB_PRIVS where GRANTEE ='" + UserName.ToUpper() + "'";
            try
            {
                objConnect.connection2(DBSource, Username, Password);
                objCommand.createCmd(strSelectPrivsForRole, objConnect.connectOracle);
                reader = objCommand.command.ExecuteReader();
                while (reader.Read())
                {
                    ObjPrivilege pri = new ObjPrivilege();
                    pri.privName = reader.GetValue(0).ToString();
                    pri.OnObject = reader.GetValue(1).ToString();

                    privsForUser.Add(pri);
                }
                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(" Insusfficent privileges !");
            }
            Delete();
            return privsForUser;
        }

        public List<string> SelectSysPrivsForRole(string RoleName)
        {
            Init();
            List<string> privsForRole = new List<string>();

            string strSelectPrivsForRole = "select privilege from role_sys_privs where role='" + RoleName.ToUpper() + "'";

            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strSelectPrivsForRole, objConnect.connectOracle);
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
               
                privsForRole.Add(reader.GetValue(0).ToString());
            }
            reader.Close();
            Delete();
            return privsForRole;
        }

        public List<SysPrivilege> SelectSysPrivsForRole2(string RoleName)
        {
            Init();
            List<SysPrivilege> privsForRole = new List<SysPrivilege>();

            string strSelectPrivsForRole = "select privilege from role_sys_privs where role='" + RoleName.ToUpper() + "'";

            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strSelectPrivsForRole, objConnect.connectOracle);
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                SysPrivilege sys = new SysPrivilege();
                sys.privName = reader.GetValue(0).ToString();
                privsForRole.Add(sys);
            }
            reader.Close();
            Delete();
            return privsForRole;
        }

        public List<ObjPrivilege> SelectObjPrivsForRole2(string RoleName)
        {
            Init();
            List<ObjPrivilege> privsForRole = new List<ObjPrivilege>();
            string strSelectPrivsForRole = "select PRIVILEGE,TABLE_NAME from role_tab_privs where ROLE  ='" + RoleName.ToUpper() + "'";
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strSelectPrivsForRole, objConnect.connectOracle);
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                ObjPrivilege pri = new ObjPrivilege();
                pri.privName = reader.GetValue(0).ToString();
                pri.OnObject = reader.GetValue(1).ToString();

                privsForRole.Add(pri);
            }
            reader.Close();
            Delete();
            return privsForRole;
        }
        //---------------------------GRANT PRIVILEGES-------------------------------------
        public bool GrantSysPrivToUser(string UserName, string privName, string ad_opt)
        {
            Init();
            string grantPrivForRole = "grant " + privName + " to " + UserName + ad_opt;
            
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(grantPrivForRole, objConnect.connectOracle);
            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                
                return false;
            }
            objConnect.connectOracle.Close();
            Delete();
            return true;

        }

      

        public List<string> SelectTableFromSchema(string Schema)
        {
            Init();
            List<string> Tablelist = new List<string>();

            string SelectTable = "select TABLE_NAME from DBA_TABLES where OWNER ='" + Schema.ToUpper() + "'";
            objConnect.connection2(DBSource, Username, Password);
            objCommand.createCmd(SelectTable, objConnect.connectOracle);
            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                Tablelist.Add(reader.GetValue(0).ToString());
            }
            reader.Close();
            Delete();
            return Tablelist;
        }

        public List<string> SelectColumnForTable(string schema,string TableName)
        {
            Init();
            List<string> ColList = new List<string>();

            string strcol = "select COLUMN_NAME from all_tab_columns where TABLE_NAME='"+TableName+"' AND OWNER='"+schema+"'";
            
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(strcol, objConnect.connectOracle);
            reader = objCommand.command.ExecuteReader();
            
            while (reader.Read())
            {
                ColList.Add(reader.GetValue(0).ToString());
            }
            reader.Close();
            Delete();
            return ColList;
        }
        //-------------------------REVOKE PRIVILEGES--------------------------------------
        public bool RevokeSysPrivFromUser(string UserName, string privName)
        {
            Init();
            string revokePriv = "revoke " + privName + " from " + UserName;
            
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(revokePriv, objConnect.connectOracle);
            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                
                return false;
            }
            return true;
        }


        //Ham nay cua Hoang
        public List<string> GetListAllUsers()
        {
            Init();
            List<string> listUsers = new List<string>();

            string query = "SELECT * FROM DBA_USERS";

            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);

            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                listUsers.Add((string)reader[0]);
            }

            return listUsers;
        }


    }
}