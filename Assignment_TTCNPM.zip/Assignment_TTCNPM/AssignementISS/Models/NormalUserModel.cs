﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using AssignementISS.Database;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Windows.Forms;

namespace AssignementISS.Models
{
    public class PrivilegeGrant
    {

        [Display(Name = "System Privileges")]
        public List<SysPrivilege> SystemPrivileges { get; set; }

        [Display(Name = "User Name")]
        public string Username { get; set; }

       

        public List<bool> admin_option { get; set; }
        public List<bool> select_pri { get; set; }
        public List<string> listuser;

        //----------------------

        [Display(Name = "Table Name")]
        public string TableName { get; set; }

        [Display(Name = "To user")]
        public string userNameobj { get; set; }

        [Display(Name = "Select")]
        public bool Select { get; set; }

        [Display(Name = "Insert")]
        public bool insert { get; set; }

        [Display(Name = "Delete")]
        public bool delete { get; set; }

        [Display(Name = "with grant option")]
        public bool grant_opt { get; set; }

        public List<string> tablelist;
        

    }

    public class PrivilegeView
    {
        [Display(Name = "Object Privileges")]
        public List<ObjPrivilege> ObjectPrivileges { get; set; }

        [Display(Name = "System Privileges")]
        public List<SysPrivilege> SystemPrivileges { get; set; }
    }
   
    public class RoleGrant
    {
        [Display(Name = "Role Name")]
        public string RoleName { get; set; }

        [Display(Name = "To user")]
        public string userName { get; set; }

        public List<string> Rolelist;
        public List<string> userlist;
    }
    public class RoleView
    {
        [Display(Name = "Role Name")]
        public string RoleName { get; set; }

        public List<string> Roleli;

        [Display(Name = "Privileges")]
        public List<string> Privilegelist { get; set; }

    }
   
  
    public class TableView
    {
        [Display(Name = "Table Name")]
        public string TableName { get; set; }

        public List<string> table;

    }

    public class Profile
    {
        [Display(Name = "Profile Name")]
        public string ProfileName { get; set; }

        public List<string> profile;

        
        public List<string> resource;

    }


    public class UserInfo
    {
        public UserInfomation user { get; set; } 
    }
}