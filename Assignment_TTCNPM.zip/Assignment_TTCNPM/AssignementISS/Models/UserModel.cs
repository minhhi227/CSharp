﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using AssignementISS.Database;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Windows.Forms;

namespace AssignementISS.Models
{

    public class ShowUser
    {
        [Display(Name = "User name")]
        public string UserName { get; set; }

        public UserInfomation user { get; set; } 

        public List<string> listuser;

    }
    public class CreateUser
    {
        
        [Display(Name = "User name")]
        public string UserName { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        [Display(Name = "Connect")]
        public bool connect { get; set; }

    }

    public class DropUser
    {
        [Display(Name = "User name")]
        public string UserName { get; set; }

        public List<string> listuser;
    }

    public class AlterUser
    {
        
        [Display(Name = "User name")]
        public string UserName { get; set; }

       
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        //[Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }


        
        [Display(Name = "Default Table Space")]
        public string DefaultTableSpace { get; set; }

        
        [Display(Name = "Temporary Table Space")]
        public string TemporaryTableSpace { get; set; }

        
        [Display(Name = "Quota")]
        public string Quota { get; set; }

        
        [Display(Name = " On Table Space")]
        public string TableSpace { get; set; }

        
        [Display(Name = "Lock")]
        public bool AccountLock { get; set; }

      
        [Display(Name = "UnLock")]
        public bool AccountUnLock { get; set; }

        //profile
       
        [Display(Name = "Profiles Name")]
        public string ProfilesName { get; set; }

        [Display(Name = "Session Per User")]
        public string SessionPerUser { get; set; }


        [Display(Name = "Connect Time")]
        public string ConnectTime { get; set; }


        [Display(Name = "Idle Time")]
        public string IdleTime { get; set; }

        [Display(Name = "Fail To Login Attempts")]
        public string FailToLogin { get; set; }


        public List<string> listuser;

        
    }

    public class ManageUser
    {
        public Connection objConnect;
        public createCommand objCommand;
        public string DBSource;
        public string Username;
        public string Password;
        public OracleDataReader reader;


        // ham khoi tao doi tuong connect va command
        public ManageUser()
        {

            DBSource = "orcl";
            Username = "admin";
            Password = "admin";
        
        }
        public void Init()
        {
            objConnect = new Connection();
            objCommand = new createCommand();
            
        }

        public void Delete()
        {
            objConnect = null;
            objCommand = null;
        }

   

        // lay danh sach tat ca cac user.   
        public List<string> GetListAllUsers()
        {
            Init();
            List<string> listUsers = new List<string>();

            string query = "SELECT * FROM DBA_USERS";

            objConnect.connection2(DBSource,Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);

            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                listUsers.Add((string)reader[0]);
            }
            reader.Close();
            Delete();
            return listUsers;
        }

        //lay thong tin cua user
        public string GetQuota(string username)
        {
            Init();

            string quota=null;
            string query = "SELECT BYTES FROM dba_ts_quotas WHERE USERNAME='" + username.ToUpper() + "'";

            objConnect.connection2(DBSource,Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);

            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                quota = reader.GetValue(0).ToString();
             
            }
            reader.Close();
            Delete();
            return quota;
        }
        

        public UserInfomation GetListInfoUsers(string username)
        {
            Init();
            
            UserInfomation newuser = new UserInfomation();
            string query = "SELECT USERNAME,ACCOUNT_STATUS,LOCK_DATE,DEFAULT_TABLESPACE,TEMPORARY_TABLESPACE,CREATED  FROM DBA_USERS WHERE USERNAME='"+username.ToUpper()+"'";

            objConnect.connection2(DBSource,Username, Password );
            objCommand.createCmd(query, objConnect.connectOracle);

            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                newuser.username = reader.GetValue(0).ToString();
                newuser.Account_status = reader.GetValue(1).ToString();
                newuser.Lock_date = reader.GetValue(2).ToString();
                newuser.Default_tablespace = reader.GetValue(3).ToString();
                newuser.Temporary_tablespace = reader.GetValue(4).ToString();
                newuser.Created_date = reader.GetValue(5).ToString();
            }
            
            newuser.Quota = this.GetQuota(username);
            
            return newuser;
        }

        public bool DropUser(string userName)
        {
            Init();
            string query = "DROP USER " + userName.Trim().ToUpper()+" CASCADE";
            
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {//showmessage
             
                return false;
            }
            return true;
        }


        public bool EditUser(string userName, string newPassword, string newDefaultTableSpace, string newTemporaryTableSpace,string quota,string tablespace,bool locks,string profile)
        {
            Init();

            string query = "ALTER USER " + userName.ToUpper() ;

            if (newPassword != null)
            {
                query += " IDENTIFIED BY " + newPassword;
            }

            if (newDefaultTableSpace !=null)
            {
                query += " DEFAULT TABLESPACE " + newDefaultTableSpace;
            }
            if (newTemporaryTableSpace !=null)
            {
                query += " TEMPORARY TABLESPACE " + newTemporaryTableSpace;
            }
            if (quota !=null && tablespace !=null)
            {
                query += " QUOTA " + quota +"M ON "+ tablespace ;
            }
            if (locks == true)
            {
                query += " Account lock";
            }
            else
            {
                query += " Account unlock";
            }
            if (profile != null)
            {
                query += " PROFILE " + profile;
            }
        
            objConnect.connection(Username, Password, DBSource);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }


        public bool CreateUser(string userName, string password)
        {
            Init();
            string query = "CREATE USER " + userName.ToUpper() + " IDENTIFIED BY " + password;
            
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
            return true;
        }

        public bool GrantSessionUser(string userName)
        {
            string query = "GRANT CREATE SESSION TO " + userName.ToUpper();

            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {//show message
                return false;
            }
            return true;
        }
        

    }
}