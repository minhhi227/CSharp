﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssignementISS.Models
{
    public class HomeModelIndex
    {
        public bool logedOn { get; set; }
        public string UserName { get; set; }
    }
}