﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssignementISS.Models
{
    public class ObjPrivilege
    {
        public String privName;
        public bool grant_opt;
        public String OnObject;
        public String OnColumn;
        public bool assigned;
        public ObjPrivilege()
        {
            assigned = false;
        }
    }
}