﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using AssignementISS.Database;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Windows.Forms;


namespace AssignementISS.Models
{
    public class CreateProfile
    {

        [Display(Name = "Profile name")]
        public string ProfileName { get; set; }


        [Display(Name = "Session Per User")]
        public string SessionPerUser { get; set; }


        [Display(Name = "Connect Time")]
        public string ConnectTime { get; set; }


        [Display(Name = "Idle Time")]
        public string IdleTime { get; set; }


    }

    public class ModifyProfile
    {


        [Display(Name = "Profile Name")]
        public string ProfileName { get; set; }



        [Display(Name = "Session Per User")]
        public string SessionPerUser { get; set; }


        [Display(Name = "Connect Time")]
        public string ConnectTime { get; set; }


        [Display(Name = "Idle Time")]
        public string IdleTime { get; set; }

        public List<string> profile;


    }

    public class DropProfile
    {


        [Display(Name = "Profile Name")]
        public string ProfileName { get; set; }

        public List<string> profile;

    }

    //----------------------------------manage profile-----------------------------------------------
    public class ManageProfile
    {
        public Connection objConnect;
        public createCommand objCommand;
        public string DBSource;
        public string Username;
        public string Password;
        public OracleDataReader reader;

        public ManageProfile()
        {
              DBSource="orcl";
         Username="admin";
        Password="admin";
        }
        public void Init()
        {
            objConnect = new Connection();
            objCommand = new createCommand();

        }
        //select profiles
        public List<string> GetListAllProfiles()
        {
            Init();
            List<string> listProfiles = new List<string>();

            string query = "SELECT DISTINCT PROFILE FROM DBA_PROFILES order by PROFILE";

            objConnect.connection(DBSource,Username,Password);
            objCommand.createCmd(query, objConnect.connectOracle);

            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                listProfiles.Add((string)reader[0]);
            }

            return listProfiles;
        }
        //create profile
        public bool CreateProfile(string ProfileName, string SessionPerUser, string ConnectTime, string IdleTime)
        {
            Init();
            string query = "CREATE PROFILE " + ProfileName.ToUpper() + " LIMIT " +
                            "SESSIONS_PER_USER  " + SessionPerUser + " " +
                            "CONNECT_TIME  " + ConnectTime + " " +
                            "IDLE_TIME  " + IdleTime ;

            
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                
                return false;
            }
            return true;
        }

        //modify profile
        public bool EditProfile(string ProfileName, string SessionPerUser, string ConnectTime, string IdleTime)
        {
            Init();

            string query = "ALTER PROFILE " + ProfileName.ToUpper() + " LIMIT " +
                            "SESSIONS_PER_USER  " + SessionPerUser + " " +
                            "CONNECT_TIME  " + ConnectTime + " " +
                            "IDLE_TIME  " + IdleTime ;


            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
            return true;
        }
        //drop profile
        public bool DropProfile(string ProfileName)
        {
            Init();
            string query = "DROP PROFILE " + ProfileName.Trim().ToUpper();
            objConnect.connection(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);
            objCommand.command = new OracleCommand(query, objConnect.connectOracle);

            try
            {
                objCommand.command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                
                return false;
            }
            return true;
        }

        //------------------------------------------------------------------------------------
        public List<string> GetListAllProfilesForUser(string username)
        {
            Init();
            List<string> listProfiles = new List<string>();

            string query = "SELECT PROFILE FROM DBA_USERS WHERE USERNAME ='"+username.ToUpper()+"'";

            objConnect.connection2(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);

            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                listProfiles.Add((string)reader[0]);
            }

            return listProfiles;
        }

        public List<string> GetListResource(string profilename)
        {
            Init();
            List<string> listResource = new List<string>();

            string query = "SELECT RESOURCE_NAME FROM DBA_PROFILES WHERE PROFILE ='" + profilename.ToUpper() + "'";
            
            objConnect.connection2(DBSource, Username, Password);
            objCommand.createCmd(query, objConnect.connectOracle);

            reader = objCommand.command.ExecuteReader();
            while (reader.Read())
            {
                listResource.Add((string)reader[0]);
            }

            return listResource;
        }

    }
}