﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
//using System.Data.OracleClient;
using System.Text;
using System.Data;
using System.Security.Cryptography;
using System.Windows.Forms;


namespace AssignementISS.Database
{
    public class Connection
    {
        public OracleConnection connectOracle;

        public void connection(String databaseSource, String adminName, String adminpassword)
        {

            string strOracle = "Data Source=" + Program.databaseSource + ";User Id=" + Program.adminName + ";Password=" + Program.adminpassword;
            connectOracle = new OracleConnection(strOracle);
            connectOracle.Open();


        }

        public void connection2(String databaseSource, String adminName, String adminpassword)
        {

            string strOracle = "Data Source=" + databaseSource + ";User Id=" + adminName + ";Password=" + adminpassword;
            connectOracle = new OracleConnection(strOracle);
            connectOracle.Open();


        }
    }
    public class createCommand
    {
        public OracleCommand command;
        public void createCmd(string cmd, OracleConnection conn)
        {
            command = new OracleCommand(cmd, conn);
            command.CommandType = CommandType.Text;
        }
    }

       /* 
        public static OracleConnection ServerConnection;
        public static string Username = "";
        public static string Password = "";

        public bool conn(string user, string pass)
        {
            try{
            string ConnectionString = "data source=orcl;user id=" + user + " ;password=" + pass + " ; ";
            ServerConnection = new OracleConnection(ConnectionString);
            ServerConnection.Open();
            Username = user;
            Password = pass;
                return true;

            }
            catch(Exception ex){
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        
        public static void LogOff()
        {
            Connection.NoneQuery("disconnect");
            ServerConnection.Close();
            ServerConnection.Dispose();
            Username = "";
            Password = "";
        }

        public static bool NoneQuery(string sql)
        {
            OracleCommand cmd = new OracleCommand(sql);
            cmd.Connection = ServerConnection;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception )
            {
                return false;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public static OracleDataReader Query(string sql)
        {
            OracleCommand cmd = new OracleCommand(sql);
            cmd.Connection = ServerConnection;
            cmd.CommandType = CommandType.Text;
            try
            {
                OracleDataReader reader = cmd.ExecuteReader();
                return reader;
            }
            catch (Exception)
            {
               return null;
            }
            finally
            {
                cmd.Dispose();
            }
        }

        public static bool ChangePass(string newpass)
        {
            string cmd = "alter user " + Username + " identified by " + Encrypt(newpass);
            NoneQuery(cmd);
            Password = newpass;
            return true;
             
        }

        public static string Encrypt(string pass)
        {
            MD5CryptoServiceProvider myMD5 = new MD5CryptoServiceProvider();
            byte[] myPass = System.Text.Encoding.UTF8.GetBytes(pass);
            myPass = myMD5.ComputeHash(myPass);
            string s = "";
            foreach (byte p in myPass) s += p.ToString();
            s += "3";
            char[] list = s.ToCharArray();
            string r = "";
            for (int i = 0; i < s.Length - 1; i += 2)
            {
                int k;
                k = En(Convert.ToInt16(list[i] + "" + list[i + 1]) + 37);
                char c = (char)k;
                r += c;

            }
            return "p" + r;
        }

        public static int En(int k)
        {
            if (k < 48) return 51;
            if (k > 57 && k < 65) return En(k + 40);
            if (k > 90 && k < 97) return En(k + 20);
            if (k > 122) return 101;
            return k;
        }

        public static class CurrentUserConnection
        {
            public static List<Connection> UserConnection = new List<Connection>();
        }
        
    }*/

}