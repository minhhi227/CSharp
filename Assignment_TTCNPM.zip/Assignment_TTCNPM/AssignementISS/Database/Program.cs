﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssignementISS.Database
{
    static class Program
    {
        public static String adminName;
        public static String adminpassword;
        public static String databaseSource;
    }
}