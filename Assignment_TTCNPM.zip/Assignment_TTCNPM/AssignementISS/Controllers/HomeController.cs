﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignementISS.Models;
using AssignementISS.Database;

namespace AssignementISS.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(HomeModelIndex model)
        {
            if (Program.adminName == null || Program.adminName == "")
            {
                model.logedOn = false;
                return View(model);
            }
            else
            {
                model.UserName = Program.adminName;
                model.logedOn = true;
                return View(model);
            }
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
