﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignementISS.Models;
using AssignementISS.Database;
using System.Windows.Forms;

namespace AssignementISS.Controllers
{
    public class TablesController : Controller
    {
        //
        // GET: /Table/

        ManageProfile manageprofile = new ManageProfile();
        ManageRoles managerole = new ManageRoles();
        PrivilegesManager privilege = new PrivilegesManager();
        ManageUser manageuser = new ManageUser();
        ManageTable managetable = new ManageTable();

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult TableDelete(TableDelete tabdel, string button)
        {

            tabdel.schemalist = manageuser.GetListAllUsers();
            if (button == ">>")
            {
                tabdel.tablelist = privilege.SelectTableFromSchema(tabdel.Schema);
            }
            if (button == "Delete")
            {
                tabdel.tablelist = privilege.SelectTableFromSchema(tabdel.Schema);
                if (managetable.DeleteTable(tabdel.Schema, tabdel.TableName) == true)
                {
                    ViewBag.Message = "Deleting Table is successful";

                }
                else
                {
                    ViewBag.Message = "Deleting Table is fail";
                }
            }
            return View(tabdel);
        }
        public ActionResult TableSelect(TableSelect tabselect, string button)
        {
            tabselect.schemalist = manageuser.GetListAllUsers();
            if (button == ">>")
            {
                tabselect.tablelist = privilege.SelectTableFromSchema(tabselect.Schema);
            }
            if (button == "Show")
            {
                tabselect.tablelist = privilege.SelectTableFromSchema(tabselect.Schema);
                tabselect.col = privilege.SelectColumnForTable(tabselect.Schema, tabselect.TableName);
                tabselect.tables = managetable.SelectTable(tabselect.Schema, tabselect.TableName, tabselect.col.Count);

            }
            return View(tabselect);

        }
        public ActionResult TableUpdate(TableUpdate tabupdate, string button)
        {
            tabupdate.schemalist = manageuser.GetListAllUsers();
            if (button == ">>")
            {
                tabupdate.tablelist = privilege.SelectTableFromSchema(tabupdate.Schema);
            }
            if (button == "ShowCol")
            {
                tabupdate.tablelist = privilege.SelectTableFromSchema(tabupdate.Schema);
                tabupdate.col = privilege.SelectColumnForTable(tabupdate.Schema, tabupdate.TableName);
            }
            if (button == "ShowValue")
            {
                tabupdate.tablelist = privilege.SelectTableFromSchema(tabupdate.Schema);
                tabupdate.col = privilege.SelectColumnForTable(tabupdate.Schema, tabupdate.TableName);
                tabupdate.oldva = managetable.Selectcolvalue(tabupdate.Schema, tabupdate.TableName, tabupdate.Colname);
            }
            if (button == "Update")
            {
                tabupdate.tablelist = privilege.SelectTableFromSchema(tabupdate.Schema);
                tabupdate.col = privilege.SelectColumnForTable(tabupdate.Schema, tabupdate.TableName);
                tabupdate.oldva = managetable.Selectcolvalue(tabupdate.Schema, tabupdate.TableName, tabupdate.Colname);

                if (managetable.UpdateTable(tabupdate.Schema, tabupdate.TableName, tabupdate.giatrimoi, tabupdate.Colname, tabupdate.oldvalue) == true)
                {
                    ViewBag.Message = " Updating is successful!";
                }
                else
                {
                    ViewBag.Message = " Updating is fail!";
                }


            }
            return View(tabupdate);

        }
        public ActionResult TableInsert(TableInsert tabinsert, string button)
        {
            tabinsert.schemalist = manageuser.GetListAllUsers();
            if (button == ">>")
            {
                tabinsert.tablelist = privilege.SelectTableFromSchema(tabinsert.Schema);
            }
            if (button == "ShowCol")
            {
                tabinsert.tablelist = privilege.SelectTableFromSchema(tabinsert.Schema);
                tabinsert.col = privilege.SelectColumnForTable(tabinsert.Schema, tabinsert.TableName);
            }
            if (button == "Insert")
            {
                if (managetable.InsertTable(tabinsert.Schema,tabinsert.TableName,tabinsert.newvalue) == true)
                {
                    ViewBag.Message = "Inserting is successful";
                }
                else
                {
                    ViewBag.Message = "Inserting is fail";
                }

            }


            return View(tabinsert);
        }
        public ActionResult TableCreate(TableCreate tabcreate, string button)
        {
            tabcreate.schemalist = manageuser.GetListAllUsers();

            if (button == "Create")
            {
                if (tabcreate.TableName == null)
                {
                    ViewBag.Message = "Table Name cannot null!";
                    return View(tabcreate);
                }
                int socot = 0;
                for (int i = 0; i < tabcreate.ColumnName.Count; i++)
                {
                    if (tabcreate.ColumnName[i].CompareTo("")==1) { socot++; }
                    
                }
                
                if (socot == 0)
                {
                    ViewBag.Message = "Please write data on field";
                    return View(tabcreate);
                }
                List<string> allnull = new List<string>();
                for (int i = 0; i < tabcreate.ColumnName.Count; i++)
                {
                    if (tabcreate.AllowNull[i] == false) allnull.Add("NOT NULL");
                    else
                    {
                        allnull.Add(" ");
                    }
                }


                if (managetable.CreateTable(tabcreate.TableName, tabcreate.Schema, tabcreate.ColumnName, tabcreate.type, tabcreate.Length, allnull, socot) == true)
                {
                    ViewBag.Message = "creating is successful";
                }
                else
                {
                    ViewBag.Message = "creating is fail";
                }


            }
            return View(tabcreate);

        }

    }
}
