﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignementISS.Models;
using AssignementISS.Database;
using System.Windows.Forms;


namespace AssignementISS.Controllers
{
    public class RolesController : Controller
    {
        PrivilegesManager privileges = new PrivilegesManager();
        MangeRoles roles = new MangeRoles();
        Connection connect = new Connection();
        ManageUser users = new ManageUser();
        ManageRoles rolehieu = new ManageRoles();
        //
        // GET: /Roles/

        public ActionResult Index()
        {
            return View();
        }

        

        public List<string> obj(List<ObjPrivilege> objprivs, string pri_name)
        {
            List<string> result = null;
            foreach (var i in objprivs)
            {
                if (i.privName == pri_name) result.Add(i.OnObject);
            }
            return result;
        }

        public ActionResult AddRoles(CreateRoles createRoleModel,string button,LogOnModel logon)
        {
            createRoleModel.SystemPrivileges = privileges.SelectSysPrivsForUser(Program.adminName);
            createRoleModel.ObjectPrivileges = privileges.SelectObjPrivsForUser(Program.adminName);
            createRoleModel.list_user = privileges.GetListAllUsers();
            //COLUMN LISTBOX
            //createRoleModel.col = privileges.SelectColumnForTable(createRoleModel.Objectname );

            //admin option
            string adminopt = null;
            if (createRoleModel.AddminOption == true) adminopt = " with admin option ";

            createRoleModel.listSchema = users.GetListAllUsers();
            if (button == ">>")
            {
                createRoleModel.obj = privileges.SelectTableFromSchema(createRoleModel.Schema);
            }

            if (button == "Create Role")
            {
                int i = 0;
                string ad_opt;
                roles.CreateRole(createRoleModel.RoleName, createRoleModel.RolePassword, createRoleModel.NoPassword);
                foreach (var pri in createRoleModel.SystemPrivileges)
                {

                    if (createRoleModel.select_pri[i] == true)
                    {
                        if (createRoleModel.admin_option[i] == true)
                        {
                            ad_opt = " with admin option ;";
                        }
                        else ad_opt = null;

                        if (roles.GrantSysPrivToRole(createRoleModel.RoleName, pri.privName, ad_opt) == true)
                        {
                            ViewBag.Message = " Granting is successful";
                        }
                        else
                        {
                            ViewBag.Message = " Granting is fail";
                        }

                        pri.assigned = true;
                    }
                    i++;
                }

                if (createRoleModel.grantobj == true)
                {

                    if (roles.GrantObjPrivToRole(createRoleModel.RoleName, createRoleModel.ObjPrivileges, createRoleModel.Columnname, createRoleModel.Objectname, adminopt) == true)
                    {
                        ViewBag.Message = " Granting is successful";
                    }
                    else
                    {
                        ViewBag.Message = " Granting is fail";
                    }
                }

            }

            return View(createRoleModel);
        }


        public ActionResult AlterRoles(AlterRoles model,string button)
        {
            model.RolesList = rolehieu.selectRoleForUser(Program.adminName);
            if (button == ">>")
            {
                model.SystemPrivs = privileges.SelectSysPrivsForRole2(model.RoleName);
                model.ObjectPrivs = privileges.SelectObjPrivsForRole2(model.RoleName);
            }
            if (button == "Alter SysRole")
            {
                model.SystemPrivs = privileges.SelectSysPrivsForRole2(model.RoleName);
                
                int i = 0;
                foreach (var pri in model.SystemPrivs)
                {

                    if (model.select_sys[i] == true)
                    {
                      
                        if (rolehieu.revokePrivFromRole(model.RoleName,pri.privName) == true)
                        {
                            ViewBag.Message = "Revoking is successful";
                        }
                        else
                        {
                            ViewBag.Message = "Revoking is fail";
                        }

                    }
                    i++;
                }
            }
            if (button == "Alter ObjRole")
            {
                model.ObjectPrivs = privileges.SelectObjPrivsForRole2(model.RoleName);
                int i = 0;
                foreach (var pri in model.ObjectPrivs)
                {

                    if (model.select_obj[i] == true)
                    {
                        string privi = pri.privName + " ON " + pri.OnObject;
                        if (rolehieu.revokePrivFromRole(model.RoleName, pri.privName) == true)
                        {
                            ViewBag.Message = "Revoking is successful";
                        }
                        else
                        {
                            ViewBag.Message = "Revoking is fail";
                        }

                    }
                    i++;
                }
            }
            return View(model);
        }

      
        public ActionResult GrantRoles(GrantRoles model,string button)
        {
            model.list_user = privileges.GetListAllUsers();
            model.RolesList = roles.GetAllRolesName(Program.adminName);
            if (button == "Grant To User")
            {
                string ad_opt;
                if (model.AdminOptUser == true)
                {
                    ad_opt = " with admin option";
                }
                else ad_opt = null;
                if (roles.GrantRole(model.RoleNameGrantToUser,model.UserNameRev, ad_opt) == true)
                {
                    ViewBag.Message = " Granting "+ model.RoleNameGrantToUser+ " to " + model.UserNameRev + " is successful";
                }
                else
                {
                    ViewBag.Message = " Granting is fail";
                }
            }
            else if (button == "Grant To Role")
            {
                string ad_opt;
                if (model.AdminOptRole == true)
                {
                    ad_opt = " with admin option";
                }
                else ad_opt = null;
                if (roles.GrantRole(model.RoleNameGrantToRole, model.RoleNameRev, ad_opt) == true)
                {
                    ViewBag.Message = " Granting " + model.RoleNameGrantToRole + " to " + model.RoleNameRev + " is successful";
                }
                else
                {
                    ViewBag.Message = " Granting is failed";
                }

            }
            return View(model);
        }
        public ActionResult DropRoles(DropRoles model,string button)
        {
            model.ListRole = roles.GetAllRolesName(Program.adminName);
            if (button == "Drop")
            {
                if (roles.DropRole(model.RoleName) == true)
                {
                    ViewBag.Message = "Drop role " + model.RoleName + " is successful !";
                }
                else
                {
                    ViewBag.Message = "Drop role " + model.RoleName + " is failed !";
                }

            }
            return View(model);
        }

 

        
    }
}
