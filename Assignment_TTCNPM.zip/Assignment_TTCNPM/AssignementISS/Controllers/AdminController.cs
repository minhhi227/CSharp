﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignementISS.Database;

namespace AssignementISS.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/

        public ActionResult Index()
        {
            if (Program.adminName == null || Program.adminName == "")
                return RedirectToAction("NotLogOn");
            else
            {
                ViewBag.Message = Program.adminName;
                return View();
            }
        }

        public ActionResult NotLogOn()
        {

            return View();
        }
    }
}
