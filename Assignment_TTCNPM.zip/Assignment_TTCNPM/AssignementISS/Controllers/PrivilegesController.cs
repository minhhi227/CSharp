﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignementISS.Models;
using AssignementISS.Database;
using System.Windows.Forms;
namespace AssignementISS.Controllers
{
    public class PrivilegesController : Controller
    {
        //
        // GET: /Privileges/

        PrivilegesManager privileges = new PrivilegesManager();
        Connection connect = new Connection();
        ManageUser user = new ManageUser();


        //
        // GET: /Privileges/
        //----------show privileges-------------------------

        public ActionResult Index()
        {

            return View();
        }

        public ActionResult ShowSysPrivileges(ShowPrivileges privs,string button)
        {
            privs.listuser = user.GetListAllUsers();
            if(button=="Show"){
            
            privs.SystemPrivileges = privileges.SelectSysPrivsForUser(privs.username);
            }
            //privs.SystemPrivileges = privileges.selectAllPrivs();
            return View(privs);

        }

        public ActionResult ShowObjPrivileges(ShowPrivileges privs,string button)
        {
            privs.listuser = user.GetListAllUsers();
            if (button == "Show")
            {
                privs.ObjectPrivileges = privileges.SelectObjPrivsForUser(privs.username);
            }
            return View(privs);

        }
        //-------------------grant privileges------------------------------

        public ActionResult GrantSysPrivileges(GrantPrivileges privs, string button)
        {
            privs.SystemPrivileges = privileges.SelectSysPrivsForUser(Program.adminName);
            //privs.SystemPrivileges = privileges.selectAllPrivs();
            privs.listuser = user.GetListAllUsers();
            int i = 0;
            string ad_opt;
            if (button == "Grant")
            {

                foreach (var pri in privs.SystemPrivileges)
                {

                    if (privs.select_pri[i] == true)
                    {
                        if (privs.admin_option[i] == true)
                        {
                            ad_opt = " with admin option ;";
                        }
                        else ad_opt = null;

                        if (privileges.GrantSysPrivToUser(privs.Username, pri.privName, ad_opt) == true)
                        {
                            ViewBag.Message = " Granting is successful";
                        }
                        else
                        {
                            ViewBag.Message = " Granting is fail";
                        }

                        
                    }
                    i++;
                }

            }


            return View(privs);
        }

      

        public ActionResult GrantObjPrivileges(GrantPrivileges privs, string button)
        {

            privs.listschema = user.GetListAllUsers();
            privs.listuser = privs.listschema;
            if (button == "On")
            {
                    privs.obj = privileges.SelectTableFromSchema(privs.Schema);
                
            }
            if (button == ">>")
            {
                    privs.obj = privileges.SelectTableFromSchema(privs.Schema);
                    privs.col = privileges.SelectColumnForTable(privs.Schema, privs.Objectname);
                    return View(privs);
            }
           
            string grantopt = null;
            if (privs.Grant_opt == true) grantopt = " with grant option ";

            if (button == "Grant")
            {
                string priv = null;
                if (privs.Columnname != null)
                {
                     priv = privs.ObjectPrivileges + " (" + privs.Columnname + ") " + " ON " + privs.Schema + "." + privs.Objectname + " ";
                }
                else

                {
                    priv = privs.ObjectPrivileges + " ON " + privs.Schema + "." + privs.Objectname + " ";
                }
                if (privileges.GrantSysPrivToUser(privs.Username, priv, grantopt) == true)
                {
                    ViewBag.Message = " Granting is successful";
                }
                else
                {
                    ViewBag.Message = " Granting is fail";
                }
            }
            
            return View(privs);

        }
        //--------------------------revoke privileges-------------------------

        public ActionResult RevokeSysPrivileges(RevokePrivileges revoke, string button)
        {
            
            //revoke.SystemPrivileges = privileges.selectAllPrivs();
            revoke.listuser = user.GetListAllUsers();
            if (button==">>")
            {
                revoke.SystemPrivileges = privileges.SelectSysPrivsForUser(revoke.username);
            }
            int i = 0;
            if (button == "Revoke")
            {
                revoke.SystemPrivileges = privileges.SelectSysPrivsForUser(revoke.username);
               
                foreach (var pri in revoke.SystemPrivileges)
                {
                    if (revoke.select_pri[i] == true)
                    {

                        if (privileges.RevokeSysPrivFromUser(revoke.username, pri.privName) == true)
                        {
                            ViewBag.Message = " Revoking is successful";
                        }
                        else
                        {
                            ViewBag.Message = " Revoking is fail";
                        }
                        pri.assigned = false;
                    }
                    i++;
                }

            }


            return View(revoke);

        }

        public ActionResult RevokeObjPrivileges(RevokePrivileges privs, string button)
        {
            privs.listuser = user.GetListAllUsers();
            if (button==">>")
            {
                privs.obj = privileges.SelectTableFromSchema(privs.username);
            }
            //select * from dba_col_privs
            //select * from user_tab_privs
            if (button == "Revoke")
            {
                string privilege = privs.ObjectPrivileges + " ON " + privs.username+"."+ privs.Objectname + " ";
                if (privileges.RevokeSysPrivFromUser(privs.revokeuser, privilege) == true)
                {
                    ViewBag.Message = " Revoking is successful";
                }
                else
                {
                    ViewBag.Message = " Revoking  is fail";
                }
            }

            return View(privs);


        }

    }
}
