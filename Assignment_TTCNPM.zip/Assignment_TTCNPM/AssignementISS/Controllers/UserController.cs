﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignementISS.Models;
using AssignementISS.Database;

namespace AssignementISS.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/

        ManageUser user = new ManageUser();
        ManageProfile pro = new ManageProfile();

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ShowUser(ShowUser showuser,string button)
        {
            showuser.listuser = user.GetListAllUsers();
            if (button == "ShowInfo")
            {
                showuser.user = user.GetListInfoUsers(showuser.UserName);
            }

            return View(showuser);
        }
        
 
        public ActionResult CreateUser(CreateUser newuser,string button)
        {

            if (button == "Create")
            {
                if (user.CreateUser(newuser.UserName,newuser.Password) == true)
                {
                    if (newuser.connect == true) user.GrantSessionUser(newuser.UserName);
                    ViewBag.Message = "Create Successful !";
                }
                else
                {
                    ViewBag.Message = "Create Fail !";
                }

            }
            return View(newuser);
        }


        public ActionResult AlterUser(AlterUser useralter,string button)
        {
            bool locks = false;
            useralter.listuser = user.GetListAllUsers();
            if (button == "Alter")
            {
                if (useralter.AccountLock == true && useralter.AccountUnLock == false)
                {
                    locks = true;
                }
                else if (useralter.AccountLock == false && useralter.AccountUnLock == true || useralter.AccountLock == false && useralter.AccountUnLock == false)
                {
                    locks = false;
                }
                else
                {
                    ViewBag.Message = " can not check both lock & unlock"; return View(useralter);
                }

                if (useralter.ProfilesName != null)
                {
                    pro.CreateProfile(useralter.ProfilesName, useralter.SessionPerUser, useralter.ConnectTime, useralter.IdleTime);
                }

                if (user.EditUser(useralter.UserName,useralter.Password,useralter.DefaultTableSpace,useralter.TemporaryTableSpace,useralter.Quota,useralter.TableSpace,locks,useralter.ProfilesName) == true)
                {
                    
                    ViewBag.Message = "Alter Successful !";
                }
                else
                {
                    ViewBag.Message = "Alter Fail !";
                }
            }
            return View(useralter);
        }

        public ActionResult DropUser(DropUser userdrop,string button)
        {
            userdrop.listuser = user.GetListAllUsers();
            if (button == "Drop")
            {
                if (user.DropUser(userdrop.UserName) == true)
                {
                    ViewBag.Message = "Drop Successful !";
                }
                else
                {
                    ViewBag.Message = "Drop Fail !";
                }
            }
            return View(userdrop);
        }

        


    }
}
