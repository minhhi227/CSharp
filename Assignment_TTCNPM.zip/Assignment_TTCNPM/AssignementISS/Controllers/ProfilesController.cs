﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignementISS.Models;
using AssignementISS.Database;
using System.Windows.Forms;


namespace AssignementISS.Controllers
{
    public class ProfilesController : Controller
    {
        //
        // GET: /Profiles/
        ManageProfile manage_profile = new ManageProfile();

        public ActionResult Index()
        {
            return View();
        }


        public ActionResult CreateProfiles(CreateProfile profile, string button)
        {

            if (button == "Create")
            {

                
                if (manage_profile.CreateProfile(profile.ProfileName, profile.SessionPerUser, profile.ConnectTime, profile.IdleTime) == true)
                {
                    ViewBag.Message = "Creating profile is successful";
                }
                else
                {
                    ViewBag.Message = "Profile wasn't created in this schema ";
                }
            }


            return View(profile);

        }

        public ActionResult ModifyProfiles(ModifyProfile modify_profile, string button)
        {
            modify_profile.profile = manage_profile.GetListAllProfiles();

            if (button == "Modify")
            {
                if (manage_profile.EditProfile(modify_profile.ProfileName, modify_profile.SessionPerUser, modify_profile.ConnectTime, modify_profile.IdleTime) == true)
                {
                    ViewBag.Message = "Modifying profile is successful";
                }
                else
                {
                    ViewBag.Message = "Profile wasn't modified in this schema";
                }

            }

            return View(modify_profile);

        }

        public ActionResult DropProfiles(DropProfile drop_profile, string button)
        {
            drop_profile.profile = manage_profile.GetListAllProfiles();

            if (button == "Drop")
            {
                if (manage_profile.DropProfile(drop_profile.ProfileName) == true)
                {
                    ViewBag.Message = "Dropping profile is successful";
                }
                else
                {
                    ViewBag.Message = "Profile wasn't droped in this schema";
                }
            }

            return View(drop_profile);

        }


    }
}
