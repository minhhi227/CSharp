﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AssignementISS.Models;
using AssignementISS.Database;
using System.Windows.Forms;

namespace AssignementISS.Controllers
{
    public class NormalUserController : Controller
    {
        //
        // GET: /NormalUser/
        ManageProfile manageprofile = new ManageProfile();
        ManageRoles managerole = new ManageRoles();
        PrivilegesManager privilege = new PrivilegesManager();
        ManageUser user = new ManageUser();
        ManageTable managetable = new ManageTable();
        
        public ActionResult  Index()
        {
            if (Program.adminName == null || Program.adminName == "")
                return RedirectToAction("NotLogOn");

            else return View();
        }

        public ActionResult NotLogOn()
        {

            return View();
        }
        public ActionResult PrivilegeGrant(PrivilegeGrant privs,string button)
        {
            privs.SystemPrivileges = privilege.SelectSysPrivsForUser(Program.adminName);
            privs.listuser = user.GetListAllUsers();
            privs.tablelist = privilege.SelectTableFromSchema(Program.adminName);
            int i = 0;
            string ad_opt;
            if (button == "Grant SysPri")
            {

                foreach (var pri in privs.SystemPrivileges)
                {

                    if (privs.select_pri[i] == true)
                    {
                        if (privs.admin_option[i] == true)
                        {
                            ad_opt = " with admin option ";
                        }
                        else ad_opt = null;

                        if (privilege.GrantSysPrivToUser(privs.Username, pri.privName, ad_opt) == true)
                        {
                            ViewBag.Message = " Granting is successful";
                        }
                        else
                        {
                            ViewBag.Message = " Granting is fail";
                        }

                        
                    }
                    i++;
                }

            }

            if (button == "Grant ObjPri")
            {
                if (privs.grant_opt == true)
                {
                    ad_opt = " with grant option ";
                }
                else ad_opt = null;

                
                if (privs.Select == true)
                {
                    string privle = "SELECT ON " + privs.TableName;
                    if (privilege.GrantSysPrivToUser(privs.userNameobj, privle, ad_opt) == true)
                    {
                        ViewBag.Message = " Granting is successful";
                    }
                    else
                    {
                        ViewBag.Message = " Granting is fail";
                    }
                }

                if (privs.delete == true)
                {
                    string privle = "DELETE ON " + privs.TableName;
                    if (privilege.GrantSysPrivToUser(privs.userNameobj, privle, ad_opt) == true)
                    {
                        ViewBag.Message = " Granting is successful";
                    }
                    else
                    {
                        ViewBag.Message = " Granting is fail";
                    }
                }

                if (privs.insert == true)
                {
                    string privle = "INSERT ON " + privs.TableName;
                    if (privilege.GrantSysPrivToUser(privs.userNameobj, privle, ad_opt) == true)
                    {
                        ViewBag.Message = " Granting is successful";
                    }
                    else
                    {
                        ViewBag.Message = " Granting is fail";
                    }
                }
                

            }

            return View(privs);
        }

        public ActionResult PrivilegeView(PrivilegeView pri)
        {
            
            pri.SystemPrivileges = privilege.SelectSysPrivsForUser(Program.adminName);
            pri.ObjectPrivileges = privilege.SelectObjPrivsForUser(Program.adminName);
            return View(pri);
        }
        
        public ActionResult RoleGrant(RoleGrant rolegrant,string button)
        {
            rolegrant.Rolelist = managerole.selectRoleForUser(Program.adminName);
            rolegrant.userlist = user.GetListAllUsers();
            if (button == "Grant")
            {
                if (managerole.grantRole(rolegrant.RoleName,rolegrant.userName)==true)
                {
                    ViewBag.Message = " Granting is successful";
                }
                else
                {
                    ViewBag.Message = " Granting is fail";
                }
            }
            return View(rolegrant);
        }

        public ActionResult RoleView(RoleView role,string button)
        {
            
            role.Roleli = managerole.selectRoleForUser(Program.adminName);
            if (button==">>")
            {
                if (role.RoleName != null)
                {
                    role.Privilegelist = privilege.SelectSysPrivsForRole(role.RoleName);
                }
                else
                {
                    ViewBag.Message = " Must select rolename";
                }
            }
           

            return View(role);
        }
        public ActionResult TableCreate(TableCreate tabcreate, string button)
        {
            tabcreate.schemalist = user.GetListAllUsers();

            if (button == "Create")
            {
                if (tabcreate.TableName == null)
                {
                    ViewBag.Message = "Table Name cannot null!";
                    return View(tabcreate);
                }
                int socot = 0;
                for (int i = 0; i < tabcreate.ColumnName.Count; i++)
                {
                    if (tabcreate.ColumnName[i].CompareTo("")==1) { socot++; }
                    
                }
               
                if (socot == 0)
                {
                    ViewBag.Message = "Please write data on field";
                    return View(tabcreate);
                }
                List<string> allnull = new List<string>();
                for (int i = 0; i < tabcreate.ColumnName.Count; i++)
                {
                    if (tabcreate.AllowNull[i] == false) allnull.Add("NOT NULL");
                    else
                    {
                        allnull.Add(" ");
                    }
                }


                if (managetable.CreateTable(tabcreate.TableName, tabcreate.Schema, tabcreate.ColumnName, tabcreate.type, tabcreate.Length, allnull, socot) == true)
                {
                    ViewBag.Message = "creating is successful";
                }
                else
                {
                    ViewBag.Message = "creating is fail";
                }


            }
            return View(tabcreate);

        }
        public ActionResult TableDrop(TableDelete tabdel, string button)
        {

            tabdel.schemalist = user.GetListAllUsers();
            if (button == ">>")
            {
                tabdel.tablelist = privilege.SelectTableFromSchema(tabdel.Schema);
            }
            if (button == "Delete")
            {
                tabdel.tablelist = privilege.SelectTableFromSchema(tabdel.Schema);
                if (managetable.DeleteTable(tabdel.Schema, tabdel.TableName) == true)
                {
                    ViewBag.Message = "Deleting Table is successful";

                }
                else
                {
                    ViewBag.Message = "Deleting Table is fail";
                }
            }
            return View(tabdel);
        }
        public ActionResult TableView(TableSelect tabselect, string button)
        {
            tabselect.schemalist = user.GetListAllUsers();
            if (button == ">>")
            {
                tabselect.tablelist = privilege.SelectTableFromSchema(tabselect.Schema);
            }
            if (button == "Show")
            {
                tabselect.tablelist = privilege.SelectTableFromSchema(tabselect.Schema);
                tabselect.col = privilege.SelectColumnForTable(tabselect.Schema, tabselect.TableName);
                tabselect.tables = managetable.SelectTable(tabselect.Schema, tabselect.TableName, tabselect.col.Count);

            }
            return View(tabselect);

        }

        public ActionResult Profile(Profile profile,string button)
        {
            profile.profile = manageprofile.GetListAllProfilesForUser(Program.adminName);
            if (button== ">>" )
            {
                profile.resource = manageprofile.GetListResource(profile.ProfileName);
            }
            return View(profile);
        }
        public ActionResult UserInfo(UserInfo userinfo)
        {
            userinfo.user = user.GetListInfoUsers(Program.adminName);
            return View(userinfo);
        }

        public ActionResult TableInsert(TableInsert tabinsert, string button)
        {
            tabinsert.schemalist = user.GetListAllUsers();
            if (button == ">>")
            {
                tabinsert.tablelist = privilege.SelectTableFromSchema(tabinsert.Schema);
            }
            if (button == "ShowCol")
            {
                tabinsert.tablelist = privilege.SelectTableFromSchema(tabinsert.Schema);
                tabinsert.col = privilege.SelectColumnForTable(tabinsert.Schema, tabinsert.TableName);
            }
            if (button == "Insert")
            {
                if (managetable.InsertTable(tabinsert.Schema, tabinsert.TableName, tabinsert.newvalue) == true)
                {
                    ViewBag.Message = "Inserting is successful";
                }
                else
                {
                    ViewBag.Message = "Inserting is fail";
                }

            }


            return View(tabinsert);
        }

    }
}
